DROP TABLE IF EXISTS `revsliderpatch_blacklist`;

CREATE TABLE `revsliderpatch_blacklist` (
  `ID` int(11) NOT NULL,
  `IP` text NOT NULL,
  `date` text NOT NULL,
  `exploit` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `revsliderpatch_blacklist` VALUES("0","87.68.43.158","1433227681","Arbitrary File Upload");


DROP TABLE IF EXISTS `wp_aiowps_events`;

CREATE TABLE `wp_aiowps_events` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `event_type` varchar(150) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `username` varchar(150) COLLATE utf8_unicode_ci DEFAULT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `event_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `ip_or_host` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `referer_info` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `url` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `event_data` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



DROP TABLE IF EXISTS `wp_aiowps_failed_logins`;

CREATE TABLE `wp_aiowps_failed_logins` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `user_login` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `failed_login_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `login_attempt_ip` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



DROP TABLE IF EXISTS `wp_aiowps_global_meta`;

CREATE TABLE `wp_aiowps_global_meta` (
  `meta_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `date_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `meta_key1` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `meta_key2` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `meta_key3` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `meta_key4` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `meta_key5` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `meta_value1` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `meta_value2` text COLLATE utf8_unicode_ci NOT NULL,
  `meta_value3` text COLLATE utf8_unicode_ci NOT NULL,
  `meta_value4` longtext COLLATE utf8_unicode_ci NOT NULL,
  `meta_value5` longtext COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`meta_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



DROP TABLE IF EXISTS `wp_aiowps_login_activity`;

CREATE TABLE `wp_aiowps_login_activity` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `user_login` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `login_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `logout_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `login_ip` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `login_country` varchar(150) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `browser_type` varchar(150) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



DROP TABLE IF EXISTS `wp_aiowps_login_lockdown`;

CREATE TABLE `wp_aiowps_login_lockdown` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `user_login` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `lockdown_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `release_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `failed_login_ip` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `lock_reason` varchar(128) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `unlock_key` varchar(128) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



DROP TABLE IF EXISTS `wp_commentmeta`;

CREATE TABLE `wp_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



DROP TABLE IF EXISTS `wp_comments`;

CREATE TABLE `wp_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext COLLATE utf8_unicode_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8_unicode_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10))
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



DROP TABLE IF EXISTS `wp_links`;

CREATE TABLE `wp_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



DROP TABLE IF EXISTS `wp_options`;

CREATE TABLE `wp_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(64) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `option_value` longtext COLLATE utf8_unicode_ci NOT NULL,
  `autoload` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`),
  KEY `wpe_autoload_options_index` (`autoload`)
) ENGINE=InnoDB AUTO_INCREMENT=13402 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `wp_options` VALUES("1","siteurl","http://ioptima.co.il","yes");
INSERT INTO `wp_options` VALUES("2","blogname","IOPtima - CO2 Laser Assisted Glaucoma  Surgery","yes");
INSERT INTO `wp_options` VALUES("3","blogdescription","CO2 Laser Assisted Glaucoma  Surgery","yes");
INSERT INTO `wp_options` VALUES("4","users_can_register","0","yes");
INSERT INTO `wp_options` VALUES("5","admin_email","info@ioptima.co.il","yes");
INSERT INTO `wp_options` VALUES("6","start_of_week","1","yes");
INSERT INTO `wp_options` VALUES("7","use_balanceTags","0","yes");
INSERT INTO `wp_options` VALUES("8","use_smilies","1","yes");
INSERT INTO `wp_options` VALUES("9","require_name_email","1","yes");
INSERT INTO `wp_options` VALUES("10","comments_notify","","yes");
INSERT INTO `wp_options` VALUES("11","posts_per_rss","10","yes");
INSERT INTO `wp_options` VALUES("12","rss_use_excerpt","0","yes");
INSERT INTO `wp_options` VALUES("13","mailserver_url","mail.example.com","yes");
INSERT INTO `wp_options` VALUES("14","mailserver_login","login@example.com","yes");
INSERT INTO `wp_options` VALUES("15","mailserver_pass","password","yes");
INSERT INTO `wp_options` VALUES("16","mailserver_port","110","yes");
INSERT INTO `wp_options` VALUES("17","default_category","1","yes");
INSERT INTO `wp_options` VALUES("18","default_comment_status","closed","yes");
INSERT INTO `wp_options` VALUES("19","default_ping_status","open","yes");
INSERT INTO `wp_options` VALUES("20","default_pingback_flag","","yes");
INSERT INTO `wp_options` VALUES("21","posts_per_page","10","yes");
INSERT INTO `wp_options` VALUES("22","date_format","F j, Y","yes");
INSERT INTO `wp_options` VALUES("23","time_format","g:i a","yes");
INSERT INTO `wp_options` VALUES("24","links_updated_date_format","F j, Y g:i a","yes");
INSERT INTO `wp_options` VALUES("28","comment_moderation","","yes");
INSERT INTO `wp_options` VALUES("29","moderation_notify","","yes");
INSERT INTO `wp_options` VALUES("30","permalink_structure","/%postname%/","yes");
INSERT INTO `wp_options` VALUES("31","gzipcompression","0","yes");
INSERT INTO `wp_options` VALUES("32","hack_file","0","yes");
INSERT INTO `wp_options` VALUES("33","blog_charset","UTF-8","yes");
INSERT INTO `wp_options` VALUES("34","moderation_keys","","no");
INSERT INTO `wp_options` VALUES("35","active_plugins","a:15:{i:0;s:53:\"adaptive-options-framework-import-export/function.php\";i:1;s:43:\"adaptive-shortcodes/adaptive-shortcodes.php\";i:2;s:35:\"admin-menu-tree-page-view/index.php\";i:3;s:51:\"all-in-one-wp-security-and-firewall/wp-security.php\";i:4;s:37:\"breadcrumb-navxt/breadcrumb-navxt.php\";i:5;s:36:\"contact-form-7/wp-contact-form-7.php\";i:6;s:33:\"custom-favicon/custom-favicon.php\";i:7;s:37:\"disable-comments/disable-comments.php\";i:8;s:27:\"js_composer/js_composer.php\";i:9;s:39:\"options-framework/options-framework.php\";i:10;s:47:\"really-simple-captcha/really-simple-captcha.php\";i:11;s:23:\"revslider/revslider.php\";i:12;s:24:\"simple-lightbox/main.php\";i:13;s:27:\"woosidebars/woosidebars.php\";i:14;s:24:\"wordpress-seo/wp-seo.php\";}","yes");
INSERT INTO `wp_options` VALUES("36","home","http://ioptima.co.il","yes");
INSERT INTO `wp_options` VALUES("37","category_base","","yes");
INSERT INTO `wp_options` VALUES("38","ping_sites","http://rpc.pingomatic.com/","yes");
INSERT INTO `wp_options` VALUES("39","advanced_edit","0","yes");
INSERT INTO `wp_options` VALUES("40","comment_max_links","2","yes");
INSERT INTO `wp_options` VALUES("41","gmt_offset","0","yes");
INSERT INTO `wp_options` VALUES("42","default_email_category","1","yes");
INSERT INTO `wp_options` VALUES("43","recently_edited","a:5:{i:0;s:96:\"/nas/wp/www/cluster-10191/ioptima/wp-content/plugins/revslider/inc_php/revslider_slide.class.php\";i:1;s:78:\"/nas/wp/www/cluster-10191/ioptima/wp-content/plugins/revslider/release_log.txt\";i:2;s:76:\"/nas/wp/www/cluster-10191/ioptima/wp-content/plugins/revslider/revslider.php\";i:3;s:106:\"/nas/wp/www/cluster-10191/ioptima/wp-content/plugins/adaptive-options-framework-import-export/function.php\";i:4;s:71:\"/nas/wp/www/cluster-10191/ioptima/wp-content/themes/twish/functions.php\";}","no");
INSERT INTO `wp_options` VALUES("44","template","twish","yes");
INSERT INTO `wp_options` VALUES("45","stylesheet","twish","yes");
INSERT INTO `wp_options` VALUES("46","comment_whitelist","1","yes");
INSERT INTO `wp_options` VALUES("47","blacklist_keys","","no");
INSERT INTO `wp_options` VALUES("48","comment_registration","","yes");
INSERT INTO `wp_options` VALUES("49","html_type","text/html","yes");
INSERT INTO `wp_options` VALUES("50","use_trackback","0","yes");
INSERT INTO `wp_options` VALUES("51","default_role","subscriber","yes");
INSERT INTO `wp_options` VALUES("52","db_version","31535","yes");
INSERT INTO `wp_options` VALUES("53","uploads_use_yearmonth_folders","1","yes");
INSERT INTO `wp_options` VALUES("54","upload_path","","yes");
INSERT INTO `wp_options` VALUES("55","blog_public","1","yes");
INSERT INTO `wp_options` VALUES("56","default_link_category","2","yes");
INSERT INTO `wp_options` VALUES("57","show_on_front","page","yes");
INSERT INTO `wp_options` VALUES("58","tag_base","","yes");
INSERT INTO `wp_options` VALUES("59","show_avatars","1","yes");
INSERT INTO `wp_options` VALUES("60","avatar_rating","G","yes");
INSERT INTO `wp_options` VALUES("61","upload_url_path","","yes");
INSERT INTO `wp_options` VALUES("62","thumbnail_size_w","150","yes");
INSERT INTO `wp_options` VALUES("63","thumbnail_size_h","150","yes");
INSERT INTO `wp_options` VALUES("64","thumbnail_crop","1","yes");
INSERT INTO `wp_options` VALUES("65","medium_size_w","300","yes");
INSERT INTO `wp_options` VALUES("66","medium_size_h","300","yes");
INSERT INTO `wp_options` VALUES("67","avatar_default","mystery","yes");
INSERT INTO `wp_options` VALUES("68","large_size_w","1024","yes");
INSERT INTO `wp_options` VALUES("69","large_size_h","1024","yes");
INSERT INTO `wp_options` VALUES("70","image_default_link_type","file","yes");
INSERT INTO `wp_options` VALUES("71","image_default_size","","yes");
INSERT INTO `wp_options` VALUES("72","image_default_align","","yes");
INSERT INTO `wp_options` VALUES("73","close_comments_for_old_posts","","yes");
INSERT INTO `wp_options` VALUES("74","close_comments_days_old","14","yes");
INSERT INTO `wp_options` VALUES("75","thread_comments","1","yes");
INSERT INTO `wp_options` VALUES("76","thread_comments_depth","5","yes");
INSERT INTO `wp_options` VALUES("77","page_comments","","yes");
INSERT INTO `wp_options` VALUES("78","comments_per_page","50","yes");
INSERT INTO `wp_options` VALUES("79","default_comments_page","newest","yes");
INSERT INTO `wp_options` VALUES("80","comment_order","asc","yes");
INSERT INTO `wp_options` VALUES("81","sticky_posts","a:0:{}","yes");
INSERT INTO `wp_options` VALUES("82","widget_categories","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("83","widget_text","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("84","widget_rss","a:0:{}","yes");
INSERT INTO `wp_options` VALUES("85","uninstall_plugins","a:0:{}","no");
INSERT INTO `wp_options` VALUES("86","timezone_string","","yes");
INSERT INTO `wp_options` VALUES("87","page_for_posts","0","yes");
INSERT INTO `wp_options` VALUES("88","page_on_front","5","yes");
INSERT INTO `wp_options` VALUES("89","default_post_format","0","yes");
INSERT INTO `wp_options` VALUES("90","link_manager_enabled","0","yes");
INSERT INTO `wp_options` VALUES("91","initial_db_version","26691","yes");
INSERT INTO `wp_options` VALUES("92","wp_user_roles","a:5:{s:13:\"administrator\";a:2:{s:4:\"name\";s:13:\"Administrator\";s:12:\"capabilities\";a:63:{s:13:\"switch_themes\";b:1;s:11:\"edit_themes\";b:1;s:16:\"activate_plugins\";b:1;s:12:\"edit_plugins\";b:1;s:10:\"edit_users\";b:1;s:10:\"edit_files\";b:1;s:14:\"manage_options\";b:1;s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:6:\"import\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:8:\"level_10\";b:1;s:7:\"level_9\";b:1;s:7:\"level_8\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;s:12:\"delete_users\";b:1;s:12:\"create_users\";b:1;s:17:\"unfiltered_upload\";b:1;s:14:\"edit_dashboard\";b:1;s:14:\"update_plugins\";b:1;s:14:\"delete_plugins\";b:1;s:15:\"install_plugins\";b:1;s:13:\"update_themes\";b:1;s:14:\"install_themes\";b:1;s:11:\"update_core\";b:1;s:10:\"list_users\";b:1;s:12:\"remove_users\";b:1;s:9:\"add_users\";b:1;s:13:\"promote_users\";b:1;s:18:\"edit_theme_options\";b:1;s:13:\"delete_themes\";b:1;s:6:\"export\";b:1;s:15:\"wpseo_bulk_edit\";b:1;}}s:6:\"editor\";a:2:{s:4:\"name\";s:6:\"Editor\";s:12:\"capabilities\";a:35:{s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;s:15:\"wpseo_bulk_edit\";b:1;}}s:6:\"author\";a:2:{s:4:\"name\";s:6:\"Author\";s:12:\"capabilities\";a:11:{s:12:\"upload_files\";b:1;s:10:\"edit_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:15:\"wpseo_bulk_edit\";b:1;}}s:11:\"contributor\";a:2:{s:4:\"name\";s:11:\"Contributor\";s:12:\"capabilities\";a:6:{s:10:\"edit_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;s:15:\"wpseo_bulk_edit\";b:1;}}s:10:\"subscriber\";a:2:{s:4:\"name\";s:10:\"Subscriber\";s:12:\"capabilities\";a:2:{s:4:\"read\";b:1;s:7:\"level_0\";b:1;}}}","yes");
INSERT INTO `wp_options` VALUES("93","widget_search","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("94","widget_recent-posts","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("95","widget_recent-comments","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("96","widget_archives","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("97","widget_meta","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("98","sidebars_widgets","a:7:{s:19:\"wp_inactive_widgets\";a:0:{}s:8:\"sidebar1\";a:0:{}s:7:\"footer1\";a:0:{}s:7:\"footer2\";a:0:{}s:7:\"footer3\";a:0:{}s:7:\"footer4\";a:0:{}s:13:\"array_version\";i:3;}","yes");
INSERT INTO `wp_options` VALUES("99","cron","a:9:{i:1433260333;a:1:{s:24:\"aiowps_hourly_cron_event\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"hourly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:3600;}}}i:1433273580;a:1:{s:20:\"wp_maybe_auto_update\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}}i:1433280054;a:2:{s:17:\"wp_update_plugins\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:16:\"wp_update_themes\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}}i:1433280055;a:1:{s:16:\"wp_version_check\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}}i:1433313572;a:1:{s:14:\"yoast_tracking\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1433323795;a:1:{s:19:\"wp_scheduled_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1433341997;a:1:{s:30:\"wp_scheduled_auto_draft_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1433343133;a:1:{s:23:\"aiowps_daily_cron_event\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}s:7:\"version\";i:2;}","yes");
INSERT INTO `wp_options` VALUES("110","category_children","a:0:{}","yes");
INSERT INTO `wp_options` VALUES("113","wpe_notices","a:2:{s:4:\"read\";s:0:\"\";s:8:\"messages\";a:0:{}}","yes");
INSERT INTO `wp_options` VALUES("114","wpe_notices_ttl","1433260238","yes");
INSERT INTO `wp_options` VALUES("167","recently_activated","a:1:{s:46:\"patch-for-revolution-slider/revsliderpatch.php\";i:1433227709;}","yes");
INSERT INTO `wp_options` VALUES("205","wpb_js_content_types","a:3:{i:0;s:4:\"post\";i:1;s:4:\"page\";i:2;s:9:\"portfolio\";}","yes");
INSERT INTO `wp_options` VALUES("207","theme_mods_twentyfourteen","a:1:{s:16:\"sidebars_widgets\";a:2:{s:4:\"time\";i:1405516620;s:4:\"data\";a:6:{s:19:\"wp_inactive_widgets\";a:0:{}s:8:\"sidebar1\";a:0:{}s:7:\"footer1\";a:0:{}s:7:\"footer2\";a:0:{}s:7:\"footer3\";a:0:{}s:7:\"footer4\";a:0:{}}}}","yes");
INSERT INTO `wp_options` VALUES("208","current_theme","Twish","yes");
INSERT INTO `wp_options` VALUES("209","theme_mods_twish","a:2:{i:0;b:0;s:18:\"nav_menu_locations\";a:2:{s:8:\"main-nav\";i:2;s:12:\"footer-links\";i:3;}}","yes");
INSERT INTO `wp_options` VALUES("210","theme_switched","","yes");
INSERT INTO `wp_options` VALUES("213","optionsframework","a:1:{s:2:\"id\";s:5:\"twish\";}","yes");
INSERT INTO `wp_options` VALUES("215","wpcf7","a:1:{s:7:\"version\";s:5:\"4.1.2\";}","yes");
INSERT INTO `wp_options` VALUES("220","wpb_js_composer_templates_slashes_updated","yes","yes");
INSERT INTO `wp_options` VALUES("221","wpb_js_templates","a:1:{i:0;a:2:{s:4:\"name\";s:0:\"\";s:8:\"template\";s:0:\"\";}}","yes");
INSERT INTO `wp_options` VALUES("223","woosidebars-version","1.3.1","yes");
INSERT INTO `wp_options` VALUES("224","_transient_random_seed","7be8bb9c17bf4cbc2d0f7b2ce172731a","yes");
INSERT INTO `wp_options` VALUES("233","twish","a:388:{s:9:\"site_logo\";s:55:\"http://ioptima.co.il/wp-content/uploads/2014/04/Log.png\";s:15:\"site_logo_width\";s:3:\"205\";s:16:\"site_logo_height\";s:2:\"80\";s:17:\"site_logo_voffset\";s:2:\"20\";s:22:\"site_mobile_logo_width\";s:3:\"100\";s:23:\"site_mobile_logo_height\";s:2:\"39\";s:24:\"site_mobile_logo_voffset\";s:1:\"8\";s:13:\"social_icon_1\";s:5:\"email\";s:17:\"social_icon_url_1\";s:39:\"http://www.linkedin.com/company/5022298\";s:25:\"social_icon_phonenumber_1\";s:0:\"\";s:26:\"social_icon_emailaddress_1\";s:18:\"info@ioptima.co.il\";s:13:\"social_icon_2\";s:8:\"linkedin\";s:17:\"social_icon_url_2\";s:39:\"http://www.linkedin.com/company/5022298\";s:25:\"social_icon_phonenumber_2\";s:0:\"\";s:26:\"social_icon_emailaddress_2\";s:18:\"info@ioptima.co.il\";s:13:\"social_icon_3\";s:4:\"none\";s:17:\"social_icon_url_3\";s:7:\"http://\";s:25:\"social_icon_phonenumber_3\";s:0:\"\";s:26:\"social_icon_emailaddress_3\";s:0:\"\";s:13:\"social_icon_4\";s:4:\"none\";s:17:\"social_icon_url_4\";s:7:\"http://\";s:25:\"social_icon_phonenumber_4\";s:0:\"\";s:26:\"social_icon_emailaddress_4\";s:0:\"\";s:21:\"sidebar_archive_pages\";s:13:\"right_sidebar\";s:12:\"sidebar_blog\";s:13:\"right_sidebar\";s:13:\"sidebar_posts\";s:13:\"right_sidebar\";s:13:\"sidebar_pages\";s:10:\"no_sidebar\";s:13:\"enable_footer\";b:0;s:13:\"footer_layout\";s:7:\"default\";s:16:\"enable_subfooter\";s:1:\"1\";s:14:\"copyright_text\";s:42:\"©2014 All Rights Reserved to IOPtima Ltd.\";s:23:\"subfooter_social_icon_1\";s:8:\"linkedin\";s:27:\"subfooter_social_icon_url_1\";s:39:\"http://www.linkedin.com/company/5022298\";s:23:\"subfooter_social_icon_2\";s:4:\"none\";s:27:\"subfooter_social_icon_url_2\";s:39:\"http://www.linkedin.com/company/5022298\";s:23:\"subfooter_social_icon_3\";s:4:\"none\";s:27:\"subfooter_social_icon_url_3\";s:7:\"http://\";s:23:\"subfooter_social_icon_4\";s:4:\"none\";s:27:\"subfooter_social_icon_url_4\";s:7:\"http://\";s:18:\"stretched_or_boxed\";s:9:\"stretched\";s:18:\"enable_page_shadow\";s:1:\"1\";s:15:\"site_background\";a:5:{s:5:\"color\";s:0:\"\";s:5:\"image\";s:0:\"\";s:6:\"repeat\";s:6:\"repeat\";s:8:\"position\";s:10:\"top center\";s:10:\"attachment\";s:6:\"scroll\";}s:23:\"enable_cover_background\";s:1:\"1\";s:17:\"base_color_scheme\";s:4:\"blue\";s:17:\"header_icon_color\";s:7:\"#181818\";s:23:\"header_icon_hover_color\";s:7:\"#1a80b6\";s:15:\"menu_item_color\";s:7:\"#000000\";s:21:\"menu_item_hover_color\";s:7:\"#1a80b6\";s:18:\"submenu_item_color\";s:7:\"#000000\";s:24:\"submenu_item_hover_color\";s:7:\"#1a80b6\";s:24:\"submenu_background_color\";s:7:\"#ffffff\";s:24:\"submenu_background_image\";a:5:{s:5:\"color\";s:0:\"\";s:5:\"image\";s:0:\"\";s:6:\"repeat\";s:6:\"repeat\";s:8:\"position\";s:10:\"top center\";s:10:\"attachment\";s:6:\"scroll\";}s:19:\"header_border_color\";s:7:\"#dadada\";s:23:\"header_background_color\";s:7:\"#ffffff\";s:24:\"custom_header_background\";a:5:{s:5:\"color\";s:0:\"\";s:5:\"image\";s:0:\"\";s:6:\"repeat\";s:6:\"repeat\";s:8:\"position\";s:10:\"top center\";s:10:\"attachment\";s:6:\"scroll\";}s:22:\"mobile_menu_item_color\";s:7:\"#ffffff\";s:25:\"mobile_submenu_item_color\";s:7:\"#83817b\";s:30:\"mobile_menu_current_item_color\";s:7:\"#1a80b6\";s:28:\"mobile_menu_background_color\";s:7:\"#000000\";s:22:\"mobile_menu_background\";a:5:{s:5:\"color\";s:7:\"#000000\";s:5:\"image\";s:0:\"\";s:6:\"repeat\";s:6:\"repeat\";s:8:\"position\";s:10:\"top center\";s:10:\"attachment\";s:6:\"scroll\";}s:21:\"breadcrumb_link_color\";s:7:\"#cccccc\";s:27:\"breadcrumb_link_hover_color\";s:7:\"#1a80b6\";s:29:\"breadcrumb_current_page_color\";s:7:\"#000000\";s:16:\"page_title_color\";s:7:\"#4883bf\";s:26:\"subheader_background_color\";s:0:\"\";s:26:\"subheader_background_image\";a:5:{s:5:\"color\";s:0:\"\";s:5:\"image\";s:0:\"\";s:6:\"repeat\";s:6:\"repeat\";s:8:\"position\";s:10:\"top center\";s:10:\"attachment\";s:6:\"scroll\";}s:27:\"main_content_heading1_color\";s:7:\"#4883bf\";s:27:\"main_content_heading2_color\";s:7:\"#000000\";s:27:\"main_content_heading3_color\";s:7:\"#000000\";s:27:\"main_content_heading4_color\";s:7:\"#000000\";s:27:\"main_content_heading5_color\";s:7:\"#000000\";s:27:\"main_content_heading6_color\";s:7:\"#000000\";s:23:\"main_content_text_color\";s:7:\"#0a0a0a\";s:30:\"main_content_bolded_text_color\";s:7:\"#000000\";s:23:\"main_content_link_color\";s:7:\"#1a80b6\";s:29:\"main_content_link_hover_color\";s:7:\"#000000\";s:23:\"main_content_lead_color\";s:7:\"#9b9b9b\";s:24:\"main_content_intro_color\";s:7:\"#363636\";s:43:\"main_content_fullwidth_row_background_color\";s:7:\"#f3f3f3\";s:25:\"main_content_border_color\";s:7:\"#e5e5e5\";s:34:\"main_content_blockquote_text_color\";s:7:\"#000000\";s:40:\"main_content_blockquote_background_color\";s:7:\"#1a80b6\";s:42:\"main_content_blockquote_reverse_text_color\";s:7:\"#ffffff\";s:31:\"main_content_dropcap_text_color\";s:7:\"#000000\";s:37:\"main_content_dropcap_background_color\";s:7:\"#1a80b6\";s:39:\"main_content_dropcap_reverse_text_color\";s:7:\"#ffffff\";s:31:\"main_content_tooltip_link_color\";s:7:\"#e7949a\";s:37:\"main_content_tooltip_background_color\";s:7:\"#1a80b6\";s:31:\"main_content_tooltip_text_color\";s:7:\"#ffffff\";s:33:\"main_content_highlight_text_color\";s:7:\"#ffffff\";s:39:\"main_content_highlight_background_color\";s:7:\"#1a80b6\";s:28:\"main_content_list_icon_color\";s:7:\"#000000\";s:28:\"main_content_list_text_color\";s:7:\"#000000\";s:29:\"main_content_label_text_color\";s:7:\"#ffffff\";s:35:\"main_content_label_background_color\";s:7:\"#1a80b6\";s:29:\"main_content_badge_text_color\";s:7:\"#ffffff\";s:35:\"main_content_badge_background_color\";s:7:\"#000000\";s:31:\"main_content_popover_link_color\";s:7:\"#1a80b6\";s:34:\"main_content_popover_heading_color\";s:7:\"#000000\";s:31:\"main_content_popover_text_color\";s:7:\"#777777\";s:33:\"main_content_accordion_link_color\";s:7:\"#000000\";s:40:\"main_content_accordion_link_active_color\";s:7:\"#000000\";s:36:\"main_content_accordion_divider_color\";s:7:\"#e5e5e5\";s:39:\"main_content_accordion_background_color\";s:7:\"#999999\";s:41:\"main_content_accordion_reverse_link_color\";s:7:\"#ffffff\";s:46:\"main_content_accordion_active_background_color\";s:7:\"#1a80b6\";s:48:\"main_content_accordion_active_reverse_link_color\";s:7:\"#ffffff\";s:31:\"main_content_alert_border_color\";s:7:\"#f7e68f\";s:35:\"main_content_alert_background_color\";s:7:\"#fdf9e7\";s:29:\"main_content_alert_text_color\";s:7:\"#998649\";s:39:\"main_content_counter_circle_label_color\";s:7:\"#000000\";s:39:\"main_content_counter_circle_track_color\";s:7:\"#e5e5e5\";s:37:\"main_content_counter_circle_bar_color\";s:7:\"#1a80b6\";s:44:\"main_content_counter_circle_background_color\";s:0:\"\";s:41:\"main_content_counter_box_percentage_color\";s:7:\"#ffffff\";s:38:\"main_content_counter_box_caption_color\";s:7:\"#ffffff\";s:41:\"main_content_counter_box_background_color\";s:7:\"#1a80b6\";s:37:\"main_content_progress_bar_label_color\";s:7:\"#000000\";s:36:\"main_content_progress_bar_icon_color\";s:7:\"#b7b7b7\";s:42:\"main_content_progress_bar_background_color\";s:7:\"#e5e5e5\";s:31:\"main_content_progress_bar_color\";s:7:\"#1a80b6\";s:36:\"main_content_button_background_color\";s:7:\"#1a80b6\";s:30:\"main_content_button_text_color\";s:7:\"#ffffff\";s:42:\"main_content_button_hover_background_color\";s:7:\"#000000\";s:36:\"main_content_button_hover_text_color\";s:7:\"#ffffff\";s:36:\"main_content_contentbox1_title_color\";s:7:\"#393939\";s:35:\"main_content_contentbox1_icon_color\";s:7:\"#393939\";s:36:\"main_content_contentbox2_title_color\";s:7:\"#1a80b6\";s:35:\"main_content_contentbox2_icon_color\";s:7:\"#ffffff\";s:41:\"main_content_contentbox2_background_color\";s:7:\"#1a80b6\";s:36:\"main_content_contentbox3_title_color\";s:7:\"#393939\";s:35:\"main_content_contentbox3_icon_color\";s:7:\"#ffffff\";s:41:\"main_content_contentbox3_background_color\";s:7:\"#1a80b6\";s:36:\"main_content_contentbox4_title_color\";s:7:\"#393939\";s:35:\"main_content_contentbox4_icon_color\";s:7:\"#1a80b6\";s:37:\"main_content_contentbox4_border_color\";s:7:\"#1a80b6\";s:36:\"main_content_contentbox5_title_color\";s:7:\"#000000\";s:35:\"main_content_contentbox5_icon_color\";s:7:\"#000000\";s:36:\"main_content_contentbox6_title_color\";s:7:\"#000000\";s:35:\"main_content_contentbox6_icon_color\";s:7:\"#ffffff\";s:41:\"main_content_contentbox6_background_color\";s:7:\"#000000\";s:37:\"main_content_contentbox6_border_color\";s:7:\"#000000\";s:38:\"main_content_contentbox6_content_color\";s:7:\"#6e6e6e\";s:49:\"main_content_contentbox6_content_background_color\";s:7:\"#f3f3f3\";s:48:\"main_content_contentbox6_button_background_color\";s:7:\"#000000\";s:42:\"main_content_contentbox6_button_text_color\";s:7:\"#ffffff\";s:54:\"main_content_contentbox6_button_background_hover_color\";s:7:\"#1a80b6\";s:48:\"main_content_contentbox6_button_text_hover_color\";s:7:\"#ffffff\";s:23:\"main_content_icon_color\";s:7:\"#ffffff\";s:34:\"main_content_icon_background_color\";s:7:\"#1a80b6\";s:30:\"main_content_icon_border_color\";s:7:\"#1a80b6\";s:29:\"main_content_icon_hover_color\";s:7:\"#1a80b6\";s:40:\"main_content_icon_hover_background_color\";s:7:\"#ffffff\";s:36:\"main_content_icon_hover_border_color\";s:7:\"#1a80b6\";s:33:\"main_content_icon_wo_circle_color\";s:7:\"#000000\";s:39:\"main_content_icon_wo_circle_hover_color\";s:7:\"#1a80b6\";s:31:\"main_content_profile_name_color\";s:7:\"#000000\";s:32:\"main_content_profile_title_color\";s:7:\"#686868\";s:38:\"main_content_profile_social_icon_color\";s:7:\"#cccccc\";s:44:\"main_content_profile_social_icon_hover_color\";s:7:\"#1a80b6\";s:38:\"main_content_pricing_plan_header_color\";s:7:\"#ffffff\";s:37:\"main_content_pricing_plan_price_color\";s:7:\"#ffffff\";s:49:\"main_content_pricing_plan_header_background_color\";s:7:\"#000000\";s:39:\"main_content_pricing_plan_details_color\";s:7:\"#535353\";s:50:\"main_content_pricing_plan_details_background_color\";s:7:\"#f3f3f3\";s:39:\"main_content_pricing_table_border_color\";s:7:\"#dadada\";s:39:\"main_content_pricing_table_header_color\";s:7:\"#1a80b6\";s:38:\"main_content_pricing_table_price_color\";s:7:\"#000000\";s:50:\"main_content_pricing_table_header_background_color\";s:7:\"#ffffff\";s:40:\"main_content_pricing_table_details_color\";s:7:\"#585858\";s:51:\"main_content_pricing_table_details_background_color\";s:7:\"#ffffff\";s:61:\"main_content_pricing_table_details_alternate_background_color\";s:7:\"#f7f7f7\";s:48:\"main_content_pricing_table_featured_header_color\";s:7:\"#ffffff\";s:59:\"main_content_pricing_table_featured_header_background_color\";s:7:\"#1a80b6\";s:33:\"main_content_posts_sc_title_color\";s:7:\"#000000\";s:39:\"main_content_posts_sc_title_hover_color\";s:7:\"#1a80b6\";s:32:\"main_content_posts_sc_date_color\";s:7:\"#686868\";s:41:\"main_content_posts_sc_comment_count_color\";s:7:\"#cccccc\";s:47:\"main_content_posts_sc_comment_count_hover_color\";s:7:\"#1a80b6\";s:30:\"main_content_tab_heading_color\";s:7:\"#a3a3a3\";s:41:\"main_content_tab_heading_background_color\";s:7:\"#ffffff\";s:37:\"main_content_tab_active_heading_color\";s:7:\"#000000\";s:48:\"main_content_tab_active_heading_background_color\";s:7:\"#e9e9e9\";s:36:\"main_content_tab_hover_heading_color\";s:7:\"#777777\";s:47:\"main_content_tab_hover_heading_background_color\";s:7:\"#ffffff\";s:30:\"main_content_tab_content_color\";s:7:\"#000000\";s:41:\"main_content_tab_content_background_color\";s:7:\"#e9e9e9\";s:39:\"main_content_hero_unit_background_color\";s:7:\"#f3f3f3\";s:36:\"main_content_hero_unit_heading_color\";s:7:\"#363636\";s:33:\"main_content_hero_unit_text_color\";s:7:\"#363636\";s:39:\"main_content_thumbnail_background_color\";s:7:\"#e5e5e5\";s:36:\"main_content_thumbnail_heading_color\";s:7:\"#323232\";s:33:\"main_content_thumbnail_text_color\";s:7:\"#323232\";s:36:\"main_content_testimonial1_text_color\";s:7:\"#000000\";s:42:\"main_content_testimonial1_background_color\";s:7:\"#e5e5e5\";s:43:\"main_content_testimonial1_author_name_color\";s:7:\"#000000\";s:44:\"main_content_testimonial1_author_title_color\";s:7:\"#a3a3a3\";s:36:\"main_content_testimonial2_text_color\";s:7:\"#000000\";s:42:\"main_content_testimonial2_background_color\";s:7:\"#e5e5e5\";s:43:\"main_content_testimonial2_author_name_color\";s:7:\"#000000\";s:44:\"main_content_testimonial2_author_title_color\";s:7:\"#a3a3a3\";s:38:\"main_content_revslider_paginator_color\";s:7:\"#000000\";s:40:\"main_content_revslider_paginator_opacity\";s:3:\"0.3\";s:46:\"main_content_revslider_current_paginator_color\";s:7:\"#000000\";s:48:\"main_content_revslider_current_paginator_opacity\";s:1:\"1\";s:42:\"main_content_revslider_big_nav_arrow_color\";s:7:\"#000000\";s:44:\"main_content_revslider_big_nav_arrow_opacity\";s:3:\"0.1\";s:48:\"main_content_revslider_big_nav_arrow_hover_color\";s:7:\"#000000\";s:50:\"main_content_revslider_big_nav_arrow_hover_opacity\";s:3:\"0.8\";s:44:\"main_content_revslider_small_nav_arrow_color\";s:0:\"\";s:46:\"main_content_revslider_small_nav_arrow_opacity\";s:1:\"1\";s:50:\"main_content_revslider_small_nav_arrow_hover_color\";s:7:\"#000000\";s:52:\"main_content_revslider_small_nav_arrow_hover_opacity\";s:3:\"0.3\";s:41:\"main_content_revslider_dark_caption_color\";s:7:\"#000000\";s:42:\"main_content_revslider_light_caption_color\";s:7:\"#ffffff\";s:44:\"main_content_revslider_colored_caption_color\";s:7:\"#1a80b6\";s:45:\"main_content_revslider_dark_button_text_color\";s:7:\"#ffffff\";s:51:\"main_content_revslider_dark_button_background_color\";s:7:\"#000000\";s:51:\"main_content_revslider_dark_button_hover_text_color\";s:7:\"#ffffff\";s:57:\"main_content_revslider_dark_button_hover_background_color\";s:7:\"#1a80b6\";s:46:\"main_content_revslider_light_button_text_color\";s:7:\"#000000\";s:52:\"main_content_revslider_light_button_background_color\";s:7:\"#ffffff\";s:52:\"main_content_revslider_light_button_hover_text_color\";s:7:\"#ffffff\";s:58:\"main_content_revslider_light_button_hover_background_color\";s:7:\"#1a80b6\";s:48:\"main_content_revslider_colored_button_text_color\";s:7:\"#ffffff\";s:54:\"main_content_revslider_colored_button_background_color\";s:7:\"#1a80b6\";s:54:\"main_content_revslider_colored_button_hover_text_color\";s:7:\"#ffffff\";s:60:\"main_content_revslider_colored_button_hover_background_color\";s:7:\"#000000\";s:39:\"main_content_nivoslider_paginator_color\";s:7:\"#000000\";s:41:\"main_content_nivoslider_paginator_opacity\";s:3:\"0.3\";s:47:\"main_content_nivoslider_current_paginator_color\";s:7:\"#1a80b6\";s:49:\"main_content_nivoslider_current_paginator_opacity\";s:1:\"1\";s:45:\"main_content_nivoslider_hover_paginator_color\";s:7:\"#000000\";s:47:\"main_content_nivoslider_hover_paginator_opacity\";s:3:\"0.4\";s:39:\"main_content_nivoslider_nav_arrow_color\";s:7:\"#ffffff\";s:50:\"main_content_nivoslider_nav_arrow_background_color\";s:7:\"#000000\";s:52:\"main_content_nivoslider_nav_arrow_background_opacity\";s:3:\"0.7\";s:45:\"main_content_nivoslider_nav_arrow_hover_color\";s:7:\"#000000\";s:56:\"main_content_nivoslider_nav_arrow_hover_background_color\";s:7:\"#ffffff\";s:58:\"main_content_nivoslider_nav_arrow_hover_background_opacity\";s:3:\"0.7\";s:39:\"main_content_flexslider_nav_arrow_color\";s:7:\"#ffffff\";s:50:\"main_content_flexslider_nav_arrow_background_color\";s:7:\"#000000\";s:52:\"main_content_flexslider_nav_arrow_background_opacity\";s:3:\"0.7\";s:45:\"main_content_flexslider_nav_arrow_hover_color\";s:7:\"#000000\";s:56:\"main_content_flexslider_nav_arrow_hover_background_color\";s:7:\"#ffffff\";s:58:\"main_content_flexslider_nav_arrow_hover_background_opacity\";s:3:\"0.7\";s:48:\"main_content_flexslider_caption_background_color\";s:7:\"#000000\";s:50:\"main_content_flexslider_caption_background_opacity\";s:3:\"0.7\";s:45:\"main_content_flexslider_caption_heading_color\";s:7:\"#ffffff\";s:42:\"main_content_flexslider_caption_text_color\";s:7:\"#ffffff\";s:35:\"main_content_portfolio_filter_color\";s:7:\"#000000\";s:41:\"main_content_portfolio_filter_hover_color\";s:7:\"#1a80b6\";s:43:\"main_content_portfolio_filter_current_color\";s:7:\"#000000\";s:40:\"main_content_portfolio_icon_filter_color\";s:7:\"#cccccc\";s:46:\"main_content_portfolio_icon_filter_hover_color\";s:7:\"#1a80b6\";s:48:\"main_content_portfolio_icon_filter_current_color\";s:7:\"#000000\";s:47:\"main_content_portfolio_overlay_background_color\";s:7:\"#1a80b6\";s:49:\"main_content_portfolio_overlay_background_opacity\";s:3:\"0.9\";s:41:\"main_content_portfolio_overlay_icon_color\";s:7:\"#ffffff\";s:47:\"main_content_portfolio_overlay_icon_hover_color\";s:7:\"#ffffff\";s:44:\"main_content_portfolio_overlay_divider_color\";s:7:\"#ffffff\";s:46:\"main_content_portfolio_overlay_divider_opacity\";s:3:\"0.3\";s:45:\"main_content_portfolio_pagination_arrow_color\";s:7:\"#000000\";s:51:\"main_content_portfolio_pagination_arrow_hover_color\";s:7:\"#1a80b6\";s:54:\"main_content_portfolio_pagination_arrow_disabled_color\";s:7:\"#cccccc\";s:51:\"main_content_portfolio_pagination_page_number_color\";s:7:\"#000000\";s:57:\"main_content_portfolio_pagination_page_number_hover_color\";s:7:\"#1a80b6\";s:59:\"main_content_portfolio_pagination_current_page_number_color\";s:7:\"#cccccc\";s:34:\"main_content_portfolio_title_color\";s:7:\"#000000\";s:40:\"main_content_portfolio_title_hover_color\";s:7:\"#1a80b6\";s:37:\"main_content_portfolio_category_color\";s:7:\"#686868\";s:43:\"main_content_portfolio_category_hover_color\";s:7:\"#1a80b6\";s:36:\"main_content_portfolio_excerpt_color\";s:7:\"#777777\";s:39:\"main_content_portfolio_item_title_color\";s:7:\"#000000\";s:38:\"main_content_portfolio_item_link_color\";s:7:\"#000000\";s:44:\"main_content_portfolio_item_link_hover_color\";s:7:\"#1a80b6\";s:52:\"main_content_portfolio_item_categories_heading_color\";s:7:\"#000000\";s:42:\"main_content_portfolio_item_category_color\";s:7:\"#737373\";s:38:\"main_content_portfolio_nav_title_color\";s:7:\"#cacaca\";s:44:\"main_content_portfolio_nav_title_hover_color\";s:7:\"#000000\";s:41:\"main_content_portfolio_nav_category_color\";s:7:\"#cacaca\";s:47:\"main_content_portfolio_nav_category_hover_color\";s:7:\"#000000\";s:37:\"main_content_portfolio_nav_icon_color\";s:7:\"#000000\";s:43:\"main_content_portfolio_nav_icon_hover_color\";s:7:\"#1a80b6\";s:52:\"main_content_blog_pagination_button_background_color\";s:7:\"#000000\";s:46:\"main_content_blog_pagination_button_text_color\";s:7:\"#ffffff\";s:58:\"main_content_blog_pagination_button_background_hover_color\";s:7:\"#1a80b6\";s:52:\"main_content_blog_pagination_button_text_hover_color\";s:7:\"#ffffff\";s:61:\"main_content_blog_pagination_disabled_button_background_color\";s:7:\"#e5e5e5\";s:55:\"main_content_blog_pagination_disabled_button_text_color\";s:7:\"#000000\";s:65:\"main_content_blog_pagination_current_page_button_background_color\";s:7:\"#e5e5e5\";s:59:\"main_content_blog_pagination_current_page_button_text_color\";s:7:\"#000000\";s:41:\"main_content_blog_post_preview_date_color\";s:7:\"#686868\";s:47:\"main_content_blog_post_preview_date_hover_color\";s:7:\"#1a80b6\";s:41:\"main_content_blog_post_preview_meta_color\";s:7:\"#b8b8b8\";s:47:\"main_content_blog_post_preview_meta_hover_color\";s:7:\"#1a80b6\";s:46:\"main_content_blog_post_preview_meta_icon_color\";s:7:\"#cccccc\";s:52:\"main_content_blog_post_preview_meta_icon_hover_color\";s:7:\"#1a80b6\";s:42:\"main_content_blog_post_preview_title_color\";s:7:\"#000000\";s:48:\"main_content_blog_post_preview_title_hover_color\";s:7:\"#1a80b6\";s:44:\"main_content_blog_post_preview_excerpt_color\";s:7:\"#737373\";s:62:\"main_content_blog_post_preview_readmorebutton_background_color\";s:7:\"#1a80b6\";s:56:\"main_content_blog_post_preview_readmorebutton_text_color\";s:7:\"#ffffff\";s:68:\"main_content_blog_post_preview_readmorebutton_background_hover_color\";s:7:\"#000000\";s:62:\"main_content_blog_post_preview_readmorebutton_text_hover_color\";s:7:\"#ffffff\";s:31:\"main_content_blog_divider_color\";s:7:\"#e5e5e5\";s:28:\"main_content_post_date_color\";s:7:\"#686868\";s:34:\"main_content_post_date_hover_color\";s:7:\"#1a80b6\";s:28:\"main_content_post_meta_color\";s:7:\"#b8b8b8\";s:34:\"main_content_post_meta_hover_color\";s:7:\"#1a80b6\";s:33:\"main_content_post_meta_icon_color\";s:7:\"#cccccc\";s:39:\"main_content_post_meta_icon_hover_color\";s:7:\"#1a80b6\";s:29:\"main_content_post_title_color\";s:7:\"#000000\";s:35:\"main_content_post_title_hover_color\";s:7:\"#1a80b6\";s:38:\"main_content_post_bottom_divider_color\";s:7:\"#e5e5e5\";s:36:\"main_content_post_author_label_color\";s:7:\"#3b3b3b\";s:35:\"main_content_post_author_link_color\";s:7:\"#3b3b3b\";s:41:\"main_content_post_author_link_hover_color\";s:7:\"#1a80b6\";s:33:\"main_content_post_tag_label_color\";s:7:\"#3b3b3b\";s:32:\"main_content_post_tag_link_color\";s:7:\"#3b3b3b\";s:38:\"main_content_post_tag_link_hover_color\";s:7:\"#1a80b6\";s:33:\"main_content_post_nav_title_color\";s:7:\"#000000\";s:45:\"main_content_post_nav_button_background_color\";s:7:\"#e5e5e5\";s:39:\"main_content_post_nav_button_text_color\";s:7:\"#000000\";s:51:\"main_content_post_nav_button_background_hover_color\";s:7:\"#1a80b6\";s:45:\"main_content_post_nav_button_text_hover_color\";s:7:\"#ffffff\";s:38:\"main_content_post_comments_title_color\";s:7:\"#000000\";s:39:\"main_content_post_comments_author_color\";s:7:\"#000000\";s:37:\"main_content_post_comments_link_color\";s:7:\"#000000\";s:43:\"main_content_post_comments_link_hover_color\";s:7:\"#1a80b6\";s:37:\"main_content_post_comments_text_color\";s:7:\"#737373\";s:42:\"main_content_post_comment_form_title_color\";s:7:\"#000000\";s:42:\"main_content_post_comment_form_label_color\";s:7:\"#000000\";s:53:\"main_content_post_comment_form_input_background_color\";s:7:\"#f5f5f5\";s:47:\"main_content_post_comment_form_input_text_color\";s:7:\"#000000\";s:54:\"main_content_post_comment_form_input_placeholder_color\";s:7:\"#c2c2c2\";s:54:\"main_content_post_comment_form_button_background_color\";s:7:\"#1a80b6\";s:48:\"main_content_post_comment_form_button_text_color\";s:7:\"#ffffff\";s:60:\"main_content_post_comment_form_button_background_hover_color\";s:7:\"#000000\";s:54:\"main_content_post_comment_form_button_text_hover_color\";s:7:\"#ffffff\";s:29:\"main_content_form_label_color\";s:6:\"000000\";s:40:\"main_content_form_input_background_color\";s:7:\"#f5f5f5\";s:34:\"main_content_form_input_text_color\";s:7:\"#000000\";s:41:\"main_content_form_input_placeholder_color\";s:7:\"#c2c2c2\";s:41:\"main_content_form_button_background_color\";s:7:\"#1a80b6\";s:35:\"main_content_form_button_text_color\";s:7:\"#ffffff\";s:47:\"main_content_form_button_background_hover_color\";s:7:\"#000000\";s:41:\"main_content_form_button_text_hover_color\";s:7:\"#ffffff\";s:29:\"main_content_background_color\";s:7:\"#ffffff\";s:30:\"custom_main_content_background\";a:5:{s:5:\"color\";s:0:\"\";s:5:\"image\";s:0:\"\";s:6:\"repeat\";s:6:\"repeat\";s:8:\"position\";s:10:\"top center\";s:10:\"attachment\";s:6:\"scroll\";}s:26:\"sidebar_widget_title_color\";s:7:\"#000000\";s:28:\"sidebar_widget_heading_color\";s:7:\"#000000\";s:25:\"sidebar_widget_text_color\";s:7:\"#737373\";s:25:\"sidebar_widget_link_color\";s:7:\"#000000\";s:31:\"sidebar_widget_link_hover_color\";s:7:\"#1a80b6\";s:35:\"sidebar_widget_twitter_widget_color\";s:7:\"#000000\";s:35:\"sidebar_navigation_background_color\";s:7:\"#f3f3f3\";s:31:\"sidebar_navigation_border_color\";s:7:\"#e5e5e5\";s:29:\"sidebar_navigation_link_color\";s:7:\"#7a7a7a\";s:35:\"sidebar_navigation_link_hover_color\";s:7:\"#1a80b6\";s:48:\"sidebar_navigation_current_page_background_color\";s:7:\"#1a80b6\";s:42:\"sidebar_navigation_current_page_link_color\";s:7:\"#ffffff\";s:20:\"footer_heading_color\";s:7:\"#424242\";s:17:\"footer_text_color\";s:7:\"#7c7c7c\";s:17:\"footer_link_color\";s:7:\"#000000\";s:23:\"footer_link_hover_color\";s:7:\"#1a80b6\";s:24:\"footer_button_text_color\";s:7:\"#ffffff\";s:30:\"footer_button_background_color\";s:7:\"#000000\";s:30:\"footer_button_text_hover_color\";s:7:\"#ffffff\";s:36:\"footer_button_background_hover_color\";s:7:\"#1a80b6\";s:28:\"footer_form_input_text_color\";s:7:\"#000000\";s:34:\"footer_form_input_background_color\";s:7:\"#cbcbcb\";s:30:\"footer_form_input_active_color\";s:7:\"#000000\";s:41:\"footer_form_input_active_background_color\";s:7:\"#ffffff\";s:17:\"footer_icon_color\";s:7:\"#b5b5b5\";s:23:\"footer_icon_hover_color\";s:7:\"#000000\";s:23:\"footer_background_color\";s:7:\"#e2e2e2\";s:24:\"custom_footer_background\";a:5:{s:5:\"color\";s:0:\"\";s:5:\"image\";s:0:\"\";s:6:\"repeat\";s:6:\"repeat\";s:8:\"position\";s:10:\"top center\";s:10:\"attachment\";s:6:\"scroll\";}s:20:\"subfooter_text_color\";s:7:\"#585858\";s:20:\"subfooter_link_color\";s:7:\"#747474\";s:26:\"subfooter_link_hover_color\";s:7:\"#ffffff\";s:20:\"subfooter_icon_color\";s:7:\"#333333\";s:26:\"subfooter_icon_hover_color\";s:7:\"#747474\";s:26:\"subfooter_background_color\";s:7:\"#0a0a0a\";s:27:\"custom_subfooter_background\";a:5:{s:5:\"color\";s:0:\"\";s:5:\"image\";s:0:\"\";s:6:\"repeat\";s:6:\"repeat\";s:8:\"position\";s:10:\"top center\";s:10:\"attachment\";s:6:\"scroll\";}s:14:\"portfolio_slug\";s:15:\"portfolio_items\";s:23:\"portfolio_items_heading\";s:8:\"Our Work\";s:30:\"portfolio_items_filter_heading\";s:30:\"Skills & Technologies Involved\";}","yes");
INSERT INTO `wp_options` VALUES("250","nav_menu_options","a:2:{i:0;b:0;s:8:\"auto_add\";a:0:{}}","yes");
INSERT INTO `wp_options` VALUES("266","dot_cfi_settings","a:5:{s:20:\"favicon_frontend_url\";s:66:\"http://ioptima.wpengine.com/wp-content/uploads/2014/04/favicon.png\";s:19:\"favicon_backend_url\";s:0:\"\";s:23:\"apple_icon_frontend_url\";s:0:\"\";s:22:\"apple_icon_backend_url\";s:0:\"\";s:16:\"apple_icon_style\";s:1:\"0\";}","yes");
INSERT INTO `wp_options` VALUES("269","bcn_options","a:68:{s:17:\"bmainsite_display\";b:0;s:18:\"Hmainsite_template\";s:67:\"<a title=\"Go to %title%.\" href=\"%link%\" class=\"%type%\">%htitle%</a>\";s:28:\"Hmainsite_template_no_anchor\";s:8:\"%htitle%\";s:13:\"bhome_display\";b:0;s:14:\"Hhome_template\";s:67:\"<a title=\"Go to %title%.\" href=\"%link%\" class=\"%type%\">%htitle%</a>\";s:24:\"Hhome_template_no_anchor\";s:8:\"%htitle%\";s:13:\"bblog_display\";b:1;s:14:\"Hblog_template\";s:67:\"<a title=\"Go to %title%.\" href=\"%link%\" class=\"%type%\">%htitle%</a>\";s:24:\"Hblog_template_no_anchor\";s:8:\"%htitle%\";s:10:\"hseparator\";s:6:\" &gt; \";s:12:\"blimit_title\";b:0;s:17:\"amax_title_length\";i:20;s:20:\"bcurrent_item_linked\";b:0;s:19:\"Hpost_page_template\";s:67:\"<a title=\"Go to %title%.\" href=\"%link%\" class=\"%type%\">%htitle%</a>\";s:29:\"Hpost_page_template_no_anchor\";s:8:\"%htitle%\";s:15:\"apost_page_root\";s:1:\"5\";s:15:\"Hpaged_template\";s:13:\"Page %htitle%\";s:14:\"bpaged_display\";b:0;s:19:\"Hpost_post_template\";s:67:\"<a title=\"Go to %title%.\" href=\"%link%\" class=\"%type%\">%htitle%</a>\";s:29:\"Hpost_post_template_no_anchor\";s:8:\"%htitle%\";s:15:\"apost_post_root\";s:1:\"0\";s:27:\"bpost_post_taxonomy_display\";b:1;s:24:\"Spost_post_taxonomy_type\";s:8:\"category\";s:25:\"Hpost_attachment_template\";s:67:\"<a title=\"Go to %title%.\" href=\"%link%\" class=\"%type%\">%htitle%</a>\";s:35:\"Hpost_attachment_template_no_anchor\";s:8:\"%htitle%\";s:13:\"H404_template\";s:8:\"%htitle%\";s:10:\"S404_title\";s:3:\"404\";s:16:\"Hsearch_template\";s:135:\"Search results for &#039;<a title=\"Go to the first page of search results for %title%.\" href=\"%link%\" class=\"%type%\">%htitle%</a>&#039;\";s:26:\"Hsearch_template_no_anchor\";s:39:\"Search results for &#039;%htitle%&#039;\";s:18:\"Hpost_tag_template\";s:84:\"<a title=\"Go to the %title% tag archives.\" href=\"%link%\" class=\"%type%\">%htitle%</a>\";s:28:\"Hpost_tag_template_no_anchor\";s:8:\"%htitle%\";s:21:\"Hpost_format_template\";s:84:\"<a title=\"Go to the %title% tag archives.\" href=\"%link%\" class=\"%type%\">%htitle%</a>\";s:31:\"Hpost_format_template_no_anchor\";s:8:\"%htitle%\";s:16:\"Hauthor_template\";s:107:\"Articles by: <a title=\"Go to the first page of posts by %title%.\" href=\"%link%\" class=\"%type%\">%htitle%</a>\";s:26:\"Hauthor_template_no_anchor\";s:21:\"Articles by: %htitle%\";s:12:\"Sauthor_name\";s:12:\"display_name\";s:18:\"Hcategory_template\";s:89:\"<a title=\"Go to the %title% category archives.\" href=\"%link%\" class=\"%type%\">%htitle%</a>\";s:28:\"Hcategory_template_no_anchor\";s:8:\"%htitle%\";s:14:\"Hdate_template\";s:80:\"<a title=\"Go to the %title% archives.\" href=\"%link%\" class=\"%type%\">%htitle%</a>\";s:24:\"Hdate_template_no_anchor\";s:8:\"%htitle%\";s:26:\"Hpost_testimonial_template\";s:52:\"<a title=\"Go to %title%.\" href=\"%link%\">%htitle%</a>\";s:36:\"Hpost_testimonial_template_no_anchor\";s:8:\"%htitle%\";s:33:\"bpost_testimonial_archive_display\";b:0;s:22:\"apost_testimonial_root\";i:0;s:34:\"bpost_testimonial_taxonomy_display\";b:1;s:31:\"Spost_testimonial_taxonomy_type\";s:20:\"testimonial-category\";s:24:\"Hpost_portfolio_template\";s:52:\"<a title=\"Go to %title%.\" href=\"%link%\">%htitle%</a>\";s:34:\"Hpost_portfolio_template_no_anchor\";s:8:\"%htitle%\";s:31:\"bpost_portfolio_archive_display\";b:1;s:20:\"apost_portfolio_root\";i:0;s:32:\"bpost_portfolio_taxonomy_display\";b:1;s:29:\"Spost_portfolio_taxonomy_type\";s:8:\"post_tag\";s:33:\"Hpost_wpcf7_contact_form_template\";s:52:\"<a title=\"Go to %title%.\" href=\"%link%\">%htitle%</a>\";s:43:\"Hpost_wpcf7_contact_form_template_no_anchor\";s:8:\"%htitle%\";s:40:\"bpost_wpcf7_contact_form_archive_display\";b:0;s:29:\"apost_wpcf7_contact_form_root\";s:1:\"0\";s:41:\"bpost_wpcf7_contact_form_taxonomy_display\";b:0;s:38:\"Spost_wpcf7_contact_form_taxonomy_type\";s:4:\"date\";s:22:\"Hpost_sidebar_template\";s:52:\"<a title=\"Go to %title%.\" href=\"%link%\">%htitle%</a>\";s:32:\"Hpost_sidebar_template_no_anchor\";s:8:\"%htitle%\";s:29:\"bpost_sidebar_archive_display\";b:0;s:18:\"apost_sidebar_root\";s:1:\"0\";s:30:\"bpost_sidebar_taxonomy_display\";b:0;s:27:\"Spost_sidebar_taxonomy_type\";s:4:\"date\";s:30:\"Htestimonial-category_template\";s:74:\"<a title=\"Go to the %title% Category archives.\" href=\"%link%\">%htitle%</a>\";s:40:\"Htestimonial-category_template_no_anchor\";s:8:\"%htitle%\";s:28:\"Hportfolio_category_template\";s:86:\"<a title=\"Go to the %title% Portfolio Categories archives.\" href=\"%link%\">%htitle%</a>\";s:38:\"Hportfolio_category_template_no_anchor\";s:8:\"%htitle%\";}","yes");
INSERT INTO `wp_options` VALUES("270","bcn_options_bk","a:68:{s:17:\"bmainsite_display\";b:0;s:18:\"Hmainsite_template\";s:67:\"<a title=\"Go to %title%.\" href=\"%link%\" class=\"%type%\">%htitle%</a>\";s:28:\"Hmainsite_template_no_anchor\";s:8:\"%htitle%\";s:13:\"bhome_display\";b:0;s:14:\"Hhome_template\";s:67:\"<a title=\"Go to %title%.\" href=\"%link%\" class=\"%type%\">%htitle%</a>\";s:24:\"Hhome_template_no_anchor\";s:8:\"%htitle%\";s:13:\"bblog_display\";b:1;s:14:\"Hblog_template\";s:67:\"<a title=\"Go to %title%.\" href=\"%link%\" class=\"%type%\">%htitle%</a>\";s:24:\"Hblog_template_no_anchor\";s:8:\"%htitle%\";s:10:\"hseparator\";s:6:\" &gt; \";s:12:\"blimit_title\";b:0;s:17:\"amax_title_length\";i:20;s:20:\"bcurrent_item_linked\";b:0;s:19:\"Hpost_page_template\";s:67:\"<a title=\"Go to %title%.\" href=\"%link%\" class=\"%type%\">%htitle%</a>\";s:29:\"Hpost_page_template_no_anchor\";s:8:\"%htitle%\";s:15:\"apost_page_root\";s:1:\"5\";s:15:\"Hpaged_template\";s:0:\"\";s:14:\"bpaged_display\";b:0;s:19:\"Hpost_post_template\";s:67:\"<a title=\"Go to %title%.\" href=\"%link%\" class=\"%type%\">%htitle%</a>\";s:29:\"Hpost_post_template_no_anchor\";s:8:\"%htitle%\";s:15:\"apost_post_root\";s:1:\"0\";s:27:\"bpost_post_taxonomy_display\";b:1;s:24:\"Spost_post_taxonomy_type\";s:8:\"category\";s:25:\"Hpost_attachment_template\";s:67:\"<a title=\"Go to %title%.\" href=\"%link%\" class=\"%type%\">%htitle%</a>\";s:35:\"Hpost_attachment_template_no_anchor\";s:8:\"%htitle%\";s:13:\"H404_template\";s:8:\"%htitle%\";s:10:\"S404_title\";s:3:\"404\";s:16:\"Hsearch_template\";s:135:\"Search results for &#039;<a title=\"Go to the first page of search results for %title%.\" href=\"%link%\" class=\"%type%\">%htitle%</a>&#039;\";s:26:\"Hsearch_template_no_anchor\";s:39:\"Search results for &#039;%htitle%&#039;\";s:18:\"Hpost_tag_template\";s:84:\"<a title=\"Go to the %title% tag archives.\" href=\"%link%\" class=\"%type%\">%htitle%</a>\";s:28:\"Hpost_tag_template_no_anchor\";s:8:\"%htitle%\";s:21:\"Hpost_format_template\";s:84:\"<a title=\"Go to the %title% tag archives.\" href=\"%link%\" class=\"%type%\">%htitle%</a>\";s:31:\"Hpost_format_template_no_anchor\";s:8:\"%htitle%\";s:16:\"Hauthor_template\";s:107:\"Articles by: <a title=\"Go to the first page of posts by %title%.\" href=\"%link%\" class=\"%type%\">%htitle%</a>\";s:26:\"Hauthor_template_no_anchor\";s:21:\"Articles by: %htitle%\";s:12:\"Sauthor_name\";s:12:\"display_name\";s:18:\"Hcategory_template\";s:89:\"<a title=\"Go to the %title% category archives.\" href=\"%link%\" class=\"%type%\">%htitle%</a>\";s:28:\"Hcategory_template_no_anchor\";s:8:\"%htitle%\";s:14:\"Hdate_template\";s:80:\"<a title=\"Go to the %title% archives.\" href=\"%link%\" class=\"%type%\">%htitle%</a>\";s:24:\"Hdate_template_no_anchor\";s:8:\"%htitle%\";s:26:\"Hpost_testimonial_template\";s:52:\"<a title=\"Go to %title%.\" href=\"%link%\">%htitle%</a>\";s:36:\"Hpost_testimonial_template_no_anchor\";s:8:\"%htitle%\";s:33:\"bpost_testimonial_archive_display\";b:0;s:22:\"apost_testimonial_root\";i:0;s:34:\"bpost_testimonial_taxonomy_display\";b:1;s:31:\"Spost_testimonial_taxonomy_type\";s:20:\"testimonial-category\";s:24:\"Hpost_portfolio_template\";s:52:\"<a title=\"Go to %title%.\" href=\"%link%\">%htitle%</a>\";s:34:\"Hpost_portfolio_template_no_anchor\";s:8:\"%htitle%\";s:31:\"bpost_portfolio_archive_display\";b:1;s:20:\"apost_portfolio_root\";i:0;s:32:\"bpost_portfolio_taxonomy_display\";b:1;s:29:\"Spost_portfolio_taxonomy_type\";s:8:\"post_tag\";s:33:\"Hpost_wpcf7_contact_form_template\";s:52:\"<a title=\"Go to %title%.\" href=\"%link%\">%htitle%</a>\";s:43:\"Hpost_wpcf7_contact_form_template_no_anchor\";s:8:\"%htitle%\";s:40:\"bpost_wpcf7_contact_form_archive_display\";b:0;s:29:\"apost_wpcf7_contact_form_root\";s:1:\"0\";s:41:\"bpost_wpcf7_contact_form_taxonomy_display\";b:0;s:38:\"Spost_wpcf7_contact_form_taxonomy_type\";s:4:\"date\";s:22:\"Hpost_sidebar_template\";s:52:\"<a title=\"Go to %title%.\" href=\"%link%\">%htitle%</a>\";s:32:\"Hpost_sidebar_template_no_anchor\";s:8:\"%htitle%\";s:29:\"bpost_sidebar_archive_display\";b:0;s:18:\"apost_sidebar_root\";s:1:\"0\";s:30:\"bpost_sidebar_taxonomy_display\";b:0;s:27:\"Spost_sidebar_taxonomy_type\";s:4:\"date\";s:30:\"Htestimonial-category_template\";s:74:\"<a title=\"Go to the %title% Category archives.\" href=\"%link%\">%htitle%</a>\";s:40:\"Htestimonial-category_template_no_anchor\";s:8:\"%htitle%\";s:28:\"Hportfolio_category_template\";s:86:\"<a title=\"Go to the %title% Portfolio Categories archives.\" href=\"%link%\">%htitle%</a>\";s:38:\"Hportfolio_category_template_no_anchor\";s:8:\"%htitle%\";}","no");
INSERT INTO `wp_options` VALUES("271","bcn_version","5.0.1","no");
INSERT INTO `wp_options` VALUES("586","widget_pages","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("659","db_upgraded","","yes");
INSERT INTO `wp_options` VALUES("695","slb_version","2.4.0","yes");
INSERT INTO `wp_options` VALUES("696","slb_options","a:25:{s:7:\"enabled\";b:1;s:12:\"enabled_home\";b:1;s:12:\"enabled_post\";b:1;s:12:\"enabled_page\";b:1;s:15:\"enabled_archive\";b:1;s:14:\"enabled_widget\";b:0;s:11:\"group_links\";b:1;s:10:\"group_post\";b:1;s:13:\"group_gallery\";b:0;s:12:\"group_widget\";b:0;s:10:\"ui_autofit\";b:1;s:10:\"ui_animate\";b:1;s:19:\"slideshow_autostart\";b:1;s:18:\"slideshow_duration\";s:1:\"6\";s:10:\"group_loop\";b:1;s:18:\"ui_overlay_opacity\";s:3:\"0.8\";s:16:\"ui_title_default\";b:0;s:11:\"txt_loading\";s:7:\"Loading\";s:9:\"txt_close\";s:5:\"Close\";s:12:\"txt_nav_next\";s:4:\"Next\";s:12:\"txt_nav_prev\";s:8:\"Previous\";s:19:\"txt_slideshow_start\";s:15:\"Start slideshow\";s:18:\"txt_slideshow_stop\";s:14:\"Stop slideshow\";s:16:\"txt_group_status\";s:25:\"Item %current% of %total%\";s:13:\"theme_default\";s:11:\"slb_default\";}","yes");
INSERT INTO `wp_options` VALUES("895","limit_login_retries","a:2:{s:13:\"182.19.173.37\";i:1;s:15:\"188.129.114.183\";i:1;}","no");
INSERT INTO `wp_options` VALUES("896","limit_login_retries_valid","a:2:{s:13:\"182.19.173.37\";i:1424628110;s:15:\"188.129.114.183\";i:1424638120;}","no");
INSERT INTO `wp_options` VALUES("1796","wpseo_titles","a:86:{s:10:\"title_test\";i:0;s:17:\"forcerewritetitle\";b:0;s:9:\"separator\";s:7:\"sc-dash\";s:5:\"noodp\";b:0;s:6:\"noydir\";b:0;s:15:\"usemetakeywords\";b:0;s:16:\"title-home-wpseo\";s:42:\"%%sitename%% %%page%% %%sep%% %%sitedesc%%\";s:18:\"title-author-wpseo\";s:0:\"\";s:19:\"title-archive-wpseo\";s:38:\"%%date%% %%page%% %%sep%% %%sitename%%\";s:18:\"title-search-wpseo\";s:0:\"\";s:15:\"title-404-wpseo\";s:0:\"\";s:19:\"metadesc-home-wpseo\";s:0:\"\";s:21:\"metadesc-author-wpseo\";s:0:\"\";s:22:\"metadesc-archive-wpseo\";s:0:\"\";s:18:\"metakey-home-wpseo\";s:0:\"\";s:20:\"metakey-author-wpseo\";s:0:\"\";s:22:\"noindex-subpages-wpseo\";b:0;s:20:\"noindex-author-wpseo\";b:0;s:21:\"noindex-archive-wpseo\";b:1;s:14:\"disable-author\";b:0;s:12:\"disable-date\";b:0;s:10:\"title-post\";s:39:\"%%title%% %%page%% %%sep%% %%sitename%%\";s:13:\"metadesc-post\";s:0:\"\";s:12:\"metakey-post\";s:0:\"\";s:12:\"noindex-post\";b:0;s:13:\"showdate-post\";b:0;s:16:\"hideeditbox-post\";b:0;s:10:\"title-page\";s:39:\"%%title%% %%page%% %%sep%% %%sitename%%\";s:13:\"metadesc-page\";s:0:\"\";s:12:\"metakey-page\";s:0:\"\";s:12:\"noindex-page\";b:0;s:13:\"showdate-page\";b:0;s:16:\"hideeditbox-page\";b:0;s:16:\"title-attachment\";s:39:\"%%title%% %%page%% %%sep%% %%sitename%%\";s:19:\"metadesc-attachment\";s:0:\"\";s:18:\"metakey-attachment\";s:0:\"\";s:18:\"noindex-attachment\";b:0;s:19:\"showdate-attachment\";b:0;s:22:\"hideeditbox-attachment\";b:0;s:18:\"title-tax-category\";s:53:\"%%term_title%% Archives %%page%% %%sep%% %%sitename%%\";s:21:\"metadesc-tax-category\";s:0:\"\";s:20:\"metakey-tax-category\";s:0:\"\";s:24:\"hideeditbox-tax-category\";b:0;s:20:\"noindex-tax-category\";b:0;s:18:\"title-tax-post_tag\";s:53:\"%%term_title%% Archives %%page%% %%sep%% %%sitename%%\";s:21:\"metadesc-tax-post_tag\";s:0:\"\";s:20:\"metakey-tax-post_tag\";s:0:\"\";s:24:\"hideeditbox-tax-post_tag\";b:0;s:20:\"noindex-tax-post_tag\";b:0;s:21:\"title-tax-post_format\";s:53:\"%%term_title%% Archives %%page%% %%sep%% %%sitename%%\";s:24:\"metadesc-tax-post_format\";s:0:\"\";s:23:\"metakey-tax-post_format\";s:0:\"\";s:27:\"hideeditbox-tax-post_format\";b:0;s:23:\"noindex-tax-post_format\";b:1;s:17:\"title-testimonial\";s:39:\"%%title%% %%page%% %%sep%% %%sitename%%\";s:20:\"metadesc-testimonial\";s:0:\"\";s:19:\"metakey-testimonial\";s:0:\"\";s:19:\"noindex-testimonial\";b:0;s:20:\"showdate-testimonial\";b:0;s:23:\"hideeditbox-testimonial\";b:0;s:15:\"title-portfolio\";s:39:\"%%title%% %%page%% %%sep%% %%sitename%%\";s:18:\"metadesc-portfolio\";s:0:\"\";s:17:\"metakey-portfolio\";s:0:\"\";s:17:\"noindex-portfolio\";b:0;s:18:\"showdate-portfolio\";b:0;s:21:\"hideeditbox-portfolio\";b:0;s:27:\"title-ptarchive-testimonial\";s:51:\"%%pt_plural%% Archive %%page%% %%sep%% %%sitename%%\";s:30:\"metadesc-ptarchive-testimonial\";s:0:\"\";s:29:\"metakey-ptarchive-testimonial\";s:0:\"\";s:29:\"bctitle-ptarchive-testimonial\";s:0:\"\";s:29:\"noindex-ptarchive-testimonial\";b:0;s:25:\"title-ptarchive-portfolio\";s:51:\"%%pt_plural%% Archive %%page%% %%sep%% %%sitename%%\";s:28:\"metadesc-ptarchive-portfolio\";s:0:\"\";s:27:\"metakey-ptarchive-portfolio\";s:0:\"\";s:27:\"bctitle-ptarchive-portfolio\";s:0:\"\";s:27:\"noindex-ptarchive-portfolio\";b:0;s:30:\"title-tax-testimonial-category\";s:53:\"%%term_title%% Archives %%page%% %%sep%% %%sitename%%\";s:33:\"metadesc-tax-testimonial-category\";s:0:\"\";s:32:\"metakey-tax-testimonial-category\";s:0:\"\";s:36:\"hideeditbox-tax-testimonial-category\";b:0;s:32:\"noindex-tax-testimonial-category\";b:0;s:28:\"title-tax-portfolio_category\";s:53:\"%%term_title%% Archives %%page%% %%sep%% %%sitename%%\";s:31:\"metadesc-tax-portfolio_category\";s:0:\"\";s:30:\"metakey-tax-portfolio_category\";s:0:\"\";s:34:\"hideeditbox-tax-portfolio_category\";b:0;s:30:\"noindex-tax-portfolio_category\";b:0;}","yes");
INSERT INTO `wp_options` VALUES("1797","wpseo","a:24:{s:14:\"blocking_files\";a:0:{}s:26:\"ignore_blog_public_warning\";b:0;s:31:\"ignore_meta_description_warning\";b:0;s:20:\"ignore_page_comments\";b:0;s:16:\"ignore_permalink\";b:0;s:11:\"ignore_tour\";b:1;s:15:\"ms_defaults_set\";b:0;s:23:\"theme_description_found\";s:0:\"\";s:21:\"theme_has_description\";b:0;s:19:\"tracking_popup_done\";b:1;s:7:\"version\";s:5:\"2.1.1\";s:10:\"seen_about\";b:1;s:11:\"alexaverify\";s:0:\"\";s:12:\"company_logo\";s:0:\"\";s:12:\"company_name\";s:0:\"\";s:17:\"company_or_person\";s:0:\"\";s:20:\"disableadvanced_meta\";b:1;s:12:\"googleverify\";s:43:\"tRpGK4U6vgjvGLoWKPV9NguOcknIokT_N1sOAEimSsM\";s:8:\"msverify\";s:0:\"\";s:11:\"person_name\";s:0:\"\";s:12:\"website_name\";s:0:\"\";s:22:\"alternate_website_name\";s:0:\"\";s:12:\"yandexverify\";s:0:\"\";s:14:\"yoast_tracking\";b:1;}","yes");
INSERT INTO `wp_options` VALUES("4665","wpseo_xml","a:15:{s:22:\"disable_author_sitemap\";b:1;s:16:\"enablexmlsitemap\";b:1;s:16:\"entries-per-page\";i:1000;s:14:\"xml_ping_yahoo\";b:0;s:12:\"xml_ping_ask\";b:0;s:30:\"post_types-post-not_in_sitemap\";b:0;s:30:\"post_types-page-not_in_sitemap\";b:0;s:36:\"post_types-attachment-not_in_sitemap\";b:0;s:34:\"taxonomies-category-not_in_sitemap\";b:0;s:34:\"taxonomies-post_tag-not_in_sitemap\";b:0;s:37:\"taxonomies-post_format-not_in_sitemap\";b:0;s:37:\"post_types-testimonial-not_in_sitemap\";b:0;s:35:\"post_types-portfolio-not_in_sitemap\";b:0;s:46:\"taxonomies-testimonial-category-not_in_sitemap\";b:0;s:44:\"taxonomies-portfolio_category-not_in_sitemap\";b:0;}","yes");
INSERT INTO `wp_options` VALUES("5078","limit_login_lockouts","a:0:{}","yes");
INSERT INTO `wp_options` VALUES("5079","limit_login_logged","a:277:{s:12:\"195.88.31.48\";a:1:{s:5:\"admin\";i:4;}s:14:\"195.114.19.195\";a:1:{s:5:\"admin\";i:4;}s:12:\"194.28.84.34\";a:1:{s:5:\"admin\";i:4;}s:14:\"89.248.166.153\";a:1:{s:5:\"admin\";i:1;}s:12:\"195.14.0.151\";a:1:{s:5:\"admin\";i:2;}s:13:\"109.74.200.74\";a:3:{s:5:\"admin\";i:2;s:4:\"test\";i:1;s:7:\"ioptima\";i:1;}s:9:\"10.3.8.80\";a:1:{s:4:\"test\";i:1;}s:14:\"64.134.191.253\";a:1:{s:4:\"test\";i:1;}s:14:\"109.228.18.144\";a:1:{s:5:\"admin\";i:1;}s:14:\"195.154.178.51\";a:1:{s:5:\"admin\";i:1;}s:12:\"216.70.90.99\";a:1:{s:5:\"admin\";i:1;}s:15:\"179.111.193.116\";a:1:{s:5:\"admin\";i:1;}s:13:\"85.197.157.72\";a:2:{s:5:\"admin\";i:2;s:4:\"test\";i:2;}s:14:\"190.121.71.105\";a:3:{s:5:\"admin\";i:1;s:4:\"test\";i:1;s:7:\"ioptima\";i:2;}s:13:\"144.76.180.27\";a:2:{s:5:\"admin\";i:2;s:4:\"test\";i:1;}s:15:\"179.111.222.175\";a:3:{s:5:\"admin\";i:2;s:4:\"test\";i:1;s:7:\"ioptima\";i:1;}s:14:\"186.64.146.244\";a:3:{s:5:\"admin\";i:2;s:4:\"test\";i:1;s:7:\"ioptima\";i:1;}s:15:\"220.245.255.104\";a:2:{s:5:\"admin\";i:1;s:7:\"ioptima\";i:1;}s:13:\"74.137.133.38\";a:1:{s:5:\"admin\";i:1;}s:11:\"94.4.28.168\";a:3:{s:5:\"admin\";i:2;s:4:\"test\";i:1;s:7:\"ioptima\";i:1;}s:12:\"96.43.177.52\";a:1:{s:5:\"admin\";i:1;}s:15:\"195.142.241.173\";a:1:{s:5:\"admin\";i:1;}s:12:\"89.74.245.92\";a:1:{s:5:\"admin\";i:1;}s:12:\"91.106.32.66\";a:2:{s:5:\"admin\";i:3;s:4:\"test\";i:1;}s:14:\"37.104.253.117\";a:3:{s:5:\"admin\";i:2;s:4:\"test\";i:1;s:7:\"ioptima\";i:1;}s:14:\"61.214.204.157\";a:2:{s:5:\"admin\";i:2;s:4:\"test\";i:2;}s:11:\"179.53.0.90\";a:3:{s:5:\"admin\";i:2;s:4:\"test\";i:3;s:7:\"ioptima\";i:3;}s:12:\"2.139.251.20\";a:3:{s:5:\"admin\";i:1;s:4:\"test\";i:1;s:7:\"ioptima\";i:2;}s:14:\"77.127.166.251\";a:3:{s:5:\"admin\";i:1;s:4:\"test\";i:2;s:7:\"ioptima\";i:1;}s:12:\"69.80.40.249\";a:1:{s:5:\"admin\";i:1;}s:13:\"109.130.22.96\";a:3:{s:5:\"admin\";i:2;s:4:\"test\";i:1;s:7:\"ioptima\";i:1;}s:13:\"181.1.147.155\";a:2:{s:5:\"admin\";i:1;s:4:\"test\";i:1;}s:14:\"188.26.238.147\";a:2:{s:5:\"admin\";i:3;s:4:\"test\";i:1;}s:14:\"79.180.135.232\";a:1:{s:5:\"admin\";i:1;}s:14:\"222.124.215.51\";a:2:{s:5:\"admin\";i:1;s:7:\"ioptima\";i:2;}s:13:\"46.116.168.18\";a:2:{s:5:\"admin\";i:2;s:4:\"test\";i:2;}s:13:\"112.205.1.231\";a:2:{s:5:\"admin\";i:2;s:4:\"test\";i:2;}s:15:\"221.120.224.147\";a:3:{s:5:\"admin\";i:2;s:4:\"test\";i:1;s:7:\"ioptima\";i:1;}s:14:\"218.155.243.75\";a:3:{s:5:\"admin\";i:1;s:4:\"test\";i:2;s:7:\"ioptima\";i:1;}s:14:\"163.178.104.96\";a:1:{s:5:\"admin\";i:1;}s:14:\"46.107.214.131\";a:3:{s:5:\"admin\";i:1;s:4:\"test\";i:1;s:7:\"ioptima\";i:1;}s:14:\"84.108.100.122\";a:3:{s:5:\"admin\";i:1;s:4:\"test\";i:2;s:7:\"ioptima\";i:1;}s:14:\"46.185.188.149\";a:2:{s:5:\"admin\";i:1;s:7:\"ioptima\";i:2;}s:14:\"186.82.183.130\";a:3:{s:5:\"admin\";i:1;s:7:\"ioptima\";i:2;s:4:\"test\";i:1;}s:15:\"115.134.147.167\";a:3:{s:5:\"admin\";i:2;s:4:\"test\";i:1;s:7:\"ioptima\";i:1;}s:14:\"190.80.132.211\";a:1:{s:5:\"admin\";i:1;}s:14:\"119.63.132.194\";a:1:{s:5:\"admin\";i:1;}s:15:\"194.224.254.178\";a:3:{s:5:\"admin\";i:1;s:4:\"test\";i:2;s:7:\"ioptima\";i:1;}s:14:\"89.134.175.163\";a:3:{s:5:\"admin\";i:1;s:4:\"test\";i:1;s:7:\"ioptima\";i:2;}s:12:\"85.250.93.50\";a:2:{s:5:\"admin\";i:1;s:4:\"test\";i:1;}s:14:\"94.122.176.233\";a:1:{s:5:\"admin\";i:1;}s:14:\"222.124.189.90\";a:3:{s:5:\"admin\";i:1;s:4:\"test\";i:2;s:7:\"ioptima\";i:1;}s:13:\"79.177.157.78\";a:3:{s:5:\"admin\";i:1;s:4:\"test\";i:2;s:7:\"ioptima\";i:1;}s:14:\"112.198.90.187\";a:3:{s:5:\"admin\";i:1;s:4:\"test\";i:1;s:7:\"ioptima\";i:2;}s:15:\"179.197.255.237\";a:2:{s:5:\"admin\";i:1;s:7:\"ioptima\";i:1;}s:15:\"179.180.237.195\";a:2:{s:5:\"admin\";i:1;s:4:\"test\";i:1;}s:11:\"36.72.4.157\";a:1:{s:5:\"admin\";i:1;}s:11:\"84.3.188.76\";a:2:{s:5:\"admin\";i:2;s:4:\"test\";i:2;}s:12:\"190.80.49.91\";a:3:{s:5:\"admin\";i:1;s:4:\"test\";i:1;s:7:\"ioptima\";i:2;}s:14:\"89.152.232.240\";a:3:{s:5:\"admin\";i:2;s:4:\"test\";i:1;s:7:\"ioptima\";i:1;}s:14:\"85.100.117.102\";a:2:{s:5:\"admin\";i:2;s:7:\"ioptima\";i:2;}s:13:\"41.220.173.99\";a:2:{s:5:\"admin\";i:1;s:4:\"test\";i:1;}s:14:\"37.248.254.164\";a:2:{s:5:\"admin\";i:1;s:4:\"test\";i:1;}s:14:\"31.214.110.189\";a:3:{s:5:\"admin\";i:1;s:4:\"test\";i:2;s:7:\"ioptima\";i:1;}s:11:\"5.54.43.167\";a:1:{s:5:\"admin\";i:1;}s:15:\"101.127.183.248\";a:1:{s:5:\"admin\";i:2;}s:13:\"78.30.186.171\";a:2:{s:5:\"admin\";i:1;s:4:\"test\";i:1;}s:13:\"50.136.39.115\";a:3:{s:5:\"admin\";i:2;s:7:\"ioptima\";i:1;s:4:\"test\";i:1;}s:10:\"41.63.3.50\";a:3:{s:5:\"admin\";i:1;s:4:\"test\";i:2;s:7:\"ioptima\";i:1;}s:12:\"78.143.92.88\";a:3:{s:5:\"admin\";i:1;s:4:\"test\";i:2;s:7:\"ioptima\";i:1;}s:15:\"202.130.124.130\";a:3:{s:5:\"admin\";i:2;s:4:\"test\";i:1;s:7:\"ioptima\";i:1;}s:12:\"36.81.35.212\";a:2:{s:5:\"admin\";i:1;s:7:\"ioptima\";i:2;}s:13:\"181.232.96.12\";a:1:{s:5:\"admin\";i:1;}s:12:\"95.16.61.191\";a:2:{s:5:\"admin\";i:1;s:7:\"ioptima\";i:1;}s:15:\"112.218.212.218\";a:3:{s:5:\"admin\";i:1;s:4:\"test\";i:2;s:7:\"ioptima\";i:1;}s:13:\"61.38.192.194\";a:1:{s:5:\"admin\";i:2;}s:15:\"201.127.163.176\";a:3:{s:5:\"admin\";i:1;s:4:\"test\";i:1;s:7:\"ioptima\";i:2;}s:14:\"65.124.232.124\";a:3:{s:5:\"admin\";i:2;s:7:\"ioptima\";i:1;s:4:\"test\";i:1;}s:14:\"187.44.161.150\";a:3:{s:5:\"admin\";i:2;s:7:\"ioptima\";i:1;s:4:\"test\";i:1;}s:12:\"14.32.120.71\";a:2:{s:4:\"test\";i:2;s:5:\"admin\";i:1;}s:12:\"109.72.63.80\";a:3:{s:4:\"test\";i:2;s:7:\"ioptima\";i:1;s:5:\"admin\";i:1;}s:13:\"91.205.154.84\";a:2:{s:5:\"admin\";i:2;s:7:\"ioptima\";i:1;}s:14:\"119.92.208.181\";a:2:{s:4:\"test\";i:2;s:7:\"ioptima\";i:2;}s:15:\"187.113.217.193\";a:1:{s:4:\"test\";i:1;}s:11:\"79.33.60.39\";a:2:{s:4:\"test\";i:2;s:7:\"ioptima\";i:2;}s:13:\"76.31.178.143\";a:1:{s:4:\"test\";i:1;}s:13:\"207.204.97.36\";a:2:{s:4:\"test\";i:1;s:7:\"ioptima\";i:2;}s:12:\"125.251.12.3\";a:2:{s:4:\"test\";i:2;s:7:\"ioptima\";i:2;}s:13:\"171.98.32.126\";a:2:{s:4:\"test\";i:1;s:7:\"ioptima\";i:1;}s:12:\"211.48.73.54\";a:1:{s:4:\"test\";i:1;}s:14:\"84.109.126.247\";a:1:{s:4:\"test\";i:1;}s:13:\"201.190.37.27\";a:3:{s:4:\"test\";i:1;s:5:\"admin\";i:1;s:7:\"ioptima\";i:1;}s:12:\"77.125.99.69\";a:3:{s:4:\"test\";i:2;s:7:\"ioptima\";i:1;s:5:\"admin\";i:1;}s:15:\"175.137.101.255\";a:2:{s:4:\"test\";i:2;s:7:\"ioptima\";i:2;}s:13:\"76.64.120.140\";a:1:{s:4:\"test\";i:1;}s:14:\"222.127.131.30\";a:2:{s:4:\"test\";i:1;s:7:\"ioptima\";i:1;}s:14:\"195.226.143.37\";a:1:{s:4:\"test\";i:3;}s:13:\"77.197.236.61\";a:2:{s:4:\"test\";i:1;s:5:\"admin\";i:1;}s:14:\"90.165.168.118\";a:2:{s:4:\"test\";i:1;s:7:\"ioptima\";i:1;}s:13:\"95.231.59.185\";a:2:{s:4:\"test\";i:2;s:7:\"ioptima\";i:1;}s:15:\"180.191.211.208\";a:1:{s:4:\"test\";i:1;}s:14:\"186.14.173.142\";a:2:{s:4:\"test\";i:2;s:5:\"admin\";i:1;}s:14:\"175.45.189.139\";a:1:{s:4:\"test\";i:1;}s:14:\"107.208.193.58\";a:2:{s:4:\"test\";i:1;s:7:\"ioptima\";i:1;}s:14:\"190.163.139.78\";a:1:{s:4:\"test\";i:1;}s:12:\"195.174.7.79\";a:1:{s:4:\"test\";i:1;}s:13:\"190.188.31.46\";a:1:{s:4:\"test\";i:1;}s:13:\"71.164.231.54\";a:2:{s:4:\"test\";i:2;s:7:\"ioptima\";i:2;}s:13:\"78.108.169.32\";a:2:{s:4:\"test\";i:1;s:5:\"admin\";i:1;}s:13:\"115.143.25.12\";a:2:{s:4:\"test\";i:1;s:7:\"ioptima\";i:3;}s:12:\"181.1.30.110\";a:2:{s:4:\"test\";i:1;s:7:\"ioptima\";i:1;}s:12:\"112.198.36.9\";a:3:{s:4:\"test\";i:1;s:7:\"ioptima\";i:1;s:5:\"admin\";i:1;}s:13:\"179.37.205.82\";a:3:{s:4:\"test\";i:1;s:5:\"admin\";i:1;s:7:\"ioptima\";i:1;}s:12:\"5.145.45.206\";a:2:{s:4:\"test\";i:2;s:5:\"admin\";i:1;}s:12:\"101.99.4.211\";a:3:{s:4:\"test\";i:2;s:5:\"admin\";i:1;s:7:\"ioptima\";i:1;}s:13:\"176.78.86.128\";a:1:{s:4:\"test\";i:3;}s:13:\"186.7.197.146\";a:2:{s:4:\"test\";i:2;s:7:\"ioptima\";i:2;}s:14:\"85.104.113.242\";a:2:{s:4:\"test\";i:2;s:7:\"ioptima\";i:1;}s:12:\"121.97.2.202\";a:3:{s:4:\"test\";i:2;s:7:\"ioptima\";i:1;s:5:\"admin\";i:1;}s:14:\"62.219.151.233\";a:1:{s:4:\"test\";i:2;}s:11:\"2.50.223.40\";a:1:{s:4:\"test\";i:1;}s:14:\"125.167.214.44\";a:1:{s:4:\"test\";i:1;}s:14:\"123.255.103.39\";a:1:{s:4:\"test\";i:1;}s:13:\"186.106.51.51\";a:1:{s:4:\"test\";i:1;}s:14:\"112.207.138.80\";a:2:{s:4:\"test\";i:1;s:7:\"ioptima\";i:2;}s:13:\"109.160.186.9\";a:2:{s:4:\"test\";i:2;s:7:\"ioptima\";i:2;}s:15:\"208.126.107.131\";a:1:{s:4:\"test\";i:1;}s:15:\"182.178.208.216\";a:1:{s:7:\"ioptima\";i:1;}s:15:\"180.191.106.155\";a:1:{s:7:\"ioptima\";i:1;}s:12:\"39.44.11.119\";a:2:{s:7:\"ioptima\";i:3;s:5:\"admin\";i:1;}s:13:\"72.27.190.193\";a:1:{s:7:\"ioptima\";i:1;}s:14:\"105.186.76.130\";a:2:{s:7:\"ioptima\";i:1;s:4:\"test\";i:2;}s:12:\"27.253.71.95\";a:1:{s:7:\"ioptima\";i:1;}s:15:\"210.217.238.143\";a:1:{s:7:\"ioptima\";i:1;}s:12:\"2.50.132.107\";a:2:{s:7:\"ioptima\";i:3;s:5:\"admin\";i:1;}s:14:\"115.188.146.14\";a:1:{s:7:\"ioptima\";i:1;}s:13:\"93.173.13.124\";a:2:{s:7:\"ioptima\";i:2;s:5:\"admin\";i:1;}s:12:\"103.251.83.6\";a:3:{s:7:\"ioptima\";i:2;s:5:\"admin\";i:1;s:4:\"test\";i:1;}s:14:\"189.103.25.200\";a:1:{s:7:\"ioptima\";i:2;}s:13:\"50.156.37.239\";a:2:{s:7:\"ioptima\";i:1;s:4:\"test\";i:1;}s:12:\"200.7.91.254\";a:1:{s:7:\"ioptima\";i:2;}s:15:\"139.192.198.223\";a:2:{s:7:\"ioptima\";i:1;s:5:\"admin\";i:2;}s:12:\"84.94.64.229\";a:1:{s:7:\"ioptima\";i:2;}s:14:\"189.131.75.118\";a:1:{s:7:\"ioptima\";i:1;}s:15:\"190.211.100.143\";a:1:{s:7:\"ioptima\";i:1;}s:12:\"39.44.24.199\";a:1:{s:7:\"ioptima\";i:1;}s:13:\"121.54.42.106\";a:2:{s:7:\"ioptima\";i:2;s:5:\"admin\";i:1;}s:13:\"89.66.216.196\";a:2:{s:7:\"ioptima\";i:1;s:4:\"test\";i:1;}s:12:\"49.145.30.25\";a:2:{s:7:\"ioptima\";i:2;s:4:\"test\";i:1;}s:14:\"180.244.173.88\";a:2:{s:7:\"ioptima\";i:1;s:5:\"admin\";i:1;}s:12:\"61.15.184.21\";a:3:{s:7:\"ioptima\";i:1;s:5:\"admin\";i:1;s:4:\"test\";i:2;}s:11:\"197.39.99.0\";a:1:{s:7:\"ioptima\";i:1;}s:11:\"36.75.57.66\";a:1:{s:7:\"ioptima\";i:1;}s:13:\"197.156.90.10\";a:3:{s:7:\"ioptima\";i:1;s:5:\"admin\";i:1;s:4:\"test\";i:1;}s:13:\"171.96.178.33\";a:1:{s:7:\"ioptima\";i:1;}s:13:\"182.19.173.37\";a:2:{s:7:\"ioptima\";i:2;s:4:\"test\";i:1;}s:13:\"46.117.111.30\";a:2:{s:7:\"ioptima\";i:2;s:5:\"admin\";i:1;}s:12:\"77.30.102.40\";a:1:{s:7:\"ioptima\";i:1;}s:12:\"212.36.207.2\";a:1:{s:5:\"admin\";i:1;}s:14:\"112.197.202.38\";a:1:{s:5:\"admin\";i:2;}s:13:\"197.27.11.130\";a:1:{s:7:\"ioptima\";i:1;}s:13:\"121.54.54.174\";a:1:{s:5:\"admin\";i:1;}s:13:\"70.115.228.90\";a:2:{s:5:\"admin\";i:1;s:7:\"ioptima\";i:2;}s:14:\"77.255.105.219\";a:1:{s:5:\"admin\";i:2;}s:13:\"222.127.67.97\";a:1:{s:5:\"admin\";i:1;}s:13:\"1.236.135.140\";a:3:{s:5:\"admin\";i:1;s:4:\"test\";i:2;s:7:\"ioptima\";i:1;}s:15:\"175.156.111.175\";a:2:{s:5:\"admin\";i:1;s:7:\"ioptima\";i:1;}s:14:\"79.180.114.100\";a:2:{s:5:\"admin\";i:1;s:4:\"test\";i:1;}s:15:\"197.248.120.234\";a:2:{s:5:\"admin\";i:1;s:7:\"ioptima\";i:1;}s:14:\"188.26.150.224\";a:2:{s:5:\"admin\";i:1;s:4:\"test\";i:1;}s:13:\"221.167.91.97\";a:2:{s:5:\"admin\";i:2;s:7:\"ioptima\";i:2;}s:14:\"210.213.92.242\";a:1:{s:5:\"admin\";i:1;}s:15:\"194.126.140.247\";a:2:{s:5:\"admin\";i:1;s:7:\"ioptima\";i:1;}s:14:\"88.235.170.154\";a:2:{s:5:\"admin\";i:1;s:4:\"test\";i:1;}s:13:\"196.36.113.18\";a:2:{s:5:\"admin\";i:1;s:4:\"test\";i:1;}s:14:\"77.249.208.180\";a:2:{s:5:\"admin\";i:1;s:7:\"ioptima\";i:1;}s:15:\"193.140.219.181\";a:2:{s:5:\"admin\";i:1;s:4:\"test\";i:1;}s:13:\"120.28.125.65\";a:2:{s:5:\"admin\";i:1;s:4:\"test\";i:2;}s:14:\"110.138.157.37\";a:1:{s:5:\"admin\";i:1;}s:15:\"112.135.121.171\";a:1:{s:5:\"admin\";i:1;}s:13:\"41.162.159.42\";a:1:{s:5:\"admin\";i:1;}s:13:\"62.80.225.188\";a:1:{s:5:\"admin\";i:1;}s:11:\"59.152.99.5\";a:2:{s:5:\"admin\";i:1;s:4:\"test\";i:1;}s:13:\"115.87.127.90\";a:1:{s:5:\"admin\";i:1;}s:13:\"77.77.209.218\";a:2:{s:5:\"admin\";i:1;s:4:\"test\";i:1;}s:14:\"88.249.225.207\";a:2:{s:5:\"admin\";i:1;s:7:\"ioptima\";i:1;}s:13:\"91.105.23.211\";a:3:{s:5:\"admin\";i:1;s:4:\"test\";i:2;s:7:\"ioptima\";i:1;}s:15:\"176.202.110.126\";a:1:{s:5:\"admin\";i:1;}s:13:\"37.105.75.117\";a:1:{s:5:\"admin\";i:1;}s:12:\"185.29.84.70\";a:1:{s:5:\"admin\";i:1;}s:10:\"2.51.9.233\";a:1:{s:5:\"admin\";i:1;}s:12:\"93.123.85.15\";a:2:{s:5:\"admin\";i:1;s:4:\"test\";i:3;}s:14:\"110.137.128.18\";a:1:{s:5:\"admin\";i:1;}s:14:\"212.36.215.162\";a:1:{s:5:\"admin\";i:1;}s:14:\"188.135.44.136\";a:1:{s:5:\"admin\";i:1;}s:11:\"31.11.115.0\";a:1:{s:5:\"admin\";i:1;}s:12:\"58.69.141.34\";a:1:{s:5:\"admin\";i:1;}s:13:\"79.132.91.149\";a:2:{s:5:\"admin\";i:1;s:4:\"test\";i:1;}s:15:\"121.119.109.205\";a:2:{s:4:\"test\";i:2;s:7:\"ioptima\";i:1;}s:15:\"197.204.118.245\";a:1:{s:4:\"test\";i:1;}s:13:\"78.108.169.35\";a:1:{s:4:\"test\";i:1;}s:14:\"197.148.41.128\";a:1:{s:4:\"test\";i:1;}s:13:\"115.66.222.44\";a:1:{s:4:\"test\";i:1;}s:10:\"78.3.48.27\";a:1:{s:4:\"test\";i:1;}s:13:\"36.83.124.104\";a:2:{s:4:\"test\";i:1;s:7:\"ioptima\";i:2;}s:13:\"39.44.245.140\";a:1:{s:4:\"test\";i:1;}s:13:\"92.99.209.189\";a:2:{s:4:\"test\";i:1;s:7:\"ioptima\";i:1;}s:14:\"222.238.232.33\";a:1:{s:4:\"test\";i:1;}s:13:\"79.169.96.112\";a:2:{s:4:\"test\";i:1;s:7:\"ioptima\";i:1;}s:14:\"188.50.243.209\";a:1:{s:4:\"test\";i:1;}s:15:\"203.111.234.115\";a:1:{s:4:\"test\";i:1;}s:15:\"103.250.189.153\";a:1:{s:4:\"test\";i:1;}s:11:\"81.134.20.2\";a:2:{s:4:\"test\";i:1;s:7:\"ioptima\";i:1;}s:13:\"89.103.136.80\";a:2:{s:4:\"test\";i:2;s:7:\"ioptima\";i:2;}s:13:\"89.143.187.12\";a:1:{s:4:\"test\";i:1;}s:12:\"88.250.192.3\";a:1:{s:4:\"test\";i:1;}s:13:\"218.39.142.97\";a:1:{s:4:\"test\";i:2;}s:11:\"83.15.70.81\";a:2:{s:4:\"test\";i:1;s:7:\"ioptima\";i:2;}s:13:\"93.55.178.203\";a:1:{s:4:\"test\";i:1;}s:13:\"111.88.54.212\";a:1:{s:4:\"test\";i:1;}s:14:\"79.182.152.216\";a:2:{s:4:\"test\";i:1;s:7:\"ioptima\";i:1;}s:12:\"93.55.179.48\";a:2:{s:4:\"test\";i:1;s:7:\"ioptima\";i:2;}s:13:\"145.2.230.218\";a:1:{s:4:\"test\";i:1;}s:13:\"93.173.173.79\";a:2:{s:4:\"test\";i:1;s:7:\"ioptima\";i:1;}s:13:\"58.239.97.237\";a:1:{s:4:\"test\";i:1;}s:13:\"121.54.54.249\";a:1:{s:4:\"test\";i:1;}s:12:\"72.50.85.117\";a:1:{s:4:\"test\";i:1;}s:14:\"41.218.221.119\";a:1:{s:4:\"test\";i:1;}s:15:\"176.106.203.177\";a:1:{s:4:\"test\";i:1;}s:11:\"2.50.47.117\";a:1:{s:4:\"test\";i:1;}s:14:\"203.215.123.97\";a:1:{s:4:\"test\";i:1;}s:14:\"14.192.215.173\";a:2:{s:4:\"test\";i:1;s:7:\"ioptima\";i:1;}s:13:\"94.96.113.219\";a:1:{s:4:\"test\";i:1;}s:12:\"39.33.54.250\";a:1:{s:4:\"test\";i:1;}s:12:\"60.50.89.171\";a:1:{s:4:\"test\";i:1;}s:13:\"109.73.82.182\";a:1:{s:4:\"test\";i:1;}s:13:\"92.52.238.133\";a:1:{s:4:\"test\";i:1;}s:11:\"85.65.3.186\";a:2:{s:4:\"test\";i:1;s:7:\"ioptima\";i:1;}s:13:\"212.54.122.90\";a:1:{s:4:\"test\";i:1;}s:12:\"92.83.118.59\";a:1:{s:7:\"ioptima\";i:1;}s:13:\"93.87.137.206\";a:1:{s:7:\"ioptima\";i:1;}s:11:\"77.59.248.2\";a:1:{s:7:\"ioptima\";i:1;}s:12:\"124.6.181.81\";a:1:{s:7:\"ioptima\";i:1;}s:15:\"123.255.103.209\";a:1:{s:7:\"ioptima\";i:1;}s:12:\"79.177.23.56\";a:1:{s:7:\"ioptima\";i:3;}s:15:\"191.255.226.173\";a:1:{s:7:\"ioptima\";i:2;}s:14:\"36.232.177.191\";a:1:{s:7:\"ioptima\";i:1;}s:14:\"190.162.67.246\";a:1:{s:7:\"ioptima\";i:1;}s:13:\"89.205.74.156\";a:1:{s:7:\"ioptima\";i:1;}s:12:\"92.97.139.24\";a:1:{s:7:\"ioptima\";i:1;}s:13:\"197.162.78.41\";a:1:{s:7:\"ioptima\";i:1;}s:13:\"197.39.123.95\";a:1:{s:7:\"ioptima\";i:1;}s:13:\"112.198.79.41\";a:1:{s:7:\"ioptima\";i:1;}s:14:\"79.119.150.187\";a:1:{s:7:\"ioptima\";i:1;}s:14:\"77.175.152.117\";a:1:{s:7:\"ioptima\";i:1;}s:10:\"2.88.69.78\";a:1:{s:7:\"ioptima\";i:1;}s:14:\"216.185.58.168\";a:1:{s:7:\"ioptima\";i:1;}s:12:\"111.94.48.15\";a:1:{s:7:\"ioptima\";i:1;}s:12:\"86.151.43.96\";a:1:{s:7:\"ioptima\";i:1;}s:12:\"79.179.149.6\";a:1:{s:7:\"ioptima\";i:1;}s:11:\"110.55.1.48\";a:1:{s:7:\"ioptima\";i:1;}s:12:\"178.61.6.156\";a:1:{s:7:\"ioptima\";i:1;}s:13:\"115.42.67.165\";a:1:{s:7:\"ioptima\";i:1;}s:13:\"94.113.233.93\";a:1:{s:7:\"ioptima\";i:1;}s:12:\"80.116.11.13\";a:1:{s:7:\"ioptima\";i:1;}s:11:\"31.44.76.65\";a:1:{s:7:\"ioptima\";i:1;}s:12:\"77.30.116.70\";a:1:{s:7:\"ioptima\";i:1;}s:13:\"78.167.23.191\";a:1:{s:7:\"ioptima\";i:1;}s:14:\"121.147.84.111\";a:1:{s:7:\"ioptima\";i:1;}s:14:\"112.207.246.89\";a:1:{s:7:\"ioptima\";i:1;}s:12:\"88.132.159.6\";a:1:{s:7:\"ioptima\";i:1;}s:12:\"93.42.39.211\";a:1:{s:7:\"ioptima\";i:1;}s:11:\"39.33.71.46\";a:1:{s:7:\"ioptima\";i:1;}s:13:\"93.103.175.95\";a:1:{s:7:\"ioptima\";i:1;}s:14:\"81.218.101.250\";a:1:{s:7:\"ioptima\";i:1;}s:14:\"188.229.26.177\";a:1:{s:7:\"ioptima\";i:1;}s:14:\"78.227.126.177\";a:1:{s:5:\"admin\";i:1;}}","no");
INSERT INTO `wp_options` VALUES("5080","limit_login_lockouts_total","586","no");
INSERT INTO `wp_options` VALUES("6295","WPLANG","","yes");
INSERT INTO `wp_options` VALUES("7544","auto_core_update_notified","a:4:{s:4:\"type\";s:6:\"manual\";s:5:\"email\";s:18:\"info@ioptima.co.il\";s:7:\"version\";s:5:\"4.0.1\";s:9:\"timestamp\";i:1416531883;}","yes");
INSERT INTO `wp_options` VALUES("12029","disable_comments_options","a:5:{s:19:\"disabled_post_types\";a:0:{}s:17:\"remove_everywhere\";b:0;s:9:\"permanent\";b:0;s:16:\"extra_post_types\";b:0;s:10:\"db_version\";i:6;}","yes");
INSERT INTO `wp_options` VALUES("12037","wpseo_permalinks","a:13:{s:15:\"cleanpermalinks\";b:0;s:24:\"cleanpermalink-extravars\";s:0:\"\";s:29:\"cleanpermalink-googlecampaign\";b:0;s:31:\"cleanpermalink-googlesitesearch\";b:0;s:15:\"cleanreplytocom\";b:0;s:10:\"cleanslugs\";b:1;s:14:\"hide-feedlinks\";b:0;s:12:\"hide-rsdlink\";b:0;s:14:\"hide-shortlink\";b:0;s:16:\"hide-wlwmanifest\";b:0;s:18:\"redirectattachment\";b:0;s:17:\"stripcategorybase\";b:0;s:13:\"trailingslash\";b:0;}","yes");
INSERT INTO `wp_options` VALUES("12038","wpseo_social","a:21:{s:9:\"fb_admins\";a:0:{}s:12:\"fbconnectkey\";s:32:\"c73e98db22aaeb04e79b5dc32f76e24c\";s:13:\"facebook_site\";s:0:\"\";s:13:\"instagram_url\";s:0:\"\";s:12:\"linkedin_url\";s:0:\"\";s:11:\"myspace_url\";s:0:\"\";s:16:\"og_default_image\";s:0:\"\";s:18:\"og_frontpage_title\";s:0:\"\";s:17:\"og_frontpage_desc\";s:0:\"\";s:18:\"og_frontpage_image\";s:0:\"\";s:9:\"opengraph\";b:1;s:10:\"googleplus\";b:0;s:13:\"pinterest_url\";s:0:\"\";s:15:\"pinterestverify\";s:0:\"\";s:14:\"plus-publisher\";s:0:\"\";s:7:\"twitter\";b:1;s:12:\"twitter_site\";s:0:\"\";s:17:\"twitter_card_type\";s:7:\"summary\";s:11:\"youtube_url\";s:0:\"\";s:15:\"google_plus_url\";s:0:\"\";s:10:\"fbadminapp\";s:0:\"\";}","yes");
INSERT INTO `wp_options` VALUES("12039","wpseo_rss","a:2:{s:9:\"rssbefore\";s:0:\"\";s:8:\"rssafter\";s:53:\"The post %%POSTLINK%% appeared first on %%BLOGLINK%%.\";}","yes");
INSERT INTO `wp_options` VALUES("12040","wpseo_internallinks","a:10:{s:20:\"breadcrumbs-404crumb\";s:25:\"Error 404: Page not found\";s:23:\"breadcrumbs-blog-remove\";b:0;s:20:\"breadcrumbs-boldlast\";b:0;s:25:\"breadcrumbs-archiveprefix\";s:12:\"Archives for\";s:18:\"breadcrumbs-enable\";b:0;s:16:\"breadcrumbs-home\";s:4:\"Home\";s:18:\"breadcrumbs-prefix\";s:0:\"\";s:24:\"breadcrumbs-searchprefix\";s:16:\"You searched for\";s:15:\"breadcrumbs-sep\";s:7:\"&raquo;\";s:23:\"post_types-post-maintax\";i:0;}","yes");
INSERT INTO `wp_options` VALUES("12970","rewrite_rules","a:120:{s:19:\"sitemap_index\\.xml$\";s:19:\"index.php?sitemap=1\";s:31:\"([^/]+?)-sitemap([0-9]+)?\\.xml$\";s:51:\"index.php?sitemap=$matches[1]&sitemap_n=$matches[2]\";s:24:\"([a-z]+)?-?sitemap\\.xsl$\";s:25:\"index.php?xsl=$matches[1]\";s:15:\"testimonials/?$\";s:31:\"index.php?post_type=testimonial\";s:45:\"testimonials/feed/(feed|rdf|rss|rss2|atom)/?$\";s:48:\"index.php?post_type=testimonial&feed=$matches[1]\";s:40:\"testimonials/(feed|rdf|rss|rss2|atom)/?$\";s:48:\"index.php?post_type=testimonial&feed=$matches[1]\";s:32:\"testimonials/page/([0-9]{1,})/?$\";s:49:\"index.php?post_type=testimonial&paged=$matches[1]\";s:18:\"portfolio_items/?$\";s:29:\"index.php?post_type=portfolio\";s:48:\"portfolio_items/feed/(feed|rdf|rss|rss2|atom)/?$\";s:46:\"index.php?post_type=portfolio&feed=$matches[1]\";s:43:\"portfolio_items/(feed|rdf|rss|rss2|atom)/?$\";s:46:\"index.php?post_type=portfolio&feed=$matches[1]\";s:35:\"portfolio_items/page/([0-9]{1,})/?$\";s:47:\"index.php?post_type=portfolio&paged=$matches[1]\";s:47:\"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?category_name=$matches[1]&feed=$matches[2]\";s:42:\"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?category_name=$matches[1]&feed=$matches[2]\";s:35:\"category/(.+?)/page/?([0-9]{1,})/?$\";s:53:\"index.php?category_name=$matches[1]&paged=$matches[2]\";s:17:\"category/(.+?)/?$\";s:35:\"index.php?category_name=$matches[1]\";s:44:\"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?tag=$matches[1]&feed=$matches[2]\";s:39:\"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?tag=$matches[1]&feed=$matches[2]\";s:32:\"tag/([^/]+)/page/?([0-9]{1,})/?$\";s:43:\"index.php?tag=$matches[1]&paged=$matches[2]\";s:14:\"tag/([^/]+)/?$\";s:25:\"index.php?tag=$matches[1]\";s:45:\"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?post_format=$matches[1]&feed=$matches[2]\";s:40:\"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?post_format=$matches[1]&feed=$matches[2]\";s:33:\"type/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?post_format=$matches[1]&paged=$matches[2]\";s:15:\"type/([^/]+)/?$\";s:33:\"index.php?post_format=$matches[1]\";s:39:\"testimonial/[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:49:\"testimonial/[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:69:\"testimonial/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:64:\"testimonial/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:64:\"testimonial/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:32:\"testimonial/([^/]+)/trackback/?$\";s:38:\"index.php?testimonial=$matches[1]&tb=1\";s:52:\"testimonial/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?testimonial=$matches[1]&feed=$matches[2]\";s:47:\"testimonial/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?testimonial=$matches[1]&feed=$matches[2]\";s:40:\"testimonial/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?testimonial=$matches[1]&paged=$matches[2]\";s:47:\"testimonial/([^/]+)/comment-page-([0-9]{1,})/?$\";s:51:\"index.php?testimonial=$matches[1]&cpage=$matches[2]\";s:32:\"testimonial/([^/]+)(/[0-9]+)?/?$\";s:50:\"index.php?testimonial=$matches[1]&page=$matches[2]\";s:28:\"testimonial/[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:38:\"testimonial/[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:58:\"testimonial/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:53:\"testimonial/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:53:\"testimonial/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:61:\"testimonial-category/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:59:\"index.php?testimonial-category=$matches[1]&feed=$matches[2]\";s:56:\"testimonial-category/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:59:\"index.php?testimonial-category=$matches[1]&feed=$matches[2]\";s:49:\"testimonial-category/([^/]+)/page/?([0-9]{1,})/?$\";s:60:\"index.php?testimonial-category=$matches[1]&paged=$matches[2]\";s:31:\"testimonial-category/([^/]+)/?$\";s:42:\"index.php?testimonial-category=$matches[1]\";s:43:\"portfolio_items/[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:53:\"portfolio_items/[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:73:\"portfolio_items/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:68:\"portfolio_items/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:68:\"portfolio_items/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:36:\"portfolio_items/([^/]+)/trackback/?$\";s:36:\"index.php?portfolio=$matches[1]&tb=1\";s:56:\"portfolio_items/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:48:\"index.php?portfolio=$matches[1]&feed=$matches[2]\";s:51:\"portfolio_items/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:48:\"index.php?portfolio=$matches[1]&feed=$matches[2]\";s:44:\"portfolio_items/([^/]+)/page/?([0-9]{1,})/?$\";s:49:\"index.php?portfolio=$matches[1]&paged=$matches[2]\";s:51:\"portfolio_items/([^/]+)/comment-page-([0-9]{1,})/?$\";s:49:\"index.php?portfolio=$matches[1]&cpage=$matches[2]\";s:36:\"portfolio_items/([^/]+)(/[0-9]+)?/?$\";s:48:\"index.php?portfolio=$matches[1]&page=$matches[2]\";s:32:\"portfolio_items/[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:42:\"portfolio_items/[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:62:\"portfolio_items/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:57:\"portfolio_items/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:57:\"portfolio_items/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:59:\"portfolio_category/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:57:\"index.php?portfolio_category=$matches[1]&feed=$matches[2]\";s:54:\"portfolio_category/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:57:\"index.php?portfolio_category=$matches[1]&feed=$matches[2]\";s:47:\"portfolio_category/([^/]+)/page/?([0-9]{1,})/?$\";s:58:\"index.php?portfolio_category=$matches[1]&paged=$matches[2]\";s:29:\"portfolio_category/([^/]+)/?$\";s:40:\"index.php?portfolio_category=$matches[1]\";s:12:\"robots\\.txt$\";s:18:\"index.php?robots=1\";s:48:\".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$\";s:18:\"index.php?feed=old\";s:20:\".*wp-app\\.php(/.*)?$\";s:19:\"index.php?error=403\";s:18:\".*wp-register.php$\";s:23:\"index.php?register=true\";s:32:\"feed/(feed|rdf|rss|rss2|atom)/?$\";s:27:\"index.php?&feed=$matches[1]\";s:27:\"(feed|rdf|rss|rss2|atom)/?$\";s:27:\"index.php?&feed=$matches[1]\";s:20:\"page/?([0-9]{1,})/?$\";s:28:\"index.php?&paged=$matches[1]\";s:27:\"comment-page-([0-9]{1,})/?$\";s:38:\"index.php?&page_id=5&cpage=$matches[1]\";s:41:\"comments/feed/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?&feed=$matches[1]&withcomments=1\";s:36:\"comments/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?&feed=$matches[1]&withcomments=1\";s:44:\"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:40:\"index.php?s=$matches[1]&feed=$matches[2]\";s:39:\"search/(.+)/(feed|rdf|rss|rss2|atom)/?$\";s:40:\"index.php?s=$matches[1]&feed=$matches[2]\";s:32:\"search/(.+)/page/?([0-9]{1,})/?$\";s:41:\"index.php?s=$matches[1]&paged=$matches[2]\";s:14:\"search/(.+)/?$\";s:23:\"index.php?s=$matches[1]\";s:47:\"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?author_name=$matches[1]&feed=$matches[2]\";s:42:\"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?author_name=$matches[1]&feed=$matches[2]\";s:35:\"author/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?author_name=$matches[1]&paged=$matches[2]\";s:17:\"author/([^/]+)/?$\";s:33:\"index.php?author_name=$matches[1]\";s:69:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:80:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]\";s:64:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$\";s:80:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]\";s:57:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$\";s:81:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]\";s:39:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$\";s:63:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]\";s:56:\"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:64:\"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]\";s:51:\"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$\";s:64:\"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]\";s:44:\"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$\";s:65:\"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]\";s:26:\"([0-9]{4})/([0-9]{1,2})/?$\";s:47:\"index.php?year=$matches[1]&monthnum=$matches[2]\";s:43:\"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?year=$matches[1]&feed=$matches[2]\";s:38:\"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?year=$matches[1]&feed=$matches[2]\";s:31:\"([0-9]{4})/page/?([0-9]{1,})/?$\";s:44:\"index.php?year=$matches[1]&paged=$matches[2]\";s:13:\"([0-9]{4})/?$\";s:26:\"index.php?year=$matches[1]\";s:27:\".?.+?/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:37:\".?.+?/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:57:\".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:20:\"(.?.+?)/trackback/?$\";s:35:\"index.php?pagename=$matches[1]&tb=1\";s:40:\"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?pagename=$matches[1]&feed=$matches[2]\";s:35:\"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?pagename=$matches[1]&feed=$matches[2]\";s:28:\"(.?.+?)/page/?([0-9]{1,})/?$\";s:48:\"index.php?pagename=$matches[1]&paged=$matches[2]\";s:35:\"(.?.+?)/comment-page-([0-9]{1,})/?$\";s:48:\"index.php?pagename=$matches[1]&cpage=$matches[2]\";s:20:\"(.?.+?)(/[0-9]+)?/?$\";s:47:\"index.php?pagename=$matches[1]&page=$matches[2]\";s:27:\"[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:37:\"[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:57:\"[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\"[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\"[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:20:\"([^/]+)/trackback/?$\";s:31:\"index.php?name=$matches[1]&tb=1\";s:40:\"([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?name=$matches[1]&feed=$matches[2]\";s:35:\"([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?name=$matches[1]&feed=$matches[2]\";s:28:\"([^/]+)/page/?([0-9]{1,})/?$\";s:44:\"index.php?name=$matches[1]&paged=$matches[2]\";s:35:\"([^/]+)/comment-page-([0-9]{1,})/?$\";s:44:\"index.php?name=$matches[1]&cpage=$matches[2]\";s:20:\"([^/]+)(/[0-9]+)?/?$\";s:43:\"index.php?name=$matches[1]&page=$matches[2]\";s:16:\"[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:26:\"[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:46:\"[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:41:\"[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:41:\"[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";}","yes");
INSERT INTO `wp_options` VALUES("12976","_site_transient_update_core","O:8:\"stdClass\":4:{s:7:\"updates\";a:1:{i:0;O:8:\"stdClass\":10:{s:8:\"response\";s:6:\"latest\";s:8:\"download\";s:59:\"https://downloads.wordpress.org/release/wordpress-4.2.2.zip\";s:6:\"locale\";s:5:\"en_US\";s:8:\"packages\";O:8:\"stdClass\":5:{s:4:\"full\";s:59:\"https://downloads.wordpress.org/release/wordpress-4.2.2.zip\";s:10:\"no_content\";s:70:\"https://downloads.wordpress.org/release/wordpress-4.2.2-no-content.zip\";s:11:\"new_bundled\";s:71:\"https://downloads.wordpress.org/release/wordpress-4.2.2-new-bundled.zip\";s:7:\"partial\";b:0;s:8:\"rollback\";b:0;}s:7:\"current\";s:5:\"4.2.2\";s:7:\"version\";s:5:\"4.2.2\";s:11:\"php_version\";s:5:\"5.2.4\";s:13:\"mysql_version\";s:3:\"5.0\";s:11:\"new_bundled\";s:3:\"4.1\";s:15:\"partial_version\";s:0:\"\";}}s:12:\"last_checked\";i:1433256726;s:15:\"version_checked\";s:5:\"4.2.2\";s:12:\"translations\";a:0:{}}","yes");
INSERT INTO `wp_options` VALUES("13209","_site_transient_timeout_browser_52fcc5c9bb837e35bcdb6a6f0af6ef5e","1433510144","yes");
INSERT INTO `wp_options` VALUES("13210","_site_transient_browser_52fcc5c9bb837e35bcdb6a6f0af6ef5e","a:9:{s:8:\"platform\";s:7:\"Windows\";s:4:\"name\";s:6:\"Chrome\";s:7:\"version\";s:12:\"43.0.2357.81\";s:10:\"update_url\";s:28:\"http://www.google.com/chrome\";s:7:\"img_src\";s:49:\"http://s.wordpress.org/images/browsers/chrome.png\";s:11:\"img_src_ssl\";s:48:\"https://wordpress.org/images/browsers/chrome.png\";s:15:\"current_version\";s:2:\"18\";s:7:\"upgrade\";b:0;s:8:\"insecure\";b:0;}","yes");
INSERT INTO `wp_options` VALUES("13211","can_compress_scripts","0","yes");
INSERT INTO `wp_options` VALUES("13213","_site_transient_timeout_browser_9979bee7064c5035270425d30c0be8f5","1433521543","yes");
INSERT INTO `wp_options` VALUES("13214","_site_transient_browser_9979bee7064c5035270425d30c0be8f5","a:9:{s:8:\"platform\";s:9:\"Macintosh\";s:4:\"name\";s:6:\"Chrome\";s:7:\"version\";s:12:\"43.0.2357.81\";s:10:\"update_url\";s:28:\"http://www.google.com/chrome\";s:7:\"img_src\";s:49:\"http://s.wordpress.org/images/browsers/chrome.png\";s:11:\"img_src_ssl\";s:48:\"https://wordpress.org/images/browsers/chrome.png\";s:15:\"current_version\";s:2:\"18\";s:7:\"upgrade\";b:0;s:8:\"insecure\";b:0;}","yes");
INSERT INTO `wp_options` VALUES("13230","_site_transient_timeout_browser_43d1522b603688bda36781305c878d46","1433525524","yes");
INSERT INTO `wp_options` VALUES("13231","_site_transient_browser_43d1522b603688bda36781305c878d46","a:9:{s:8:\"platform\";s:9:\"Macintosh\";s:4:\"name\";s:7:\"Firefox\";s:7:\"version\";s:4:\"38.0\";s:10:\"update_url\";s:23:\"http://www.firefox.com/\";s:7:\"img_src\";s:50:\"http://s.wordpress.org/images/browsers/firefox.png\";s:11:\"img_src_ssl\";s:49:\"https://wordpress.org/images/browsers/firefox.png\";s:15:\"current_version\";s:2:\"16\";s:7:\"upgrade\";b:0;s:8:\"insecure\";b:0;}","yes");
INSERT INTO `wp_options` VALUES("13251","_site_transient_update_themes","O:8:\"stdClass\":4:{s:12:\"last_checked\";i:1433256727;s:7:\"checked\";a:5:{s:13:\"twentyfifteen\";s:3:\"1.2\";s:14:\"twentyfourteen\";s:3:\"1.4\";s:14:\"twentythirteen\";s:3:\"1.5\";s:12:\"twentytwelve\";s:3:\"1.7\";s:5:\"twish\";s:5:\"1.0.1\";}s:8:\"response\";a:0:{}s:12:\"translations\";a:0:{}}","yes");
INSERT INTO `wp_options` VALUES("13320","_transient_timeout_wpseo_sitemap_cache_1_1","1433219000","no");
INSERT INTO `wp_options` VALUES("13321","_transient_wpseo_sitemap_cache_1_1","<sitemapindex xmlns=\"http://www.sitemaps.org/schemas/sitemap/0.9\">
<sitemap>
<loc>http://ioptima.co.il/page-sitemap.xml</loc>
<lastmod>2015-04-19T06:25:25+00:00</lastmod>
</sitemap>
<sitemap>
<loc>http://ioptima.co.il/attachment-sitemap.xml</loc>
<lastmod>2015-05-13T14:52:03+00:00</lastmod>
</sitemap>
<sitemap>
<loc>http://ioptima.co.il/category-sitemap.xml</loc>
<lastmod>2015-06-01T04:23:20+00:00</lastmod>
</sitemap>
<sitemap>
<loc>http://ioptima.co.il/post_tag-sitemap.xml</loc>
<lastmod>2015-06-01T04:23:20+00:00</lastmod>
</sitemap>
<sitemap>
<loc>http://ioptima.co.il/testimonial-category-sitemap.xml</loc>
<lastmod>2015-06-01T04:23:20+00:00</lastmod>
</sitemap>
<sitemap>
<loc>http://ioptima.co.il/portfolio_category-sitemap.xml</loc>
<lastmod>2015-06-01T04:23:20+00:00</lastmod>
</sitemap>
</sitemapindex>","no");
INSERT INTO `wp_options` VALUES("13328","_transient_wpseo_sitemap_cache_attachment_1","<urlset xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:image=\"http://www.google.com/schemas/sitemap-image/1.1\" xsi:schemaLocation=\"http://www.sitemaps.org/schemas/sitemap/0.9 http://www.sitemaps.org/schemas/sitemap/0.9/sitemap.xsd\" xmlns=\"http://www.sitemaps.org/schemas/sitemap/0.9\">
	<url>
		<loc>http://ioptima.co.il/?attachment_id=10</loc>
		<lastmod>2014-03-24T15:17:11+00:00</lastmod>
		<changefreq>weekly</changefreq>
		<priority>0.6</priority>
	</url>
	<url>
		<loc>http://ioptima.co.il/?attachment_id=36</loc>
		<lastmod>2014-03-24T18:23:43+00:00</lastmod>
		<changefreq>weekly</changefreq>
		<priority>0.6</priority>
	</url>
	<url>
		<loc>http://ioptima.co.il/?attachment_id=37</loc>
		<lastmod>2014-03-24T18:28:05+00:00</lastmod>
		<changefreq>weekly</changefreq>
		<priority>0.6</priority>
	</url>
	<url>
		<loc>http://ioptima.co.il/?attachment_id=38</loc>
		<lastmod>2014-03-24T18:41:41+00:00</lastmod>
		<changefreq>weekly</changefreq>
		<priority>0.6</priority>
	</url>
	<url>
		<loc>http://ioptima.co.il/?attachment_id=70</loc>
		<lastmod>2014-04-03T14:10:06+00:00</lastmod>
		<changefreq>weekly</changefreq>
		<priority>0.6</priority>
	</url>
	<url>
		<loc>http://ioptima.co.il/?attachment_id=74</loc>
		<lastmod>2014-04-04T15:59:19+00:00</lastmod>
		<changefreq>weekly</changefreq>
		<priority>0.6</priority>
	</url>
	<url>
		<loc>http://ioptima.co.il/?attachment_id=75</loc>
		<lastmod>2014-04-07T17:23:32+00:00</lastmod>
		<changefreq>weekly</changefreq>
		<priority>0.6</priority>
	</url>
	<url>
		<loc>http://ioptima.co.il/technology/the-ioptimate-system/scanner-2/</loc>
		<lastmod>2014-04-07T18:39:30+00:00</lastmod>
		<changefreq>weekly</changefreq>
		<priority>0.6</priority>
	</url>
	<url>
		<loc>http://ioptima.co.il/technology/the-ioptimate-system/scanner-1/</loc>
		<lastmod>2014-04-07T18:39:32+00:00</lastmod>
		<changefreq>weekly</changefreq>
		<priority>0.6</priority>
	</url>
	<url>
		<loc>http://ioptima.co.il/technology/class-procedure/class-principle-of-operation/</loc>
		<lastmod>2014-04-07T18:50:34+00:00</lastmod>
		<changefreq>weekly</changefreq>
		<priority>0.6</priority>
	</url>
	<url>
		<loc>http://ioptima.co.il/technology/class-procedure/procedure-6/</loc>
		<lastmod>2014-04-07T18:56:40+00:00</lastmod>
		<changefreq>weekly</changefreq>
		<priority>0.6</priority>
	</url>
	<url>
		<loc>http://ioptima.co.il/technology/class-procedure/procedure-1/</loc>
		<lastmod>2014-04-07T18:56:42+00:00</lastmod>
		<changefreq>weekly</changefreq>
		<priority>0.6</priority>
	</url>
	<url>
		<loc>http://ioptima.co.il/technology/class-procedure/procedure-2/</loc>
		<lastmod>2014-04-07T18:56:43+00:00</lastmod>
		<changefreq>weekly</changefreq>
		<priority>0.6</priority>
	</url>
	<url>
		<loc>http://ioptima.co.il/technology/class-procedure/procedure-3/</loc>
		<lastmod>2014-04-07T18:56:45+00:00</lastmod>
		<changefreq>weekly</changefreq>
		<priority>0.6</priority>
	</url>
	<url>
		<loc>http://ioptima.co.il/technology/class-procedure/procedure-4/</loc>
		<lastmod>2014-04-07T18:56:47+00:00</lastmod>
		<changefreq>weekly</changefreq>
		<priority>0.6</priority>
	</url>
	<url>
		<loc>http://ioptima.co.il/technology/class-procedure/procedure-5/</loc>
		<lastmod>2014-04-07T18:56:48+00:00</lastmod>
		<changefreq>weekly</changefreq>
		<priority>0.6</priority>
	</url>
	<url>
		<loc>http://ioptima.co.il/company/quality/quality-2/</loc>
		<lastmod>2014-04-17T15:17:14+00:00</lastmod>
		<changefreq>weekly</changefreq>
		<priority>0.6</priority>
	</url>
	<url>
		<loc>http://ioptima.co.il/for-physicians/class-benefits/venn-diagram/</loc>
		<lastmod>2014-04-17T15:52:15+00:00</lastmod>
		<changefreq>weekly</changefreq>
		<priority>0.6</priority>
	</url>
	<url>
		<loc>http://ioptima.co.il/for-physicians/class-benefits/the-surgical-procedure/</loc>
		<lastmod>2014-04-17T15:57:34+00:00</lastmod>
		<changefreq>weekly</changefreq>
		<priority>0.6</priority>
	</url>
	<url>
		<loc>http://ioptima.co.il/for-physicians/publications/class-a-novel-filtration-treatment-for-glaucoma-patients-2/</loc>
		<lastmod>2014-04-17T16:13:57+00:00</lastmod>
		<changefreq>weekly</changefreq>
		<priority>0.6</priority>
	</url>
	<url>
		<loc>http://ioptima.co.il/for-physicians/publications/class-co2-laser-assisted-sclerectomy-surgery/</loc>
		<lastmod>2014-04-17T16:13:59+00:00</lastmod>
		<changefreq>weekly</changefreq>
		<priority>0.6</priority>
	</url>
	<url>
		<loc>http://ioptima.co.il/for-physicians/publications/class-%c2%ady-laser-treats-glaucoma/</loc>
		<lastmod>2014-04-17T16:14:00+00:00</lastmod>
		<changefreq>weekly</changefreq>
		<priority>0.6</priority>
	</url>
	<url>
		<loc>http://ioptima.co.il/for-physicians/publications/co2-laser-assisted-deep-sclerectomy-in/</loc>
		<lastmod>2014-04-17T16:14:03+00:00</lastmod>
		<changefreq>weekly</changefreq>
		<priority>0.6</priority>
	</url>
	<url>
		<loc>http://ioptima.co.il/for-physicians/publications/co2-laser-assisted-sclerectomy-surgery-part-ii/</loc>
		<lastmod>2014-04-17T16:14:05+00:00</lastmod>
		<changefreq>weekly</changefreq>
		<priority>0.6</priority>
	</url>
	<url>
		<loc>http://ioptima.co.il/for-physicians/publications/co2-laser-assisted-sclerectomy-surgery/</loc>
		<lastmod>2014-04-17T16:14:06+00:00</lastmod>
		<changefreq>weekly</changefreq>
		<priority>0.6</priority>
	</url>
	<url>
		<loc>http://ioptima.co.il/for-physicians/publications/co2-laser-assisted-sclerectomy-surgery-part-i/</loc>
		<lastmod>2014-04-17T16:14:08+00:00</lastmod>
		<changefreq>weekly</changefreq>
		<priority>0.6</priority>
	</url>
	<url>
		<loc>http://ioptima.co.il/for-physicians/publications/long-term-results-of-class/</loc>
		<lastmod>2014-04-17T16:14:09+00:00</lastmod>
		<changefreq>weekly</changefreq>
		<priority>0.6</priority>
	</url>
	<url>
		<loc>http://ioptima.co.il/for-physicians/publications/class-a-novel-filtration-treatment-for-glaucoma-patients/</loc>
		<lastmod>2014-04-17T16:14:11+00:00</lastmod>
		<changefreq>weekly</changefreq>
		<priority>0.6</priority>
	</url>
	<url>
		<loc>http://ioptima.co.il/?attachment_id=116</loc>
		<lastmod>2014-04-17T16:27:38+00:00</lastmod>
		<changefreq>weekly</changefreq>
		<priority>0.6</priority>
	</url>
	<url>
		<loc>http://ioptima.co.il/?attachment_id=117</loc>
		<lastmod>2014-04-17T16:30:48+00:00</lastmod>
		<changefreq>weekly</changefreq>
		<priority>0.6</priority>
	</url>
	<url>
		<loc>http://ioptima.co.il/?attachment_id=118</loc>
		<lastmod>2014-04-17T16:31:09+00:00</lastmod>
		<changefreq>weekly</changefreq>
		<priority>0.6</priority>
	</url>
	<url>
		<loc>http://ioptima.co.il/?attachment_id=119</loc>
		<lastmod>2014-04-17T16:31:15+00:00</lastmod>
		<changefreq>weekly</changefreq>
		<priority>0.6</priority>
	</url>
	<url>
		<loc>http://ioptima.co.il/?attachment_id=120</loc>
		<lastmod>2014-04-17T16:31:21+00:00</lastmod>
		<changefreq>weekly</changefreq>
		<priority>0.6</priority>
	</url>
	<url>
		<loc>http://ioptima.co.il/?attachment_id=121</loc>
		<lastmod>2014-04-17T16:31:45+00:00</lastmod>
		<changefreq>weekly</changefreq>
		<priority>0.6</priority>
	</url>
	<url>
		<loc>http://ioptima.co.il/?attachment_id=122</loc>
		<lastmod>2014-04-17T16:32:06+00:00</lastmod>
		<changefreq>weekly</changefreq>
		<priority>0.6</priority>
	</url>
	<url>
		<loc>http://ioptima.co.il/?attachment_id=123</loc>
		<lastmod>2014-04-17T16:32:19+00:00</lastmod>
		<changefreq>weekly</changefreq>
		<priority>0.6</priority>
	</url>
	<url>
		<loc>http://ioptima.co.il/?attachment_id=124</loc>
		<lastmod>2014-04-17T16:32:23+00:00</lastmod>
		<changefreq>weekly</changefreq>
		<priority>0.6</priority>
	</url>
	<url>
		<loc>http://ioptima.co.il/technology/the-ioptimate-system/the-laser-control-unit/</loc>
		<lastmod>2014-04-17T17:05:24+00:00</lastmod>
		<changefreq>weekly</changefreq>
		<priority>0.6</priority>
	</url>
	<url>
		<loc>http://ioptima.co.il/technology/the-ioptimate-system/the-scanner/</loc>
		<lastmod>2014-04-17T17:07:22+00:00</lastmod>
		<changefreq>weekly</changefreq>
		<priority>0.6</priority>
	</url>
	<url>
		<loc>http://ioptima.co.il/?attachment_id=129</loc>
		<lastmod>2014-04-17T17:15:52+00:00</lastmod>
		<changefreq>weekly</changefreq>
		<priority>0.6</priority>
	</url>
	<url>
		<loc>http://ioptima.co.il/technology/class-procedure/class-principle-of-operation-2/</loc>
		<lastmod>2014-04-17T17:38:21+00:00</lastmod>
		<changefreq>weekly</changefreq>
		<priority>0.6</priority>
	</url>
	<url>
		<loc>http://ioptima.co.il/?attachment_id=137</loc>
		<lastmod>2014-04-24T17:39:53+00:00</lastmod>
		<changefreq>weekly</changefreq>
		<priority>0.6</priority>
	</url>
	<url>
		<loc>http://ioptima.co.il/?attachment_id=138</loc>
		<lastmod>2014-04-24T17:42:53+00:00</lastmod>
		<changefreq>weekly</changefreq>
		<priority>0.6</priority>
	</url>
	<url>
		<loc>http://ioptima.co.il/for-petients/ioptimas-solution/procedure-steps-4/</loc>
		<lastmod>2014-04-24T18:23:03+00:00</lastmod>
		<changefreq>weekly</changefreq>
		<priority>0.6</priority>
	</url>
	<url>
		<loc>http://ioptima.co.il/for-petients/ioptimas-solution/procedure-steps-1/</loc>
		<lastmod>2014-04-24T18:23:05+00:00</lastmod>
		<changefreq>weekly</changefreq>
		<priority>0.6</priority>
	</url>
	<url>
		<loc>http://ioptima.co.il/for-petients/ioptimas-solution/procedure-steps-2/</loc>
		<lastmod>2014-04-24T18:23:07+00:00</lastmod>
		<changefreq>weekly</changefreq>
		<priority>0.6</priority>
	</url>
	<url>
		<loc>http://ioptima.co.il/for-petients/ioptimas-solution/procedure-steps-3/</loc>
		<lastmod>2014-04-24T18:23:09+00:00</lastmod>
		<changefreq>weekly</changefreq>
		<priority>0.6</priority>
	</url>
	<url>
		<loc>http://ioptima.co.il/for-physicians/testimonials/shaarawy-tarek/</loc>
		<lastmod>2014-04-27T13:28:57+00:00</lastmod>
		<changefreq>weekly</changefreq>
		<priority>0.6</priority>
	</url>
	<url>
		<loc>http://ioptima.co.il/for-physicians/testimonials/assia-ehud/</loc>
		<lastmod>2014-04-27T13:28:59+00:00</lastmod>
		<changefreq>weekly</changefreq>
		<priority>0.6</priority>
	</url>
	<url>
		<loc>http://ioptima.co.il/for-physicians/testimonials/felix-gil-carrasco/</loc>
		<lastmod>2014-04-27T13:29:03+00:00</lastmod>
		<changefreq>weekly</changefreq>
		<priority>0.6</priority>
	</url>
	<url>
		<loc>http://ioptima.co.il/for-physicians/testimonials/melamed-shlomo/</loc>
		<lastmod>2014-04-27T13:29:05+00:00</lastmod>
		<changefreq>weekly</changefreq>
		<priority>0.6</priority>
	</url>
	<url>
		<loc>http://ioptima.co.il/for-physicians/testimonials/mermoud-andre/</loc>
		<lastmod>2014-04-27T13:29:07+00:00</lastmod>
		<changefreq>weekly</changefreq>
		<priority>0.6</priority>
	</url>
	<url>
		<loc>http://ioptima.co.il/for-physicians/testimonials/munoz-gonzalo/</loc>
		<lastmod>2014-04-27T13:29:09+00:00</lastmod>
		<changefreq>weekly</changefreq>
		<priority>0.6</priority>
	</url>
	<url>
		<loc>http://ioptima.co.il/for-physicians/class-benefits/venn-diagram-2/</loc>
		<lastmod>2014-04-27T13:46:09+00:00</lastmod>
		<changefreq>weekly</changefreq>
		<priority>0.6</priority>
	</url>
	<url>
		<loc>http://ioptima.co.il/?attachment_id=154</loc>
		<lastmod>2014-04-27T13:49:58+00:00</lastmod>
		<changefreq>weekly</changefreq>
		<priority>0.6</priority>
	</url>
	<url>
		<loc>http://ioptima.co.il/?attachment_id=165</loc>
		<lastmod>2014-05-01T08:15:18+00:00</lastmod>
		<changefreq>weekly</changefreq>
		<priority>0.6</priority>
	</url>
	<url>
		<loc>http://ioptima.co.il/?attachment_id=168</loc>
		<lastmod>2014-05-08T08:52:48+00:00</lastmod>
		<changefreq>weekly</changefreq>
		<priority>0.6</priority>
	</url>
	<url>
		<loc>http://ioptima.co.il/?attachment_id=170</loc>
		<lastmod>2014-05-08T09:17:47+00:00</lastmod>
		<changefreq>weekly</changefreq>
		<priority>0.6</priority>
	</url>
	<url>
		<loc>http://ioptima.co.il/?attachment_id=172</loc>
		<lastmod>2014-05-08T09:24:41+00:00</lastmod>
		<changefreq>weekly</changefreq>
		<priority>0.6</priority>
	</url>
	<url>
		<loc>http://ioptima.co.il/?attachment_id=173</loc>
		<lastmod>2014-05-08T12:04:29+00:00</lastmod>
		<changefreq>weekly</changefreq>
		<priority>0.6</priority>
	</url>
	<url>
		<loc>http://ioptima.co.il/?attachment_id=176</loc>
		<lastmod>2014-05-08T12:12:02+00:00</lastmod>
		<changefreq>weekly</changefreq>
		<priority>0.6</priority>
	</url>
	<url>
		<loc>http://ioptima.co.il/?attachment_id=177</loc>
		<lastmod>2014-05-08T14:55:23+00:00</lastmod>
		<changefreq>weekly</changefreq>
		<priority>0.6</priority>
	</url>
	<url>
		<loc>http://ioptima.co.il/?attachment_id=180</loc>
		<lastmod>2014-05-22T11:43:13+00:00</lastmod>
		<changefreq>weekly</changefreq>
		<priority>0.6</priority>
	</url>
	<url>
		<loc>http://ioptima.co.il/?attachment_id=185</loc>
		<lastmod>2014-05-26T08:31:14+00:00</lastmod>
		<changefreq>weekly</changefreq>
		<priority>0.6</priority>
	</url>
	<url>
		<loc>http://ioptima.co.il/?attachment_id=193</loc>
		<lastmod>2014-06-02T15:01:34+00:00</lastmod>
		<changefreq>weekly</changefreq>
		<priority>0.6</priority>
	</url>
	<url>
		<loc>http://ioptima.co.il/company/management/nurit-radin-vp-marketing-sales/</loc>
		<lastmod>2014-06-02T18:18:07+00:00</lastmod>
		<changefreq>weekly</changefreq>
		<priority>0.6</priority>
	</url>
	<url>
		<loc>http://ioptima.co.il/company/management/ronen-castro-ceo/</loc>
		<lastmod>2014-06-02T18:18:08+00:00</lastmod>
		<changefreq>weekly</changefreq>
		<priority>0.6</priority>
	</url>
	<url>
		<loc>http://ioptima.co.il/company/management/amnon-nahum-sharon-coo/</loc>
		<lastmod>2014-06-02T18:18:10+00:00</lastmod>
		<changefreq>weekly</changefreq>
		<priority>0.6</priority>
	</url>
	<url>
		<loc>http://ioptima.co.il/company/management/assaf-gur-cto/</loc>
		<lastmod>2014-06-02T18:18:11+00:00</lastmod>
		<changefreq>weekly</changefreq>
		<priority>0.6</priority>
	</url>
	<url>
		<loc>http://ioptima.co.il/company/management/itai-bar-natan-cfo/</loc>
		<lastmod>2014-06-02T18:18:13+00:00</lastmod>
		<changefreq>weekly</changefreq>
		<priority>0.6</priority>
	</url>
	<url>
		<loc>http://ioptima.co.il/?attachment_id=200</loc>
		<lastmod>2014-06-09T12:34:46+00:00</lastmod>
		<changefreq>weekly</changefreq>
		<priority>0.6</priority>
	</url>
	<url>
		<loc>http://ioptima.co.il/?attachment_id=201</loc>
		<lastmod>2014-06-09T12:34:59+00:00</lastmod>
		<changefreq>weekly</changefreq>
		<priority>0.6</priority>
	</url>
	<url>
		<loc>http://ioptima.co.il/?attachment_id=205</loc>
		<lastmod>2014-06-09T13:10:16+00:00</lastmod>
		<changefreq>weekly</changefreq>
		<priority>0.6</priority>
	</url>
	<url>
		<loc>http://ioptima.co.il/company/management/ronen-castro-ceo-2/</loc>
		<lastmod>2014-06-16T07:10:17+00:00</lastmod>
		<changefreq>weekly</changefreq>
		<priority>0.6</priority>
	</url>
	<url>
		<loc>http://ioptima.co.il/?attachment_id=211</loc>
		<lastmod>2014-06-23T06:58:25+00:00</lastmod>
		<changefreq>weekly</changefreq>
		<priority>0.6</priority>
	</url>
	<url>
		<loc>http://ioptima.co.il/company/management/maital-ben-hur-clinical-manager-2/</loc>
		<lastmod>2014-06-23T12:50:08+00:00</lastmod>
		<changefreq>weekly</changefreq>
		<priority>0.6</priority>
	</url>
	<url>
		<loc>http://ioptima.co.il/company/management/maital-ben-hur-clinical-manager-3/</loc>
		<lastmod>2014-06-23T12:52:44+00:00</lastmod>
		<changefreq>weekly</changefreq>
		<priority>0.6</priority>
	</url>
	<url>
		<loc>http://ioptima.co.il/for-physicians/publications/p254-mauricio-turati-2/</loc>
		<lastmod>2014-07-01T14:43:53+00:00</lastmod>
		<changefreq>weekly</changefreq>
		<priority>0.6</priority>
	</url>
	<url>
		<loc>http://ioptima.co.il/?attachment_id=218</loc>
		<lastmod>2014-07-02T06:02:34+00:00</lastmod>
		<changefreq>weekly</changefreq>
		<priority>0.6</priority>
	</url>
	<url>
		<loc>http://ioptima.co.il/for-physicians/publications/p254-mauricio-turati-page-001-2/</loc>
		<lastmod>2014-07-02T06:04:18+00:00</lastmod>
		<changefreq>weekly</changefreq>
		<priority>0.6</priority>
	</url>
	<url>
		<loc>http://ioptima.co.il/for-physicians/publications/eyeworld-may-2014_class-act-why-a-new-co2-laser-is-competing-with-the-gold-standard-page-001/</loc>
		<lastmod>2014-07-02T07:00:04+00:00</lastmod>
		<changefreq>weekly</changefreq>
		<priority>0.6</priority>
	</url>
	<url>
		<loc>http://ioptima.co.il/for-physicians/publications/class-y-laser-treats-glaucoma-asia-page-001/</loc>
		<lastmod>2014-07-02T07:07:07+00:00</lastmod>
		<changefreq>weekly</changefreq>
		<priority>0.6</priority>
	</url>
	<url>
		<loc>http://ioptima.co.il/for-physicians/publications/ophthalmology-time-eu-class_may14_pdf-assia-and-melamed-page-001/</loc>
		<lastmod>2014-07-02T07:43:51+00:00</lastmod>
		<changefreq>weekly</changefreq>
		<priority>0.6</priority>
	</url>
	<url>
		<loc>http://ioptima.co.il/?attachment_id=223</loc>
		<lastmod>2014-07-02T07:45:18+00:00</lastmod>
		<changefreq>weekly</changefreq>
		<priority>0.6</priority>
	</url>
	<url>
		<loc>http://ioptima.co.il/for-physicians/publications/ophthalmology-time-us-co2-laser-surgery-a-new-option-for-glaucoma-page-001/</loc>
		<lastmod>2014-07-02T09:10:39+00:00</lastmod>
		<changefreq>weekly</changefreq>
		<priority>0.6</priority>
	</url>
	<url>
		<loc>http://ioptima.co.il/?attachment_id=225</loc>
		<lastmod>2014-07-02T09:11:35+00:00</lastmod>
		<changefreq>weekly</changefreq>
		<priority>0.6</priority>
	</url>
	<url>
		<loc>http://ioptima.co.il/for-physicians/publications/eurotimes-industy-brief-may-2014-p-43-page-001/</loc>
		<lastmod>2014-07-02T09:17:04+00:00</lastmod>
		<changefreq>weekly</changefreq>
		<priority>0.6</priority>
	</url>
	<url>
		<loc>http://ioptima.co.il/?attachment_id=227</loc>
		<lastmod>2014-07-02T09:17:38+00:00</lastmod>
		<changefreq>weekly</changefreq>
		<priority>0.6</priority>
	</url>
	<url>
		<loc>http://ioptima.co.il/?attachment_id=228</loc>
		<lastmod>2014-07-02T12:45:43+00:00</lastmod>
		<changefreq>weekly</changefreq>
		<priority>0.6</priority>
	</url>
	<url>
		<loc>http://ioptima.co.il/?attachment_id=275</loc>
		<lastmod>2014-07-16T05:55:27+00:00</lastmod>
		<changefreq>weekly</changefreq>
		<priority>0.6</priority>
	</url>
	<url>
		<loc>http://ioptima.co.il/?attachment_id=276</loc>
		<lastmod>2014-07-16T05:55:49+00:00</lastmod>
		<changefreq>weekly</changefreq>
		<priority>0.6</priority>
	</url>
	<url>
		<loc>http://ioptima.co.il/?attachment_id=277</loc>
		<lastmod>2014-07-16T05:57:05+00:00</lastmod>
		<changefreq>weekly</changefreq>
		<priority>0.6</priority>
	</url>
	<url>
		<loc>http://ioptima.co.il/?attachment_id=278</loc>
		<lastmod>2014-07-16T05:58:50+00:00</lastmod>
		<changefreq>weekly</changefreq>
		<priority>0.6</priority>
	</url>
	<url>
		<loc>http://ioptima.co.il/?attachment_id=281</loc>
		<lastmod>2014-07-16T06:34:56+00:00</lastmod>
		<changefreq>weekly</changefreq>
		<priority>0.6</priority>
	</url>
	<url>
		<loc>http://ioptima.co.il/?attachment_id=282</loc>
		<lastmod>2014-07-16T06:35:50+00:00</lastmod>
		<changefreq>weekly</changefreq>
		<priority>0.6</priority>
	</url>
	<url>
		<loc>http://ioptima.co.il/?attachment_id=283</loc>
		<lastmod>2014-07-16T06:36:16+00:00</lastmod>
		<changefreq>weekly</changefreq>
		<priority>0.6</priority>
	</url>
	<url>
		<loc>http://ioptima.co.il/?attachment_id=287</loc>
		<lastmod>2014-07-16T06:38:47+00:00</lastmod>
		<changefreq>weekly</changefreq>
		<priority>0.6</priority>
	</url>
	<url>
		<loc>http://ioptima.co.il/?attachment_id=301</loc>
		<lastmod>2014-07-28T18:09:59+00:00</lastmod>
		<changefreq>weekly</changefreq>
		<priority>0.6</priority>
	</url>
	<url>
		<loc>http://ioptima.co.il/?attachment_id=303</loc>
		<lastmod>2014-07-28T18:31:34+00:00</lastmod>
		<changefreq>weekly</changefreq>
		<priority>0.6</priority>
	</url>
	<url>
		<loc>http://ioptima.co.il/?attachment_id=325</loc>
		<lastmod>2014-08-05T11:45:00+00:00</lastmod>
		<changefreq>weekly</changefreq>
		<priority>0.6</priority>
	</url>
	<url>
		<loc>http://ioptima.co.il/?attachment_id=326</loc>
		<lastmod>2014-08-05T11:46:55+00:00</lastmod>
		<changefreq>weekly</changefreq>
		<priority>0.6</priority>
	</url>
	<url>
		<loc>http://ioptima.co.il/?attachment_id=329</loc>
		<lastmod>2014-08-05T12:27:15+00:00</lastmod>
		<changefreq>weekly</changefreq>
		<priority>0.6</priority>
	</url>
	<url>
		<loc>http://ioptima.co.il/?attachment_id=357</loc>
		<lastmod>2014-08-21T13:54:18+00:00</lastmod>
		<changefreq>weekly</changefreq>
		<priority>0.6</priority>
	</url>
	<url>
		<loc>http://ioptima.co.il/?attachment_id=358</loc>
		<lastmod>2014-08-21T13:54:22+00:00</lastmod>
		<changefreq>weekly</changefreq>
		<priority>0.6</priority>
	</url>
	<url>
		<loc>http://ioptima.co.il/?attachment_id=359</loc>
		<lastmod>2014-08-21T14:03:06+00:00</lastmod>
		<changefreq>weekly</changefreq>
		<priority>0.6</priority>
	</url>
	<url>
		<loc>http://ioptima.co.il/?attachment_id=361</loc>
		<lastmod>2014-08-24T06:18:53+00:00</lastmod>
		<changefreq>weekly</changefreq>
		<priority>0.6</priority>
	</url>
	<url>
		<loc>http://ioptima.co.il/?attachment_id=362</loc>
		<lastmod>2014-08-24T06:19:02+00:00</lastmod>
		<changefreq>weekly</changefreq>
		<priority>0.6</priority>
	</url>
	<url>
		<loc>http://ioptima.co.il/?attachment_id=385</loc>
		<lastmod>2014-09-21T06:36:23+00:00</lastmod>
		<changefreq>weekly</changefreq>
		<priority>0.6</priority>
	</url>
	<url>
		<loc>http://ioptima.co.il/?attachment_id=386</loc>
		<lastmod>2014-09-21T06:36:24+00:00</lastmod>
		<changefreq>weekly</changefreq>
		<priority>0.6</priority>
	</url>
	<url>
		<loc>http://ioptima.co.il/?attachment_id=387</loc>
		<lastmod>2014-09-21T06:38:01+00:00</lastmod>
		<changefreq>weekly</changefreq>
		<priority>0.6</priority>
	</url>
	<url>
		<loc>http://ioptima.co.il/?attachment_id=388</loc>
		<lastmod>2014-09-21T06:39:53+00:00</lastmod>
		<changefreq>weekly</changefreq>
		<priority>0.6</priority>
	</url>
	<url>
		<loc>http://ioptima.co.il/?attachment_id=391</loc>
		<lastmod>2014-09-23T10:57:14+00:00</lastmod>
		<changefreq>weekly</changefreq>
		<priority>0.6</priority>
	</url>
	<url>
		<loc>http://ioptima.co.il/?attachment_id=393</loc>
		<lastmod>2014-09-23T11:04:57+00:00</lastmod>
		<changefreq>weekly</changefreq>
		<priority>0.6</priority>
	</url>
	<url>
		<loc>http://ioptima.co.il/?attachment_id=401</loc>
		<lastmod>2014-10-30T09:18:38+00:00</lastmod>
		<changefreq>weekly</changefreq>
		<priority>0.6</priority>
	</url>
	<url>
		<loc>http://ioptima.co.il/?attachment_id=403</loc>
		<lastmod>2014-10-30T15:01:22+00:00</lastmod>
		<changefreq>weekly</changefreq>
		<priority>0.6</priority>
	</url>
	<url>
		<loc>http://ioptima.co.il/?attachment_id=404</loc>
		<lastmod>2014-10-30T15:01:29+00:00</lastmod>
		<changefreq>weekly</changefreq>
		<priority>0.6</priority>
	</url>
	<url>
		<loc>http://ioptima.co.il/?attachment_id=405</loc>
		<lastmod>2014-10-30T15:01:31+00:00</lastmod>
		<changefreq>weekly</changefreq>
		<priority>0.6</priority>
	</url>
	<url>
		<loc>http://ioptima.co.il/?attachment_id=406</loc>
		<lastmod>2014-10-30T15:01:32+00:00</lastmod>
		<changefreq>weekly</changefreq>
		<priority>0.6</priority>
	</url>
	<url>
		<loc>http://ioptima.co.il/?attachment_id=407</loc>
		<lastmod>2014-10-30T15:01:33+00:00</lastmod>
		<changefreq>weekly</changefreq>
		<priority>0.6</priority>
	</url>
	<url>
		<loc>http://ioptima.co.il/?attachment_id=414</loc>
		<lastmod>2014-11-05T15:49:01+00:00</lastmod>
		<changefreq>weekly</changefreq>
		<priority>0.6</priority>
	</url>
	<url>
		<loc>http://ioptima.co.il/?attachment_id=423</loc>
		<lastmod>2014-11-11T13:17:56+00:00</lastmod>
		<changefreq>weekly</changefreq>
		<priority>0.6</priority>
	</url>
	<url>
		<loc>http://ioptima.co.il/?attachment_id=428</loc>
		<lastmod>2014-11-27T09:59:33+00:00</lastmod>
		<changefreq>weekly</changefreq>
		<priority>0.6</priority>
	</url>
	<url>
		<loc>http://ioptima.co.il/?attachment_id=429</loc>
		<lastmod>2014-11-27T09:59:37+00:00</lastmod>
		<changefreq>weekly</changefreq>
		<priority>0.6</priority>
	</url>
	<url>
		<loc>http://ioptima.co.il/?attachment_id=430</loc>
		<lastmod>2014-11-27T09:59:50+00:00</lastmod>
		<changefreq>weekly</changefreq>
		<priority>0.6</priority>
	</url>
	<url>
		<loc>http://ioptima.co.il/?attachment_id=431</loc>
		<lastmod>2014-11-27T09:59:52+00:00</lastmod>
		<changefreq>weekly</changefreq>
		<priority>0.6</priority>
	</url>
	<url>
		<loc>http://ioptima.co.il/?attachment_id=433</loc>
		<lastmod>2014-11-30T09:08:57+00:00</lastmod>
		<changefreq>weekly</changefreq>
		<priority>0.6</priority>
	</url>
	<url>
		<loc>http://ioptima.co.il/?attachment_id=435</loc>
		<lastmod>2014-12-03T14:33:03+00:00</lastmod>
		<changefreq>weekly</changefreq>
		<priority>0.6</priority>
	</url>
	<url>
		<loc>http://ioptima.co.il/?attachment_id=436</loc>
		<lastmod>2014-12-03T14:34:06+00:00</lastmod>
		<changefreq>weekly</changefreq>
		<priority>0.6</priority>
	</url>
	<url>
		<loc>http://ioptima.co.il/?attachment_id=444</loc>
		<lastmod>2015-01-14T11:45:52+00:00</lastmod>
		<changefreq>weekly</changefreq>
		<priority>0.6</priority>
	</url>
	<url>
		<loc>http://ioptima.co.il/?attachment_id=445</loc>
		<lastmod>2015-01-14T11:46:08+00:00</lastmod>
		<changefreq>weekly</changefreq>
		<priority>0.6</priority>
	</url>
	<url>
		<loc>http://ioptima.co.il/for-physicians/publications/glaucoma-surgery_-taking-the-sub-conjunctival-route-_tarek-shaarawy-middle-east-african-journal-of-ophthalmology-2-page-003/</loc>
		<lastmod>2015-01-14T12:45:35+00:00</lastmod>
		<changefreq>weekly</changefreq>
		<priority>0.6</priority>
	</url>
	<url>
		<loc>http://ioptima.co.il/?attachment_id=454</loc>
		<lastmod>2015-02-10T07:06:50+00:00</lastmod>
		<changefreq>weekly</changefreq>
		<priority>0.6</priority>
	</url>
	<url>
		<loc>http://ioptima.co.il/?attachment_id=455</loc>
		<lastmod>2015-02-10T07:10:23+00:00</lastmod>
		<changefreq>weekly</changefreq>
		<priority>0.6</priority>
	</url>
	<url>
		<loc>http://ioptima.co.il/?attachment_id=461</loc>
		<lastmod>2015-03-11T12:59:09+00:00</lastmod>
		<changefreq>weekly</changefreq>
		<priority>0.6</priority>
	</url>
	<url>
		<loc>http://ioptima.co.il/?attachment_id=463</loc>
		<lastmod>2015-03-11T13:03:02+00:00</lastmod>
		<changefreq>weekly</changefreq>
		<priority>0.6</priority>
	</url>
	<url>
		<loc>http://ioptima.co.il/?attachment_id=464</loc>
		<lastmod>2015-03-11T13:05:13+00:00</lastmod>
		<changefreq>weekly</changefreq>
		<priority>0.6</priority>
	</url>
	<url>
		<loc>http://ioptima.co.il/?attachment_id=467</loc>
		<lastmod>2015-03-29T12:16:21+00:00</lastmod>
		<changefreq>weekly</changefreq>
		<priority>0.6</priority>
	</url>
	<url>
		<loc>http://ioptima.co.il/?attachment_id=468</loc>
		<lastmod>2015-03-29T12:16:45+00:00</lastmod>
		<changefreq>weekly</changefreq>
		<priority>0.6</priority>
	</url>
	<url>
		<loc>http://ioptima.co.il/?attachment_id=475</loc>
		<lastmod>2015-05-13T14:52:03+00:00</lastmod>
		<changefreq>weekly</changefreq>
		<priority>0.6</priority>
	</url>
</urlset>","no");
INSERT INTO `wp_options` VALUES("13345","_transient_timeout_plugin_slugs","1433343134","no");
INSERT INTO `wp_options` VALUES("13346","_transient_plugin_slugs","a:15:{i:0;s:53:\"adaptive-options-framework-import-export/function.php\";i:1;s:43:\"adaptive-shortcodes/adaptive-shortcodes.php\";i:2;s:35:\"admin-menu-tree-page-view/index.php\";i:3;s:51:\"all-in-one-wp-security-and-firewall/wp-security.php\";i:4;s:37:\"breadcrumb-navxt/breadcrumb-navxt.php\";i:5;s:36:\"contact-form-7/wp-contact-form-7.php\";i:6;s:33:\"custom-favicon/custom-favicon.php\";i:7;s:37:\"disable-comments/disable-comments.php\";i:8;s:39:\"options-framework/options-framework.php\";i:9;s:47:\"really-simple-captcha/really-simple-captcha.php\";i:10;s:23:\"revslider/revslider.php\";i:11;s:24:\"simple-lightbox/main.php\";i:12;s:27:\"woosidebars/woosidebars.php\";i:13;s:24:\"wordpress-seo/wp-seo.php\";i:14;s:27:\"js_composer/js_composer.php\";}","no");
INSERT INTO `wp_options` VALUES("13357","_transient_timeout_feed_ac0b00fe65abe10e0c5b588f3ed8c7ca","1433269709","no");
INSERT INTO `wp_options` VALUES("13358","_transient_timeout_feed_mod_ac0b00fe65abe10e0c5b588f3ed8c7ca","1433269709","no");
INSERT INTO `wp_options` VALUES("13359","_transient_feed_mod_ac0b00fe65abe10e0c5b588f3ed8c7ca","1433226509","no");
INSERT INTO `wp_options` VALUES("13360","_transient_timeout_feed_d117b5738fbd35bd8c0391cda1f2b5d9","1433269710","no");
INSERT INTO `wp_options` VALUES("13361","_transient_feed_d117b5738fbd35bd8c0391cda1f2b5d9","a:4:{s:5:\"child\";a:1:{s:0:\"\";a:1:{s:3:\"rss\";a:1:{i:0;a:6:{s:4:\"data\";s:3:\"


\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:7:\"version\";s:3:\"2.0\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:1:{s:0:\"\";a:1:{s:7:\"channel\";a:1:{i:0;a:6:{s:4:\"data\";s:61:\"
	
	
	
	




















































\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:1:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:16:\"WordPress Planet\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://planet.wordpress.org/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"language\";a:1:{i:0;a:5:{s:4:\"data\";s:2:\"en\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:47:\"WordPress Planet - http://planet.wordpress.org/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"item\";a:50:{i:0;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:60:\"WPTavern: Matt Mullenweg’s Keynote at WordCamp Dallas 2008\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=44639\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:67:\"http://wptavern.com/matt-mullenwegs-keynote-at-wordcamp-dallas-2008\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:3206:\"<a href=\"http://i1.wp.com/wptavern.com/wp-content/uploads/2015/06/WordCampDallas2008FeaturedImage.png\"><img class=\"size-full wp-image-44643\" src=\"http://i1.wp.com/wptavern.com/wp-content/uploads/2015/06/WordCampDallas2008FeaturedImage.png?resize=650%2C200\" alt=\"WordCamp Dallas Featured Image\" /></a>Photo courtesy of <a href=\"http://ma.tt/2008/03/first-day-of-wordcamp/\">Matt Mullenweg</a>
<p>The following is a recording of Matt Mullenweg&#8217;s keynote presentation at WordCamp Dallas 2008. <a href=\"http://onemansblog.com/2008/04/03/wordcamp-dallas-2008-matt-mullenweg-wordpress-25-and-beyond/\">Recorded by John Pozadzides</a> who helped organize the event, it&#8217;s the only video of Mullenweg&#8217;s keynote that exists. In the video, Mullenweg walks the audience through WordPress 2.5, the redesign of WordPress.org, and the future of WordPress. There&#8217;s also a question and answer segment in the second half of the presentation.</p>
<p><!--[if IE]><object width=\"545\" height=\"405\" id=\"viddlerOuter-33a80f5b\" classid=\"clsid:D27CDB6E-AE6D-11cf-96B8-444553540000\"><param name=\"movie\" value=\"//www.viddler.com/player/33a80f5b/0/\"><param name=\"allowScriptAccess\" value=\"always\"><param name=\"allowNetworking\" value=\"all\"><param name=\"allowFullScreen\" value=\"true\"><param name=\"flashVars\" value=\"f=1&#038;autoplay=f&#038;disablebranding=f\"><object id=\"viddlerInner-33a80f5b\"><video id=\"viddlerVideo-33a80f5b\" src=\"//www.viddler.com/file/33a80f5b/html5mobile/\" type=\"video/mp4\" width=\"545\" height=\"363\" poster=\"//www.viddler.com/thumbnail/33a80f5b/\" controls=\"controls\" x-webkit-airplay=\"allow\"></video></object></object><![endif]--> <!--[if !IE]> <!-->  <!--<![endif]--></p>
<p>WordCamp Dallas 2008 was the first WordCamp I&#8217;ve ever attended and is the first time I met Mullenweg in person. Minutes before he took the stage, <a href=\"https://wordpress.org/news/2008/03/wordpress-25-brecker/\">WordPress 2.5 &#8220;Michael Brecker&#8221;</a> was released to the world.</p>
<p>WordPress 2.5 was the culmination of six months of work. In fact, Mullenweg <a href=\"http://lists.automattic.com/pipermail/wp-hackers/2008-January/016993.html\">announced</a> on the WP-Hackers mailing list that WordPress 2.4 would be skipped so that extra focus could be applied to 2.5.</p>
<blockquote><p>In light of the big changes happening in the codebase and admin section, we&#8217;re going to push back the next release to be aimed for early March.</p>
<p>This is the timeframe when 2.5 was originally scheduled for, so we&#8217;re treating the originally planned 2.4 in December as a skipped release, as a result of both the holidays and the large changes which we weren&#8217;t able to start on until late October.</p>
<p>There&#8217;s some good stuff in the oven, and we don&#8217;t want to rush it. The new release shall be called 2.5. Various official docs and roadmaps will be updated in due course.</p></blockquote>
<p>The video is an important piece of WordPress history that needs to be preserved and if possible, uploaded to <a href=\"http://wordpress.tv/\">WordPress.tv</a>. I&#8217;ve asked Pozadzides for permission to upload it to WordPress.tv and will update the post once I receive a response.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 02 Jun 2015 04:40:02 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:1;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:23:\"Matt: Webmonkey Podcast\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:21:\"http://ma.tt/?p=45115\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:39:\"http://ma.tt/2015/06/webmonkey-podcast/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:239:\"<p>I was on the <a href=\"http://www.wired.com/2015/05/webmonkey-podcast-e-commerce-coming-wordpress-com/\">Webmonkey Podcast talking about WooCommerce and tech in general</a>, my part starts around 26 minutes in.</p>
<p></p>
<p>&nbsp;</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 01 Jun 2015 23:34:55 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"Matt\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:2;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:89:\"WPTavern: WordPress.com Launches Insights: Better Stats for Visualizing Publishing Trends\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=44598\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:98:\"http://wptavern.com/wordpress-com-launches-insights-better-stats-for-visualizing-publishing-trends\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:3505:\"<p>WordPress.com <a href=\"https://en.blog.wordpress.com/2015/06/01/insights-a-new-view-of-your-stats/\" target=\"_blank\">announced</a> major improvements to its Stats feature today. The new Insights tab gives users a bird&#8217;s eye view of posting activity and visitor trends. The Stats panel now displays all-time numbers for posts, views, visitors, and the day the site received the most number of views.</p>
<p>Insights also calculates the most popular day of the week and the most popular hour based on when the site gets the most views on average.</p>
<p><a href=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2015/06/insights-all-time-stats.jpg\"><img src=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2015/06/insights-all-time-stats.jpg?resize=667%2C362\" alt=\"insights-all-time-stats\" class=\"aligncenter size-full wp-image-44604\" /></a></p>
<p>Posting Activity is another new addition that provides a way to visualize how often you are publishing. The feature is reminiscent of GitHub&#8217;s <a href=\"https://help.github.com/articles/viewing-contributions-on-your-profile-page/#viewing-contributions-from-specific-times\" target=\"_blank\">Contributions calendar</a>, which makes it easy to view contributions from specific times. Insights allows you to mouse over a specific date with a color marker to see how many posts were published that day.</p>
<p><a href=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2015/06/insights-posting-activity.jpg\"><img src=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2015/06/insights-posting-activity.jpg?resize=658%2C256\" alt=\"insights-posting-activity\" class=\"aligncenter size-full wp-image-44615\" /></a></p>
<p>If, for some reason, you&#8217;re missing the old version of WordPress.com&#8217;s stats, it is available for a limited time under <a href=\"https://wordpress.com/my-stats/\" target=\"_blank\">wordpress.com/my-stats/</a>.</p>
<p>Insights is not yet available on WordPress mobile apps but will likely be added soon. When asked when Insights will be available to self-hosted users, WordPress.com representative Jonathan Sadowski replied, &#8220;If you install Jetpack and enable the Stats module, you’ll be able to view these stats on WordPress.com for your .org blog.&#8221;</p>
<p>Stats is arguably one of the most popular features in Jetpack and a major factor for many in the decision to connect with WordPress.com. However, the view from inside the self-hosted Jetpack stats panel is starting to look a little dated when compared to the mobile apps or WordPress.com. Adding Insights to Jetpack&#8217;s stats panel would save users a trip over to WordPress.com to discover this information.</p>
<p>Most people don&#8217;t have the time or motivation to log into Google Analytics and create a meaningful interpretation of that data to improve their publishing habits. The new and improved stats with Insights offers a better understanding of when you&#8217;re posting and even interprets your traffic to provide actionable data, such as what hour might be the best for scheduling a post, what months lend you the most time to commit to blogging, etc.</p>
<p>The all-time stats also make it easier to track your blogging progress and set milestones for increasing posts, views, and visitors, and ultimately beating your best traffic day on record. The new feature is <a href=\"https://wordpress.com/stats/insights\" target=\"_blank\">live on WordPress.com</a> today and we&#8217;ll be watching for it in future updates to the mobile apps.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 01 Jun 2015 22:07:23 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:3;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:76:\"WPTavern: Sergej Müller, Creator of Antispam Bee, Says Goodbye to WordPress\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=44567\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:83:\"http://wptavern.com/sergej-muller-creator-of-antispam-bee-says-goodbye-to-wordpress\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:4847:\"<p><a href=\"http://i1.wp.com/wptavern.com/wp-content/uploads/2015/06/Sergej-Müller.jpg\"><img src=\"http://i1.wp.com/wptavern.com/wp-content/uploads/2015/06/Sergej-Müller.jpg?resize=250%2C382\" alt=\"Sergej-Müller\" class=\"alignright size-full wp-image-44590\" /></a>Sergej Müller is <a href=\"https://gist.github.com/sergejmueller/bccd658a5cdeb5b57deb\" target=\"_blank\">saying goodbye to WordPress</a> after nine years and nearly three million downloads of his <a href=\"https://profiles.wordpress.org/sergejmueller/#content-plugins\" target=\"_blank\">free plugins</a>. <a href=\"https://wordpress.org/plugins/antispam-bee/\" target=\"_blank\">Antispam Bee</a>, his most popular contribution, is currently in use on more than 200,000 WordPress sites.</p>
<p>Müller penned a <a href=\"https://gist.github.com/sergejmueller/bccd658a5cdeb5b57deb\" target=\"_blank\">farewell</a> Gist on GitHub in his native German, which <a href=\"http://glueckpress.com/\" target=\"_blank\">Caspar Hübinger</a> was kind enough to <a href=\"https://gist.github.com/glueckpress/ed370acc556c475c3be5\" target=\"_blank\">translate</a> into English.</p>
<blockquote><p>For me, a chapter of my life is coming to an end. A chapter that has brought an abundance of experience, learning, and fun. A chapter that, on the other hand, demanded a lot of time, nerves, and motivation. But where there’s a will, there’s a way, and I deeply hope my software and my commitment may have made the WordPress community a bit better in terms of quality.</p></blockquote>
<p>Müller is discontinuing his WordPress contributions due to health reasons, but he plans to find a suitable successor who will be able to deliver the level of quality and support that his users have come to expect. His plugins, most notably <a href=\"https://wordpress.org/plugins/antispam-bee/\" target=\"_blank\">Antispam Bee</a>, <a href=\"https://wordpress.org/plugins/cachify/\" target=\"_blank\">Cachify</a>, <a href=\"https://wordpress.org/plugins/statify/\" target=\"_blank\">Statify</a>, <a href=\"https://wpseo.de/\" target=\"_blank\">wpSEO</a> and <a href=\"https://optimus.io/\" target=\"_blank\">Optimus</a>, are used widely around the world, particularly throughout Germany, Austria, and the germanophone parts of Switzerland.</p>
<p>Hübinger, who is active in the German and European WordPress communities, has been using Müller&#8217;s plugins for the past six years.</p>
<p>&#8220;Just as valuable for me personally were his blog posts and tutorials,&#8221; he said. &#8220;I pretty much learned WordPress development from his blog, and <a href=\"http://bueltge.de/\" target=\"_blank\">Frank Bueltge</a>&#8216;s.</p>
<p>&#8220;There are a lot of comments expressing great surprise. No one saw him quitting, obviously. Sergej has been a key figure of the German-speaking WordPress community for the last nine years. While not quite so popular beyond the Germanophone context, I think his note that almost every WordPress user over here has heard of or uses at least one of his plugins is no exaggeration.&#8221;</p>
<p>While Müller does have a couple commercial plugins available, he has never made a living from them. For the past nine years he has been working as a software engineer outside of WordPress. Anyone aspiring to adopt his plugins will need to meet the high standards that he has set in terms of quality and support, especially in regards to supporting the German community.</p>
<p>&#8220;Monika Thon-Soun, a WordPress veteran from Austria, <a href=\"http://www.texto.de/sergej-einfach-danke-fuer-alles-2192/\" target=\"_blank\">mentions</a> she doesn’t remember a single instance where one of Sergej’s plugins would have been hacked,&#8221; Hübinger said. &#8220;Given the popularity of his plugins, that’s truly worth mentioning, as it underlines a character feature that everyone loves him for: reliability.&#8221;</p>
<p>Müller&#8217;s plugin contributions have always been a hobby for him but he is no longer able to sustain their development and support. He is currently in conversations with parties who are interested in his projects and will announce the new maintainers once it has been finalized.</p>
<p>Sergej Müller&#8217;s contributions signify the importance of having WordPress extensions and tutorials available for users to learn WordPress in their own language. His role in cultivating the German development community and supporting its many users will not be easily filled.</p>
<p>&#8220;As a friend, I understand and support his decision completely,&#8221; Hübinger said. &#8220;As a WordPress user, it’s&#8230;a catastrophe.</p>
<p>&#8220;Whoever follows him on G+ will have seen occasional moments of disappointment. In those moments, you could see all his passion. Because it really wasn’t about money for him. Acknowledgement and paying it forward is his favorite currency.&#8221;</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 01 Jun 2015 17:11:02 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:4;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"Matt: Beethoven, Mozart, Bach\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:21:\"http://ma.tt/?p=45099\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:43:\"http://ma.tt/2015/05/beethoven-mozart-bach/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:238:\"<blockquote><p>Beethoven tells you what it&#8217;s like to be Beethoven and Mozart tells you what it&#8217;s like to be human. Bach tells you what it&#8217;s like to be the universe.</p></blockquote>
<p>― Douglas Adams</p>
<p>&nbsp;</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 01 Jun 2015 05:42:00 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"Matt\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:5;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:20:\"Matt: Martian Review\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:21:\"http://ma.tt/?p=45110\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:36:\"http://ma.tt/2015/05/martian-review/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:1727:\"<p>On the recommendation of my friend <a href=\"https://twitter.com/timyoung\">Timothy Young</a> I checked out the book <a href=\"http://www.amazon.com/dp/B00EMXBDMA\"><em>The Martian: A Novel</em> by Andy Weir</a>. Think of it like <a href=\"http://www.amazon.com/dp/B00IC8VF10/\">Shackleton&#8217;s Voyage</a> (a great recommendation from <a href=\"http://toni.org/\">Toni</a>) but on Mars. I really enjoyed the book, and if you like geeky, science-filled novels you will too.  One thing about the publishing I thought was really cool, as <a href=\"http://en.wikipedia.org/wiki/The_Martian_(Weir_novel)\">the Wikipedia puts it</a>:</p>
<blockquote><p>Having been rebuffed by literary agents when trying to get prior books published, Weir decided to put the book online in serial format one chapter at a time for free at his website. At the request of fans he made an Amazon Kindle version available through Amazon.com at 99 cents (the minimum he could set the price). The Kindle edition rose to the top of Amazon&#8217;s list of best-selling science-fiction titles, where it sold 35,000 copies in three months, more than had previously downloaded it for free. This garnered the attention of publishers: Podium Publishing, an audiobook publisher, signed for the audiobook rights in January 2013. Weir sold the print rights to Crown in March 2013 for six figures.</p></blockquote>
<p>I was hoping it was on a WordPress blog, but <a href=\"http://www.galactanet.com/writing.html\">it appears to be more of a static HTML site</a> (his <a href=\"http://www.andyweirauthor.com/\">official site is WP-powered</a>) and includes some awesome short vignettes like <a href=\"http://www.galactanet.com/oneoff/meetingsarah.html\">Meeting Sarah</a>.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Sat, 30 May 2015 10:54:06 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"Matt\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:6;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:66:\"WPTavern: Why Cloudup is Not Replacing the WordPress Media Library\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=44516\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:76:\"http://wptavern.com/why-cloudup-is-not-replacing-the-wordpress-media-library\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:4027:\"<p><a href=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2015/04/CloudUpFeaturedImage2.png\"><img class=\"aligncenter size-full wp-image-42250\" src=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2015/04/CloudUpFeaturedImage2.png?resize=650%2C200\" alt=\"CloudUpFeaturedImage2\" /></a>When <a href=\"http://en.blog.wordpress.com/2013/09/25/cloudup-joins-the-automattic-family/\">Automattic acquired Cloudup</a> in 2013, two of the most exciting parts <a href=\"http://techcrunch.com/2013/09/25/automattic-acquires-file-sharing-service-cloudup-to-build-faster-media-library-and-enable-co-editing/\">of the announcement</a> was replacing the WordPress media library with <a href=\"https://cloudup.com/\">Cloudup</a> and the ability to co-edit posts similar to Google Docs. We <a href=\"http://wptavern.com/cloudup-makes-file-sharing-incredibly-easy\">discussed the concept</a> in early 2014 and readers were concerned about owning their data.</p>
<p>Two years later, the <a href=\"https://wordpress.org/news/2014/04/smith/\">WordPress media library and the visual post editor</a> have received major improvements while integration with Cloudup is non-existent. When Matt Mullenweg was asked about the integration in a <a href=\"http://wptavern.com/wpweekly-episode-194-celebrating-wordpress-12th-birthday-with-matt-mullenweg\">recent interview</a>, he responded,</p>
<blockquote><p>We did a lot of really awesome UI improvements to the editor and did some things we were very excited about, but because we weren&#8217;t working on a TinyMCE base, some of the basic editing stuff was really difficult.</p></blockquote>
<p>The team spent about six months to complete the first 80% of the project then spent a year and a half to reach 85%. Setbacks included a lot of rabbit holes and hidden complexity. The team now works on different things within Automattic that revolve around data.</p>
<h2>Zeditor is an Educational Resource</h2>
<p>The work completed by the team is <a href=\"https://github.com/Automattic/zeditor\">open source and available on GitHub</a>. It&#8217;s called Zeditor and serves as an educational resource. &#8220;We learned a ton through the way we architected the JavaScript and we think it serves as a good model for doing lots of JavaScript projects going forward,&#8221; Mullenweg said.</p>
<p>Listen to Mullenweg explain why Cloudup is not replacing the WordPress media library in the following audio clip. Be sure to <a href=\"http://wptavern.com/wpweekly-episode-194-celebrating-wordpress-12th-birthday-with-matt-mullenweg\">check out the entire interview</a> where we discuss a variety of other WordPress topics.</p>
<div class=\"audio-shortcode-wrap\"><img src=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2015/04/CloudUpFeaturedImage2.png?resize=175%2C131\" alt=\"Why Cloudup is Not Replacing the WordPress Media Library\" class=\"landscape thumbnail post-thumbnail audio-image\" /><!--[if lt IE 9]><script>document.createElement(\'audio\');</script><![endif]-->
<a href=\"http://wptavern.com/wp-content/uploads/2015/05/CloudupWordPressMediaLibraryZeditor.mp3\">http://wptavern.com/wp-content/uploads/2015/05/CloudupWordPressMediaLibraryZeditor.mp3</a></div><div class=\"media-shortcode-extend\"><div class=\"media-info audio-info\"><ul class=\"media-meta\"><li><span class=\"prep\">Run Time</span> <span class=\"data\">3:14</span></li><li><span class=\"prep\">Artist</span> <span class=\"data\">Jeff Chandler and Marcus Couch</span></li><li><span class=\"prep\">Album</span> <span class=\"data\">WordPress Weekly</span></li><li><span class=\"prep\">File Name</span> <span class=\"data\"><a href=\"http://wptavern.com/wp-content/uploads/2015/05/CloudupWordPressMediaLibraryZeditor.mp3\">CloudupWordPressMediaLibraryZeditor.mp3</a></span></li><li><span class=\"prep\">File Size</span> <span class=\"data\">1.36 MB</span></li><li><span class=\"prep\">File Type</span> <span class=\"data\">MP3</span></li><li><span class=\"prep\">Mime Type</span> <span class=\"data\">audio/mpeg</span></li></ul></div><button class=\"media-info-toggle\">Audio Info</button></div>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 29 May 2015 21:11:41 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:7;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:90:\"WPTavern: Fight for the Future Leads Congress Blackout Campaign to Protest the Patriot Act\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=44507\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:100:\"http://wptavern.com/fight-for-the-future-leads-congress-blackout-campaign-to-protest-the-patriot-act\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:3501:\"<p><a href=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2015/05/congress-blackout.jpg\"><img src=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2015/05/congress-blackout.jpg?resize=1025%2C481\" alt=\"congress-blackout\" class=\"aligncenter size-full wp-image-44522\" /></a></p>
<p>Three key provisions within the Patriot Act will expire at the stroke of midnight on Sunday. The Senate needs 60 votes in order to provide an extension or renew the provisions past June 1st. <a href=\"http://en.wikipedia.org/wiki/Section_summary_of_the_Patriot_Act,_Title_II#Section_215:_Access_to_records_and_other_items_under_FISA\" target=\"_blank\">Section 215</a> of the measure is particularly controversial in that it allows the National Security Agency (NSA) to collect data from Americans&#8217; phone records.</p>
<p><a href=\"https://www.fightforthefuture.org/\" target=\"_blank\">Fight for the Future</a> is leading an internet campaign wherein 14,000+ websites will be blocking access to Congress&#8217; IP addresses, redirecting that traffic to the <a href=\"https://www.blackoutcongress.org/\" target=\"_blank\">blackout protest page</a> where they will see the following message:</p>
<blockquote><p>You have conducted mass surveillance of everyone illegally and are now on record for trying to enact those programs into law. You have presented Americans with the false dichotomy of reauthorizing the PATRIOT Act or passing the USA Freedom Act. The real answer is to end all authorities used to conduct mass surveillance. Until you do, thousands of web sites have blocked your access, and more are joining every day.</p></blockquote>
<p>The campaign is coordinated by the <a href=\"https://www.internetdefenseleague.org/\" target=\"_blank\">Internet Defense League</a>, an organization that has been instrumental in <a href=\"http://wptavern.com/join-the-september-10th-internet-slowdown-protest-with-these-wordpress-plugins\" target=\"_blank\">defending net neutrality</a> and protesting the SOPA/PIPA censorship bills.</p>
<p>Self-hosted WordPress site owners who want to participate in protesting the renewal of the Patriot Act can install the <a href=\"https://wordpress.org/plugins/cat-signal/\" target=\"_blank\">Internet Defense League Cat Signal</a> plugin from WordPress.org. It includes the blackout script as well as a dismissable notice to site visitors, asking them to <a href=\"https://www.sunsetthepatriotact.com/\" target=\"_blank\">urge Congress to sunset the Patriot Act</a>.</p>
<p><a href=\"http://i1.wp.com/wptavern.com/wp-content/uploads/2015/05/cat-signal-modal.jpg\"><img src=\"http://i1.wp.com/wptavern.com/wp-content/uploads/2015/05/cat-signal-modal.jpg?resize=749%2C426\" alt=\"cat-signal-modal\" class=\"aligncenter size-full wp-image-44519\" /></a></p>
<p>The Cat Signal plugin will link your site up to the Internet Defense League&#8217;s online activist group. When an important bill is up for action, it will automatically enqueue the JavaScript required to post a notice on your site. It also includes an options page for selecting the pages where it should be active and for setting the notice as a banner or a modal.</p>
<p>If sunsetting the Patriot Act is important to you, the Cat Signal plugin is the easiest way to get your WordPress site into the protest. Alternatively, you can <a href=\"https://github.com/fightforthefuture/breakcongressinternet/blob/gh-pages/README.md\" target=\"_blank\">manually add the JavaScript to join the Congress Blackout</a> that will block Congress&#8217; IP addresses.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 29 May 2015 20:32:48 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:8;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:77:\"WPTavern: o2 Development Team Shifts Focus to WordPress.com’s Core Products\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=44505\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:84:\"http://wptavern.com/o2-development-team-shifts-focus-to-wordpress-coms-core-products\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:3737:\"<a href=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2014/04/O2SiteHeader.png\"><img class=\"size-full wp-image-20307\" src=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2014/04/O2SiteHeader.png?resize=682%2C151\" alt=\"O2 Is The Successor To The P2 Theme\" /></a>O2 Is The Successor To The P2 Theme
<p>Since <a href=\"http://wptavern.com/o2-wordpress-plugin-expected-to-be-available-in-early-2014\">writing about o2</a>, Automattic&#8217;s successor to the P2 theme in 2013, a <a href=\"https://twitter.com/dimensionmedia/status/534522740037148672\">number of readers</a> have requested updates on the project&#8217;s status. When asked about the project in a recent interview, Matt Mullenweg explained that despite loving the project and truly believing in it, work on o2 has shifted to other parts of WordPress.com to focus on the service&#8217;s core products.</p>
<blockquote><p>Saying no is one of the hardest things but I think that&#8217;s where great design comes from is when you say no to a thousand things, including the things you love, or you really wanted to do. Saying no to the lame stuff is easy, but saying no to something you really believe in like o2 is much harder but that focus is crucial for creating great products.</p></blockquote>
<p>Although Mullenweg says anyone on WordPress.com can enable o2, this is not the case. Searching for o2 on WordPress.com generates no results while P2 brings up the original P2 theme.</p>
<a href=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2015/05/o2ThemeNotFound.png\"><img class=\"size-full wp-image-44513\" src=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2015/05/o2ThemeNotFound.png?resize=921%2C312\" alt=\"o2 Theme Not Found\" /></a>o2 Theme Not Found
<p>o2 is used internally at Automattic and the code is available via <a href=\"https://wpcom-themes.svn.automattic.com/p2-breathe/\">WordPress.com&#8217;s subversion repository</a>. o2 is not listed since it was supposed to be a plugin but the work inside of o2 is listed under P2 Breathe. While you can download the code, it&#8217;s developed in such a way that it doesn&#8217;t make sense to run it outside of WordPress.com&#8217;s infrastructure.</p>
<p>Listen to Mullenweg explain why development resources have shifted away from o2 to WordPress.com&#8217;s core products and be sure to check <a href=\"http://wptavern.com/wpweekly-episode-194-celebrating-wordpress-12th-birthday-with-matt-mullenweg\">out the full interview</a>.</p>
<div class=\"audio-shortcode-wrap\"><img src=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2014/04/O2SiteHeader.png?resize=175%2C131\" alt=\"O2 Is The Successor To The P2 Theme\" class=\"landscape thumbnail post-thumbnail audio-image\" /><a href=\"http://wptavern.com/wp-content/uploads/2015/05/StatusOfo2Theme.mp3\">http://wptavern.com/wp-content/uploads/2015/05/StatusOfo2Theme.mp3</a></div><div class=\"media-shortcode-extend\"><div class=\"media-info audio-info\"><ul class=\"media-meta\"><li><span class=\"prep\">Run Time</span> <span class=\"data\">2:53</span></li><li><span class=\"prep\">Artist</span> <span class=\"data\">Jeff Chandler and Marcus Couch</span></li><li><span class=\"prep\">Album</span> <span class=\"data\">WordPress Weekly</span></li><li><span class=\"prep\">Track</span> <span class=\"data\">194</span></li><li><span class=\"prep\">File Name</span> <span class=\"data\"><a href=\"http://wptavern.com/wp-content/uploads/2015/05/StatusOfo2Theme.mp3\">StatusOfo2Theme.mp3</a></span></li><li><span class=\"prep\">File Size</span> <span class=\"data\">1.24 MB</span></li><li><span class=\"prep\">File Type</span> <span class=\"data\">MP3</span></li><li><span class=\"prep\">Mime Type</span> <span class=\"data\">audio/mpeg</span></li></ul></div><button class=\"media-info-toggle\">Audio Info</button></div>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 29 May 2015 19:00:08 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:9;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:68:\"WPTavern: WordCamp Miami to Livestream Tracks Throughout the Weekend\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=44488\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:78:\"http://wptavern.com/wordcamp-miami-to-livestream-tracks-throughout-the-weekend\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:2189:\"<p><a href=\"http://i1.wp.com/wptavern.com/wp-content/uploads/2015/02/wcmia-2015.jpg\"><img src=\"http://i1.wp.com/wptavern.com/wp-content/uploads/2015/02/wcmia-2015.jpg?resize=750%2C349\" alt=\"wcmia-2015\" class=\"aligncenter size-full wp-image-39447\" /></a></p>
<p><a href=\"http://wptavern.com/wordcamp-miami-2015-to-experiment-with-new-tracks-tickets-selling-out-fast\" target=\"_blank\">WordCamp Miami 2015</a> is taking place this weekend with a BuddyCamp kicking off today. The event sold out again this year and will have roughly 800 attendees, including a kids&#8217; camp, convening at the Florida International University School of Business campus on Saturday and Sunday.</p>
<p>If you weren&#8217;t able to make it to BuddyCamp, the event is <a href=\"https://miami.wordcamp.org/2015/wcmia-livestream/\" target=\"_blank\">live streaming now</a> and will be throughout the afternoon. A Livestream account is required in order to watch but signup is free and allows you to watch from anywhere in the world.</p>
<blockquote class=\"twitter-tweet\" width=\"550\"><p lang=\"en\" dir=\"ltr\">I\'m attending <a href=\"https://twitter.com/hashtag/BuddyCamp?src=hash\">#BuddyCamp</a> Miami although there\'s an ocean between us! Many thanks <a href=\"https://twitter.com/buddycampmia\">@buddycampmia</a> :) &lt;3 <a href=\"http://t.co/gtVmkmf91C\">pic.twitter.com/gtVmkmf91C</a></p>
<p>&mdash; imath (@imath) <a href=\"https://twitter.com/imath/status/604290006274822145\">May 29, 2015</a></p></blockquote>
<p></p>
<p>WordCamp Miami is experimenting with new tracks and mini-workshops this year. The &#8220;How-To&#8221; track, for example, is a new concept for the camp and will include hand-selected speakers presenting with slides that are formatted to be a lasting educational resource for attendees and Livestream viewers.</p>
<p>The How-To, Content and Design, and Developer tracks will be available via Livestream on Saturday. Sunday&#8217;s live viewing schedule will include Business, Users, and more Developer tracks. The links are likely to change during the event but will be updated on the <a href=\"https://miami.wordcamp.org/2015/wcmia-livestream/\" target=\"_blank\">Livestream</a> page for each track.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 29 May 2015 16:49:32 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:10;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:24:\"Matt: Ireland Censorship\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:21:\"http://ma.tt/?p=45107\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:40:\"http://ma.tt/2015/05/ireland-censorship/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:992:\"<p>When I spoke in Ireland yesterday someone asked if I would blog about them today. I am, but not the best story: <a href=\"http://www.theguardian.com/media/greenslade/2015/may/29/irelands-media-silenced-over-mps-speech-about-denis-obrien\">Ireland&#8217;s media silenced over MP&#8217;s speech about Denis O&#8217;Brien</a>. Because of an injunction, no media in Ireland can report on alleged corruption, laws I think set up with good intentions (preventing libel?) but being twisted now to prevent the vital functioning of <a href=\"http://en.wikipedia.org/wiki/Fourth_Estate\">the fourth estate</a>. The country showed <a href=\"http://www.nytimes.com/2015/05/24/world/europe/ireland-gay-marriage-referendum.html\">amazing mettle in their Yes vote for gay marriage</a> last week, perhaps censorship could be the next thing the populace tackles. (Also I really enjoyed my visit to Dublin, if you want an amazing meal check out <a href=\"http://forestavenuerestaurant.ie/\">Forest Avenue</a>.)</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 29 May 2015 16:00:33 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"Matt\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:11;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:74:\"WPTavern: Nametiles Plugin Brings Blockchain-Powered Profiles to WordPress\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=44447\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:84:\"http://wptavern.com/nametiles-plugin-brings-blockchain-powered-profiles-to-wordpress\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:4750:\"<p><a href=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2015/05/nametiles.jpg\"><img src=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2015/05/nametiles.jpg?resize=1025%2C495\" alt=\"nametiles\" class=\"aligncenter size-full wp-image-44466\" /></a></p>
<p><a href=\"https://openname.org/\" target=\"_blank\">Openname</a>, the decentralized identity and naming system built on the blockchain, was recently renamed to Blockchain Name System (BNS). Founders <a href=\"http://muneebali.com\" target=\"_blank\">Muneeb Ali</a> and <a href=\"http://shea.io/\" target=\"_blank\">Ryan Shea</a> are pioneering decentralized identity with the long-term goal of creating decentralized authentication.</p>
<p>Earlier this month, BNS debuted <a href=\"https://passcard.info/\" target=\"_blank\">Passcard</a>, a digital form of identity and access control combined. It&#8217;s essentially a digital passport, secured by the blockchain, that allows you to control and display your identity.</p>
<p>A few months ago,  <a href=\"https://www.larrysalibra.com/\" target=\"_blank\">Larry Salibra</a>, founder and CEO of <a href=\"https://www.pay4bugs.com/\" target=\"_blank\">Pay4Bugs</a>, released a <a href=\"http://wptavern.com/new-plugin-adds-openname-avatars-to-wordpress\" target=\"_blank\">plugin that adds Openname avatars to WordPress</a>. An ardent fan of blockchain technology, Salibra has just released another plugin called <a href=\"https://wordpress.org/plugins/nametiles/\" target=\"_blank\">Nametiles</a> that adds Passcard profiles and tagging to WordPress.</p>
<p>Nametiles works like this: Type the plus character and a person&#8217;s +passname on a post or page and it will automatically display that person&#8217;s Passcard profile information when you hover over the link.</p>
<p><a href=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2015/05/nametiles-example.jpg\"><img src=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2015/05/nametiles-example.jpg?resize=920%2C739\" alt=\"nametiles-example\" class=\"aligncenter size-full wp-image-44449\" /></a></p>
<p>The plugin also includes the ability for registered users on your site to optionally use their Passcard avatar via a setting in wp-admin/profile.php.</p>
<p>The <a href=\"https://nametiles.co/\" target=\"_blank\">Nametiles</a> site has a live demo of how the tiles appear on your website. You can also see Nametiles in action on the <a href=\"https://www.bitcoinhk.org/\" target=\"_blank\">Bitcoin Association of Hong Kong’s website</a>, where it&#8217;s in use on the <a href=\"https://www.bitcoinhk.org/members/\" target=\"_blank\">members</a> page and <a href=\"https://www.bitcoinhk.org/2015-inside-bitcoins-discount/\" target=\"_blank\">posts</a>.</p>
<p>Salibra created Nametiles to help publishers keep people&#8217;s information and links continually up-to-date. Its two primary benefits for publishers include:</p>
<ul>
<li>Profile information is never stale and always up-to-date (including website, bio, social links, avatar, etc)</li>
<li>Users control their information and personal brand via Passcard</li>
</ul>
<p>&#8220;Publishers have no idea when the people mentioned or linked on their blog update their profile pic, bio, or website and no practical way to find out,&#8221; Salibra said. &#8220;The result is a site littered with broken links and out of date information that conveys sloppiness and apathy to visitors.&#8221;</p>
<p>This plugin is especially useful for sites that often have guest post authors, as well as news and organization sites that frequently reference names in content.</p>
<p>&#8220;With Nametiles, profile information about those you mention on your site is always up to date because the information is maintained by those who care most, the owners of the information,&#8221; Salibra said.</p>
<p>&#8220;I&#8217;m excited for a future where digital identity is something we own instead of something big social companies use to pull visitors from our blogs and websites and track people,&#8221; he said.</p>
<p>The only catch is that users who are linked have to be registered for a <a href=\"https://passcard.info/\" target=\"_blank\">Passcard</a> profile. The blockchain-powered identity service is free but it is also so new that it hasn&#8217;t yet caught on.</p>
<p>The idea of Passcard is similar to <a href=\"https://en.gravatar.com/\" target=\"_blank\">Gravatar</a> but has the potential to be more powerful, as it is secured by the blockchain and may eventually support decentralized authentication. If Passcard founders are successful in building the future of identification, it may be a long before the identity system is mainstream enough for the <a href=\"https://wordpress.org/plugins/nametiles/\" target=\"_blank\">Nametiles</a> plugin to be useful beyond certain niche websites.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 29 May 2015 00:35:43 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:12;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:26:\"Matt: Money and Motivation\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:21:\"http://ma.tt/?p=45104\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:42:\"http://ma.tt/2015/05/money-and-motivation/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:210:\"<p><a href=\"http://intenseminimalism.com/2012/the-misconception-about-money-and-motivation/\">The Misconception about Money and Motivation</a>, a good summary of the work by Dan Pink, Dan Ariely, and others.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 29 May 2015 00:23:52 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"Matt\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:13;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:70:\"WPTavern: Sucuri is Building a Comprehensive Alternative to CloudFlare\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=44415\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:80:\"http://wptavern.com/sucuri-is-building-a-comprehensive-alternative-to-cloudflare\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:4812:\"<p><a href=\"https://sucuri.net/\" target=\"_blank\">Sucuri</a> launched a new free performance tool today. The <a href=\"https://performance.sucuri.net/\" target=\"_blank\">Global Website Performance Tester</a> allows anyone to enter a URL and get a quick assessment of how fast the website is loading from 13 globally distributed testing stations. Results include three key metrics: connection time, time to first byte (TTFB) and total load time.</p>
<p><a href=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2015/05/performance-test.jpg\"><img src=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2015/05/performance-test.jpg?resize=958%2C476\" alt=\"performance-test\" class=\"aligncenter size-full wp-image-44422\" /></a></p>
<p>At the moment, there are no plans for an API, but Sucuri CEO <a href=\"https://twitter.com/perezbox\" target=\"_blank\">Tony Perez</a> said that it&#8217;s possible to build one if there&#8217;s enough demand.</p>
<p>The new performance checker is a simple free tool that the Sucuri team built for its own use but also signifies the company&#8217;s foray into performance-related products and services.</p>
<p>&#8220;Performance can easily fall into the realm of Availability, and as such we see it as an important piece of security,&#8221; Perez told the Tavern. &#8220;There is no denying that performance is top of mind to most website owners, as is security.&#8221;</p>
<p>Sucuri has been quietly beefing up its architecture to support an expansion into performance-related services that would go hand-in-hand with its <a href=\"https://sucuri.net/website-firewall/\" target=\"_blank\">WAF</a> (Website Firewall) product.</p>
<p>&#8220;We&#8217;ve been building out our network and performance is a tenant of our Website Firewall,&#8221; Perez said. &#8220;It was imperative that we understood how good or bad our network was compared to the other performance (CDN) providers. Like most things we do, the performance tool was a tool to satisfy our own needs.&#8221;</p>
<h3>Sucuri Is Expanding to Accommodate Plans for a Full-Featured CloudFlare Alternative</h3>
<p>Sucuri is currently managing over 40 billion page views per month via its WAF network. The team is working on expanding to a full WAF/CDN solution to serve performance-related features.</p>
<p>&#8220;The fundamental difference is that it&#8217;s security first, performance second,&#8221; Perez said. &#8220;So yes, in the coming months you&#8217;ll see more as our solution blossoms into a full WAF/CDN solution.&#8221;</p>
<p>Up until now the company has been limited by using a leased architecture but is making changes to support the WAF/CDN expansion.</p>
<p>&#8220;We&#8217;re actively migrating from a leased architecture to our own infrastructure, giving us full control of the website,&#8221; Perez said. &#8220;This gives us optimal control to mitigate all attacks, including large scale DDOS attacks; a by-product of that will be performance in the form of a global CDN.&#8221;</p>
<p>Sucuri is is building its own DNS architecture with full DNS management within its application.</p>
<p>&#8220;Users will have an alternative to solutions like <a href=\"https://www.cloudflare.com/\" target=\"_blank\">CloudFlare</a>,&#8221; Perez said. &#8220;The fundamental difference being we&#8217;re a security company first.</p>
<p>Sucuri is building its expansion on top of the an <a href=\"http://en.wikipedia.org/wiki/Anycast\" target=\"_blank\">Anycast</a> network, which means that users&#8217; requests will be routed to the nearest node on request.</p>
<p>&#8220;With most of the content cached at the edge it&#8217;ll be designed for optimal speeds regardless of where you are in the world,&#8221; Perez said. &#8220;That&#8217;s perhaps the biggest feature &#8211; most everything comes down to our design and configuration and how we handle the traffic.&#8221;</p>
<p>When asked if he sees the final WAF/CDN solution to be a comprehensive Cloudflare alternative, Perez responded, &#8220;Oh hell yeah &#8211; with one key differentiator: we&#8217;ll clean the mess too.&#8221;</p>
<p>&#8220;The idea is when you think of Sucuri it&#8217;s a complete package &#8211; Protection &#8211; Detection &#8211; Response. It&#8217;s all built in-house, no third-party integrations,&#8221; he said.</p>
<p>&#8220;The cleaning is the one thing that no one else can match us on, it&#8217;s either too much liability or they haven&#8217;t figured out how to scale.&#8221;</p>
<p>Sucuri&#8217;s WAF service is currently used by iThemes, Gravity Forms, List25, and many others in the WordPress space. If the company is able to deliver on their CloudFlare alternative, which is planned for this summer, customers will have the opportunity to get their security services bundled in with the new performance-enhancing features of the CDN.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 28 May 2015 19:23:47 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:14;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:92:\"WPTavern: Fast Page Switch Adds a Quick Way to Switch Between Pages in the WordPress Backend\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=44405\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:102:\"http://wptavern.com/fast-page-switch-adds-a-quick-way-to-switch-between-pages-in-the-wordpress-backend\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:1232:\"<p>If you find yourself editing pages often and want a quick way to switch between them without visiting the All Pages screen first, try the <a href=\"https://wordpress.org/plugins/fast-page-switch/\">Fast Page Switch</a> plugin by <a href=\"https://profiles.wordpress.org/marclarr/\">Marc Wiest</a>.</p>
<p>Fast Page Switch adds a metabox with a drop down menu to the Page editing screen that allows you to quickly switch to a different page. This eliminates the need to visit the All Pages screen and search for the next page you want to edit.</p>
<p>Fast Page Switch saves time if you have less than 20 pages. If you have more than 20, it could be cumbersome to use and outweigh the time saving benefits.</p>
<a href=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2015/05/FastPageSwitchInAction.png\"><img class=\"size-full wp-image-44406\" src=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2015/05/FastPageSwitchInAction.png?resize=919%2C403\" alt=\"Fast Page Switch in Action\" /></a>Fast Page Switch in Action
<p>I tested Fast Page Switch on WordPress 4.2.2 and didn&#8217;t experience any issues. You can <a href=\"https://wordpress.org/plugins/fast-page-switch/\">download it for free</a> from the WordPress plugin directory.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 28 May 2015 05:48:33 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:15;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:93:\"WPTavern: WPWeekly Episode 194 – Celebrating WordPress’ 12th Birthday with Matt Mullenweg\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:44:\"http://wptavern.com?p=44397&preview_id=44397\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:96:\"http://wptavern.com/wpweekly-episode-194-celebrating-wordpress-12th-birthday-with-matt-mullenweg\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:1644:\"<p>In this birthday celebration episode of WordPress Weekly, <a href=\"http://marcuscouch.com/\">Marcus Couch</a> and I are joined by Automattic CEO, <a href=\"http://ma.tt/\">Matt Mullenweg</a>. We covered a lot of ground with Mullenweg discussing the following topics:</p>
<ul>
<li>Update on <a href=\"http://wptavern.com/o2-wordpress-plugin-expected-to-be-available-in-early-2014\">O2</a> the successor to the <a href=\"http://p2theme.com/\">P2 theme</a></li>
<li>Memorable moments of the last 12 years</li>
<li>Update on the <a href=\"https://github.com/WordPress/book\">WordPress history book</a></li>
<li>Status of WordCamp USA</li>
<li>The WooThemes/WooCommerce acquisition</li>
<li>Hype surrounding the WP REST API</li>
<li>The WordPress Mobile App</li>
</ul>
<p>We talked about a number of other topics as well. I apologize for the audio glitches in this episode as Mullenweg experienced bandwidth issues. We also experienced some technical difficulties with Google Hangouts.</p>
<h2>WPWeekly Meta:</h2>
<p><strong>Next Episode:</strong> Wednesday, June 3rd 9:30 P.M. Eastern</p>
<p><strong>Subscribe To WPWeekly Via Itunes: </strong><a href=\"https://itunes.apple.com/us/podcast/wordpress-weekly/id694849738\" target=\"_blank\">Click here to subscribe</a></p>
<p><strong>Subscribe To WPWeekly Via RSS: </strong><a href=\"http://www.wptavern.com/feed/podcast\" target=\"_blank\">Click here to subscribe</a></p>
<p><strong>Subscribe To WPWeekly Via Stitcher Radio: </strong><a href=\"http://www.stitcher.com/podcast/wordpress-weekly-podcast?refid=stpr\" target=\"_blank\">Click here to subscribe</a></p>
<p><strong>Listen To Episode #194:</strong><br />
</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 28 May 2015 03:52:11 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:16;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:116:\"WPTavern: WordPress Theme Review Team is Cracking Down on Violations of the Presentation vs. Functionality Guideline\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=44356\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:125:\"http://wptavern.com/wordpress-theme-review-team-is-cracking-down-on-violations-of-the-presentation-vs-functionality-guideline\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:8344:\"<a href=\"http://i1.wp.com/wptavern.com/wp-content/uploads/2015/01/red-pen.jpg\"><img src=\"http://i1.wp.com/wptavern.com/wp-content/uploads/2015/01/red-pen.jpg?resize=1024%2C500\" alt=\"photo credit: pollas - cc\" class=\"size-full wp-image-37241\" /></a>photo credit: <a href=\"https://www.flickr.com/photos/pollas/526544001/\">pollas</a> &#8211; <a href=\"http://creativecommons.org/licenses/by-nc-sa/2.0/\">cc</a>
<p>During this week&#8217;s WordPress.org Theme Review Team meeting Chip Bennett opened the floor to discuss the &#8220;grey areas&#8221; of presentation vs. functionality distinctions in themes. The hotly debated topic concerns what is permissible in terms of &#8220;content creation&#8221; for themes that are hosted in the official directory.</p>
<p>&#8220;We know that CPTs and custom taxonomies are off-limits; likewise with non-presentational post custom meta data,&#8221; Bennett said. &#8220;But what about content created via theme options, custom widgets, etc.?&#8221;</p>
<p>This question often comes up in relation to themes that offer static front pages with custom widgets or textareas in the customizer where users can add small blocks of text. For example, a theme might offer a biography section or a place to enter copyright text. The concern is that a user is entering content, not knowing that it will be lost upon switching themes.</p>
<p>The Theme Review Team has had an <a href=\"https://wordpress.slack.com/archives/themereview/p1432668662001049\" target=\"_blank\">established policy for years</a> that forbids theme authors from defining the generation of user content. However, due to disorganization during the process of moving the official version of theme requirements from the Codex to the Theme Review Handbook, this particular guideline was omitted.</p>
<p>Bennett posted a <a href=\"https://make.wordpress.org/themes/2015/05/27/theme-review-requirements-and-documentation/\" target=\"_blank\">review of Theme Review Requirements and documentation</a> today on the Make/Themes blog with previously omitted items highlighted in red for clarity.</p>
<blockquote><p><strong>Presentation vs. Functionality</strong><br />
Since the purpose of Themes is to define the presentation of user content, Themes must not be used to define the generation of user content, or to define Theme-independent site options or functionality.</p></blockquote>
<p>As this is a fairly general statement, the Theme Review Team will be discussing the finer points of how it applies during the next meeting. In the past, this guideline has been subjectively and inconsistently applied, allowing many themes to slip by with functionality that falls into these grey areas.</p>
<h2>Theme Review Team to Begin Aggressively Enforcing &#8220;No Content Creation&#8221; Guideline</h2>
<p><a href=\"https://wordpress.org/themes/zerif-lite/\" target=\"_blank\">Zerif Lite</a>, one of the top themes on WordPress.org, was highlighted during the meeting as an example of a theme that has been permitted to skirt this guideline, among others.</p>
<p>&#8220;Looking at Zerif Lite: testimonials, our team, our focus, about us &#8211; these are all CPTs, disguised as custom widgets,&#8221; Bennett said. In a <a href=\"https://themes.trac.wordpress.org/ticket/24907\" target=\"_blank\">ticket where the theme is currently being reviewed for updates</a>, Bennett encouraged Zerif Lite&#8217;s author to remove any custom post meta data, except for that that which is presenatational, as it falls into plugin territory. This includes aspects of the theme such as author details, team member position, social network profiles, etc.</p>
<p>Reviewers are already aggressively cracking down on Zerif Lite&#8217;s violation of this specific guideline and will likely extend their vigilance to uphold the guideline more consistently with all themes as they come up for review.</p>
<p><a href=\"http://www.codeinwp.com/\" target=\"_blank\">Codeinwp</a>, the company behind Zerif Lite, replied to Bennetts&#8217; requests on the ticket:</p>
<blockquote><p>Most of the things that you are pointing out are really sensitive for two reasons: </p>
<ul>
<li>Probably 50% of the most popular themes use some custom content on the homepage</li>
<li>A lot of things like contact issue or testimonial can&#8217;t be solved without breaking 100k sites which use the theme</li>
</ul>
</blockquote>
<p>Codeinwp contends that the approach used in Zerif Lite is far more user friendly than having to install a plugin, or multiple plugins, in order to add small bits of text to the home page.</p>
<blockquote><p>At the end I agree that our approach was a bit different/radical. However, it looks like it is something that people really want (Zerif is one of the hottest themes at the moment, with mentions all over the web). I mean most of them want to build a beautiful site in 10 minutes, without any knowledge and with Zerif Lite they can easily do it. They don&#8217;t want 10 CPT, 10 required plugins, contact form, and Captcha plugins for a simple site.</p></blockquote>
<p>The theme author believes that creating a plugin to handle four of the theme&#8217;s focus widgets would simply waste users&#8217; time.</p>
<p>&#8220;Also, you realize the amount of work required to do this for 100+ themes installed on million of sites, right?&#8221; Codeinwp said. The author also cited several other examples of popular themes in violation, including <a href=\"https://wordpress.org/themes/accesspress-parallax/\" target=\"_blank\">AccessPress Parallax</a>, <a href=\"https://wordpress.org/themes/onetone/\" target=\"_blank\">Onetone</a>, and <a href=\"https://wordpress.org/themes/colorway\" target=\"_blank\">Colorway</a>.</p>
<p>Given that the WordPress.org theme directory is riddled with violations of what is purported to be a long standing guideline, it&#8217;s clear that reviewers have been exceedingly lax in enforcing it. Theme authors who were ignorant of this guideline will be in for a rude awakening on their next submission for an update. Bennett <a href=\"https://themes.trac.wordpress.org/ticket/24907\" target=\"_blank\">confirmed</a> in the ticket open on Zerif Lite that the policy will be strongly enforced in the future:</p>
<blockquote><p>It has recently come to our attention that possibly several themes have been approved that may have similar issues. We&#8217;ll address them as we find them, and work with the developers to come up with a plan to bring the themes back into conformance with the requirements &#8211; just as we&#8217;ll do here with your theme.</p></blockquote>
<p>This will mean a considerable amount of work for authors who have defined ways for users to generate content through the theme. They will need to port this functionality into a plugin(s).</p>
<p>WordPress.org themes are not permitted to bundle plugins, but authors can recommend plugins using the <a href=\"http://wptavern.com/tgm-plugin-activation-library-publishes-roadmap-for-version-3-0\" target=\"_blank\">TGM Plugin Activation Library</a> or another method. Themes are only permitted to recommend plugins that are listed in the official WordPress.org plugin directory. This means that authors who remove functionality in favor of companion plugins will need to get those plugins approved for WordPress.org before submitting their themes for updates.</p>
<p>Next week&#8217;s Theme Review Team meeting will include a discussion on specific examples of types of content that themes should or should not be allowed to create, i.e. button text, copyright text, etc. The team is generally in favor of authors using core methods for content creation.</p>
<p>Documentation regarding this issue has been unclear, incomplete, and scattered, spread across the Codex, Make/Themes, and two different places in the Theme Handbook. The team is working to rectify this in light of its renewed dedication to systematically enforce the &#8220;no content creation&#8221; guideline.</p>
<p>This will affect many of the top themes hosted on WordPress.org, which will be forced to implement changes that are likely to break thousands of sites&#8217; appearance on update. <a href=\"http://wptavern.com/do-wordpress-org-themes-need-a-changelog\" target=\"_blank\">Without a change log</a> in place, many users will not be aware when they are receiving an update that suddenly requires the installation of new plugins.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 27 May 2015 21:31:06 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:17;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Matt: Why Awe?\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:21:\"http://ma.tt/?p=45102\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"http://ma.tt/2015/05/why-awe/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:436:\"<blockquote><p>In the great balancing act of our social lives, between the gratification of self-interest and a concern for others, fleeting experiences of awe redefine the self in terms of the collective, and orient our actions toward the needs of those around us.</p></blockquote>
<p>The New York Times answers <a href=\"http://www.nytimes.com/2015/05/24/opinion/sunday/why-do-we-experience-awe.html\">Why Do We Experience Awe?</a></p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 27 May 2015 16:48:33 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"Matt\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:18;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:63:\"WPTavern: My Struggle to Learn How the WordPress REST API Works\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=44319\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:73:\"http://wptavern.com/my-struggle-to-learn-how-the-wordpress-rest-api-works\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:3087:\"<p>Earlier today, I watched a <a href=\"http://wptavern.com/learn-how-to-utilize-the-wp-rest-api-with-rachel-baker\">free presentation</a> on how to use the WordPress REST API by Rachael Baker via <a href=\"http://wpsessions.com\">WPSessions</a>. If you missed it, you can <a href=\"http://wpsessions.com/sessions/utilizing-the-wp-rest-api/\">watch the recording</a> for $9.</p>
<p>As I watched the presentation, it was clear that no matter how many tutorials I read, WordCamp sessions I attend, and videos I watch, I won&#8217;t be able to grasp the API until I use products built with it. I&#8217;m not a developer and the REST API is developer centric technology.</p>
<h2>What I Think the REST API Is</h2>
<p>Based on what I&#8217;ve learned so far, I&#8217;ve figured out that the API provides a series of end points which are specific parts of WordPress. These end points can be connected to and manipulated through the REST API.</p>
<p>It&#8217;s this API that opens up a slew of new opportunities for application developers to send and receive data. This is what allows a developer to build an app that connects to WordPress with minimal code.</p>
<h2>Learning Custom Post Types</h2>
<p>In 2010, there <a href=\"https://wordpress.org/support/topic/styling-individual-pagesposts\">were a lot of requests</a> for <a href=\"http://www.nathanrice.net/blog/wordpress-2-8-and-the-body_class-function/\">tutorials</a> on how to give specific posts a unique style. When <a href=\"https://codex.wordpress.org/Post_Types\">Custom Post Types</a> were introduced in WordPress 3.0, I was excited because I thought they would provide the ability to create custom styles for posts.</p>
<p>Looking back, some of the requests are due to the <a href=\"http://codex.wordpress.org/Migrating_Plugins_and_Themes_to_2.7#Post_Classes\">post_class() function</a> added in WordPress 2.7 that provides the ability to use CSS to style a post. It took a few years to rewire my brain to not think of Custom Post Types this way.</p>
<p>When I described how long it took to figure out Custom Post Types on Twitter, Justin Tadlock responded, that end users should have never been introduced to the term <em>post type</em>.</p>
<blockquote class=\"twitter-tweet\" width=\"550\"><p lang=\"en\" dir=\"ltr\"><a href=\"https://twitter.com/jeffr0\">@jeffr0</a> End users should\'ve never heard the term \"post type\". We devs did a poor job with that. We should\'ve said \"forums,\" \"e-commerce,\"&#8230;</p>
<p>&mdash; Justin Tadlock (@justintadlock) <a href=\"https://twitter.com/justintadlock/status/603287148863819776\">May 26, 2015</a></p></blockquote>
<p></p>
<h2>Reviewing Products Helps Connect the Dots</h2>
<p>I didn&#8217;t fully comprehend Custom Post Types until I reviewed several WordPress products that utilized them. After awhile, I was able to connect the dots between what I saw in the WordPress backend and what appeared on the front end.</p>
<p>I think the same thing will happen when the REST API is added to WordPress core. I&#8217;ll be able to connect the dots and figure out how it works by reviewing products that use it.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 27 May 2015 02:02:41 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:19;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:77:\"WPTavern: Replace the BuddyPress Mystery Man with Unique, Colorful Identicons\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=39298\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:86:\"http://wptavern.com/replace-the-buddypress-mystery-man-with-unique-colorful-identicons\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:3665:\"<p><a href=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2015/05/buddypress-identicons-featured.jpg\"><img src=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2015/05/buddypress-identicons-featured.jpg?resize=752%2C377\" alt=\"buddypress-identicons-featured\" class=\"aligncenter size-full wp-image-44341\" /></a></p>
<p>Nothing makes a BuddyPress site seem more active or more colorful than when members upload their own unique avatars. Unfortunately, not all users have the motivation to follow through with adding a profile picture. You could use a plugin to <a href=\"http://wptavern.com/add-avatar-upload-to-buddypress-registration\" target=\"_blank\">add avatar upload to registration</a>, or even <a href=\"http://wptavern.com/new-plugin-forces-buddypress-users-to-upload-a-profile-photo\" target=\"_blank\">force BuddyPress users to upload a profile photo</a> before accessing other pages. However, this may seem a bit heavy handed for some social networks.</p>
<p>The <a href=\"https://wordpress.org/plugins/buddypress-identicons/\" target=\"_blank\">BuddyPress Identicons</a> plugin is one alternative that will bring some color to the members directory without troubling users to upload a profile photo. By default, those who haven&#8217;t uploaded an image will have the mystery man avatar assigned. Too many of these can turn your directories into a sea of grey and white and give the impression that members are not invested in the community. BuddyPress Identicons replaces the mystery man with GitHub-style identicons.</p>
<p><a href=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2015/05/buddypress-identicons.jpg\"><img src=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2015/05/buddypress-identicons.jpg?resize=644%2C404\" alt=\"buddypress-identicons\" class=\"aligncenter size-full wp-image-44322\" /></a></p>
<p>BuddyPress developer <a href=\"http://henrywright.me/\" target=\"_blank\">Henry Wright</a>, the plugin&#8217;s creator, was inspired by <a href=\"https://github.com/blog/1586-identicons\" target=\"_blank\">GitHub&#8217;s implementation of identicons</a>, which the social network added in 2013 for users who do not have a Gravatar. The idea is based on <a href=\"https://github.com/donpark/identicon\" target=\"_blank\">Don Park&#8217;s original Java and Canvas implementations</a> for creating unique identicons.</p>
<p><a href=\"http://i1.wp.com/wptavern.com/wp-content/uploads/2015/05/henry-identicon.jpg\"><img src=\"http://i1.wp.com/wptavern.com/wp-content/uploads/2015/05/henry-identicon.jpg?resize=229%2C163\" alt=\"henry-identicon\" class=\"alignright size-full wp-image-44338\" /></a>BuddyPress Identicons are uniquely generated from a hash of the member&#8217;s username. The implementation will not look exactly how it does on GitHub, as the logic used to generate the identicon is somewhat different. In fact, this plugin allows for a few customizations to better fit your social network. You can set the background to transparent in the BuddyPress settings menu and also adjust the image size by <a href=\"https://wordpress.org/plugins/buddypress-identicons/faq/\" target=\"_blank\">defining the constants in your bp-custom.php file</a>.</p>
<p>The plugin is compatible with both WordPress multisite and bbPress. After testing it on a BuddyPress site, I can confirm that it works as advertised. If you&#8217;ve been frustrated by a lack of unique avatars on your social network, the <a href=\"https://wordpress.org/plugins/buddypress-identicons/\" target=\"_blank\">BuddyPress Identicons</a> plugin provides an instant fix. Simply install it from WordPress.org, activate it, and all of your mystery men will be transformed into unique, colorful identicons.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 26 May 2015 23:04:33 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:20;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:77:\"WPTavern: Postcard Project Discontinued, iOS and Android Apps Now Open Source\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=44282\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:86:\"http://wptavern.com/postcard-project-discontinued-ios-and-android-apps-now-open-source\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:6094:\"<p><a href=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2015/05/postcard-share.jpg\"><img src=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2015/05/postcard-share.jpg?resize=316%2C531\" alt=\"postcard-share\" class=\"alignright size-full wp-image-44291\" /></a>Kyle Newsome, creator of <a href=\"http://www.postcardsocial.net/\" target=\"_blank\">Postcard</a>, announced over the weekend that the project will be discontinued. The free social sharing app for iOS <a href=\"http://wptavern.com/own-your-content-postcard-social-sharing-app-launches-with-wordpress-integration\" target=\"_blank\">launched in February of 2014</a> with the aim to make it easy to share content from your phone to multiple social networks, including your own website.</p>
<p>Postcard&#8217;s chief selling point was the idea of owning your own content. Instead of posting content directly on Facebook or Twitter, for example, you could set your own website as the “host” network and direct all the traffic there.</p>
<p>Newsome also built a free WordPress <a href=\"https://wordpress.org/plugins/postcard-social/\" target=\"_blank\">plugin</a> as a companion to the app to allow users to host and archive their data. He intended it to help users make sure their websites didn&#8217;t go stale as they regularly posted short form content to social networks.</p>
<p>Unfortunately, the idea did not catch on as Newsome hoped it would and he was unable to keep up with the maintenance.</p>
<p>&#8220;I&#8217;ve fallen behind on maintenance and, due to some sweeping new policy changes in Facebook&#8217;s platform as of May 2015, the live iOS and Android development versions are broken and it&#8217;s been the final kick in my ass necessary to admit Postcard is unsustainable,&#8221; he said.</p>
<p>Despite making progress on the Android version last month, he was ultimately unable to get it ready for release on the Android market.</p>
<blockquote class=\"twitter-tweet\" width=\"550\"><p lang=\"en\" dir=\"ltr\">Android version making progress. It is very real. <a href=\"http://t.co/7nYYtnHZpm\">pic.twitter.com/7nYYtnHZpm</a></p>
<p>&mdash; Postcard (@postcardsocial) <a href=\"https://twitter.com/postcardsocial/status/458338905772023808\">April 21, 2014</a></p></blockquote>
<p></p>
<p>In <a href=\"http://postcardsocial.net/posts/2015-05-25-post-mortem\" target=\"_blank\">Postcard&#8217;s post mortem</a>, Newsome identified changes to external services and their APIs as one of the primary factors for discontinuing the project.</p>
<blockquote><p>Postcard was an interesting project for me. It started from a frustration with ever changing policies and lack of standardization in social media and ironically will be shutting down for exactly the same reasons. I really have to say that social media management is a tough thing to tackle for any single developer. It&#8217;s hard enough to depend on code that you didn&#8217;t write yourself and it&#8217;s even harder to depend multiple on APIs. It takes a lot of maintenance just to stand still.</p></blockquote>
<p>Keeping the WordPress plugin updated was also a challenge, and Newsome was discouraged at the prospect of having to rebuild it in the near future.</p>
<p>&#8220;The WordPress plugin also got stale as a major update and even a new forthcoming JSON API made the custom work I had done seem like a large investment made in something soon to be obsolete,&#8221; he said.</p>
<p>Additionally, he found that the costs of maintaining the app, both financially and in terms of time spent, were unsustainable, as the app only pulled in a total of $750 over the past year. This barely covered the app store licensing fees.</p>
<h3>Postcard Mobile Apps Now Open Source</h3>
<p>Newsome has no intention of maintaining or developing the mobile apps or the <a href=\"https://wordpress.org/plugins/postcard-social/\" target=\"_blank\">WordPress plugin</a> anymore. The apps are now available on GitHub under the MIT license with broken/partial functionality:</p>
<ul>
<li><strong>iOS:</strong> <a href=\"http://github.com/bitwit/postcard-ios\" target=\"_blank\">github.com/bitwit/postcard-ios</a></li>
<li><strong>Android:</strong> <a href=\"http://github.com/bitwit/postcard-android\" target=\"_blank\">github.com/bitwit/postcard-android</a></li>
</ul>
<p>All the code is available to any developer who wants to take the original Postcard idea and run with it or modify it to suit another purpose.</p>
<p>&#8220;I don&#8217;t want to be that developer who never admits their project is over when it&#8217;s over,&#8221; Newsome said. &#8220;Both myself and my users deserve better.&#8221;</p>
<p>He hoped that Postcard would fundamentally change how people use social networks, but the idea of having your WordPress site as the host network for your social content never really caught on. Since many people do not host and maintain their own websites, the golden feature of this app probably went unused by the majority of those who tried it. The ability to broadcast the same content to multiple networks was likely the more popular feature. In the end, the Postcard iOS app was downloaded just 6,000 times.</p>
<p>Postcard&#8217;s failure may be an indication that people are still not ready for decentralized social networking, where you host your own data and distribute it to third-party social networks at will. Given that the project was powered by a one-person team (a developer who is otherwise employed), Postcard had little chance of being able to keep pace with the development burden of external networks and their changing APIs.</p>
<p>Newsome may not have launched it with enough resources, or it may not have been the right approach or the right time. Multiple factors combined ultimately spelled Postcard&#8217;s doom, but if any interested parties have the vision and time to revive it or fork it, Newsome is happy to assist in any small way. You can contact him directly via the <a href=\"http://bitwit.ca/blog/2015-05-25-postcard-post-mortem/\" target=\"_blank\">Postcard post mortem blog</a> or on <a href=\"http://www.twitter.com/kylnew\" target=\"_blank\">Twitter</a>.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 26 May 2015 17:18:57 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:21;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"Matt: Best of Thelonious Monk\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:21:\"http://ma.tt/?p=45097\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:45:\"http://ma.tt/2015/05/best-of-thelonious-monk/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:556:\"<blockquote><p>Monk was the master of the single note, perfectly selected, timed, and struck so that it would have a symphonic amplitude. The asymptote of his music is a punctuated silence, which is why he was especially sensitive to his drummers and dependent on them to organize the music’s forward motion.</p></blockquote>
<p><a href=\"http://www.newyorker.com/culture/richard-brody/the-best-of-thelonious-monk\">The New Yorker reviews the 15 CD set, The Best of Thelonious Monk</a>, which sounds like a lovely set of music to spend a weekend with.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 26 May 2015 16:21:38 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"Matt\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:22;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:23:\"Matt: WordPress + Japan\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:21:\"http://ma.tt/?p=45095\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:37:\"http://ma.tt/2015/05/wordpress-japan/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:407:\"<p>Did you know that WordPress users in Japan have meetups dedicated just to eating crab in the Fukui prefecture? WP Tavern has <a href=\"http://wptavern.com/community-translation-and-wapuu-how-japan-is-shaping-wordpress-history\">has a fantastic article on Community, Translation, and Wapuu: How Japan is Shaping WordPress History</a>. There is so much that is quotable, just check out the entire thing!</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 25 May 2015 22:53:17 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"Matt\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:23;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:27:\"Matt: Bosworth says Be Kind\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:21:\"http://ma.tt/?p=45093\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:43:\"http://ma.tt/2015/05/bosworth-says-be-kind/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:361:\"<p>Andrew Bosworth, one of the early engineers and leaders at Facebook <a href=\"http://boz.com/articles/be-kind.html\">tells the story about how he almost got fired in the early days despite being a top engineer</a>. &#8220;If I was a good engineer, why would it be hard to work with me? Of course that question was the very foundation of my problem.&#8221;</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Sun, 24 May 2015 23:45:10 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"Matt\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:24;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:50:\"Andrew Nacin: Smarter algorithms, smarter defaults\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:24:\"http://nacin.com/?p=4329\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:54:\"http://nacin.com/2015/05/24/smart-algorithms-defaults/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:961:\"<blockquote><p>Instead of showing the user an alert that something might not work, maybe we can build a smarter algorithm. Instead of asking the user to make a choice up front, maybe we can set a smart default and see if there is high demand after launch for more customization.</p></blockquote>
<p>— <a href=\"http://www.rebeccarolfe.com/\">Rebecca Rolfe</a> on the Google Chrome team, interviewed in <a href=\"http://www.refinery29.com/female-white-hat-hackers-google-chrome\">The Badass Women of Chrome&#8217;s Security Team</a> in Refinery29.</p>
<p>(More on making <a href=\"http://nacin.com/2011/12/18/in-open-source-learn-to-decide/\">decisions</a>, <a href=\"http://nacin.com/2013/07/01/firefox-makes-a-decision-removes-an-option/\">not options</a>.)</p>
<p class=\"share-sfc-stc\"><a href=\"http://twitter.com/share?url=http%3A%2F%2Fwp.me%2FpQEdq-17P&count=vertical&related=nacin&text=Smarter algorithms, smarter defaults\" class=\"twitter-share-button\"></a></p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Sun, 24 May 2015 23:11:28 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:12:\"Andrew Nacin\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:25;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:24:\"Matt: Soaring SV Housing\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:21:\"http://ma.tt/?p=45090\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:40:\"http://ma.tt/2015/05/soaring-sv-housing/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:277:\"<blockquote><p>Talent is leaving Silicon Valley because of high real estate costs. Today, the median price for a home just exceeded $1 million.</p></blockquote>
<p><a href=\"http://www.cnbc.com/id/102697372\">Why one in four Silicon Valley homebuyers wants to leave</a>. Yep.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Sun, 24 May 2015 01:38:19 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"Matt\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:26;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:23:\"Matt: TC on Apple Watch\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:21:\"http://ma.tt/?p=45087\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:39:\"http://ma.tt/2015/05/tc-on-apple-watch/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:373:\"<p>The John Biggs article on <a href=\"http://techcrunch.com/2015/05/16/why-im-still-wearing-my-apple-watch/\">Why I’m Still Wearing My Apple Watch</a> almost perfectly describes how I&#8217;m feeling about the watch right now. It is a very personal device, I&#8217;ve gotten attached to the little fellow, and I should probably start selling all my mechanical watches.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Sat, 23 May 2015 00:55:13 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"Matt\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:27;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:100:\"WPTavern: Cover: A Minimalist Blogging Theme for WordPress, Featuring Support for Aesop Story Engine\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=44165\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:110:\"http://wptavern.com/cover-a-minimalistic-blogging-theme-for-wordpress-featuring-support-for-aesop-story-engine\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:3410:\"<p>If you&#8217;re looking to bring your blog&#8217;s design back to the bare bones of pure content without distractions, then the new <a href=\"https://wordpress.org/themes/cover/\" target=\"_blank\">Cover</a> theme may be a good option. Cover brings blogging minimalism to a new level. After less than a month on WordPress.org, it has already been downloaded more than 2,500 times.</p>
<p><a href=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2015/05/cover.png\"><img src=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2015/05/cover.png?resize=880%2C660\" alt=\"cover\" class=\"aligncenter size-full wp-image-44244\" /></a></p>
<p>Cover was created by new WordPress.org theme author <a href=\"http://eichefam.net/\" target=\"_blank\">Paul Eiche</a> and is based on the popular <a href=\"http://underscores.me/\" target=\"_blank\">Underscores starter theme</a> maintained by Automattic.</p>
<p>The theme&#8217;s simple, single-column design is accented by support for full-width featured images. It was bundled with <a href=\"http://fortawesome.github.io/Font-Awesome/\" target=\"_blank\">Font Awesome</a> to allow users to easily add scalable vector icons to any content or social menu. Cover incorporates the lightweight <a href=\"https://github.com/WickyNilliams/headroom.js\" target=\"_blank\">Headroom.js</a> script for hiding your header until it&#8217;s needed. It also includes <a href=\"https://github.com/Prinzhorn/skrollr\" target=\"_blank\">skrollr.js</a>, a stand-alone parallax scrolling library for mobile (Android + iOS) and desktop.</p>
<p>Cover&#8217;s widgets and menus are optional and hidden behind an full-screen overlay triggered by the hamburger icon. This keeps the focus on your content while offering plenty of space for unlimited widgets in the overlay.</p>
<a href=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2015/05/cover-overlay.jpg\"><img src=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2015/05/cover-overlay.jpg?resize=965%2C669\" alt=\"Cover\'s overlay for widgets and menus\" class=\"size-full wp-image-44265\" /></a>Cover&#8217;s overlay for widgets and menus
<p>Cover supports one regular navigation menu, one for social media, and an additional social menu in the footer. If you&#8217;re using Jetpack’s Infinite Scrolling module, the theme will actually detect whether or not the footer social menu is present and respond accordingly.</p>
<p>The theme was built to make a nice accompaniment to sites using the <a href=\"https://wordpress.org/plugins/aesop-story-engine/\" target=\"_blank\">Aesop Story Engine</a> plugin, although it&#8217;s not required. When used with the plugin, content can expand to full-width when using components such as images, galleries, maps, etc.</p>
<p>If you&#8217;re a developer wanting to modify the theme, you&#8217;ll find that Cover&#8217;s stylesheet is compressed. It was built with Sass and the /sass directory includes all the necessary components for compiling the stylesheet.</p>
<p>Cover is a beautifully responsive theme that presents your website in a bold way on any device. Its minimalist design supports your content instead of upstaging it with the clutter of widgets and navigation. Check out a <a href=\"http://eichefam.net/projects/cover/\" target=\"_blank\">live demo</a> on the theme&#8217;s project page to see it in action. <a href=\"https://wordpress.org/themes/cover/\" target=\"_blank\">Cover</a> is available for free on WordPress.org.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 22 May 2015 23:15:58 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:28;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:94:\"WPTavern: Hello Security Plugin Aims to Educate WordPress Users on Web Security Best Practices\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=44205\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:104:\"http://wptavern.com/hello-security-plugin-aims-to-educate-wordpress-users-on-web-security-best-practices\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:4532:\"<p><a href=\"https://wordpress.org/plugins/hello-security/\">Hello Security</a> is a new plugin developed by <a href=\"https://profiles.wordpress.org/m_butcher/\">Michele Butcher</a> that displays security tips and reminders in the WordPress backend. It&#8217;s a fork of Hello Dolly and Butcher&#8217;s first plugin submitted to the <a href=\"https://wordpress.org/plugins/\">plugin directory</a>.</p>
<a href=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2015/05/HelloSecurityTips.png\"><img class=\"size-full wp-image-44216\" src=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2015/05/HelloSecurityTips.png?resize=478%2C159\" alt=\"Hello Security Tips\" /></a>Hello Security Tips
<p>Security best practices include PASSWORD is never a good password, backup all the things, and only give users the access they need. A full list of the tips used is located <a href=\"https://github.com/mlbanddrb/hello-security/blob/master/hello-security.php\">within the hello-security.php file</a>.</p>
<h2>Inspiration, Motivation, and Determination</h2>
<p>For years, Butcher has avoided learning how to code. Thanks to a WordCamp session and inspirational members of the WordPress community, she now has a plugin of her own. In this short interview, we find out what held her back from developing plugins sooner and who inspired her to go through the process.</p>
<p><strong>What held you back from writing your first plugin?</strong></p>
<p>For the longest time, I didn&#8217;t want to learn how to code. I was a firm believer in that there&#8217;s a plugin for everything. Once I was motivated enough to create one, I didn&#8217;t know what to create first.</p>
<p>I have ideas for the types of plugins I want to make but I always find three plugins with similar functionality. The first WordPress plugin I&#8217;ve ever looked at the code for is Better WP Security, developed by <a href=\"https://profiles.wordpress.org/chriswiegman/\">Chris Wiegman</a> that eventually turned into iThemes Security.</p>
<p>I knew I would have to dig deep into learning code before I could write a plugin that large. I discovered the best way to learn code is to jump in and read actively developed code. Once I became comfortable reading code, I started to get ideas on plugins to create.</p>
<p><strong>What motivated you enough to go through with creating and releasing your first plugin?</strong></p>
<p>I subconsciously kept telling myself to <em>just make something</em>. I eventually decided to get into plugin development and taking the first step was the hardest. I bounced ideas off of friends for a long time before I jumped in and just made one.</p>
<p>At WordCamp North Canton, I attended <a href=\"https://northcanton.wordcamp.org/2015/session/introduction-to-plugin-development/\">Topher DeRosia&#8217;s session, </a>Introduction to WordPress Plugin Development. After the session was over, I realized I didn&#8217;t have to make something that has thousands of lines of code. I brainstormed ideas, thinking how I could use Hello Dolly.</p>
<p><strong>What inspired you to write Hello Security?</strong></p>
<p>The first idea that came to mind in using Hello Dolly was not security related. I initially thought of doing something fun like Hello Jovi (Bon Jovi lyrics) or Hello Marvel where I use awesome one liners from the various Marvel movies. Iron Man quotes alone would have given me at least 30 lines to work with.</p>
<p>I decided against doing something fun and make something that could be useful. Many of the quotes in Hello Security are things I say at all of my talks, tell every client after I clean their site, and mention to everyone who is getting into WordPress.</p>
<p>Hello Security is there to help those who are either new to WordPress or might not know how or why they should keep their site secure. It is a way to be proactive before something bad happens. Wiegman and DeRosia inspired me the most and I&#8217;m glad they did.</p>
<h2>Informing Without Overwhelming</h2>
<p>Hello Security is a good plugin that educates users on best practices related to web security without overwhelming them with information. I tested Hello Security on WordPress 4.2.2 and didn&#8217;t experience any issues. It&#8217;s available for free on <a href=\"https://wordpress.org/plugins/hello-security/\">WordPress.org</a> and <a href=\"https://github.com/mlbanddrb/hello-security\">GitHub.</a> Butcher encourages those who want to see a security tip added to submit a <a href=\"https://github.com/mlbanddrb/hello-security\">pull request on GitHub</a>.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 22 May 2015 21:24:42 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:29;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:90:\"WPTavern: How WordPress Business Owners are Benefiting from Publicly Sharing Revenue Stats\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=44207\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:100:\"http://wptavern.com/how-wordpress-business-owners-are-benefiting-from-publicly-sharing-revenue-stats\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:4890:\"<p>In light of <a href=\"http://wptavern.com/automattic-acquires-woocommerce\" target=\"_blank\">Automattic&#8217;s recent acquisition of WooCommerce</a> (and all of WooThemes), estimated to be in the range of $30M, WordPress business owners have been infused with a fresh perspective of the value and potential in creating strong GPL-licensed products.</p>
<p>Automattic&#8217;s acquisition of Woo, colloquially referred to as the &#8220;WooMattic&#8221; deal, is the company&#8217;s first major purchase within the WordPress ecosystem since BuddyPress in 2007.</p>
<blockquote class=\"twitter-tweet\" width=\"550\"><p lang=\"en\" dir=\"ltr\">Perhaps most interesting: Woo is Automattic\'s first acquisition of a WP ecosystem product since BuddyPress (2007) <a href=\"http://t.co/AJ1CIPS9Nc\">http://t.co/AJ1CIPS9Nc</a></p>
<p>&mdash; Andrew Nacin (@nacin) <a href=\"https://twitter.com/nacin/status/601087179624947713\">May 20, 2015</a></p></blockquote>
<p></p>
<p>The business model that brought WooCommerce to success is a free base product with a marketplace of commercial extensions. This revenue model currently drives the success of many of the top products in the WordPress ecosystem and is also proving to be effective for new businesses looking to quickly establish a user base.</p>
<p>This morning, WordPress developer Scott Bolinger published a compilation of <a href=\"http://scottbolinger.com/2015-wordpress-revenue-statistics/\" target=\"_blank\">2015 WordPress business revenue statistics</a> based on publicly available transparency reports and figures submitted by business owners. The resource includes each company&#8217;s business model, description, and monthly/yearly revenue.</p>
<p><a href=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2015/05/wordpress-business-revenue.png\"><img src=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2015/05/wordpress-business-revenue.png?resize=1025%2C921\" alt=\"wordpress-business-revenue\" class=\"aligncenter size-full wp-image-44219\" /></a></p>
<p>Bolinger is planning to use this information in an upcoming presentation and will be keeping the resource up to date with new submissions and figures as they roll in.</p>
<p>Transparency reports from WordPress businesses, ranging from small to large, have been popping up frequently over the past year, as owners are surprisingly eager to share their progress and receive feedback from the community. These kinds of reports are not unique to the WordPress ecosystem, but they do seem to complement the spirit of adventure that is common among open source product developers.</p>
<p>Zack Katz, co-founder of <a href=\"http://wptavern.com/gravityview-is-now-public-on-github\" target=\"_blank\">GravityView</a>, remarked on his motivation to share the company&#8217;s revenue publicly.</p>
<p>&#8220;I think sharing revenue humanizes GravityView: we&#8217;re not a nameless corporation where you put in money and somehow good products and customer service come out,&#8221; he said. &#8220;Our customers are part of an interaction: their purchase of a support license directly allows us to develop the product and help them do great things with their websites.&#8221;</p>
<p>Katz hopes that the resource will be inspirational for WordPress entrepreneurs who are just getting started.</p>
<blockquote><p>The WordPress community is slowly realizing that businesses don&#8217;t have to be cutthroat black boxes to succeed. As more people and businesses share and open up, we&#8217;re redefining what it means to be a business in the WordPress ecosystem. I think this leads to lower barriers to entry for others to participate. By sharing GravityView&#8217;s numbers and some of the things I&#8217;ve learned, I hope others are better informed and inspired to join our community.</p></blockquote>
<p>Nick Haskins, founder of Aesop Interactive, is currently in the midst of <a href=\"http://wptavern.com/lasso-frontend-editing-plugin-for-wordpress-now-available-on-github\" target=\"_blank\"> active experimentation with his products and business model</a> and recently published a <a href=\"http://aesopinteractive.com/jan-april-2015-report/\" target=\"_blank\">transparency report</a> for his 15-month old company. He believes that these kinds of reports are important for demonstrating the types of products and pricing models that can be successful.</p>
<p>&#8220;I think for Aesopinteractive it&#8217;s showing that you can still abide by WordPress theme best practices, and be successful at selling WordPress themes as add-ons at $129 each with 3-5 options and no functionality,&#8221; Haskins said.</p>
<p>&#8220;Plus, I really hope it motivates other &#8216;small timers&#8217; to share numbers as well, and be held accountable for our growth. It&#8217;s a lot like sharing your goals publicly, and letting people hold you accountable for it. Sink or swim, the lessons will be valuable either way.&#8221;</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 22 May 2015 20:11:30 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:30;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:44:\"WPTavern: WPWeekly Episode 193 – WooMattic\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:44:\"http://wptavern.com?p=44199&preview_id=44199\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:50:\"http://wptavern.com/wpweekly-episode-193-woomattic\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:3179:\"<p>In this episode of WordPress Weekly, <a href=\"http://marcuscouch.com/\">Marcus Couch</a> and I break down Automattic&#8217;s acquisition of WooThemes and discuss the future of WooCommerce. We discuss how the Japanese WordPress community influences WordPress development. Last but not least, we debate the merits of using an honor system for commercial plugins.</p>
<h2>Stories Discussed:</h2>
<p><a href=\"http://wptavern.com/automattic-acquires-woocommerce\">Automattic Acquires WooThemes</a><br />
<a href=\"http://wptavern.com/wordpress-org-is-testing-international-theme-and-plugin-directories\">WordPress.org is Testing International Theme and Plugin Directories</a><br />
<a href=\"http://wptavern.com/community-translation-and-wapuu-how-japan-is-shaping-wordpress-history\">Community, Translation, and Wapuu: How Japan is Shaping WordPress History</a><br />
<a href=\"http://wptavern.com/lasso-frontend-editing-plugin-for-wordpress-now-available-on-github\">Lasso Frontend Editing Plugin for WordPress Now Available on GitHub</a><br />
<a href=\"http://wptavern.com/cpanels-site-software-addon-disables-wordpress-auto-updates\">cPanel’s Site Software Addon Disables WordPress Auto Updates</a><br />
<a href=\"http://wptavern.com/all-sessions-from-loopconf-now-available-on-youtube\">All Sessions from LoopConf Now Available on YouTube</a></p>
<h2>Plugins Picked By Marcus:</h2>
<p><a href=\"https://wordpress.org/plugins/simply-pinterest/\">Simply Pinterest</a> adds a Pin It button call to action over each image in your post to prompt visitors to Pin your content. You can customize how the plugin is applied to your site with counts, colors and many other settings.</p>
<p>I wanted to highlight this plugin because it’s the first from Terry Ann Swallow. Terry has been active in WordPress since 2006 but this is her first plugin, and it’s good. We often forget to recognize first time plugin contributors, and I want to recognize Terry and wish her well with this plugin and many more to follow.</p>
<p><a href=\"https://wordpress.org/plugins/new-facebook-comments/\">New Facebook Comments</a> makes it simple to add the Facebook comments system to WordPress. You can also insert the comment box as a shortcode into any post, page or theme.</p>
<p><a href=\"https://wordpress.org/plugins/simple-project-managment/\">Simple Project Manager</a> lets you manage projects, clients, tasks, and create invoices in PDF format. It also gives you the ability to run reports about projects, clients, tasks and invoices.</p>
<h2>WPWeekly Meta:</h2>
<p><strong>Next Episode:</strong> Wednesday, May 27th 4:00 P.M. Eastern</p>
<p><strong>Subscribe To WPWeekly Via Itunes: </strong><a href=\"https://itunes.apple.com/us/podcast/wordpress-weekly/id694849738\" target=\"_blank\">Click here to subscribe</a></p>
<p><strong>Subscribe To WPWeekly Via RSS: </strong><a href=\"http://www.wptavern.com/feed/podcast\" target=\"_blank\">Click here to subscribe</a></p>
<p><strong>Subscribe To WPWeekly Via Stitcher Radio: </strong><a href=\"http://www.stitcher.com/podcast/wordpress-weekly-podcast?refid=stpr\" target=\"_blank\">Click here to subscribe</a></p>
<p><strong>Listen To Episode #193:</strong><br />
</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 22 May 2015 16:15:12 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:31;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:22:\"Matt: Undercover UberX\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:21:\"http://ma.tt/?p=45059\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:38:\"http://ma.tt/2015/05/undercover-uberx/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:337:\"<p>Emily Guendelsberger <a href=\"http://citypaper.net/uberdriver/\">went undercover as an UberX driver in Philadelphia and wrote about the experience, particularly the economics of it</a>. It&#8217;s a pretty fascinating and gripping <a href=\"http://longreads.com/\">longread</a>, both in its content and it&#8217;s just well-written.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 22 May 2015 05:29:00 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"Matt\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:32;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:79:\"WPTavern: Hookr Enters Beta with New UI and Support for 800+ Plugins and Themes\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=44167\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:88:\"http://wptavern.com/hookr-enters-beta-with-new-ui-and-support-for-800-plugins-and-themes\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:9212:\"<p><a href=\"http://i1.wp.com/wptavern.com/wp-content/uploads/2015/05/hookr-featured.jpg\"><img src=\"http://i1.wp.com/wptavern.com/wp-content/uploads/2015/05/hookr-featured.jpg?resize=1025%2C464\" alt=\"hookr-featured\" class=\"aligncenter size-full wp-image-44175\" /></a></p>
<p>Last April, <a href=\"https://twitter.com/explodybits\" target=\"_blank\">Christopher Sanford</a> launched <a href=\"http://hookr.io/\" target=\"_blank\">Hookr</a>, a WordPress hook/API reference for developers. He initially wrote the parser/indexer for his own use, to improve efficiency in his work, and was inspired to make it a public resource.</p>
<p>&#8220;I have been professionally working with WordPress since 2.8, but most of which I would describe as &#8216;superficial development,\'&#8221; Sanford said. &#8220;It wasn&#8217;t until later, roughly WordPress 3.5, that a large-scale WordPress project came along.</p>
<p>&#8220;I found myself spending an obscene amount of time either digging through code within my IDE, or performing countless Google searches, in order to uncover/understand various hooks, functions, constants etc. So, I wrote a plugin that would index the application/site it was installed within&#8211; this was the first iteration of Hookr.&#8221;</p>
<p>As a developer whose career is not based in the WordPress ecosystem, Sanford didn&#8217;t know what to expect when he tested the waters with his new public resource for developers. After several months in alpha, the traffic and feedback were enough to convince him to invest in performance improvements and an overhaul of the UI.</p>
<p>&#8220;The alpha version of the site was truly alpha &#8211; the UI was a complete afterthought, there were many UI bugs/hiccups, the navigation was not cohesive; it was a hot mess,&#8221; Sanford said. &#8220;Prior to the beta, I had not updated hookr.io for months, which was purposeful. I wanted to see if the traffic would completely level-off, or if it would remain consistent, with the latter being the determining factor as to whether or not I would continue with the project.&#8221;</p>
<h2>Hookr Beta Adds UI/UX Improvements and Support for 800+ Plugins and Themes</h2>
<p>Sanford was surprised and encouraged to find that usage of the site was solid and continued to grow. He spent the next three months fixing issues, rewriting core parts of the parser, and refining the UI to focus on features that people actually needed. The site has now entered beta with a slew of noteworthy improvements:</p>
<ul>
<li>UI/UX overhaul, with emphasis on responsiveness and fewest number of clicks</li>
<li>Hookr.io is now twice as fast with half the download payload (mobile first)</li>
<li>Themes have been introduced to the index &#8211; (current count: 62)</li>
<li>Hundreds of plugins added to the index (current count: 827)</li>
<li>5 of the latest versions of each plugin and theme (previously included a single version for each plugin)</li>
<li>Usage examples that users can cut and paste</li>
<li>Annotated source code</li>
</ul>
<p><a href=\"http://hookr.io/all/#index=a\" target=\"_blank\">Index screens</a> are infinitely-scrollable and filterable, which cuts down on a lot of clicking through endless pagination. <a href=\"http://hookr.io/4.1.1/filters/get_search_form/\" target=\"_blank\">Hook details</a> have been refined to follow a format similar to PHP&#8217;s detail pages and include annotated code signatures and descriptions.</p>
<p><a href=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2015/05/hookr-annotated-descriptions.png\"><img src=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2015/05/hookr-annotated-descriptions.png?resize=1025%2C701\" alt=\"hookr-annotated-descriptions\" class=\"aligncenter size-full wp-image-44177\" /></a></p>
<p>In addition to the basic info about the file and lines where the code/object is defined, Hookr has also been updated to display any related hook callbacks sharing the same tag name or signature.</p>
<p><a href=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2015/05/hookr-relations.png\"><img src=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2015/05/hookr-relations.png?resize=1025%2C701\" alt=\"hookr-relations\" class=\"aligncenter size-full wp-image-44179\" /></a></p>
<p>Usage examples for every action, filter, function, and constant can now be easily copied. Users can also quickly view source code with Hookr&#8217;s new hyperlinked and annotated source code blocks.</p>
<h2>To Rebrand or Not to Rebrand?</h2>
<p>Many of those in search of a comprehensive hook/API reference find Hookr to be easier to use than the official <a href=\"https://developer.wordpress.org/reference/\" target=\"_blank\">WordPress.org code reference</a>. Sanford has experienced friction from creating what some perceive to be a competing resource.</p>
<blockquote><p>There were several people that have/had an issue with the resource even existing. For the sake of full-disclosure, my career is outside the WordPress ecosystem; it is simply a platform I use (and love), not a lifestyle. </p>
<p>My experience with the &#8216;community&#8217; has been mostly positive; many people love the resource, while others are indifferent. I wrote Hookr to aid legit designers/developers/agencies, not hobbyists masquerading as designers/developers who have no skill besides martyrdom and nothing positive to contribute.</p></blockquote>
<p>The Hookr name has also proven to be controversial, as a few vocal opponents find it to be off-putting and offensive. Sanford said that he is very much torn over rebranding the site but is open to the idea.</p>
<p>&#8220;The WordPress market is saturated &#8211; it is hard to make any sort of impact, hence the name,&#8221; he said. &#8220;The name is short, controversial, relevant, and memorable &#8211; either people love or hate it, of course. It was never the intent to insult, offend, or alienate any demographic.</p>
<p>&#8220;If people are uncomfortable saying &#8220;Hookr&#8221; in an open forum, then maybe it&#8217;s time to put my personal ethos aside for the betterment of the resource. That being said, I am on the fence in regards to renaming/rebranding Hookr. If I do, it&#8217;s only to remove the initial barrier/stigma and promote usage.&#8221;</p>
<p>As the site is still in beta, Sanford is still collecting feedback from users but is concentrating on features, fixes, and SEO. If he decides to rebrand, it will likely happen as the site moves out of beta.</p>
<h2>The Future of the Hookr.io Resource</h2>
<p>After streamlining the design, removing a few features that no one used, and refining those that worked, Sanford reports that so far users are enjoying the beta version of Hookr.</p>
<p>&#8220;The feedback I have received has been exceedingly positive,&#8221; he said. &#8220;The usage has effectively doubled.&#8221; User suggestions regarding the search functionality are shaping the roadmap for the next iteration of the resource.</p>
<p>&#8220;The current search implementation is more or less a filter mechanism, which is effective once you&#8217;ve drilled-down to the relevant index,&#8221; Sanford said. &#8220;However, numerous users have asked for a traditional &#8216;global&#8217; keyword search that spans core, plugins, and themes. The global search, along with a few other features, will be released within the next month or so.&#8221;</p>
<p>While Sanford is committed to keeping the resource free for anyone to use, he is exploring a few long term options for monetization.</p>
<p>&#8220;Cluttering the interface with ads is not something I want to do, but never say never,&#8221; he said. &#8220;However, there is another opportunity for monetization.&#8221;</p>
<p>In the future, Sanford is looking at the possibility of establishing the infrastructure to offer Hookr (SaaS) for commercial theme and plugin developers.</p>
<blockquote><p>When I released Hookr Alpha, a few people inquired about using it to augment the documentation of their premium plugin/theme. I wasn&#8217;t confident that it was a true &#8216;value-add.&#8217; Over the course of a year, I&#8217;ve refined the parser and data objects to a point of viability. </p>
<p>The Hookr Parser analyzes source code, which is then reconciled against the inline documentation describing it; often times, the inline documentation is either missing or is erroneous. <a href=\"https://twitter.com/TheJeffMatson\" target=\"_blank\">Jeff Matson</a> and I discussed these issues and decided that Hookr would be invaluable if it could identify these issues, which it now does.</p></blockquote>
<p>A SaaS model for monetization would allow Sanford to offer developers pre-generated documentation with their themes/plugins. He is also exploring the possibility of offering the raw data in JSON, XML, CSV, etc. to vendors to implement an API microsite.</p>
<p>For the time being, Sanford will continue investing time into improving Hookr as a reference and refining features according to user feedback. If you use <a href=\"http://hookr.io/\" target=\"_blank\">Hookr.io</a> regularly, feel free to offer your suggestions in the comments and <a href=\"http://twitter.com/hookr_io\" target=\"_blank\">follow the project on Twitter</a> for all the latest updates.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 21 May 2015 20:05:04 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:33;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:26:\"Matt: William Zinsser Obit\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:21:\"http://ma.tt/?p=45066\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:42:\"http://ma.tt/2015/05/william-zinsser-obit/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:515:\"<blockquote><p>Mr. Zinsser was a prolific author, editor and teacher, but it was his role as an arbiter of good writing that resonated widely and deeply.</p></blockquote>
<p>The <a href=\"http://www.nytimes.com/2015/05/13/arts/william-zinsser-author-of-on-writing-well-dies-at-92.html\">New York Times obituary of William Zinsser is touching and fascinating</a>. Clear writing and clear thinking go hand in hand, and Zinnsser&#8217;s work <em>On Writing Well</em> did more than any other to help me hone my mind.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 21 May 2015 04:41:32 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"Matt\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:34;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:103:\"WPTavern: Happy Joe Partners with WebDevStudios, SiteGround and Announces Dates for WordPress BootCamps\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=44114\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:112:\"http://wptavern.com/happy-joe-partners-with-webdevstudios-siteground-and-announces-dates-for-wordpress-bootcamps\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:6025:\"<p><a href=\"https://www.happyjoe.org/\">Happy Joe</a>, a 501 c3 non-profit organization that helps U.S. veterans with entrepreneurship and employment opportunities <strong>using WordPress,</strong> has announced a new round of sponsorships and dates to upcoming boot camps.</p>
<p>When I <a href=\"http://wptavern.com/happy-joe-uses-wordpress-to-train-and-help-veterans-find-careers-in-web-technology\">talked to James Dalman</a>, founder of Happy Joe in late 2014, he emphasized how important financial assistance is to the organization, &#8220;We need people to help fund the training and mentoring of our veterans. We have a lot of people who are sharing the story and mission of Happy Joe and we are <strong>VERY</strong> appreciative of that. However, we need sponsorships and donations to make a true difference.&#8221;</p>
<h2>New Sponsors</h2>
<p><a href=\"http://webdevstudios.com/\">WebDevStudios</a> is <a href=\"http://webdevstudios.com/2015/05/19/webdevstudios-partners-with-happy-joe/\">partnering with Happy Joe</a> as a <a href=\"http://www.happyjoe.org/partners/\">Hero Partner</a> which is the highest financial contributing level available. Considering the number of military veterans that work at WebDevStudios, the organizations are a perfect match. The agency will also volunteer their time and expertise at upcoming <a href=\"http://www.happyjoe.org/wp-bootcamp/\">WP BootCamps</a> across the United States.</p>
<p>I asked Brad Williams, founder of WebDevStudios and a military veteran, what it means to be able to help veterans through Happy Joe.</p>
<blockquote><p>I’m very excited to officially support Happy Joe and their efforts to help Veterans find jobs. As a Veteran myself, I know the struggles trying to find work after leaving the Service, so knowing we are doing something to help ease that process makes me extremely proud.</p></blockquote>
<p><a href=\"https://www.siteground.com/\">SiteGround,</a> a webhosting company based in Bulgaria, is also <a href=\"http://www.happyjoe.org/corporate-partnerships/\">partnering with Happy Joe</a> and will provide business mentoring, career development, training resources, and work opportunities to military veterans and their families.</p>
<p>The company is also providing free hosting for three months to all WP BootCamp attendees. Dalman hints that the partnership may one day lead to the first WP BootCamp in Europe.</p>
<h2>Upcoming WP BootCamps</h2>
<a href=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2014/11/WPBootCamp.png\"><img class=\"size-full wp-image-33462\" src=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2014/11/WPBootCamp.png?resize=639%2C200\" alt=\"WordPress Boot Camp\" /></a>photo credit: <a href=\"https://www.flickr.com/photos/vamcmag/3098352208/\">MizGingerSnaps</a> &#8211; <a href=\"http://creativecommons.org/licenses/by-nc-nd/2.0/\">cc</a>
<p><a href=\"http://www.happyjoe.org/wp-bootcamp/\">WP BootCamps</a> are events tailored to the military community and help veterans of the Armed Forces to set up resume style websites on WordPress so that they can be seen as technology relevant. Veterans are also shown how to launch or build a very successful business or career in the WordPress marketplace.</p>
<p>Dalman has released a schedule of upcoming camps with the first taking place on July 11th and 12th on <a href=\"http://godaddy.com/\">GoDaddy&#8217;s</a> Sunnyvale, CA campus.</p>
<ul>
<li>Sunnyvale, CA : July 11 &amp; 12</li>
<li>Las Vegas, NV : July 25-26</li>
<li>Seattle, WA : Aug 15 &amp; 16</li>
<li>San Diego, CA : September 12 &amp; 13</li>
<li>Austin, TX (WordCamp Austin) : Oct 16</li>
<li>Fayetteville, North Carolina : Dates TBA</li>
<li>Norfolk, Virginia : Dates TBA</li>
<li>Tampa, FL : Dates TBA</li>
</ul>
<p>Presentations will include, <em>Discovering Opportunities in WordPress, Starting Off Right with WordPress, Finding the Perfect (and Paying) Clients, Winning An Agency Interview, Skills Companies Pay MORE For</em> and more by the following presenters:</p>
<ul>
<li><a href=\"https://twitter.com/perezbox\">Tony Perez</a>, CEO and Founder of <a href=\"https://sucuri.net/\">Sucuri Security</a>, USMC Veteran</li>
<li><a href=\"https://twitter.com/dremeda\">Dre Armeda</a>, VP of Operations at <a href=\"http://webdevstudios.com/\">WebDevStudios</a> , US Navy Veteran</li>
<li><a href=\"https://twitter.com/lisasabinwilson\">Lisa Sabin Wilson</a>, COO at <a href=\"http://webdevstudios.com/\">WebDevStudios</a>, Author of <a href=\"http://www.amazon.com/Lisa-Sabin-Wilson/e/B002BLY54I/ref=ntt_athr_dp_pel_1\">WordPress for Dummies</a></li>
<li><a href=\"https://twitter.com/cdils\">Carrie Dils</a>, CEO at <a href=\"http://www.carriedils.com/\">Carrie Dils</a> and <a href=\"http://officehours.fm/\">Office Hours</a> , Veteran Spouse</li>
<li><a href=\"https://twitter.com/bobwp\">Bob Dunn</a>, CEO and Founder of <a href=\"http://bobwp.com/\">BobWP</a></li>
<li><a href=\"https://twitter.com/jamesdalman\">James Dalman</a>, CEO and Founder at <a href=\"http://happyjoe.org/\">Happy Joe</a>, US Army Veteran</li>
</ul>
<p>There are a limited amount of tickets available but only those who meet the following criteria are able to attend.</p>
<ul>
<li>All Active Duty Service Members</li>
<li>Military Veterans from any branch of service, regardless of era served</li>
<li>Military Spouse or Military Caregiver</li>
<li>Service Dogs</li>
<li>Non-Military People wanting to work with veterans (limited seating)</li>
</ul>
<p>You&#8217;ll need to show proof of military service via an Active Duty Card, Retirement Card, DD Form 214 from you, your spouse, or family member. Tickets have yet to go on sale but Dalman expects this information to be available in the next few weeks.</p>
<p>As we approach <a href=\"http://en.wikipedia.org/wiki/Memorial_Day\">Memorial Day</a> in the US, take some time to remember and thank those who honorably serve or served in the military. Consider <a href=\"https://www.happyjoe.org/donate/\">supporting an organization</a> like Happy Joe that works year round to give back to veterans.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 21 May 2015 03:52:31 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:35;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:64:\"WPTavern: Learn How to Utilize the WP REST API with Rachel Baker\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=43136\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:74:\"http://wptavern.com/learn-how-to-utilize-the-wp-rest-api-with-rachel-baker\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:5264:\"<a href=\"http://i1.wp.com/wptavern.com/wp-content/uploads/2014/05/building.jpg\"><img src=\"http://i1.wp.com/wptavern.com/wp-content/uploads/2014/05/building.jpg?resize=1024%2C526\" alt=\"photo credit: shenamt - cc\" class=\"size-full wp-image-23698\" /></a>photo credit: <a href=\"http://www.flickr.com/photos/shenamt/6906784503/\">shenamt</a> &#8211; <a href=\"http://creativecommons.org/licenses/by-nc-nd/2.0/\">cc</a>
<p>One trend at recent WordCamps is that any session on the <a href=\"https://github.com/WP-API/WP-API\" target=\"_blank\">WP REST API</a> will undoubtedly pack the room with attendees eager to learn more about using it. This was certainly the case at WordCamp London 2015 where more than 200 people crammed into a small room to hear <a href=\"http://wptavern.com/jack-lenox-on-building-themes-with-the-wp-rest-api\" target=\"_blank\">Jack Lenox’s presentation on Building Themes with the WP REST API</a>.</p>
<p><a href=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2015/05/rachel-baker.jpeg\"><img src=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2015/05/rachel-baker.jpeg?resize=140%2C140\" alt=\"rachel-baker\" class=\"alignright size-full wp-image-44126\" /></a>If you&#8217;re a developer who is ready to learn more about getting started with the API, you will not want to miss WPSessions&#8217; upcoming free live event. <a href=\"https://twitter.com/rachelbaker\" target=\"_blank\">Rachel Baker</a>, lead engineer at <a href=\"http://thewirecutter.com/\" target=\"_blank\">The Wirecutter</a> and formerly a senior engineer at <a href=\"http://10up.com/\" target=\"_blank\">10up</a>, will be presenting on <a href=\"http://wpsessions.com/sessions/utilizing-the-wp-rest-api/\" target=\"_blank\">Utilizing the WP REST API</a> on Tuesday, May 26, 2015.</p>
<p>Baker is one of the lead developers on the <a href=\"https://github.com/WP-API/WP-API\" target=\"_blank\">WP-API project</a> and is fully in tune with where it&#8217;s headed, as well as all the changes in the latest <a href=\"http://wptavern.com/wp-rest-api-version-2-0-beta-1-released\" target=\"_blank\">2.0 beta release</a>. The topics she plans to cover will help developers dive in and start extending 2.0.</p>
<p>&#8220;The content is driven by wanting to dig deeper with a more technical audience from the overview presentations you see at WordCamps and wanting to show off how easy it is to extend our version 2.0,&#8221; Baker said. &#8220;This course is only 30-40 minutes, but if it goes well Brian would like to add more.&#8221;</p>
<p>She plans to cover the following topics:</p>
<ul>
<li>Installing the WP REST API</li>
<li>Consuming core endpoints</li>
<li>Creating custom endpoints</li>
<li>Manipulating and Extending API results</li>
<li>Preparing for future inclusion in WordPress core</li>
</ul>
<p>&#8220;It is targeted at developers who are interested in seeing how they can use and customize the API,&#8221; Baker said. &#8220;Front-end and full-stack developers will see how to add additional fields to the existing endpoint responses. Plugin developers will see a demonstration of how to add their own endpoints. If you are interested in using the WP REST API, or have used version 1.x, you will want to see how version 2.0 works.&#8221;</p>
<p>Baker&#8217;s session will essentially be a crash course in getting started, covering all the basics and more. While there has been a great deal of excitement surrounding the API and what it means for the future of WordPress, many developers are still getting a grasp on how they can incorporate it into real world projects. John James Jacoby made an interesting observation in his <a href=\"http://jaco.by/2015/05/14/loopconf/\" target=\"_blank\">recap of LoopConf</a>:</p>
<blockquote><p>So many mentions of the REST API, but not a lot of truly practical usages yet – everyone is building WordPress minus WordPress instead of replacing existing piecemeal AJAX calls or iteratively improving WordPress itself.</p></blockquote>
<p>Baker is planning to include practical examples in her presentation. One of her main objectives is to help developers get going with the 2.0 beta version so they can offer feedback as they continue to work with it.</p>
<p>&#8220;I can think of many practical uses, from powering interactions in a plugin like <a href=\"https://wordpress.org/plugins/custom-contact-forms/\" target=\"_blank\">Custom Contact Forms</a> to providing an API for a mobile app like <a href=\"https://storycorps.me/\" target=\"_blank\">StoryCorps.me</a>,&#8221; Baker said.</p>
<p>&#8220;Our community is hearing that the WP REST API is going to <em>change WordPress</em> and they haven’t seen that happen. I don’t see the WP REST API as changing WordPress. I see the WP REST API as a WordPress feature that makes it easier to interact with your site’s data.&#8221;</p>
<p>Those who haven&#8217;t been able to attend a session on the API in person have an excellent opportunity to see <a href=\"http://wpsessions.com/sessions/utilizing-the-wp-rest-api/\" target=\"_blank\">Baker&#8217;s WPSessions presentation</a> live for free on Tuesday, May 26th at 3pm EST (<a href=\"http://www.timeanddate.com/worldclock/fixedtime.html?iso=20150526T19&p1=1440&ah=1\" target=\"_blank\">UTC-4</a>). It will also be recorded and available after the event for $9.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 20 May 2015 21:43:50 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:36;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:110:\"WPTavern: WordPress Trainer Morten Rand-Hendriksen on Common Pain Points, Roadblocks, and Advice for New Users\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=43952\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:118:\"http://wptavern.com/wordpress-trainer-morten-rand-hendriksen-on-common-pain-points-roadblocks-and-advice-for-new-users\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:9380:\"<p>The WordPress community is filled with resources to learn about WordPress but finding them can be difficult. WordPress is developed around the clock and locating material that keeps pace can also be a challenge.</p>
<p><a href=\"http://www.lynda.com/\">Lynda.com</a> is an online learning center devoted to teaching topics such as, business, technology, design, and photography. For more than five years, <a href=\"http://mor10.com/\">Morten Rand-Hendriksen</a> has taught and maintained the <i><a href=\"http://www.lynda.com/WordPress-tutorials/WordPress-Essential-Training/154417-2.html\">WordPress Essential Training</a></i> course on Lynda.com. The course has been viewed by more than 100,000 individuals and to celebrate, Lynda.com is making it<a href=\"http://www.lynda.com/articles/wordpress-training-100000-views\"> available for free</a> for one month.</p>
<p>By maintaining a WordPress training course, Hendriksen is in a unique position to see trends. He&#8217;s also had to keep up with and monitor the vast changes to WordPress that have occurred in the last five years. In the following short interview, Hendriksen describes common pain points users experience with WordPress and shares advice for new users.</p>
<h2>Short Interview with Hendriksen</h2>
<a href=\"http://i1.wp.com/wptavern.com/wp-content/uploads/2014/02/wordpress-swag.jpg\"><img class=\"size-full wp-image-17801\" src=\"http://i1.wp.com/wptavern.com/wp-content/uploads/2014/02/wordpress-swag.jpg?resize=1024%2C441\" alt=\"photo credit: Huasonic - cc\" /></a>photo credit: <a href=\"http://www.flickr.com/photos/huasonic/3008912290/\">Huasonic</a> &#8211; <a href=\"http://creativecommons.org/licenses/by-nc/2.0/\">cc</a>
<p><strong>Which aspects of WordPress do users have the most trouble with?</strong></p>
<p>Based on course feedback and a myriad of emails and questions on Twitter, the hangups people encounter when using WordPress fall into three main categories:</p>
<ol>
<li>Installation and migration</li>
<li>User interface and feature changes</li>
<li>Theme and plugin inconsistencies</li>
</ol>
<h3>Installation and Migration</h3>
<p>More and more users create local installs to experiment before launching their sites, and they&#8217;re creating quite advanced sites on their local computers. When it comes time to migrate these sites, they often get stuck.</p>
<p>I think this is partially due to lack of official and understandable documentation about migration, and partially because the general level of technical know-how necessary to build a local install is decreasing. Thanks to tools like MAMP/WAMP, BitNami, and ServerPress, more advanced skills like migration and external hosting become bigger steps up than they were previously.</p>
<h3><strong>User Interface and Feature Changes</strong></h3>
<p>As WordPress evolves, user interface changes are fairly common but in most cases, they are left unaddressed in release documentation. Recent examples include the removal of <a href=\"https://wordpress.org/support/topic/major-problems-with-image-editing-in-wp-39?replies=12\">Advanced Image Options</a> and <a href=\"http://wptavern.com/how-to-restore-the-link-title-attribute-removed-in-wordpress-4-2\">Link Title</a> from the editor modals. When changes like these are encountered by existing users, their first response is to assume they are doing something wrong or there is something wrong with their install.</p>
<p>In my opinion, this is justifiable: In other software and in most other situations in the physical world, when a feature is removed or altered in such a way it is not easily found, this change is clearly addressed.</p>
<p>In WordPress, it is usually only the large feature changes that are explained while the smaller ones are left for the user to discover on their own. When these features are part of the user&#8217;s workflow, that becomes a problem. This is further exacerbated when meta-conversations in the advanced community go public providing confusing and often contradictory information for new users.</p>
<h3><strong>Theme and Plugin Inconsistencies</strong></h3>
<p>The final grouping is the most obvious one. As the theme and plugin landscape becomes more diversified, users often feel overwhelmed and confused about what solutions to choose and how to use them. A search for membership plugins, business themes, or booking calendars returns hundreds if not thousands of widely different solutions that often have little in common.</p>
<p>Meanwhile, you can find blog posts and lists claiming that pretty much every one of them is the best one and the rest are inferior copies. On top of that, more and more themes and plugins are released as freemium offerings or shells that lead the user to a third-party service.</p>
<p>All of this comes together to produce a confusing and frustrating user experience that leaves many users feeling like they are not smart enough to use the application or that they made a wrong choice in going with WordPress.</p>
<p>These are all issues that could be resolved by creating consistent user experiences and by theme and plugin developer communities becoming more mindful of what kind of experiences they provide for the user when they ship freemium solutions or third-party up-sells.</p>
<a href=\"http://i1.wp.com/wptavern.com/wp-content/uploads/2015/05/WordPressRoadBlocks.png\"><img class=\"size-full wp-image-44073\" src=\"http://i1.wp.com/wptavern.com/wp-content/uploads/2015/05/WordPressRoadBlocks.png?resize=650%2C200\" alt=\"WordPress Road Blocks\" /></a>photo credit: <a href=\"http://www.flickr.com/photos/23559988@N05/2931537231\">Haven bridge road block</a> &#8211; <a href=\"https://creativecommons.org/licenses/by-nd/2.0/\">(license)</a>
<p><strong>Are there more roadblocks to overcome than there were five years ago?</strong></p>
<p>The answer to this question is both yes and no. WordPress has more roadblocks for the beginner, but for the more experienced user there are also more opportunities. I think one of the major challenges we are facing as a community is that WordPress is becoming too advanced for its core user base. The appeal of click-and-publish services like WIX and SquareSpace is that they do not require an in-depth understanding of the underpinnings of the application for it to work.</p>
<p>In striving to become a full-fledged CMS for advanced developers and large publications, <span class=\"pullquote alignleft\">WordPress has let itself drift away from its core philosophy of democratizing publishing by adding the very level of complexity it originally aimed to remove.</span> Combined with the theme and plugin issues described above and a lack of modern tools that users expect such as, drag-and-drop design tools and front-end editing, I see new users respond the same way to WordPress today that they did to Drupal five years ago.</p>
<p>On the plus side, these roadblocks are more like speed bumps than fortified walls. With patience and access to well-crafted and easy to understand training materials, I stand by my claim that anyone, regardless of previous experience, can learn to build a great website with WordPress. What has changed is the level of complexity, both in use and in what you can produce.</p>
<a href=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2015/05/WordPressAdviceForNewUsers.png\"><img class=\"size-full wp-image-44085\" src=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2015/05/WordPressAdviceForNewUsers.png?resize=612%2C237\" alt=\"WordPress Advice For New Users\" /></a>photo credit: <a href=\"http://www.flickr.com/photos/99329675@N02/11064947983\">What You Need To Know About Food Poisoning</a> &#8211; <a href=\"https://creativecommons.org/licenses/by-sa/2.0/\">(license)</a>
<p><strong>What advice do you have for those new to WordPress?</strong></p>
<p>My number one piece of advice for new and existing WordPress users is to always remember that WordPress is just a tool that makes it easy for you to put content in a database and your visitors to retrieve that content. When learning a new tool as technically advanced as WordPress, it is easy to get so caught up in the tool itself, that you forget what you wanted to do in the first place. Whatever your goals and intentions were when you picked up WordPress for the first time, make sure you remember them and keep working toward them.</p>
<p>When learning WordPress, whether you are teaching yourself, learning from books or videos, or going to class, remember that every person in the community, even <a href=\"http://nacin.com/\">Andrew Nacin</a>, was at some point in time where you are now: <strong>Just trying to figure it all out</strong>. While every person&#8217;s path to learning is different, they all have one thing in common: <strong>They all learn from each other.</strong></p>
<p>So reach out online, in person, through Twitter, Facebook groups, Meetups, WordCamps, and beyond, and find like-minded people who want to learn with you or help you on your way. When you meet someone who is just starting out, help them get their footing and invite them into the community.</p>
<p>Finally, remember that WordPress is not an island. The web community is a rich ecosystem with many differing solutions based on the same core technology. Learning how the web works gives you the power to use WordPress to move beyond its borders and it&#8217;s beyond those borders where true magic is found.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 20 May 2015 19:21:46 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:37;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:77:\"WPTavern: WordPress.org is Testing International Theme and Plugin Directories\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=44068\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:87:\"http://wptavern.com/wordpress-org-is-testing-international-theme-and-plugin-directories\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:3751:\"<p><a href=\"http://i1.wp.com/wptavern.com/wp-content/uploads/2014/02/flags.jpg\"><img src=\"http://i1.wp.com/wptavern.com/wp-content/uploads/2014/02/flags.jpg?resize=1020%2C500\" alt=\"flags\" class=\"aligncenter size-full wp-image-16697\" /></a></p>
<p>WordPress.org is making strides towards fully localizing the project&#8217;s official theme and plugin directories. Dion Hulse <a href=\"https://make.wordpress.org/polyglots/2015/05/20/hi-everyone-as-some-of-you-are-aware/\" target=\"_blank\">posted</a> this morning that he has enabled localized theme directories for all Rosetta sites. For example, the Romanian themes directory is available at: <a href=\"https://ro.wordpress.org/themes/\" target=\"_blank\">ro.wordpress.org/themes/</a>.</p>
<p>Theme filters, directory sub-navigation, info and download buttons, and other aspects of the details page are all translated. Description and titles are not yet translated, but Hulse says the plan is to add those in the near future.</p>
<p><a href=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2015/05/romanian-themes.png\"><img src=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2015/05/romanian-themes.png?resize=1025%2C677\" alt=\"romanian-themes\" class=\"aligncenter size-full wp-image-44080\" /></a></p>
<p>Those who are interested in helping translate the interface for the localized theme directories are encouraged to visit the <a href=\"https://translate.wordpress.org/projects/meta/themes\" target=\"_blank\">meta translation project page</a>. The process for contributing is the same that is used with WordPress&#8217; other Rosetta translations.</p>
<p>Localized plugin directories are being actively tested at /plugins/ and the sites are also <a href=\"https://translate.wordpress.org/projects/meta/plugins\" target=\"_blank\">available for contributions from translators</a>. Check out <a href=\"https://ro.wordpress.org/plugins/\" target=\"_blank\">ro.wordpress.org/plugins/</a> to see the Romanian plugin directory as an example.</p>
<p><a href=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2015/05/romanian-plugins.png\"><img src=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2015/05/romanian-plugins.png?resize=1025%2C685\" alt=\"romanian-plugins\" class=\"aligncenter size-full wp-image-44079\" /></a></p>
<p>As the localized theme and plugin directories are new, there are still a few missing pieces and likely a good number of bugs that will need to be resolved. You can help by reporting them on Hulse&#8217;s <a href=\"https://make.wordpress.org/polyglots/2015/05/20/hi-everyone-as-some-of-you-are-aware/\" target=\"_blank\">announcement</a> on the make.wordperss.org/polyglots blog or by opening a ticket on <a href=\"https://meta.trac.wordpress.org/newticket?component=Theme%20Directory\" target=\"_blank\">meta.trac</a>.</p>
<p>In <a href=\"http://wptavern.com/matt-mullenwegs-state-of-the-word-highlights-internationalization-mobile-and-new-tools-for-wordpress-contributors\" target=\"_blank\">Matt Mullenweg&#8217;s 2014 State of the Word address</a>, he highlighted the importance of internationalization improvements for connecting and growing the global WordPress community. Localized directories for plugins and themes on WordPress.org are part of this larger effort and make the project&#8217;s website easier to navigate for non-English speaking users.</p>
<p>In the future, translation of WordPress&#8217; development handbooks, the codex, and other documentation could also play a large part towards inspiring international developers to make more extensions, products for the marketplace, and contributions back to the project. Growing WordPress&#8217; market share outside of English-speaking countries will be facilitated by having all basic WordPress resources available in other languages.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 20 May 2015 18:37:34 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:38;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:69:\"Post Status: Automattic has acquired WooThemes, makers of WooCommerce\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"https://poststatus.com/?p=12682\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:65:\"https://poststatus.com/automattic-acquired-woocommerce-woothemes/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:21325:\"<p>This acquisition is an important milestone for <a href=\"https://automattic.com\">Automattic</a>, validation for the bootstrapped <a href=\"http://woothemes.com\">WooThemes</a>, and will be hugely impactful on the WordPress economy as a whole.</p>
<h3>The history of WooThemes and WooCommerce</h3>
<p>WooThemes <a href=\"http://www.woothemes.com/about/\">was started</a> in 2008 as one of the first commercial WordPress theme shops. It quickly became popular and paved the way for hundreds of shops to follow in their footsteps.</p>
<p>With the leadership of Adii Pienaar and co-founders Mark Forrester and Magnus Jepson, WooThemes did a ton of interesting things over the years, and dominated the market with a handful of other shops. They <a href=\"http://www.woothemes.com/2011/09/woocommerce-has-arrived/\">launched WooCommerce in September 2011</a>, in the middle of the commercial theme heyday.</p>
<p>WooCommerce&#8217;s origins are a hot mess and a long story. WooThemes worked for a long time to develop, with partners, their own eCommerce solution. After numerous failed attempts and false starts, they hired <a href=\"http://mikejolley.com/\">Mike Jolley</a> and <a href=\"http://jameskoster.co.uk/\">Jay Koster</a> full time, and forked JigoShop after acquisition negotiations broke down. Jigoshop is a product that Mike and Jay built as freelancers for JigoWatt, but has since been sold off to another consulting company.</p>
<p>Mike and Jay were, and are, the heart of that eCommerce plugin &#8212; the one we know today as WooCommerce. Under their stewardship, and dozens of other full time and part time contributors &#8212; mixed in with outstanding marketing, perfect timing, and a lack of modern competition &#8212; WooCommerce took the WordPress world by storm.</p>
<p>They pioneered the extension model for paid add-ons. They put all doubters to rest over and over again. They made mistakes. But they kept at it, kept working, kept making it better. And soon enough, they took the eCommerce world by storm too.</p>
<p>In a short period of four years, WooCommerce has gone from a struggling concept, to a fork, to a remarkable open source commercial software success story.</p>
<p>I&#8217;ve had the privilege of following WooThemes since around the time they started, and have gotten to know the project and their team even more closely since the very early days of WooCommerce&#8217;s launch. In this post, I bring my analysis of the company based on those years of my watching them grow and interacting with them, and hope to share what the acquisition by Automattic may mean for the future.</p>
<h3>Why WooCommerce is attractive</h3>
<p>On the surface, it may seem to many that Automattic was the obvious choice to acquire WooCommerce.</p>
<p>After all, they need eCommerce support for <a href=\"https://wordpress.com\">WordPress.com</a>. As Matt Mullenweg shared with me, they, &#8220;have a ton of demand,&#8221; for eCommerce from WordPress.com users. Acquiring WooCommerce gives Automattic access to the largest single group of eCommerce stores in the world.</p>
<h4>One of many options</h4>
<p>But Mark Forrester and Magnus Jepson &#8212; co-founders and owners of WooThemes &#8212; could have gone many other routes.</p>
<p>WooCommerce is big enough, and has enough brand power, to have attracted significant venture capital investments, as well as suitors from well outside the WordPress space &#8212; suitors like MasterCard, eBay/Paypal, Amazon, or Yahoo.</p>
<p>There are 1.2+ million active installs of WooCommerce. They have a nearly <a href=\"http://trends.builtwith.com/shop\">20% eCommerce marketshare</a> of the top one million websites, and over 24% eCommerce marketshare of all websites.</p>
<p><img class=\"aligncenter size-full wp-image-12685\" src=\"https://poststatus.com/wp-content/uploads/2015/05/woocommerce-builtwith-top-million.png\" alt=\"woocommerce-builtwith-top-million\" width=\"631\" height=\"499\" /></p>
<p>The plugin has had rapid growth over its short four year existence, making it a ripe target for the right buyer.</p>
<h4>A natural fit</h4>
<p>WooCommerce&#8217;s popularity has largely been due to the fact that it&#8217;s available on WordPress. WordPress makes WooCommerce an attractive choice for websites that need bolt-on eCommerce.</p>
<p>One of WooCommerce&#8217;s greatest opportunities for growth is for customers that are eCommerce first, other-parts-of-the-website second. It&#8217;s gaining ground quickly as both WooCommerce and WordPress gain further respect for usage on websites of all sizes and scopes.</p>
<p>All of these factors make WooCommerce an attractive choice for Automattic. Automattic&#8217;s team knows, understands, and contributes greatly to the WordPress project. A shared reliance on WordPress core makes a WooCommerce and WordPress.com integration simpler. And 55 talented, eCommerce focused employees makes for an inviting addition to Automattic&#8217;s relatively small workforce.</p>
<h3>18% growth in Automattic employees</h3>
<p>Bringing 55 new people on at once swells Automattic&#8217;s ranks by around 18%, bringing them to over 360 people. Recruiting is not easy. This gain of talented people, in a single fell swoop, should not be underestimated.</p>
<p>But there may be some challenges integrating the two teams. This is, by far, the most people brought under the Automattic umbrella in a single acquisition.</p>
<h4>Team integration</h4>
<p>WooThemes&#8217; theme division and team members will join Automattic&#8217;s theme team, and it&#8217;s my understanding that WooThemes support will join the Happiness team at Automattic as well.</p>
<p>WooThemes has long battled a significant support burden, even before WooCommerce came along. With the demands of supporting eCommerce software that can conflict with nearly infinite plugins, themes, and hosting environments makes support expensive. As long as WooCommerce offers paid self-hosted products, this support will need to be managed.</p>
<p>WooCommerce will certainly benefit from the developer resources at Automattic. Matt told me, &#8220;lots of folks at Automattic [are] interested in working on eCommerce.&#8221; From code audits, to fresh eyes, to more seasoned developers, Automattic&#8217;s team will be able to have an immediate impact on the WooCommerce product line.</p>
<h4>Merging management</h4>
<p>One aspect I don&#8217;t know much about yet is in regard to WooThemes&#8217; middle management. Mark and Magnus own the company, but there is a four person leadership team beyond them:</p>
<ul>
<li>Joel Bronkowski, Chief Business Development Officer</li>
<li>Warren Holmes, Chief Marketing Officer</li>
<li>Matty Cohen, Chief Product Officer</li>
<li>Michael Krapf, Chief Happiness Officer</li>
</ul>
<p>Furthermore, there are product leads for WooCommerce, Sensei, themes, and other elements of WooThemes&#8217; business. As a company, WooThemes is probably as hierarchical as Automattic with six times fewer people.</p>
<p>I anticipate some managers may merge into other Automattic teams under new roles, or play a part in sub-teams of sorts, which is (I believe) how Jetpack works now that it&#8217;s such a big team.</p>
<h4>Already distributed</h4>
<p>WooThemes is already distributed across five continents and perfectly accustomed to remote work. While they have an office (WooHQ) in Cape Town, South Africa, it&#8217;s a &#8220;come as you please&#8221; environment, similar to Automattic&#8217;s San Francisco space.</p>
<p>Joining Automattic will be a much cleaner culture fit than other potential buyers would have been. Some team members will naturally leave or integrate to other roles, but the overall gain is a huge win for both organizations.</p>
<h3>The likely end of &#8220;WooThemes&#8221; as a name</h3>
<p>WooThemes is a staple brand of the WordPress ecosystem. They&#8217;ve been around since 2008 and probably have the biggest single brand presence after WordPress itself; I&#8217;d argue the name is more well-known than Automattic, or even perhaps ThemeForest.</p>
<p>For all practical purposes, I believe the name WooThemes will be retired.</p>
<p>WooThemes has previously considered a name change to reflect the change in their business focus, but have not done it. Under the umbrella of Automattic and WordPress.com, there is really no need to carry on the WooThemes brand.</p>
<p>I&#8217;m told the decision to change the name of the website hasn&#8217;t been officially made yet, but it makes no sense to me to keep WooThemes. I&#8217;d expect the website we see at WooThemes.com to before long be simply <a href=\"http://woocommerce.com\">WooCommerce.com</a>.</p>
<p>They better keep Hiro, the Woo Ninja though. I love that little guy.</p>
<h3>The WooCommerce business model</h3>
<p>The WooCommerce business model is built largely on paid extensions that offer additional eCommerce functionality, updates, and support.</p>
<h4>The current extension model</h4>
<p>WooThemes lists a whopping 346 paid and free extensions on their website, about 150 of which link to third party sites. The remaining 200 or so extensions are either developed in house or in partnership with third party developers, but sold on WooThemes&#8217; website. There are also dozens, if not hundreds more, distributed plugins by other vendors that are not listed.</p>
<p>Companies like <a href=\"https://www.skyverge.com/\">SkyVerge</a> and <a href=\"http://prospress.com/\">Prospress</a> have built their businesses on WooCommerce extension development. If the model were to change drastically, it could have a great deal of impact on them and similar companies or solo developers.</p>
<p>Third party developers have been told that life will be business as usual. In an email to strategic partners, Joel Bronkowski said, &#8220;There are no plans to mess with the magic sauce strategy that has brought us this far.&#8221;</p>
<h4>A conflict of ideology</h4>
<p>However, the model of paid plugins is also counter to Matt Mullenweg&#8217;s often stated beliefs for what commercialization in the WordPress plugin space should look like.</p>
<p>I asked him to explain how his mindset has changed in regard to paid plugins that charge for support and updates. Paid Automattic plugins, like Akismet and VaultPress, are based on SaaS models.</p>
<p>He says that his view has not changed. He told me that one goal with WooCommerce will be to determine, &#8220;what services provide the most value to people over a long period of time.&#8221; He also noted that such a question is due to the fact that many WordPress product sales are one-time.</p>
<p>I found his sentiment curious. He didn&#8217;t directly answer the question about paid plugins, which isn&#8217;t too surprising. It&#8217;s impossible to imagine Automattic doing away with paid extensions in the short term, but there are serious threats to third party developers in the longer term, I believe.</p>
<h4>Expansion of partnerships with larger corporations</h4>
<p>WooCommerce has spent a lot of time doing business development over the last couple of years. Last summer, their leadership team <a href=\"http://www.woothemes.com/2014/07/woocommerce-journey-irce-2014/\">went to Chicago</a> for a big eCommerce conference and had a whole new world opened up to them.</p>
<p>Joel told me they, &#8220;still have a lot to figure out in terms of the road ahead, but [we are] incredibly excited about what this means for us in terms of product development, partner opportunities and for WordPress powered eCommerce.&#8221;</p>
<p>Under the wing of Automattic and in the future WordPress.com, I think WooCommerce will be able to further leverage their position in the eCommerce market with big payment companies and other potential corporate entities.</p>
<h4>Potential changes to the business model</h4>
<p>I would guess that a gradual change in business model will occur over the next several years, especially in regard to extensions. <span class=\"pullquote alignright\">WooCommerce has a dismal 17% renewal rate for extension purchases.</span> This is a number that needs to improve, or something should change.</p>
<p>It may make sense &#8212; and I&#8217;m shocked I&#8217;m saying it &#8212; to make WooCommerce more like Jetpack.</p>
<p>If I were at Automattic, I would encourage the two teams to brainstorm and evolve together. I think a model where a credit card is connected to WordPress.com, and extensions (free and paid) can be easily activated from within the admin makes sense. It would require a lot of change to existing UIs and development infrastructure, but it could also drastically improve what is often a convoluted method for site management with so many add-ons being independently managed.</p>
<p>If we take the potential even further: imagine the VaultPress model of instant syncing, data tracking, and backups being heavily integrated into eCommerce stores. Such a system could be part of a monthly fee.</p>
<p>Extensions also don&#8217;t have to be piecemeal, or the &#8220;nickel and dime&#8221; method. Automattic could make WooCommerce a tiered payment plan, where certain levels unlock particular functionality. Or they could buyout all third party paid extensions they care about and make the entire product free or part of a single package.</p>
<p>The point is that Automattic purchasing WooCommerce gives them an incredible amount of flexibility in terms of how to move forward. WooCommerce store owners should be prepared for a lot of potential change.</p>
<p>As a bootstrapped company, WooThemes had to turn a profit. Automattic has to make the company more valuable, but does not need to care about cash day to day. Their stated goal is to make products people want to use. <span class=\"pullquote alignright\">A very small number of people at Automattic really consider profits and losses regularly. That mindset, when applied to WooCommerce, could bring about significant change indeed.</span></p>
<h4>Bringing WooCommerce to WordPress.com</h4>
<p>An important concern over the next year or two will be how to bring WooCommerce to WordPress.com. There is little question that it will happen.</p>
<p>Matt Mullenweg highlighted the demand from the general WordPress.com userbase, and hosted WooCommerce would be a great answer to Squarespace&#8217;s eCommerce add-on, and the likes of Shopify and BigCartel.</p>
<p>Furthermore, I&#8217;m sure a number of WordPress.com VIP customers will be clamoring for WooCommerce. Automattic&#8217;s Vice President of Platform Services, Paul Maiorana, said, &#8220;VIP tends to follow the same trends as the broader WP community. Initially blogs, then CMS, now everything.&#8221; He is excited about being able to offer a more catered eCommerce experience &#8220;in house to better service those customers.&#8221;</p>
<p>A hosted version of WooCommerce will be a very compelling upsell for WordPress.com if they are able to pull it off well. This too, will not be easy. But they are starting with a heck of a head start, given the WooCommerce brand name, team, and existing plugin infrastructure.</p>
<h3>What the acquisition means for other WooThemes products</h3>
<p>WooThemes makes more than WooCommerce, however nearly all of their products today at least integrate with WooCommerce.</p>
<p>WooThemes&#8217; themes will be integrated into WordPress.com&#8217;s theme offering. Eleven themes are <a href=\"https://theme.wordpress.com/?theme_shop=woothemes\">already listed there</a> from an existing partnership that goes back to early 2011.</p>
<p>The <a href=\"http://www.woothemes.com/products/sensei/\">Sensei courseware plugin</a> will also continue to be developed and maintained. Regarding Sensei, Matt Mullenweg said, &#8220;their team is passionate about it, which is kind of the criteria for what Automattic works on.&#8221;</p>
<p>There is a lot of potential in the course space, and I actually think this could be a nice win for Automattic in this acquisition, especially if Sensei gets additional resources and attention.</p>
<p>WooThemes has other active free plugins that I doubt will change much. WooSlider is their only other paid plugin, but I don&#8217;t think it makes up a considerable amount of revenue.</p>
<p>I wouldn&#8217;t be surprised if both WooSlider and Sensei core become free plugins.</p>
<h3>WooThemes&#8217; revenue and the acquisition price</h3>
<p>Everyone wants to know: how much was WooThemes making, and how much was the acquisition for?</p>
<p><a href=\"http://recode.net/2015/05/19/wordpress-parent-automattic-buys-woocommerce-a-shopping-tool-for-web-publishers/\">Re/code&#8217;s Peter Kafka</a> has sources that say the acquisition was for, &#8220;more than $30 million in cash and stock.&#8221; I believe this to be a reasonable amount and I don&#8217;t think he&#8217;d make the claim without some confidence.</p>
<p>I don&#8217;t know what the terms of the deal were. I&#8217;ve tried all day to find out. The best I can do is tell you what I know, what I think I know, and guess right along with everyone else. Sounds fun, right?</p>
<p>I&#8217;m quite confident that WooThemes&#8217; revenues were around $9-$10 million in 2013. I also know that they have had positive trajectory month over month growth for some time, and I have reason to believe one of their more recent record months well exceeded $1 million in revenue.</p>
<p>If we extrapolate the 2013 numbers with 10-20% growth, we can presume that their gross revenues are somewhere in the neighborhood of $15 million annually.</p>
<p>Based on some feedback from people I trust, a 2x multiple of expected 2015 revenues isn&#8217;t out of the question. In typical proprietary software and product situations, that would be a low multiplier.</p>
<p>But in this case, WooThemes&#8217; sends a lot of money directly to third party developers, and spends a great deal of money on development and support. Furthermore, WooCommerce isn&#8217;t proprietary, it&#8217;s open source; which while I love and advocate for it, it simply would be difficult to valuate the same as proprietary software.</p>
<p>Additionally, I could be naive, but in the case of Automattic I&#8217;d rather more stock than cash. They are destined for an IPO (someday) that will likely put them well beyond their latest <a href=\"http://ma.tt/2014/05/new-funding-for-automattic/\">$1.16 billion valuation</a>, and today&#8217;s stock could be worth many times what it is now in the years to come.</p>
<p>Lastly, I don&#8217;t think Re/code would run a number they pulled out of thin air. I think they got that from somewhere &#8212; perhaps a VC source.</p>
<h3>Good for both sides, but not without consequences</h3>
<p>I firmly believe WooThemes could&#8217;ve continued to grow WooCommerce to be worth $100 million or more. But it would&#8217;ve likely been a long and challenging road.</p>
<p>Under the Automattic umbrella, they have a great shot to continue making an awesome eCommerce product without some of their current burdens and with some outstanding new resources.</p>
<p>Meanwhile, especially if the $30-$35 million price is correct, I think Automattic got a steal. It&#8217;s a brilliant way into a huge market with a major player.</p>
<p>There are potential downsides to this purchase. For one, it makes Automattic further feel like a vacuum that inevitably sucks up the best talent, agencies, and products once they showcase their potential for success.</p>
<p>WooThemes was the bastion all other bootstrapped WordPress products stood behind. Knowing it&#8217;s possible to do something as big as WooThemes was doing, without funding and starting from nothing, is awesome.</p>
<p>Seeing them snatched up by Automattic around the time they&#8217;ve become nearly ubiquitous with the term &#8220;WordPress eCommerce&#8221; is kind of a bummer. <span class=\"pullquote alignright\">It&#8217;s like we now have to start over again to see what WordPress centric product company can grow big enough to stand beside Automattic, not under it.</span></p>
<p>I also have some fear that if Automattic rocks the boat too much with WooCommerce it will cause some big inroads WordPress has made in self-hosted eCommerce to be lost.</p>
<p>My concerns are relatively minor. Would I have loved to see WooThemes continue to grow and dominate eCommerce alone? Yes. Am I excited by what this deal makes possible? Yes. Am I a little concerned what it will do to the WordPress economy? Yes.</p>
<p>We must all weigh the pros and cons of any decision. For Mark, Magnus, and the WooThemes team, this is a move that is good for them during this time, and will likely be good for the company they started seven years ago.</p>
<p>For Automattic, this is a heck of a way to round out their first decade in business. It&#8217;ll be really interesting to see what the next decade holds in store, but I bet Automattic will look a lot different then, like they do now compared to 2005.</p>
<p>Congratulations to both teams. You can read the announcements on <a href=\"http://ma.tt/2015/05/woomattic/\">Matt&#8217;s blog</a> and <a href=\"http://www.woothemes.com/2015/05/woothemes-joins-automattic/\">WooThemes&#8217; blog</a>.</p>
<p>Photo credit: <a href=\"https://matt.wordpress.com/2015/05/19/woo-announcement-pics/\">Matt Mullenweg</a></p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 20 May 2015 07:15:52 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:15:\"Brian Krogsgard\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:39;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:41:\"WPTavern: Automattic Acquires WooCommerce\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=44023\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:51:\"http://wptavern.com/automattic-acquires-woocommerce\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:6368:\"<a href=\"http://i1.wp.com/wptavern.com/wp-content/uploads/2015/05/woomattic.jpg\"><img src=\"http://i1.wp.com/wptavern.com/wp-content/uploads/2015/05/woomattic.jpg?resize=1025%2C463\" alt=\"photo credit: Ma.tt - \" /></a>photo credit: <a href=\"https://matt.wordpress.com/2015/05/19/woo-announcement-pics/\">Ma.tt &#8211; &#8220;A Celebratory Toast</a>
<p>Automattic CEO Matt Mullenweg announced today that the company has <a href=\"http://ma.tt/2015/05/woomattic/\" target=\"_blank\">acquired WooCommerce</a>, WordPress&#8217; most popular e-commerce platform. The <a href=\"http://www.woothemes.com/woocommerce/\" target=\"_blank\">plugin</a> recently passed seven million downloads and stats from BuiltWith show that <a href=\"http://wptavern.com/woocommerce-dominates-global-e-commerce-platforms-passes-7-million-downloads\" target=\"_blank\">WooCommerce is dominating global e-commerce platforms</a>, powering roughly 30% of all online stores.</p>
<p>This is Automattic&#8217;s largest acquisition to date, bringing 55 new employees into the company from 16 countries for a total of 370 Automatticians. Mullenweg confirmed that the acquisition includes <a href=\"http://www.woothemes.com/\" target=\"_blank\">Woo</a>, <a href=\"http://www.woothemes.com/products/sensei/\" target=\"_blank\">Sensei</a>, and all of the other plugins and themes.</p>
<p>Given WooCommerce&#8217;s extensive adoption on the web, Automattic will not be re-branding the newly acquired products. WooThemes and WooCommerce will continue to be sold via their dedicated websites.</p>
<p>&#8220;We’re planning on retaining (and growing) the WooCommerce brand,&#8221; Mullenweg told the Tavern. &#8220;The plan is to keep what has been working going.&#8221;</p>
<p>Mullenweg has spoken frequently over the years about growing Automattic&#8217;s reach into global commerce, but few could have predicted that the company would acquire Woo as opposed to building its own in-house commerce platform.</p>
<p>&#8220;They have a full team that goes to bed every night and wakes up in the morning thinking about commerce; it’s core to their DNA,&#8221; Mullenweg said. &#8220;That’s better than starting it in-house. Also they have a ton of adoption already.&#8221;</p>
<p>In April, WooThemes co-founder Magnus Jepson told the Tavern that <a href=\"http://wptavern.com/woocommerce-dominates-global-e-commerce-platforms-passes-7-million-downloads\" target=\"_blank\">WooCommerce accounts for over 85% of overall sales</a> and processes &#8220;several million dollars per year.” Jepson also confirmed that WooCommerce&#8217;s revenue &#8220;has been climbing steadily over the past few years, and we are regularly breaking monthly revenue records.”</p>
<p>Automattic is not releasing the financial details of the acquisition, but <a href=\"http://recode.net/2015/05/19/wordpress-parent-automattic-buys-woocommerce-a-shopping-tool-for-web-publishers/\" target=\"_blank\">Re/code speculates</a> that it was in the range of $30 million:</p>
<blockquote><p>Sources say Automattic will spend more than $30 million in cash and stock to buy the 55-person company. Automattic CEO Matt Mullenweg wouldn’t comment on the price but said the acquisition was the largest his company had made, &#8216;by about 6x.&#8217;</p></blockquote>
<p>In addition to growing the current WooCommerce customer base, Automattic is looking to use the platform to add more selling options for WordPress.com customers, while retaining its existing e-commerce partnerships.</p>
<p>&#8220;Partnerships will remain in place on WP.com, but long-term we’d like to offer Woo as an option there as well,&#8221; Mullenweg said.</p>
<p>When asked about plans to integrate WooCommerce into Jetpack, he said, &#8220;Jetpack could definitely complement WooCommerce (and WooThemes), but not the other way around.&#8221;</p>
<p>WooThemes founders never imagined that WooCommerce would rise to the level of popularity that it has, ultimately bringing them into the Automattic family. Co-founder Mark Forrester <a href=\"http://www.woothemes.com/2015/05/woothemes-joins-automattic/\" target=\"_blank\">writes</a>:</p>
<blockquote><p>In 2008, as three strangers in three countries, we set out on a quest to pioneer WordPress commercial theming, never dreaming of the rocket-propelled voyage into the self-hosted eCommerce unknown that lay ahead. It’s been an incredible ride, backed by a unique community, and here we find ourselves powering over 24% of online stores with our flagship product, WooCommerce.</p></blockquote>
<p>The acquisition affects a whole fleet of third-party designers and developers who create products for WooCommerce. They will likely have more opportunities and sales ahead of them with the power of Automattic behind the core plugin. Mullenweg confirmed that the next WooConf, scheduled to take place in Austin in November, will continue on as planned. Those who are heavily involved in the WooCommerce ecosystem will still be able to connect and build for the platform as they have done previously.</p>
<h3>Democratizing Selling with WooCommerce</h3>
<p>With Automattic now at the helm of the most dominant e-commerce platform on the web, it will be interesting to see if the company can make selling online just as simple as it has made publishing online. WordPress.com&#8217;s tremendous success can be partially attributed to the company&#8217;s <a href=\"http://wptavern.com/matt-mullenweg-on-ensuring-the-future-of-wordpress\" target=\"_blank\">commitment to democratizing publishing</a>.</p>
<p><strong>&#8220;I do believe that the web needs an open, independent and easy-to-use commerce platform that you can run yourself on your own website,&#8221;</strong> Mullenweg said in his <a href=\"https://www.youtube.com/watch?v=xJOfTB8-daA\" target=\"_blank\">video announcement</a>, the first video ever to be published to Automattic&#8217;s YouTube account.</p>
<p>Publishing products and selling them on the web is arguably a more complex endeavor than simple publishing, especially when you factor in location, tax, payment gateways, and everything needed to process transactions. The average non-developer has no concept of what it takes to set up a blog, let alone an online store. But if Automattic can play a part in democratizing the ability for regular folks to sell products online, it has the potential to globally transform e-commerce.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 19 May 2015 21:15:07 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:40;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:26:\"Matt: Woo &amp; Automattic\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:21:\"http://ma.tt/?p=45068\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"http://ma.tt/2015/05/woomattic/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:4529:\"<p>For years, we&#8217;ve been working on democratizing publishing, and today more people have independent sites built on open source software than ever before in the history of the web. Now, we want to make it easy for anyone to sell online independently, without being locked into closed, centralized services &#8212; to enable freedom of livelihood along with freedom of expression.</p>
<p>It’s not a new idea: at a WordCamp a few years ago, someone stood up and asked me when we were going to make it as easy to create an online store as we’d made it to create a blog. Everyone applauded; there’s long been demand for better ecommerce functionality, but it’s been outside the scope of what Automattic could do well.</p>
<p>That changes today &#8212; drum roll &#8212; as <a href=\"http://woocommerce.com/\">WooCommerce</a> joins the <a href=\"http://automattic.com/\">Automattic</a> team to make it easier for people to sell online. <a href=\"http://www.woothemes.com/2015/05/woothemes-joins-automattic/\">Along with Woo’s announcement</a>, here&#8217;s a short video explaining more:</p>
<p><span class=\"embed-youtube\"></span></p>
<p>In the past few years, WooCommerce really distinguished itself in its field. Just like WordPress as a whole, it developed a robust community around its software, and its products meet the needs of hundreds of thousands of people around the world.</p>
<p>Woo is also a team after Automattic’s own distributed heart: WooCommerce is created and supported by 55 people in 16 countries. Added to Automattic&#8217;s 325 people in 37 countries, that’s a combined 380-person company across 42 countries &#8212; the sun never sets.* I can&#8217;t wait to meet all my new colleagues.</p>
<p>Just like us, the vast majority of WooCommerce&#8217;s work is also open source and 100% GPL. And just like WordPress, you&#8217;ll find WooCommerce meetups popping up everywhere, from Los Angeles to London, and its global and community-focused work together to make the users’ experiences the best they can be.</p>
<p><a href=\"http://trends.builtwith.com/shop\"><img class=\"alignright  wp-image-45072\" src=\"http://i0.wp.com/ma.tt/files/2015/05/ecomm-trends.png?resize=447%2C294\" alt=\"ecomm-trends\" /></a> The stats are impressive: the <a href=\"https://wordpress.org/plugins/woocommerce/\">WooCommerce plugin has over 7.5 million downloads and a million+ active installs</a>; BuiltWith&#8217;s <a href=\"http://trends.builtwith.com/shop\">survey of ecommerce platforms shows Woo passing up Magento in the top million</a>, with about triple the number of total sites. Even a conservative estimate that WooCommerce powers 650,000 storefronts means they’re enabling a huge number of independent sellers. They’ve added a tremendous amount to the WordPress ecosystem (alongside everyone else working in this area).</p>
<p>WordPress currently <a href=\"http://w3techs.com/technologies/history_overview/content_management/all/y\">powers about 23% of the web</a>. As we work our way toward 51%, WooCommerce joining Automattic is a big step opening WordPress up to an entirely new audience. I can’t wait to see how much more we can build together.</p>
<p>Automattic <em>turns ten</em> next month: another amazing milestone I couldn&#8217;t have imagined a decade ago. Today&#8217;s news is just the first of a number of announcements we have planned for the remainder of the year, so please stay tuned! There&#8217;s still so much work to do.</p>
<p>* Want to work with us? <a href=\"http://automattic.com/work-with-us/\">We’re hiring</a>. Bonus points if you live in Antarctica, the only continent we don’t have covered.</p>
<p>As I said in the video, please drop any questions you might have in the comments and I&#8217;ll answer them as soon as I can. Also check out the posts from <a href=\"http://www.markforrester.co.za/2015/05/19/woothemes-has-a-new-home/\">Mark</a> and <a href=\"http://jepson.no/we-are-joining-automattic/\">Magnus</a>.</p>
<p>Read more: <a href=\"https://href.li/?http://mashable.com/2015/05/19/automattic-woocommerce-acquisition/\">Mashable</a>, <a href=\"http://recode.net/2015/05/19/wordpress-parent-automattic-buys-woocommerce-a-shopping-tool-for-web-publishers/\">Recode</a>, <a href=\"https://href.li/?http://techcrunch.com/2015/05/19/automattic-buys-woocommerce-the-popular-plugin-for-turning-wordpress-into-a-store/\">Techcrunch</a>, <a href=\"http://venturebeat.com/2015/05/19/automattic-buys-woocommerce-to-get-into-ecommerce-its-largest-acquisition-to-date/\">Venturebeat</a>.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 19 May 2015 18:59:56 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"Matt\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:41;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:74:\"WPTavern: WordPress Cape Town to Host 2nd Annual Charity Hackathon in June\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=43986\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:84:\"http://wptavern.com/wordpress-cape-town-to-host-2nd-annual-charity-hackathon-in-june\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:3696:\"<p><a href=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2015/05/wordpress-cape-town-charity-hackathon-2015.jpg\"><img src=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2015/05/wordpress-cape-town-charity-hackathon-2015.jpg?resize=1025%2C529\" alt=\"wordpress-cape-town-charity-hackathon-2015\" class=\"aligncenter size-full wp-image-44002\" /></a></p>
<p>Last August, the <a href=\"http://www.wpcapetown.co.za/\" target=\"_blank\">WordPress Cape Town</a> meetup group experimented with <a href=\"http://wptavern.com/wordpress-cape-town-to-host-charity-hackathon-in-august\" target=\"_blank\">hosting its first charity hackathon</a> to benefit local charities. The <strong>do_action( ‘wordpress-charity-hackathon’ );</strong> event was so successful in 2014 that organizers were inspired to make it an annual event. The <a href=\"http://www.wpcapetown.co.za/event/do_action-wordpress-charity-hackathon-2015/\" target=\"_blank\">2015 hackathon</a> is scheduled for June 20th from 9:00 AM &#8211; 5:00 PM.</p>
<p>&#8220;With a team of nearly 50 volunteers from the community, we built brand new websites for nine different charitable organizations and we will be doing the same again this year,&#8221; said Hugh Lashbrooke, an organizer for the event.</p>
<p>The concept will be the same as the previous year &#8211; volunteers will build sites for nine Capetown-based charities, giving each their own unique online presence by the end of the day.</p>
<p>A few examples of websites built by the volunteers last year include:</p>
<ul>
<li><a href=\"http://feedinginaction.co.za/\" target=\"_blank\">Feeding in Action</a></li>
<li><a href=\"http://www.stlukes.co.za/\" target=\"_blank\">St. Luke’s Hospice</a></li>
<li><a href=\"http://www.equinoxtrust.org/\" target=\"_blank\">Equinox Trust</a></li>
<li><a href=\"http://www.carecareers.co.za/\" target=\"_blank\">Care Career Connection</a></li>
<li><a href=\"http://www.theup.org.za/\" target=\"_blank\">The UPliftment Porgramme</a></li>
</ul>
<p>&#8220;The charities this year are equally as deserving and spread across the whole spectrum of society again,&#8221; Lashbrooke said. The 2015 charities list includes organizations such as the Academy for Adults with Autism, FoodBank South Africa, and the Down Syndrome Inclusive Education Foundation NPC.</p>
<p>Sponsors this year include <a href=\"http://hetzner.co.za/\" target=\"_blank\">Hetzner</a>, <a href=\"http://oboxthemes.com/\" target=\"_blank\">Obox</a>, and <a href=\"http://www.woothemes.com/\" target=\"_blank\">WooThemes</a>. Their generous contributions will help to provide snacks, lunch, dinner, and a prize for the team that builds the best site of the day. All attendees will also receive a ticket to <a href=\"https://capetown.wordcamp.org/2015/\" target=\"_blank\">WordCamp Cape Town 2015</a>.</p>
<p>&#8220;We are still looking for volunteers (there are about 20 spots left at the time of writing this) and it&#8217;s important to note that we are not just looking for developers here,&#8221; he said. &#8220;This is open to Project Managers, Designers, Developers, Content Creators, and Social Media Managers, as all of those individuals are needed to bring a complete website together (especially when it is all being done in one day.)&#8221;</p>
<p>If you&#8217;re in the Cape Town area and you&#8217;d like to be part of this event, you can select a charity team to work on and specify your role when filling out the <a href=\"http://www.wpcapetown.co.za/event/do_action-wordpress-charity-hackathon-2015/\" target=\"_blank\">volunteer application</a> form. Check out the recap video below for a closer look at attendees&#8217; experiences from last year&#8217;s event.</p>
<p><span class=\"embed-youtube\"></span></p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 19 May 2015 18:49:31 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:42;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:73:\"WPTavern: Short Survey on Which WordCamp Organizer Tools to Improve First\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=43992\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:83:\"http://wptavern.com/short-survey-on-which-wordcamp-organizer-tools-to-improve-first\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:1978:\"<p>In the past several months, the <a href=\"https://make.wordpress.org/community/\">Make WordPress Community</a> team has engaged in numerous discussions with WordCamp organizers on how they can improve the tools that are available. Those discussions include:</p>
<ul>
<li><a href=\"https://make.wordpress.org/community/2015/03/05/improving-wordcamp-org-notes-from-the-2014-community-summit/\" rel=\"nofollow\">Notes from the Community Summit</a></li>
<li><a href=\"https://make.wordpress.org/community/2015/03/05/improving-wordcamp-org-user-experience-of-the-css-editor/\" rel=\"nofollow\">Improving the CSS Editing Experience</a></li>
<li><a href=\"https://make.wordpress.org/community/2015/04/09/improving-wordcamp-org-adding-more-themes-page-templates/\" rel=\"nofollow\">Adding More Themes and/or Page Templates </a></li>
</ul>
<p>The team has created a <a href=\"https://make.wordpress.org/community/2015/05/05/wordcamp-organizer-survey/\">six question survey</a> to gather data to determine what tools should be worked on or improved first. If you&#8217;ve worked with any of the tools available on <a href=\"https://central.wordcamp.org/\">WordCamp.org</a> within the last 18 months, you&#8217;re strongly encouraged to take the survey.</p>
<a href=\"http://i1.wp.com/wptavern.com/wp-content/uploads/2015/05/WordCampOrganizerToolSurveyQuestion.png\"><img class=\"size-full wp-image-44005\" src=\"http://i1.wp.com/wptavern.com/wp-content/uploads/2015/05/WordCampOrganizerToolSurveyQuestion.png?resize=598%2C495\" alt=\"WordCamp Tools Survey Question\" /></a>WordCamp Tools Survey Question
<p>The last section has two questions that are open-ended to allow for feedback that extends beyond the tools in question. This is an excellent opportunity for WordCamp organizers to voice their opinion on what direction the team should take on creating and improving the tools available to them. It&#8217;s also a way to tell the team which tools you want to see created that don&#8217;t already exist.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 19 May 2015 18:36:50 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:43;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:38:\"Matt: How to Get Yourself to Do Things\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:21:\"http://ma.tt/?p=45054\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:54:\"http://ma.tt/2015/05/how-to-get-yourself-to-do-things/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:227:\"<p><a href=\"http://www.raptitude.com/2015/03/how-to-get-yourself-to-do-things/\">How to Get Yourself to Do Things</a>. Hat tip: <a href=\"https://alexjgustafson.wordpress.com/2015/04/04/ignore-stuff-and-do-a-thing/\">Alex</a>.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 19 May 2015 05:16:00 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"Matt\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:44;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:54:\"WPTavern: A WordPress Veteran’s Take on DrupalCon LA\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=43963\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:61:\"http://wptavern.com/a-wordpress-veterans-take-on-drupalcon-la\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:5746:\"<p><a href=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2015/05/MendelKurland.jpg\"><img class=\"alignright size-thumbnail wp-image-43970\" src=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2015/05/MendelKurland.jpg?resize=150%2C150\" alt=\"Mendel Kurland\" /></a>This post was contributed by guest author <a href=\"https://mendel.me/\">Mendel Kurland</a>. Kurland is GoDaddy&#8217;s evangelist who travels to WordCamps and is the interface between various open source communities and GoDaddy.</p>
<p>In the following post, Kurland shares his experience attending <a href=\"https://events.drupal.org/losangeles2015\">DrupalCon Los Angeles</a>, a large conference devoted to <a href=\"https://www.drupal.org/\">Drupal</a>.</p>
<hr />
<p>As I flew from DrupalCon Los Angeles, CA to <a href=\"https://mendel.me/events/wordcamp/wordcamp-maine-2015/\">WordCamp Maine</a>, I thought a lot about what the Drupal and WordPress communities could learn from each other. <a href=\"https://wordpress.org/\">WordPress</a> and Drupal are two community-built platforms and each community is powerful. We stand to learn a lot from each other, because<a href=\"https://mendel.me/articles/business/why-all-open-source-projects-matter/\"> all open source projects matter</a>.</p>
<p>With an eye toward looking for the similarities, rather than the differences, both WordPress and Drupal are working to overcome similar obstacles including, brand recognition, threat mitigation, adoption, onboarding, contribution, the list goes on. So why did I go to <a href=\"https://events.drupal.org/losangeles2015\">DrupalCon LA</a>? To learn and give back to another community that’s steeped in collaborative culture.</p>
<h2>The Experience</h2>
<p>Thousands of people attended <a href=\"https://mendel.me/events/drupalcon/drupalcon-la/\">DrupalCon in Los Angeles</a> this year. It’s massive and the layout is similar to a large developer conference. There are sessions centered on technical, as well as business topics, and usually lively question and answer opportunities after each session. There’s a coder lounge, a contribution room, and a huge emphasis on contributing to coding sprints for the next release of Drupal, Drupal 8.</p>
<a href=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2015/05/DrupalConLA.png\"><img class=\"size-full wp-image-43971\" src=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2015/05/DrupalConLA.png?resize=1024%2C683\" alt=\"DrupalCon LA\" /></a>Photo via <a href=\"https://mendel.me/events/drupalcon/drupalcon-la/#jp-carousel-16491\">Mendel</a>
<h2>Leveling and Onboarding</h2>
<p>Prior to the conference, DrupalCon had summits to help gather community members around a particular vertical or topic such as, higher education, community, business, and training sessions to help level-up skills based on experience.</p>
<p>The theme of organizing around common interests is strong throughout the entire conference with<a href=\"https://events.drupal.org/losangeles2015/bofs/2015-05-12\"> birds of a feather sessions</a> and<a href=\"https://events.drupal.org/losangeles2015/events\"> topical social gatherings</a> with topics like,<a href=\"https://events.drupal.org/losangeles2015/women-drupal\"> women in Drupal</a> and<a href=\"https://events.drupal.org/losangeles2015/first-time-attendee-social\"> first time attendees</a>. When it comes to mobilizing around interest groups, Drupal does a brilliant job.</p>
<h2>Comparing WordPress and Drupal</h2>
<p>I’ve met a higher proportion of people who work on enterprise sites at DrupalCons and a higher proportion of people who work on small business sites at DrupalCamps, local conferences similar to WordCamps. There are some important lessons, however, that I took away from the Drupal community.</p>
<h2><b>Lessons and Questions from DrupalCon</b></h2>
<ul>
<li>Onboarding starts with education. The Drupal community puts an emphasis on training at just about every event while only a handful of WordCamps offer a <strong>Foundation Friday</strong> or some other local onboarding event.</li>
<li>Building community means valuing the same things and aligning along common interests. BoF (Birds of a Feather) sessions are a part of Drupal and other technical community conferences. There are certainly people with specific interests related to performance, security, women in WordPress, WP-CLI, etc. Should the WordPress community offer BoF sessions at WordCamps? Or are the existing <strong>tracks</strong> that many WordCamps offer enough?</li>
<li>Networking with those who work in a similar vertical is important. Just as Drupal holds summits for particular verticals, the WordPress community is beginning to do the same with things like, <a href=\"https://miami.wordcamp.org/2015/announcing-buddycamp-miami-2015/\">BuddyCamp at WordCamp Miami</a>, <a href=\"http://conf.woocommerce.com/\">WooConf</a> (e-commerce), <a href=\"http://pressnomics.com/\">Pressnomics</a> (business), <a href=\"http://prestigeconf.com/\">Prestige</a> (business), <a href=\"https://loopconf.io/\">LoopConf</a> (developer). Can more be done at WordCamps?</li>
</ul>
<h2>It&#8217;s OK to Love Drupal Too</h2>
<p>If you’re reading this article on the Tavern, you’re likely a WordPress loyalist. I love WordPress, and it’s also <strong>ok to love Drupal</strong>. They are both tools in an open source toolbox that we all share. The beauty of our opportunity as developers, designers, and creative professionals is our ability to create awesome things in a million different ways.</p>
<p>In going to DrupalCon, it was refreshing for me to take a second to see the web development industry from another perspective. I’d love to hear your perspective in the comments <a href=\"https://twitter.com/ifyouwillit\">and on Twitter</a>.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 19 May 2015 01:53:43 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:45;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:83:\"WPTavern: Community, Translation, and Wapuu: How Japan is Shaping WordPress History\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=43605\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:90:\"http://wptavern.com/community-translation-and-wapuu-how-japan-is-shaping-wordpress-history\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:16719:\"<a href=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2015/05/wcsf-2014-japanese-community.jpg\"><img src=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2015/05/wcsf-2014-japanese-community.jpg?resize=1025%2C523\" alt=\"Japanese WordPress community representatives at WordCamp San Francisco 2014\" class=\"size-full wp-image-43923\" /></a>Japanese WordPress community representatives at WordCamp San Francisco 2014
<p>Japanese WordPress users were some of the earliest to see the project&#8217;s potential and help bring the software to the non-English speaking world. At the end of 2003, just six months after Matt Mullenweg and Mike Little <a href=\"http://ma.tt/2003/01/the-blogging-software-dilemma/\" target=\"_blank\">decided to fork b2</a>, a Japanese version of WordPress was available.</p>
<p><a href=\"http://i1.wp.com/wptavern.com/wp-content/uploads/2015/05/WordPress-ME.jpg\"><img src=\"http://i1.wp.com/wptavern.com/wp-content/uploads/2015/05/WordPress-ME.jpg?resize=748%2C299\" alt=\"WordPress-ME\" class=\"aligncenter size-full wp-image-43607\" /></a></p>
<p>The version was originally called &#8220;WordPress ME&#8221; and was maintained by a user called <a href=\"https://profiles.wordpress.org/otsukare/\" target=\"_blank\">Otsukare</a>, whose <a href=\"http://web.archive.org/web/20040802092512/http://wordpress.xwd.jp/\" target=\"_blank\">translation notes</a> indicate that he believed WordPress would become &#8220;convenient and increasingly easy to use in the future.&#8221; This Japanese version corresponded with <a href=\"https://wordpress.org/news/2003/10/072-final-version-available/\" target=\"_blank\">WordPress 0.72</a>, as WordPress wouldn&#8217;t have internationalization support until version 1.2.</p>
<p>Otsukare was instrumental in demonstrating the demand for translation for all languages with the popularity of his <a href=\"https://wordpress.org/support/topic/localization-help-needed\" target=\"_blank\">multilingual fork of WordPress</a>, which allowed easy modification via the use of a language file. It is rumored that this multilingual edition, along with discussions on the WordPress ME fourms, was influential in bringing <a href=\"https://codex.wordpress.org/Plugin_API/Filter_Reference/gettext\" target=\"_blank\">gettext</a> into WordPress.</p>
<h2>Growing the Japanese WordPress Community Through Local Meetups</h2>
<p>Over the past 11 years, local Japanese WordPress communities have grown steadily. <a href=\"https://profiles.wordpress.org/Nao\" target=\"_blank\">Naoko Takano</a>, who has been involved with the local community since 2003, attributes that growth to <a href=\"http://www.slideshare.net/naokomc/wordcamp-europe2013\" target=\"_blank\">consistent translation and a reliable release workflow</a>, managed by a dedicated Japanese package team.</p>
<p><a href=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2015/05/japanese-package-team.jpg\"><img src=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2015/05/japanese-package-team.jpg?resize=625%2C247\" alt=\"japanese-package-team\" class=\"aligncenter size-full wp-image-43918\" /></a></p>
<p>An organized system around translation and documentation were two key ingredients that helped germinate the early Japanese WordPress community, but local meetups were ultimately the catalyst for its massive growth.</p>
<p><a href=\"https://www.flickr.com/search/?tags=wordcamptokyo2008\" target=\"_blank\">The first WordCamp Tokyo</a> was held in 2008 with 60 attendees. <a href=\"https://tokyo.wordcamp.org/\" target=\"_blank\">WordCamp Tokyo</a> today now pulls in 1200 &#8211; 1400 people, according to co-organizer <a href=\"https://profiles.wordpress.org/shinichin\" target=\"_blank\">Shinichi Nishikawa</a>. This event is larger than past editions of WordCamps Europe and San Francisco.</p>
<p>Nishikawa reports that over the past seven years, Japan has hosted 15 WordCamps in Tokyo, Kyoto, Fukuoka, Yokohama Nagoyo, Kobe, and Osaka. <a href=\"https://kansai.wordcamp.org/2014/\" target=\"_blank\">WordCamp Kansai</a>, held in the Western part of the country, was organized by WordBench members of that area, including Shiga, Kyoto, Osaka, Hyogo, Nara and Wakayama.</p>
<p>Regional WordPress groups in Japan are organized on <a href=\"http://WordBench.org\" target=\"_blank\">WordBench.org</a>, a site that allows users to find, join, and create a meetup. The site was <a href=\"http://wordpress.tv/2009/04/30/wordcamp-tokyo-2009-takayuki-miyoshi-introducing-wordpress-regional-community-wordbench/\" target=\"_blank\">created in 2009 by Takayuki Miyoshi</a>, the author of <a href=\"https://wordpress.org/plugins/contact-form-7/\" target=\"_blank\">Contact Form 7</a>, one of WordPress&#8217; most popular plugins. WordBench has been running on BuddyPress for the past six years and was originally built on RC1 of the plugin.</p>
<p><a href=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2015/05/wordbench.png\"><img src=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2015/05/wordbench.png?resize=1025%2C672\" alt=\"wordbench\" class=\"aligncenter size-full wp-image-43929\" /></a></p>
<p>The site currently lists 48 local groups throughout Japan, named for their cities, i.e. WordBench Tokyo, WordBench Osaka, WordBench Kawasaki. Members and organizers use the site to post about upcoming events and recaps of meetups recently held in various locations. The site serves to keep Japan&#8217;s local communities connected and inspired.</p>
<h2>Japan&#8217;s Unique WordPress Meetups and the Importance of Wapuu</h2>
<p>In addition to the regional WordBench groups, interest-based meetups are also common in the Japanese WordPress community. In this format, members meet around different interests outside of WordPress, such as cooking or photography. For example, the <a href=\"https://shashinbu.wordpress.com/\" target=\"_blank\">WordPhotoclub</a> meetup gathers together to go on walks and take photos. Members&#8217; <a href=\"http://8bitodyssey.com/archives/1547\" target=\"_blank\">photos</a> were printed and displayed at WordCamp Tokyo 2012.</p>
<p><a href=\"http://takamorry.com/article/20130209_wordcrab.html\" target=\"_blank\">WordCrab</a> is another example of one of Japan&#8217;s unique WordPress meetups. Members from all over from Japan gather in the Fukui prefecture, where they combine WordPress sessions with a giant <a href=\"https://www.flickr.com/search/?q=wordcrab&l=commderiv&ss=0&ct=0&mt=all&w=all&adv=1\" target=\"_blank\">crab party</a> where everyone feasts upon the region&#8217;s renowned crabs.</p>
<a href=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2015/05/wordcrab.jpg\"><img src=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2015/05/wordcrab.jpg?resize=1025%2C586\" alt=\"photo credit: WordCrab meetup\" class=\"size-full wp-image-43936\" /></a>photo credit: <a href=\"https://www.flickr.com/search/?q=wordcrab&l=commderiv&ss=0&ct=0&mt=all&w=all&adv=1\">WordCrab meetup</a>
<p>The <a href=\"http://2014onsen.wbsendai.com/\" target=\"_blank\">Word温泉 (WordOnsen) meetup</a> is centered around the enjoyment of hot springs. Members gather in Fukushima and stay at a hotel where they have WordPress sessions and a party night.</p>
<p>&#8220;In meetups we started doing more things than just learning WordPress,&#8221; community organizer Shinichi Nishikawa said. &#8220;We get friends together and go for a walk and eat lunch/dinner together.</p>
<p>&#8220;I think this a really good way to make the community stronger. <span class=\"pullquote alignleft\">People are talented in different things and by doing something together, other than WordPress, people can show their talents.</span> And of course, it’s fun.&#8221;</p>
<p>Japan&#8217;s holistic approach to meetups incorporates various aspects of life and relationships, as opposed to simply centering around improving WordPress technical skill. As a result, members become more connected and meetups are highly personalized. That&#8217;s where Wapuu enters the picture to bring special meaning to each group.</p>
<p><a href=\"https://ja.wordpress.org/about-wp-ja/wapuu/\" target=\"_blank\">Wapuu</a>, the official mascot character of WordPress, was designed by Kazuko Kaneuchi in 2011. It&#8217;s <a href=\"https://github.com/jawordpressorg/wapuu\" target=\"_blank\">distributed under the GPLv2 or later</a> and can be modified by anyone to add more personality to the character.</p>
<p>&#8220;Thanks to the freedom of the GPL, there have been many <a href=\"http://jawordpressorg.github.io/wapuu/\" target=\"_blank\">forked versions of Wapuu</a>,&#8221; Nishikawa said. &#8220;All local Wapuus are created by someone who belongs to each local community and they hold something that represents where they are from.&#8221;</p>
<a href=\"http://i1.wp.com/wptavern.com/wp-content/uploads/2015/05/local-wapuu.jpg\"><img src=\"http://i1.wp.com/wptavern.com/wp-content/uploads/2015/05/local-wapuu.jpg?resize=627%2C349\" alt=\"photo credit:  Naoko Takano - WordPress History\" class=\"size-full wp-image-43943\" /></a>photo credit:<br />Naoko Takano &#8211; <a href=\"http://www.slideshare.net/naokomc/wordpress-history-21925968/42\">WordPress History</a>
<p>Wapuu is so well-loved that the creature ends up making its way onto <a href=\"https://www.flickr.com/photos/odysseygate/8509556933/\" target=\"_blank\">swag</a>, cakes, and nail and coffee art at Japanese WordPress events.</p>
<a href=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2015/05/wapuu-everywhere.jpg\"><img src=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2015/05/wapuu-everywhere.jpg?resize=1025%2C703\" alt=\"photo credit:  Naoko Takano - Learnings from Growing Local WordPress Communities\" class=\"size-full wp-image-43945\" /></a>photo credit:<br />Naoko Takano &#8211; <a href=\"http://www.slideshare.net/naokomc/wordcamp-europe2013/47\">Learnings from Growing Local WordPress Communities</a>
<p>The name &#8220;Wapuu&#8221; was given to the mascot by a users&#8217; poll. &#8220;Japanese people pronounce WordPress as &#8216;WAADOPURESU,\'&#8221; Nishikawa said. &#8220;Wapuu sounds like an abbreviation of WAADOPURESU, taking &#8216;Wa&#8217; and &#8216;Pu&#8217; from it.&#8221;</p>
<p>Modifications of the mascot have recently started popping up at WordCamps outside of Japan. <a href=\"http://wptavern.com/scott-evans-on-designing-the-punk-wapuu-for-wordcamp-london-2015\" target=\"_blank\">WordCamp London&#8217;s wapuunk</a> was so popular that it inspired WordCamp Philly and <a href=\"http://wptavern.com/meet-wapuujlo-official-mascot-of-wordcamp-belgrade\" target=\"_blank\">WordCamp Belgrade</a> to create their own unique modifications to the character.</p>
<p>For whatever reason, Wapuu seems to have a special power to bring people together, regardless of culture or location. WordPress has the Japanese community to thank for its unique open source contribution to meetup branding.</p>
<h2>The Challenges of Contributing to WordPress Across the Language Barrier</h2>
<p>Despite having a large WordPress community thriving in Japan, with many of the <a href=\"http://www.sailor.co.jp/\" target=\"_blank\">top</a> <a href=\"http://womens.marathon-festival.com/2014/\" target=\"_blank\">websites</a> <a href=\"http://tasukeaijapan.jp/\" target=\"_blank\">built</a> on the <a href=\"http://www.kurashi-no-techo.co.jp/\" target=\"_blank\">software</a>, Japanese developers have a difficult time contributing back to core.</p>
<p>&#8220;Language is the biggest barrier,&#8221; Nishikawa told the Tavern. &#8220;There are many good developers in Japan (and in other countries) who don’t speak English. Most of them can read documentation but joining in the conversation in tickets and on Slack is a different thing.</p>
<p>&#8220;In my opinion, there is English for native speakers and English for international people, and they are different,&#8221; he explained.</p>
<p>&#8220;It’s difficult to say how different they are, but for us who are not native, ambiguous words, abbreviations like &#8216;FWIW,&#8217; jokes, and slang are difficult,&#8221; Nishikawa said. &#8220;Sometimes nesting a long sentence in another long sentence by using &#8216;that,&#8217; &#8216;which,&#8217; and &#8216;including&#8217; is difficult.&#8221;</p>
<p>He explained that overcoming the language barrier is more than simply learning English; it also includes the hurdle of trying to understand the abbreviations and expressions that are infused by the culture around native English speakers.</p>
<p>&#8220;People would say that you can understand because it’s code, but if we look at the conversations in tickets, the surrounding discussion often concerns more than just the code,&#8221; he said.</p>
<p>&#8220;Non-English speaking developers are trying to learn English, but it would be good if people in the ticket / Slack would keep in mind that there are people who don’t share the context or culture behind the words they write,&#8221; Nishikawa suggested.</p>
<p>&#8220;If we make the words and expressions easier to understand, someone who understands 80%  will have the opportunity to understand nearly 100%.&#8221;</p>
<p>However, Nishikawa is unsure of whether or not it is productive to request these kinds of changes, given that communication can never really be separated from culture.</p>
<p>&#8220;Maybe a more welcoming atmosphere needed?&#8221; he said. &#8220;On the other hand, I know that the discussions include a great deal of context and many cultural things. It’s a place for communication, too. So, I don’t know if it’s right to say that something needs to change.</p>
<p>&#8220;Additionally, there are many talented developers who don’t understand English at all and I have no idea what can be done for them,&#8221; he said.</p>
<p>Nishikawa said that he felt much more connected to the community after attending WordCamp San Francisco and the following summit and contributor day.</p>
<p>&#8220;Even for developers who didn&#8217;t speak English, we had translators and discussed things, looked at the code and shared the WordPress projects they are working on,&#8221; he said. &#8220;After these face-to-face conversations, developers are more relaxed and motivated to work in the <a href=\"https://make.wordpress.org/\" target=\"_blank\">core Make project</a>. Inviting developers to meetups/camps in the English world or inviting core contributors travel and join local contribution days will be a big trigger to involve more people.&#8221;</p>
<h2>The Future of WordPress in Japan</h2>
<p>Nishikawa believes that WordPress has a bright future in Japan, thanks to the efforts of Otsukare, Naoko Takano, Takayuki Miyoshi and all the plugin developers, Tenpura (the author of <a href=\"https://wordpress.org/plugins/wp-multibyte-patch/\" target=\"_blank\">WP Multibyte Patch</a> plugin), bloggers, community organizers, an army of dedicated translators and more.</p>
<p>He is hopeful that positive experiences for developers at global meetups like WCSF will help the Japanese WordPress community find ways to contribute back to core and other projects.</p>
<p>&#8220;There have been a few people who had contributed separately, but now I feel there is a small groove of people who are more interested in contribution,&#8221; he said.</p>
<p>&#8220;For the community, we hope that the activeness of the Japanese community will be exported to other Asian (and global) communities, especially with Wapuu or the unique &#8220;more-than-learning&#8221; style of meetups.&#8221;</p>
<p>He also believes the future of WordPress in Japan will be brighter with the internationalization improvements that are continually being added to core.</p>
<p>&#8220;For the users, when everything is translatable, people are happier. If WordPress can become more mobile friendly, it will be used more by young people. When the WP-API is in core, there will be more diverse apps available.&#8221;</p>
<p>Nishikawa has had such a positive experience organizing WordPress community events in Japan that he is now active in growing the community in Thailand.</p>
<p>&#8220;We now have meetups twice per month in Bangkok for developers/users/designers. We don’t have &#8216;session-oriented meetups&#8217; anymore but we try to have casual talks every time, where everyone can speak in their own languages. Translation is more than welcome but we don’t want to rely on someone.&#8221;</p>
<p>As Japan&#8217;s community-oriented approach to learning has paid off with highly active meetup groups and some of the largest WordCamps on the globe, Nishikawa is hoping to bring his experience to Thailand and help organize a WordCamp Bangkok in the near future.</p>
<p>&#8220;Community has made my life/job much more exciting and fun,&#8221; he said. &#8220;Many things will differ culture by culture but the core value of community should be the same everywhere.&#8221;</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 18 May 2015 21:26:06 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:46;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"Matt: 2 Chocolate Chip Cookies\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:21:\"http://ma.tt/?p=45056\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:46:\"http://ma.tt/2015/05/2-chocolate-chip-cookies/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:494:\"<blockquote><p>Sometimes, you just want 2 chocolate chip cookies. This happens to me all of the time. I want a super indulgent, rich and buttery chocolate chip cookie, but don’t want to make the whole 36 of them which I’d inevitably inhale over about the same amount of hours.</p></blockquote>
<p><a href=\"http://www.inthiskitchen.com/2014/05/21/just-2-chocolate-chip-cookies-single-serving-recipe/\">Ever wondered a good recipe to make just 2 chocolate chip cookies</a>? Now you know.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 18 May 2015 06:35:00 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"Matt\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:47;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:23:\"Matt: Silk Road, Part 2\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:21:\"http://ma.tt/?p=45063\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:38:\"http://ma.tt/2015/05/silk-road-part-2/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:435:\"<p>As <a href=\"http://ma.tt/2015/05/untold-silk-road/\">promised a few weeks ago</a>, a new installment of the Wired Silk Road story is out and I wanted to share it, <a href=\"http://www.wired.com/2015/05/silk-road-2/\">The Untold Story of Silk Road, Part 2: The Fall</a>. This one is actually a lot more normal, with some surprisingly simple breaks leading to the downfall of Ross, but there&#8217;s an interesting twist at the end.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Sat, 16 May 2015 17:14:26 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"Matt\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:48;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:27:\"Matt: Memorable Musk Quotes\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:21:\"http://ma.tt/?p=45046\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:43:\"http://ma.tt/2015/05/memorable-musk-quotes/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:224:\"<p><a href=\"http://www.washingtonpost.com/blogs/innovations/wp/2015/05/11/the-22-most-memorable-quotes-from-the-new-elon-musk-book-ranked/\">The 22 most memorable quotes from the new Elon Musk book, ranked</a>. Hilarious.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Sat, 16 May 2015 06:14:00 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"Matt\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:49;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:82:\"WPTavern: Display Your Contributions to WordPress With the WP Contributions Plugin\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=43823\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:92:\"http://wptavern.com/display-your-contributions-to-wordpress-with-the-wp-contributions-plugin\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:4327:\"<p><a href=\"http://i1.wp.com/wptavern.com/wp-content/uploads/2015/05/WPContributionsFeaturedImage.png\"><img class=\"aligncenter size-full wp-image-43884\" src=\"http://i1.wp.com/wptavern.com/wp-content/uploads/2015/05/WPContributionsFeaturedImage.png?resize=748%2C239\" alt=\"WPContributionsFeaturedImage\" /></a><a href=\"https://wordpress.org/plugins/wp-contributions/\">WP Contributions</a> is a new plugin by Dustin Filippini, Damon Cook, and WebDevStudios that displays WordPress contributions via widgets. Widgets included are:</p>
<ul>
<li>Contributions to the Codex</li>
<li>WordPress Core Contributions</li>
<li>Featured Plugin</li>
<li>Featured Theme</li>
</ul>
<p>Once activated, browse to Appearance &gt; Widgets to access the new widgets. You&#8217;ll need to know your username for WordPress trac and the Codex to display your contributions. Keep in mind that the core contributions widget only list tickets that are closed and you received props for.</p>
<a href=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2015/05/WPContributionsCoreWidget.png\"><img class=\"size-full wp-image-43880\" src=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2015/05/WPContributionsCoreWidget.png?resize=342%2C272\" alt=\"WP Core Contributions Widget\" /></a>WP Core Contributions Widget
<p>The Codex contributions widget displays the most recent articles you&#8217;ve edited along with a link to see more.</p>
<a href=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2015/05/WPContributionsCodexWidget.png\"><img class=\"size-full wp-image-43881\" src=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2015/05/WPContributionsCodexWidget.png?resize=330%2C296\" alt=\"Codex Contributions Widget\" /></a>Codex Contributions Widget
<p>The theme and plugin widgets use the slug of the theme and plugin you want to feature. You can only feature one theme or plugin at a time unless you use multiple widgets. The featured plugin widget displays a thumbnail of the plugin&#8217;s header image, author name, version, description, average rating, total downloads, and when it was last updated.</p>
<a href=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2015/05/WPContributionPluginWidget.png\"><img class=\"size-full wp-image-43882\" src=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2015/05/WPContributionPluginWidget.png?resize=331%2C438\" alt=\"WP Contribution Plugin Widget\" /></a>WP Contribution Plugin Widget
<p>The featured theme widget displays a small preview of the theme, a short description, average rating, author, current version, total downloads, and when it was last updated.</p>
<a href=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2015/05/WPContribThemeWidget.png\"><img class=\"size-full wp-image-43883\" src=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2015/05/WPContribThemeWidget.png?resize=379%2C707\" alt=\"Featured Theme Widget\" /></a>Featured Theme Widget
<p>Even though the plugin and theme widgets are meant to be used to showcase your own work, they&#8217;re great for featuring any plugin or theme you&#8217;d like people to know about. WP Contributions comes with a series of <a href=\"https://wordpress.org/plugins/wp-contributions/faq/\">template tags</a> for those who want more control over how the information is displayed.</p>
<p>One thing I&#8217;d like to see in a future version is short code support. This way, users could create a WP Contributions page on their site with easy to use short codes. It&#8217;s not supported now, but Filippini informs me that a future version will include the ability to display badges attached to a WordPress.org user profile.</p>
<p>As WordPress <a href=\"http://w3techs.com/\">continues to increase in marketshare</a>, the ability to show how much you&#8217;ve contributed to the project is a huge resume booster, especially if you can say your code runs on millions of sites. In early 2014, WordPress made substantial <a href=\"http://wptavern.com/wordpress-org-profile-redesign-is-live\">improvements to user profiles</a> but there&#8217;s no easy way to display those contributions to a wider audience.</p>
<p>WP Contributions does a decent job filling the void and is available for free on the WordPress.org plugin directory. I tested <a href=\"https://wordpress.org/plugins/wp-contributions/\">WP Contributions</a> on WordPress 4.2.2 and it works without any problems.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 15 May 2015 23:28:08 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}}}}}}}}}}}}s:4:\"type\";i:128;s:7:\"headers\";a:10:{s:6:\"server\";s:5:\"nginx\";s:4:\"date\";s:29:\"Tue, 02 Jun 2015 06:28:29 GMT\";s:12:\"content-type\";s:8:\"text/xml\";s:14:\"content-length\";s:6:\"225756\";s:10:\"connection\";s:5:\"close\";s:4:\"vary\";s:15:\"Accept-Encoding\";s:13:\"last-modified\";s:29:\"Tue, 02 Jun 2015 06:15:15 GMT\";s:15:\"x-frame-options\";s:10:\"SAMEORIGIN\";s:4:\"x-nc\";s:11:\"HIT lax 249\";s:13:\"accept-ranges\";s:5:\"bytes\";}s:5:\"build\";s:14:\"20130911040210\";}","no");
INSERT INTO `wp_options` VALUES("13362","_transient_timeout_feed_mod_d117b5738fbd35bd8c0391cda1f2b5d9","1433269710","no");
INSERT INTO `wp_options` VALUES("13363","_transient_feed_mod_d117b5738fbd35bd8c0391cda1f2b5d9","1433226510","no");
INSERT INTO `wp_options` VALUES("13364","_transient_timeout_feed_b9388c83948825c1edaef0d856b7b109","1433269711","no");
INSERT INTO `wp_options` VALUES("13365","_transient_feed_b9388c83948825c1edaef0d856b7b109","a:4:{s:5:\"child\";a:1:{s:0:\"\";a:1:{s:3:\"rss\";a:1:{i:0;a:6:{s:4:\"data\";s:3:\"
	
\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:7:\"version\";s:3:\"2.0\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:1:{s:0:\"\";a:1:{s:7:\"channel\";a:1:{i:0;a:6:{s:4:\"data\";s:117:\"
		
		
		
		
		
		
				

		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		

	\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:7:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:39:\"WordPress Plugins » View: Most Popular\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:45:\"https://wordpress.org/plugins/browse/popular/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:39:\"WordPress Plugins » View: Most Popular\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"language\";a:1:{i:0;a:5:{s:4:\"data\";s:5:\"en-US\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 02 Jun 2015 05:53:47 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:9:\"generator\";a:1:{i:0;a:5:{s:4:\"data\";s:25:\"http://bbpress.org/?v=1.1\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"item\";a:30:{i:0;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Contact Form 7\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:55:\"https://wordpress.org/plugins/contact-form-7/#post-2141\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 02 Aug 2007 12:45:03 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:35:\"2141@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:54:\"Just another contact form plugin. Simple but flexible.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:16:\"Takayuki Miyoshi\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:1;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:18:\"Wordfence Security\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:51:\"https://wordpress.org/plugins/wordfence/#post-29832\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Sun, 04 Sep 2011 03:13:51 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:36:\"29832@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:137:\"Wordfence Security is a free enterprise class security and performance plugin that makes your site up to 50 times faster and more secure.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:9:\"Wordfence\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:2;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:33:\"WooCommerce - excelling eCommerce\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:53:\"https://wordpress.org/plugins/woocommerce/#post-29860\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 05 Sep 2011 08:13:36 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:36:\"29860@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:97:\"WooCommerce is a powerful, extendable eCommerce plugin that helps you sell anything. Beautifully.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:9:\"WooThemes\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:3;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:7:\"Akismet\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:46:\"https://wordpress.org/plugins/akismet/#post-15\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 09 Mar 2007 22:11:30 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:33:\"15@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:98:\"Akismet checks your comments against the Akismet Web service to see if they look like spam or not.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Matt Mullenweg\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:4;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:24:\"Jetpack by WordPress.com\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:49:\"https://wordpress.org/plugins/jetpack/#post-23862\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 20 Jan 2011 02:21:38 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:36:\"23862@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"Your WordPress, Streamlined.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:9:\"Tim Moore\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:5;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:22:\"WordPress SEO by Yoast\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:54:\"https://wordpress.org/plugins/wordpress-seo/#post-8321\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 01 Jan 2009 20:34:44 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:35:\"8321@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:131:\"Improve your WordPress SEO: Write better content and have a fully optimized WordPress site using Yoast&#039;s WordPress SEO plugin.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Joost de Valk\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:6;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:18:\"WordPress Importer\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:60:\"https://wordpress.org/plugins/wordpress-importer/#post-18101\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 20 May 2010 17:42:45 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:36:\"18101@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:101:\"Import posts, pages, comments, custom fields, categories, tags and more from a WordPress export file.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Brian Colinger\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:7;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:23:\"MailChimp for WordPress\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:58:\"https://wordpress.org/plugins/mailchimp-for-wp/#post-54377\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 10 Jun 2013 17:32:11 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:36:\"54377@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:138:\"The best MailChimp plugin to get more email subscribers. Easily add MailChimp sign-up forms and sign-up checkboxes to your WordPress site.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:16:\"Danny van Kooten\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:8;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:15:\"NextGEN Gallery\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:56:\"https://wordpress.org/plugins/nextgen-gallery/#post-1169\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 23 Apr 2007 20:08:06 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:35:\"1169@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:121:\"The most popular WordPress gallery plugin and one of the most popular plugins of all time with over 12 million downloads.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:9:\"Alex Rabe\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:9;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:11:\"Redirection\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:52:\"https://wordpress.org/plugins/redirection/#post-2286\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 10 Sep 2007 04:45:08 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:35:\"2286@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:144:\"Redirection is a WordPress plugin to manage 301 redirections and keep track of 404 errors without requiring knowledge of Apache .htaccess files.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:11:\"John Godley\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:10;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:22:\"Advanced Custom Fields\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:64:\"https://wordpress.org/plugins/advanced-custom-fields/#post-25254\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 17 Mar 2011 04:07:30 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:36:\"25254@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:68:\"Customise WordPress with powerful, professional and intuitive fields\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:12:\"elliotcondon\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:11;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:19:\"All in One SEO Pack\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:59:\"https://wordpress.org/plugins/all-in-one-seo-pack/#post-753\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 30 Mar 2007 20:08:18 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"753@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:126:\"All in One SEO Pack is a WordPress SEO plugin to automatically optimize your WordPress blog for Search Engines such as Google.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:8:\"uberdose\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:12;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:16:\"Breadcrumb NavXT\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:57:\"https://wordpress.org/plugins/breadcrumb-navxt/#post-2634\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Sat, 01 Dec 2007 00:15:03 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:35:\"2634@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:85:\"Adds breadcrumb navigation showing the visitor&#039;s path to their current location.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:11:\"John Havlik\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:13;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:19:\"Google Analyticator\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:59:\"https://wordpress.org/plugins/google-analyticator/#post-130\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 09 Mar 2007 22:31:18 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"130@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:129:\"Easily view your Google Analytics and real-time statistics inside WordPress! Makes it super simple to add your tracking code too.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:12:\"cavemonkey50\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:14;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:21:\"WPtouch Mobile Plugin\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:48:\"https://wordpress.org/plugins/wptouch/#post-5468\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 01 May 2008 04:58:09 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:35:\"5468@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:66:\"Make your WordPress website mobile-friendly with just a few clicks\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:17:\"BraveNewCode Inc.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:15;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:10:\"Duplicator\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:52:\"https://wordpress.org/plugins/duplicator/#post-26607\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 16 May 2011 12:15:41 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:36:\"26607@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:88:\"Duplicate, clone, backup, move and transfer an entire site from one location to another.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:10:\"Cory Lamle\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:16;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:24:\"Fast Secure Contact Form\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:57:\"https://wordpress.org/plugins/si-contact-form/#post-12636\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 27 Aug 2009 01:20:04 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:36:\"12636@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:131:\"An easy and powerful form builder that lets your visitors send you email. Blocks all automated spammers. No templates to mess with.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:12:\"Mike Challis\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:17;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Photo Gallery\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:55:\"https://wordpress.org/plugins/photo-gallery/#post-63299\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 27 Jan 2014 15:58:41 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:36:\"63299@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:143:\"Photo Gallery is an advanced plugin with a list of tools and options for adding and editing images for different views. It is fully responsive.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:9:\"webdorado\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:18;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:25:\"Google Analytics by Yoast\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:71:\"https://wordpress.org/plugins/google-analytics-for-wordpress/#post-2316\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 14 Sep 2007 12:15:27 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:35:\"2316@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:124:\"Track your WordPress site easily with the latest tracking codes and lots added data for search result pages and error pages.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Joost de Valk\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:19;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:16:\"TinyMCE Advanced\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:57:\"https://wordpress.org/plugins/tinymce-advanced/#post-2082\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 27 Jun 2007 15:00:26 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:35:\"2082@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:71:\"Enables the advanced features of TinyMCE, the WordPress WYSIWYG editor.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:10:\"Andrew Ozz\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:20;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:27:\"Black Studio TinyMCE Widget\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:69:\"https://wordpress.org/plugins/black-studio-tinymce-widget/#post-31973\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 10 Nov 2011 15:06:14 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:36:\"31973@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:39:\"The visual editor widget for Wordpress.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:12:\"Marco Chiesi\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:21;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"WP Super Cache\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:55:\"https://wordpress.org/plugins/wp-super-cache/#post-2572\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 05 Nov 2007 11:40:04 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:35:\"2572@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:73:\"A very fast caching engine for WordPress that produces static html files.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:16:\"Donncha O Caoimh\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:22;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:19:\"Google XML Sitemaps\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:64:\"https://wordpress.org/plugins/google-sitemap-generator/#post-132\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 09 Mar 2007 22:31:32 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"132@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:105:\"This plugin will generate a special XML sitemap which will help search engines to better index your blog.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Arne Brachhold\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:23;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:19:\"Shortcodes Ultimate\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:61:\"https://wordpress.org/plugins/shortcodes-ultimate/#post-25618\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 04 Apr 2011 13:08:34 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:36:\"25618@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:61:\"Supercharge your WordPress theme with mega pack of shortcodes\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:16:\"Vladimir Anokhin\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:24;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:11:\"Ninja Forms\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:53:\"https://wordpress.org/plugins/ninja-forms/#post-33147\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 20 Dec 2011 18:11:48 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:36:\"33147@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:142:\"Forms created with a simple drag and drop interface. Contact forms, Email collection forms, or any other form you want on your WordPress site.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:7:\"kstover\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:25;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:33:\"Google Analytics Dashboard for WP\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:75:\"https://wordpress.org/plugins/google-analytics-dashboard-for-wp/#post-50539\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Sun, 10 Mar 2013 17:07:11 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:36:\"50539@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:148:\"Displays Google Analytics reports and real-time statistics in your WordPress Dashboard. Inserts the latest tracking code in every page of your site.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:10:\"Alin Marcu\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:26;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"WP Google Maps\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:56:\"https://wordpress.org/plugins/wp-google-maps/#post-34206\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 25 Jan 2012 06:23:42 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:36:\"34206@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:146:\"The easiest to use Google maps plugin! Create a custom Google map with high quality markers containing categories, descriptions, images and links.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:7:\"WPGMaps\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:27;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:8:\"WP Smush\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:51:\"https://wordpress.org/plugins/wp-smushit/#post-7936\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 04 Dec 2008 00:00:37 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:35:\"7936@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:108:\"Reduce image file sizes, improve performance and boost your SEO using the free WPMU DEV WordPress Smush API.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:10:\"Alex Dunae\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:28;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:26:\"Page Builder by SiteOrigin\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:59:\"https://wordpress.org/plugins/siteorigin-panels/#post-51888\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 11 Apr 2013 10:36:42 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:36:\"51888@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:111:\"Build responsive page layouts using the widgets you know and love using this simple drag and drop page builder.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:11:\"Greg Priday\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:29;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"UpdraftPlus Backup and Restoration\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:53:\"https://wordpress.org/plugins/updraftplus/#post-38058\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 21 May 2012 15:14:11 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:36:\"38058@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:148:\"Backup and restoration made easy. Complete backups; manual or scheduled (backup to S3, Dropbox, Google Drive, Rackspace, FTP, SFTP, email + others).\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"David Anderson\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}}}s:27:\"http://www.w3.org/2005/Atom\";a:1:{s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:0:\"\";s:7:\"attribs\";a:1:{s:0:\"\";a:3:{s:4:\"href\";s:46:\"https://wordpress.org/plugins/rss/view/popular\";s:3:\"rel\";s:4:\"self\";s:4:\"type\";s:19:\"application/rss+xml\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}}}}}}}}s:4:\"type\";i:128;s:7:\"headers\";a:12:{s:6:\"server\";s:5:\"nginx\";s:4:\"date\";s:29:\"Tue, 02 Jun 2015 06:28:31 GMT\";s:12:\"content-type\";s:23:\"text/xml; charset=UTF-8\";s:10:\"connection\";s:5:\"close\";s:4:\"vary\";s:15:\"Accept-Encoding\";s:25:\"strict-transport-security\";s:11:\"max-age=360\";s:7:\"expires\";s:29:\"Tue, 02 Jun 2015 06:28:47 GMT\";s:13:\"cache-control\";s:0:\"\";s:6:\"pragma\";s:0:\"\";s:13:\"last-modified\";s:31:\"Tue, 02 Jun 2015 05:53:47 +0000\";s:15:\"x-frame-options\";s:10:\"SAMEORIGIN\";s:4:\"x-nc\";s:11:\"HIT lax 249\";}s:5:\"build\";s:14:\"20130911040210\";}","no");
INSERT INTO `wp_options` VALUES("13366","_transient_timeout_feed_mod_b9388c83948825c1edaef0d856b7b109","1433269711","no");
INSERT INTO `wp_options` VALUES("13367","_transient_feed_mod_b9388c83948825c1edaef0d856b7b109","1433226511","no");
INSERT INTO `wp_options` VALUES("13368","_transient_timeout_dash_4077549d03da2e451c8b5f002294ff51","1433269711","no");
INSERT INTO `wp_options` VALUES("13369","_transient_dash_4077549d03da2e451c8b5f002294ff51","<div class=\"rss-widget\"><ul><li><a class=\'rsswidget\' href=\'https://wordpress.org/news/2015/05/wordpress-4-2-2/\'>WordPress 4.2.2 Security and Maintenance Release</a> <span class=\"rss-date\">May 7, 2015</span><div class=\"rssSummary\">WordPress 4.2.2 is now available. This is a critical security release for all previous versions and we strongly encourage you to update your sites immediately. Version 4.2.2 addresses two security issues: The Genericons icon font package, which is used in a number of popular themes and plugins, contained an HTML file vulnerable to a cross-site [&hellip;]</div></li></ul></div><div class=\"rss-widget\"><ul><li><a class=\'rsswidget\' href=\'http://wptavern.com/matt-mullenwegs-keynote-at-wordcamp-dallas-2008\'>WPTavern: Matt Mullenweg’s Keynote at WordCamp Dallas 2008</a></li><li><a class=\'rsswidget\' href=\'http://ma.tt/2015/06/webmonkey-podcast/\'>Matt: Webmonkey Podcast</a></li><li><a class=\'rsswidget\' href=\'http://wptavern.com/wordpress-com-launches-insights-better-stats-for-visualizing-publishing-trends\'>WPTavern: WordPress.com Launches Insights: Better Stats for Visualizing Publishing Trends</a></li></ul></div><div class=\"rss-widget\"><ul><li class=\'dashboard-news-plugin\'><span>Popular Plugin:</span> <a href=\'https://wordpress.org/plugins/google-analytics-dashboard-for-wp/\' class=\'dashboard-news-plugin-link\'>Google Analytics Dashboard for WP</a>&nbsp;<span>(<a href=\'plugin-install.php?tab=plugin-information&amp;plugin=google-analytics-dashboard-for-wp&amp;_wpnonce=6e662449b6&amp;TB_iframe=true&amp;width=600&amp;height=800\' class=\'thickbox\' title=\'Google Analytics Dashboard for WP\'>Install</a>)</span></li></ul></div>","no");
INSERT INTO `wp_options` VALUES("13377","revslider_checktables","1","yes");
INSERT INTO `wp_options` VALUES("13378","revslider-static-css",".tp-caption a {
color:#ff7302;
text-shadow:none;
-webkit-transition:all 0.2s ease-out;
-moz-transition:all 0.2s ease-out;
-o-transition:all 0.2s ease-out;
-ms-transition:all 0.2s ease-out;
}

.tp-caption a:hover {
color:#ffa902;
}","yes");
INSERT INTO `wp_options` VALUES("13379","revslider-update-check-short","1433227725","yes");
INSERT INTO `wp_options` VALUES("13392","_site_transient_timeout_poptags_40cd750bba9870f18aada2478b24840a","1433267503","yes");
INSERT INTO `wp_options` VALUES("13393","_site_transient_poptags_40cd750bba9870f18aada2478b24840a","a:40:{s:6:\"widget\";a:3:{s:4:\"name\";s:6:\"widget\";s:4:\"slug\";s:6:\"widget\";s:5:\"count\";s:4:\"5223\";}s:4:\"post\";a:3:{s:4:\"name\";s:4:\"Post\";s:4:\"slug\";s:4:\"post\";s:5:\"count\";s:4:\"3269\";}s:6:\"plugin\";a:3:{s:4:\"name\";s:6:\"plugin\";s:4:\"slug\";s:6:\"plugin\";s:5:\"count\";s:4:\"3204\";}s:5:\"admin\";a:3:{s:4:\"name\";s:5:\"admin\";s:4:\"slug\";s:5:\"admin\";s:5:\"count\";s:4:\"2734\";}s:5:\"posts\";a:3:{s:4:\"name\";s:5:\"posts\";s:4:\"slug\";s:5:\"posts\";s:5:\"count\";s:4:\"2503\";}s:7:\"sidebar\";a:3:{s:4:\"name\";s:7:\"sidebar\";s:4:\"slug\";s:7:\"sidebar\";s:5:\"count\";s:4:\"2001\";}s:9:\"shortcode\";a:3:{s:4:\"name\";s:9:\"shortcode\";s:4:\"slug\";s:9:\"shortcode\";s:5:\"count\";s:4:\"1906\";}s:6:\"google\";a:3:{s:4:\"name\";s:6:\"google\";s:4:\"slug\";s:6:\"google\";s:5:\"count\";s:4:\"1836\";}s:7:\"twitter\";a:3:{s:4:\"name\";s:7:\"twitter\";s:4:\"slug\";s:7:\"twitter\";s:5:\"count\";s:4:\"1787\";}s:6:\"images\";a:3:{s:4:\"name\";s:6:\"images\";s:4:\"slug\";s:6:\"images\";s:5:\"count\";s:4:\"1769\";}s:4:\"page\";a:3:{s:4:\"name\";s:4:\"page\";s:4:\"slug\";s:4:\"page\";s:5:\"count\";s:4:\"1738\";}s:8:\"comments\";a:3:{s:4:\"name\";s:8:\"comments\";s:4:\"slug\";s:8:\"comments\";s:5:\"count\";s:4:\"1728\";}s:5:\"image\";a:3:{s:4:\"name\";s:5:\"image\";s:4:\"slug\";s:5:\"image\";s:5:\"count\";s:4:\"1621\";}s:8:\"facebook\";a:3:{s:4:\"name\";s:8:\"Facebook\";s:4:\"slug\";s:8:\"facebook\";s:5:\"count\";s:4:\"1419\";}s:3:\"seo\";a:3:{s:4:\"name\";s:3:\"seo\";s:4:\"slug\";s:3:\"seo\";s:5:\"count\";s:4:\"1357\";}s:9:\"wordpress\";a:3:{s:4:\"name\";s:9:\"wordpress\";s:4:\"slug\";s:9:\"wordpress\";s:5:\"count\";s:4:\"1299\";}s:5:\"links\";a:3:{s:4:\"name\";s:5:\"links\";s:4:\"slug\";s:5:\"links\";s:5:\"count\";s:4:\"1207\";}s:6:\"social\";a:3:{s:4:\"name\";s:6:\"social\";s:4:\"slug\";s:6:\"social\";s:5:\"count\";s:4:\"1165\";}s:7:\"gallery\";a:3:{s:4:\"name\";s:7:\"gallery\";s:4:\"slug\";s:7:\"gallery\";s:5:\"count\";s:4:\"1150\";}s:5:\"email\";a:3:{s:4:\"name\";s:5:\"email\";s:4:\"slug\";s:5:\"email\";s:5:\"count\";s:4:\"1021\";}s:7:\"widgets\";a:3:{s:4:\"name\";s:7:\"widgets\";s:4:\"slug\";s:7:\"widgets\";s:5:\"count\";s:3:\"975\";}s:11:\"woocommerce\";a:3:{s:4:\"name\";s:11:\"woocommerce\";s:4:\"slug\";s:11:\"woocommerce\";s:5:\"count\";s:3:\"942\";}s:5:\"pages\";a:3:{s:4:\"name\";s:5:\"pages\";s:4:\"slug\";s:5:\"pages\";s:5:\"count\";s:3:\"932\";}s:6:\"jquery\";a:3:{s:4:\"name\";s:6:\"jquery\";s:4:\"slug\";s:6:\"jquery\";s:5:\"count\";s:3:\"896\";}s:3:\"rss\";a:3:{s:4:\"name\";s:3:\"rss\";s:4:\"slug\";s:3:\"rss\";s:5:\"count\";s:3:\"865\";}s:5:\"media\";a:3:{s:4:\"name\";s:5:\"media\";s:4:\"slug\";s:5:\"media\";s:5:\"count\";s:3:\"853\";}s:5:\"video\";a:3:{s:4:\"name\";s:5:\"video\";s:4:\"slug\";s:5:\"video\";s:5:\"count\";s:3:\"806\";}s:4:\"ajax\";a:3:{s:4:\"name\";s:4:\"AJAX\";s:4:\"slug\";s:4:\"ajax\";s:5:\"count\";s:3:\"791\";}s:7:\"content\";a:3:{s:4:\"name\";s:7:\"content\";s:4:\"slug\";s:7:\"content\";s:5:\"count\";s:3:\"767\";}s:5:\"login\";a:3:{s:4:\"name\";s:5:\"login\";s:4:\"slug\";s:5:\"login\";s:5:\"count\";s:3:\"743\";}s:9:\"ecommerce\";a:3:{s:4:\"name\";s:9:\"ecommerce\";s:4:\"slug\";s:9:\"ecommerce\";s:5:\"count\";s:3:\"738\";}s:10:\"javascript\";a:3:{s:4:\"name\";s:10:\"javascript\";s:4:\"slug\";s:10:\"javascript\";s:5:\"count\";s:3:\"736\";}s:10:\"buddypress\";a:3:{s:4:\"name\";s:10:\"buddypress\";s:4:\"slug\";s:10:\"buddypress\";s:5:\"count\";s:3:\"695\";}s:5:\"photo\";a:3:{s:4:\"name\";s:5:\"photo\";s:4:\"slug\";s:5:\"photo\";s:5:\"count\";s:3:\"687\";}s:4:\"feed\";a:3:{s:4:\"name\";s:4:\"feed\";s:4:\"slug\";s:4:\"feed\";s:5:\"count\";s:3:\"682\";}s:4:\"link\";a:3:{s:4:\"name\";s:4:\"link\";s:4:\"slug\";s:4:\"link\";s:5:\"count\";s:3:\"669\";}s:7:\"youtube\";a:3:{s:4:\"name\";s:7:\"youtube\";s:4:\"slug\";s:7:\"youtube\";s:5:\"count\";s:3:\"649\";}s:8:\"security\";a:3:{s:4:\"name\";s:8:\"security\";s:4:\"slug\";s:8:\"security\";s:5:\"count\";s:3:\"645\";}s:4:\"spam\";a:3:{s:4:\"name\";s:4:\"spam\";s:4:\"slug\";s:4:\"spam\";s:5:\"count\";s:3:\"640\";}s:6:\"photos\";a:3:{s:4:\"name\";s:6:\"photos\";s:4:\"slug\";s:6:\"photos\";s:5:\"count\";s:3:\"639\";}}","yes");
INSERT INTO `wp_options` VALUES("13394","_site_transient_timeout_theme_roots","1433258521","yes");
INSERT INTO `wp_options` VALUES("13395","_site_transient_theme_roots","a:5:{s:13:\"twentyfifteen\";s:7:\"/themes\";s:14:\"twentyfourteen\";s:7:\"/themes\";s:14:\"twentythirteen\";s:7:\"/themes\";s:12:\"twentytwelve\";s:7:\"/themes\";s:5:\"twish\";s:7:\"/themes\";}","yes");
INSERT INTO `wp_options` VALUES("13396","_site_transient_update_plugins","O:8:\"stdClass\":5:{s:12:\"last_checked\";i:1433256732;s:7:\"checked\";a:15:{s:53:\"adaptive-options-framework-import-export/function.php\";s:3:\"1.0\";s:43:\"adaptive-shortcodes/adaptive-shortcodes.php\";s:3:\"1.0\";s:35:\"admin-menu-tree-page-view/index.php\";s:5:\"2.6.9\";s:51:\"all-in-one-wp-security-and-firewall/wp-security.php\";s:6:\"v3.9.6\";s:37:\"breadcrumb-navxt/breadcrumb-navxt.php\";s:5:\"5.2.2\";s:36:\"contact-form-7/wp-contact-form-7.php\";s:5:\"4.1.2\";s:33:\"custom-favicon/custom-favicon.php\";s:5:\"1.0.3\";s:37:\"disable-comments/disable-comments.php\";s:5:\"1.3.1\";s:39:\"options-framework/options-framework.php\";s:5:\"1.8.4\";s:47:\"really-simple-captcha/really-simple-captcha.php\";s:7:\"1.8.0.1\";s:23:\"revslider/revslider.php\";s:5:\"4.6.0\";s:24:\"simple-lightbox/main.php\";s:5:\"2.4.0\";s:27:\"woosidebars/woosidebars.php\";s:5:\"1.4.2\";s:24:\"wordpress-seo/wp-seo.php\";s:5:\"2.1.1\";s:27:\"js_composer/js_composer.php\";s:6:\"3.6.13\";}s:8:\"response\";a:1:{s:27:\"js_composer/js_composer.php\";O:8:\"stdClass\":4:{s:4:\"slug\";s:11:\"js_composer\";s:11:\"new_version\";s:5:\"4.5.2\";s:3:\"url\";s:0:\"\";s:7:\"package\";s:0:\"\";}}s:12:\"translations\";a:0:{}s:9:\"no_update\";a:11:{s:35:\"admin-menu-tree-page-view/index.php\";O:8:\"stdClass\":6:{s:2:\"id\";s:5:\"17833\";s:4:\"slug\";s:25:\"admin-menu-tree-page-view\";s:6:\"plugin\";s:35:\"admin-menu-tree-page-view/index.php\";s:11:\"new_version\";s:5:\"2.6.9\";s:3:\"url\";s:56:\"https://wordpress.org/plugins/admin-menu-tree-page-view/\";s:7:\"package\";s:74:\"https://downloads.wordpress.org/plugin/admin-menu-tree-page-view.2.6.9.zip\";}s:51:\"all-in-one-wp-security-and-firewall/wp-security.php\";O:8:\"stdClass\":6:{s:2:\"id\";s:5:\"41309\";s:4:\"slug\";s:35:\"all-in-one-wp-security-and-firewall\";s:6:\"plugin\";s:51:\"all-in-one-wp-security-and-firewall/wp-security.php\";s:11:\"new_version\";s:6:\"v3.9.6\";s:3:\"url\";s:66:\"https://wordpress.org/plugins/all-in-one-wp-security-and-firewall/\";s:7:\"package\";s:78:\"https://downloads.wordpress.org/plugin/all-in-one-wp-security-and-firewall.zip\";}s:37:\"breadcrumb-navxt/breadcrumb-navxt.php\";O:8:\"stdClass\":6:{s:2:\"id\";s:4:\"1283\";s:4:\"slug\";s:16:\"breadcrumb-navxt\";s:6:\"plugin\";s:37:\"breadcrumb-navxt/breadcrumb-navxt.php\";s:11:\"new_version\";s:5:\"5.2.2\";s:3:\"url\";s:47:\"https://wordpress.org/plugins/breadcrumb-navxt/\";s:7:\"package\";s:65:\"https://downloads.wordpress.org/plugin/breadcrumb-navxt.5.2.2.zip\";}s:36:\"contact-form-7/wp-contact-form-7.php\";O:8:\"stdClass\":6:{s:2:\"id\";s:3:\"790\";s:4:\"slug\";s:14:\"contact-form-7\";s:6:\"plugin\";s:36:\"contact-form-7/wp-contact-form-7.php\";s:11:\"new_version\";s:5:\"4.1.2\";s:3:\"url\";s:45:\"https://wordpress.org/plugins/contact-form-7/\";s:7:\"package\";s:63:\"https://downloads.wordpress.org/plugin/contact-form-7.4.1.2.zip\";}s:33:\"custom-favicon/custom-favicon.php\";O:8:\"stdClass\":6:{s:2:\"id\";s:5:\"41158\";s:4:\"slug\";s:14:\"custom-favicon\";s:6:\"plugin\";s:33:\"custom-favicon/custom-favicon.php\";s:11:\"new_version\";s:5:\"1.0.3\";s:3:\"url\";s:45:\"https://wordpress.org/plugins/custom-favicon/\";s:7:\"package\";s:63:\"https://downloads.wordpress.org/plugin/custom-favicon.1.0.3.zip\";}s:37:\"disable-comments/disable-comments.php\";O:8:\"stdClass\":6:{s:2:\"id\";s:5:\"22847\";s:4:\"slug\";s:16:\"disable-comments\";s:6:\"plugin\";s:37:\"disable-comments/disable-comments.php\";s:11:\"new_version\";s:5:\"1.3.1\";s:3:\"url\";s:47:\"https://wordpress.org/plugins/disable-comments/\";s:7:\"package\";s:59:\"https://downloads.wordpress.org/plugin/disable-comments.zip\";}s:39:\"options-framework/options-framework.php\";O:8:\"stdClass\":6:{s:2:\"id\";s:5:\"21510\";s:4:\"slug\";s:17:\"options-framework\";s:6:\"plugin\";s:39:\"options-framework/options-framework.php\";s:11:\"new_version\";s:5:\"1.8.4\";s:3:\"url\";s:48:\"https://wordpress.org/plugins/options-framework/\";s:7:\"package\";s:66:\"https://downloads.wordpress.org/plugin/options-framework.1.8.4.zip\";}s:47:\"really-simple-captcha/really-simple-captcha.php\";O:8:\"stdClass\":6:{s:2:\"id\";s:4:\"7028\";s:4:\"slug\";s:21:\"really-simple-captcha\";s:6:\"plugin\";s:47:\"really-simple-captcha/really-simple-captcha.php\";s:11:\"new_version\";s:7:\"1.8.0.1\";s:3:\"url\";s:52:\"https://wordpress.org/plugins/really-simple-captcha/\";s:7:\"package\";s:72:\"https://downloads.wordpress.org/plugin/really-simple-captcha.1.8.0.1.zip\";}s:24:\"simple-lightbox/main.php\";O:8:\"stdClass\":6:{s:2:\"id\";s:5:\"14990\";s:4:\"slug\";s:15:\"simple-lightbox\";s:6:\"plugin\";s:24:\"simple-lightbox/main.php\";s:11:\"new_version\";s:5:\"2.4.0\";s:3:\"url\";s:46:\"https://wordpress.org/plugins/simple-lightbox/\";s:7:\"package\";s:58:\"https://downloads.wordpress.org/plugin/simple-lightbox.zip\";}s:27:\"woosidebars/woosidebars.php\";O:8:\"stdClass\":7:{s:2:\"id\";s:5:\"30668\";s:4:\"slug\";s:11:\"woosidebars\";s:6:\"plugin\";s:27:\"woosidebars/woosidebars.php\";s:11:\"new_version\";s:5:\"1.4.2\";s:3:\"url\";s:42:\"https://wordpress.org/plugins/woosidebars/\";s:7:\"package\";s:60:\"https://downloads.wordpress.org/plugin/woosidebars.1.4.2.zip\";s:14:\"upgrade_notice\";s:34:\"Security Fix for XSS vulnerability\";}s:24:\"wordpress-seo/wp-seo.php\";O:8:\"stdClass\":6:{s:2:\"id\";s:4:\"5899\";s:4:\"slug\";s:13:\"wordpress-seo\";s:6:\"plugin\";s:24:\"wordpress-seo/wp-seo.php\";s:11:\"new_version\";s:5:\"2.1.1\";s:3:\"url\";s:44:\"https://wordpress.org/plugins/wordpress-seo/\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/plugin/wordpress-seo.2.1.1.zip\";}}}","yes");
INSERT INTO `wp_options` VALUES("13397","aiowpsec_db_version","1.6","yes");
INSERT INTO `wp_options` VALUES("13398","aio_wp_security_configs","a:67:{s:36:\"aiowps_remove_wp_generator_meta_info\";s:0:\"\";s:25:\"aiowps_prevent_hotlinking\";s:0:\"\";s:28:\"aiowps_enable_login_lockdown\";s:1:\"1\";s:28:\"aiowps_allow_unlock_requests\";s:0:\"\";s:25:\"aiowps_max_login_attempts\";i:3;s:24:\"aiowps_retry_time_period\";i:5;s:26:\"aiowps_lockout_time_length\";i:60;s:28:\"aiowps_set_generic_login_msg\";s:0:\"\";s:26:\"aiowps_enable_email_notify\";s:1:\"1\";s:20:\"aiowps_email_address\";s:18:\"info@ioptima.co.il\";s:27:\"aiowps_enable_forced_logout\";s:0:\"\";s:25:\"aiowps_logout_time_period\";s:2:\"60\";s:39:\"aiowps_enable_invalid_username_lockdown\";s:0:\"\";s:32:\"aiowps_unlock_request_secret_key\";s:20:\"7fphjjsrpbmgb61pgvb2\";s:26:\"aiowps_enable_whitelisting\";s:0:\"\";s:27:\"aiowps_allowed_ip_addresses\";s:0:\"\";s:27:\"aiowps_enable_login_captcha\";s:0:\"\";s:34:\"aiowps_enable_custom_login_captcha\";s:0:\"\";s:25:\"aiowps_captcha_secret_key\";s:20:\"mjcq9emiyvry2nzkhmxz\";s:42:\"aiowps_enable_manual_registration_approval\";s:1:\"1\";s:39:\"aiowps_enable_registration_page_captcha\";s:0:\"\";s:27:\"aiowps_enable_random_prefix\";s:0:\"\";s:31:\"aiowps_enable_automated_backups\";s:0:\"\";s:26:\"aiowps_db_backup_frequency\";s:1:\"4\";s:25:\"aiowps_db_backup_interval\";s:1:\"2\";s:26:\"aiowps_backup_files_stored\";s:1:\"2\";s:32:\"aiowps_send_backup_email_address\";s:0:\"\";s:27:\"aiowps_backup_email_address\";s:18:\"info@ioptima.co.il\";s:27:\"aiowps_disable_file_editing\";s:0:\"\";s:37:\"aiowps_prevent_default_wp_file_access\";s:0:\"\";s:22:\"aiowps_system_log_file\";s:9:\"error_log\";s:26:\"aiowps_enable_blacklisting\";s:0:\"\";s:26:\"aiowps_banned_ip_addresses\";s:0:\"\";s:28:\"aiowps_enable_basic_firewall\";s:0:\"\";s:31:\"aiowps_enable_pingback_firewall\";s:0:\"\";s:26:\"aiowps_disable_index_views\";s:0:\"\";s:30:\"aiowps_disable_trace_and_track\";s:0:\"\";s:28:\"aiowps_forbid_proxy_comments\";s:0:\"\";s:29:\"aiowps_deny_bad_query_strings\";s:0:\"\";s:34:\"aiowps_advanced_char_string_filter\";s:0:\"\";s:25:\"aiowps_enable_5g_firewall\";s:0:\"\";s:25:\"aiowps_enable_404_logging\";s:0:\"\";s:28:\"aiowps_enable_404_IP_lockout\";s:0:\"\";s:30:\"aiowps_404_lockout_time_length\";s:2:\"60\";s:28:\"aiowps_404_lock_redirect_url\";s:16:\"http://127.0.0.1\";s:31:\"aiowps_enable_rename_login_page\";s:0:\"\";s:28:\"aiowps_enable_login_honeypot\";s:0:\"\";s:43:\"aiowps_enable_brute_force_attack_prevention\";s:0:\"\";s:30:\"aiowps_brute_force_secret_word\";s:0:\"\";s:24:\"aiowps_cookie_brute_test\";s:0:\"\";s:44:\"aiowps_cookie_based_brute_force_redirect_url\";s:16:\"http://127.0.0.1\";s:59:\"aiowps_brute_force_attack_prevention_pw_protected_exception\";s:0:\"\";s:51:\"aiowps_brute_force_attack_prevention_ajax_exception\";s:0:\"\";s:19:\"aiowps_site_lockout\";s:0:\"\";s:23:\"aiowps_site_lockout_msg\";s:0:\"\";s:30:\"aiowps_enable_spambot_blocking\";s:0:\"\";s:29:\"aiowps_enable_comment_captcha\";s:0:\"\";s:32:\"aiowps_enable_automated_fcd_scan\";s:0:\"\";s:25:\"aiowps_fcd_scan_frequency\";s:1:\"4\";s:24:\"aiowps_fcd_scan_interval\";s:1:\"2\";s:28:\"aiowps_fcd_exclude_filetypes\";s:0:\"\";s:24:\"aiowps_fcd_exclude_files\";s:0:\"\";s:26:\"aiowps_send_fcd_scan_email\";s:0:\"\";s:29:\"aiowps_fcd_scan_email_address\";s:18:\"info@ioptima.co.il\";s:27:\"aiowps_fcds_change_detected\";b:0;s:22:\"aiowps_copy_protection\";s:0:\"\";s:40:\"aiowps_prevent_site_display_inside_frame\";s:0:\"\";}","yes");
INSERT INTO `wp_options` VALUES("13399","_transient_timeout_users_online","1433258533","no");
INSERT INTO `wp_options` VALUES("13400","_transient_users_online","a:1:{i:0;a:3:{s:7:\"user_id\";i:2;s:13:\"last_activity\";i:1433256733;s:10:\"ip_address\";s:12:\"87.68.43.158\";}}","no");


DROP TABLE IF EXISTS `wp_postmeta`;

CREATE TABLE `wp_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=1849 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `wp_postmeta` VALUES("4","5","_edit_lock","1433256522:2");
INSERT INTO `wp_postmeta` VALUES("5","5","_edit_last","2");
INSERT INTO `wp_postmeta` VALUES("6","6","_form","<p>Your Name (required)<br />
    [text* your-name] </p>

<p>Your Email (required)<br />
    [email* your-email] </p>

<p>Subject<br />
    [text your-subject] </p>

<p>Your Message<br />
    [textarea your-message] </p>

<p>[submit \"Send\"]</p>");
INSERT INTO `wp_postmeta` VALUES("7","6","_mail","a:7:{s:7:\"subject\";s:14:\"[your-subject]\";s:6:\"sender\";s:26:\"[your-name] <[your-email]>\";s:4:\"body\";s:182:\"From: [your-name] <[your-email]>
Subject: [your-subject]

Message Body:
[your-message]

--
This e-mail was sent from a contact form on Ronen Castro Blog (http://ioptima.wpengine.com)\";s:9:\"recipient\";s:18:\"info@ioptima.co.il\";s:18:\"additional_headers\";s:0:\"\";s:11:\"attachments\";s:0:\"\";s:8:\"use_html\";i:0;}");
INSERT INTO `wp_postmeta` VALUES("8","6","_mail_2","a:8:{s:6:\"active\";b:0;s:7:\"subject\";s:14:\"[your-subject]\";s:6:\"sender\";s:26:\"[your-name] <[your-email]>\";s:4:\"body\";s:124:\"Message Body:
[your-message]

--
This e-mail was sent from a contact form on Ronen Castro Blog (http://ioptima.wpengine.com)\";s:9:\"recipient\";s:12:\"[your-email]\";s:18:\"additional_headers\";s:0:\"\";s:11:\"attachments\";s:0:\"\";s:8:\"use_html\";i:0;}");
INSERT INTO `wp_postmeta` VALUES("9","6","_messages","a:6:{s:12:\"mail_sent_ok\";s:43:\"Your message was sent successfully. Thanks.\";s:12:\"mail_sent_ng\";s:93:\"Failed to send your message. Please try later or contact the administrator by another method.\";s:16:\"validation_error\";s:74:\"Validation errors occurred. Please confirm the fields and submit it again.\";s:4:\"spam\";s:93:\"Failed to send your message. Please try later or contact the administrator by another method.\";s:12:\"accept_terms\";s:35:\"Please accept the terms to proceed.\";s:16:\"invalid_required\";s:31:\"Please fill the required field.\";}");
INSERT INTO `wp_postmeta` VALUES("10","6","_additional_settings","");
INSERT INTO `wp_postmeta` VALUES("11","6","_locale","en_US");
INSERT INTO `wp_postmeta` VALUES("14","5","_wp_page_template","default");
INSERT INTO `wp_postmeta` VALUES("15","5","_wpb_vc_js_status","true");
INSERT INTO `wp_postmeta` VALUES("16","5","_wpb_vc_js_interface_version","0");
INSERT INTO `wp_postmeta` VALUES("17","5","_peach_hide_subheader","on");
INSERT INTO `wp_postmeta` VALUES("18","5","_peach_bkgd_color","#f3f3f3");
INSERT INTO `wp_postmeta` VALUES("19","5","_peach_bkgd_repeat","no-repeat");
INSERT INTO `wp_postmeta` VALUES("20","5","_peach_bkgd_position","top center");
INSERT INTO `wp_postmeta` VALUES("21","5","_peach_bkgd_attachment","scroll");
INSERT INTO `wp_postmeta` VALUES("23","5","_peach_header_bkgd_repeat","no-repeat");
INSERT INTO `wp_postmeta` VALUES("24","5","_peach_header_bkgd_position","top left");
INSERT INTO `wp_postmeta` VALUES("25","5","_peach_header_bkgd_attachment","scroll");
INSERT INTO `wp_postmeta` VALUES("30","5","_peach_breadcrumb_align","left");
INSERT INTO `wp_postmeta` VALUES("31","5","_peach_header_bkgd_color","#");
INSERT INTO `wp_postmeta` VALUES("34","10","_wp_attached_file","2014/03/logo.jpg");
INSERT INTO `wp_postmeta` VALUES("35","10","_wp_attachment_metadata","a:5:{s:5:\"width\";i:217;s:6:\"height\";i:87;s:4:\"file\";s:16:\"2014/03/logo.jpg\";s:5:\"sizes\";a:2:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:15:\"logo-150x87.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:87;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:15:\"logo-125x87.jpg\";s:5:\"width\";i:125;s:6:\"height\";i:87;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES("36","5","_peach_bkgd_cover","on");
INSERT INTO `wp_postmeta` VALUES("37","11","_edit_lock","1426079180:2");
INSERT INTO `wp_postmeta` VALUES("38","11","_edit_last","2");
INSERT INTO `wp_postmeta` VALUES("39","11","_wp_page_template","page-sidebar-left-submenu.php");
INSERT INTO `wp_postmeta` VALUES("40","11","_wpb_vc_js_status","true");
INSERT INTO `wp_postmeta` VALUES("41","11","_wpb_vc_js_interface_version","2");
INSERT INTO `wp_postmeta` VALUES("42","11","_peach_bkgd_color","#");
INSERT INTO `wp_postmeta` VALUES("43","11","_peach_bkgd_repeat","no-repeat");
INSERT INTO `wp_postmeta` VALUES("44","11","_peach_bkgd_position","top left");
INSERT INTO `wp_postmeta` VALUES("45","11","_peach_bkgd_attachment","scroll");
INSERT INTO `wp_postmeta` VALUES("46","11","_peach_header_bkgd_color","#");
INSERT INTO `wp_postmeta` VALUES("47","11","_peach_header_bkgd_repeat","no-repeat");
INSERT INTO `wp_postmeta` VALUES("48","11","_peach_header_bkgd_position","top left");
INSERT INTO `wp_postmeta` VALUES("49","11","_peach_header_bkgd_attachment","scroll");
INSERT INTO `wp_postmeta` VALUES("50","11","_peach_breadcrumb_align","left");
INSERT INTO `wp_postmeta` VALUES("51","12","_edit_last","2");
INSERT INTO `wp_postmeta` VALUES("52","12","_wp_page_template","page-sidebar-left-submenu.php");
INSERT INTO `wp_postmeta` VALUES("53","12","_wpb_vc_js_status","false");
INSERT INTO `wp_postmeta` VALUES("54","12","_wpb_vc_js_interface_version","2");
INSERT INTO `wp_postmeta` VALUES("55","12","_peach_bkgd_color","#");
INSERT INTO `wp_postmeta` VALUES("56","12","_peach_bkgd_repeat","no-repeat");
INSERT INTO `wp_postmeta` VALUES("57","12","_peach_bkgd_position","top left");
INSERT INTO `wp_postmeta` VALUES("58","12","_peach_bkgd_attachment","scroll");
INSERT INTO `wp_postmeta` VALUES("59","12","_peach_header_bkgd_color","#");
INSERT INTO `wp_postmeta` VALUES("60","12","_peach_header_bkgd_repeat","no-repeat");
INSERT INTO `wp_postmeta` VALUES("61","12","_peach_header_bkgd_position","top left");
INSERT INTO `wp_postmeta` VALUES("62","12","_peach_header_bkgd_attachment","scroll");
INSERT INTO `wp_postmeta` VALUES("63","12","_peach_breadcrumb_align","left");
INSERT INTO `wp_postmeta` VALUES("64","12","_edit_lock","1408960989:2");
INSERT INTO `wp_postmeta` VALUES("65","13","_edit_last","2");
INSERT INTO `wp_postmeta` VALUES("66","13","_wp_page_template","default");
INSERT INTO `wp_postmeta` VALUES("67","13","_wpb_vc_js_status","false");
INSERT INTO `wp_postmeta` VALUES("68","13","_wpb_vc_js_interface_version","2");
INSERT INTO `wp_postmeta` VALUES("69","13","_peach_bkgd_color","#");
INSERT INTO `wp_postmeta` VALUES("70","13","_peach_bkgd_repeat","no-repeat");
INSERT INTO `wp_postmeta` VALUES("71","13","_peach_bkgd_position","top left");
INSERT INTO `wp_postmeta` VALUES("72","13","_peach_bkgd_attachment","scroll");
INSERT INTO `wp_postmeta` VALUES("73","13","_peach_header_bkgd_color","#");
INSERT INTO `wp_postmeta` VALUES("74","13","_peach_header_bkgd_repeat","no-repeat");
INSERT INTO `wp_postmeta` VALUES("75","13","_peach_header_bkgd_position","top left");
INSERT INTO `wp_postmeta` VALUES("76","13","_peach_header_bkgd_attachment","scroll");
INSERT INTO `wp_postmeta` VALUES("77","13","_peach_breadcrumb_align","left");
INSERT INTO `wp_postmeta` VALUES("78","13","_edit_lock","1409482507:2");
INSERT INTO `wp_postmeta` VALUES("149","19","_edit_last","2");
INSERT INTO `wp_postmeta` VALUES("150","19","_edit_lock","1427631743:2");
INSERT INTO `wp_postmeta` VALUES("151","19","_wp_page_template","page-sidebar-left-submenu.php");
INSERT INTO `wp_postmeta` VALUES("152","19","_wpb_vc_js_status","true");
INSERT INTO `wp_postmeta` VALUES("153","19","_wpb_vc_js_interface_version","2");
INSERT INTO `wp_postmeta` VALUES("154","19","_peach_bkgd_color","#");
INSERT INTO `wp_postmeta` VALUES("155","19","_peach_bkgd_repeat","no-repeat");
INSERT INTO `wp_postmeta` VALUES("156","19","_peach_bkgd_position","top left");
INSERT INTO `wp_postmeta` VALUES("157","19","_peach_bkgd_attachment","scroll");
INSERT INTO `wp_postmeta` VALUES("158","19","_peach_header_bkgd_color","#");
INSERT INTO `wp_postmeta` VALUES("159","19","_peach_header_bkgd_repeat","no-repeat");
INSERT INTO `wp_postmeta` VALUES("160","19","_peach_header_bkgd_position","top left");
INSERT INTO `wp_postmeta` VALUES("161","19","_peach_header_bkgd_attachment","scroll");
INSERT INTO `wp_postmeta` VALUES("162","19","_peach_breadcrumb_align","left");
INSERT INTO `wp_postmeta` VALUES("163","20","_menu_item_type","post_type");
INSERT INTO `wp_postmeta` VALUES("164","20","_menu_item_menu_item_parent","132");
INSERT INTO `wp_postmeta` VALUES("165","20","_menu_item_object_id","19");
INSERT INTO `wp_postmeta` VALUES("166","20","_menu_item_object","page");
INSERT INTO `wp_postmeta` VALUES("167","20","_menu_item_target","");
INSERT INTO `wp_postmeta` VALUES("168","20","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `wp_postmeta` VALUES("169","20","_menu_item_xfn","");
INSERT INTO `wp_postmeta` VALUES("170","20","_menu_item_url","");
INSERT INTO `wp_postmeta` VALUES("217","26","_menu_item_type","post_type");
INSERT INTO `wp_postmeta` VALUES("218","26","_menu_item_menu_item_parent","0");
INSERT INTO `wp_postmeta` VALUES("219","26","_menu_item_object_id","13");
INSERT INTO `wp_postmeta` VALUES("220","26","_menu_item_object","page");
INSERT INTO `wp_postmeta` VALUES("221","26","_menu_item_target","");
INSERT INTO `wp_postmeta` VALUES("222","26","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `wp_postmeta` VALUES("223","26","_menu_item_xfn","");
INSERT INTO `wp_postmeta` VALUES("224","26","_menu_item_url","");
INSERT INTO `wp_postmeta` VALUES("226","27","_menu_item_type","post_type");
INSERT INTO `wp_postmeta` VALUES("227","27","_menu_item_menu_item_parent","30");
INSERT INTO `wp_postmeta` VALUES("228","27","_menu_item_object_id","12");
INSERT INTO `wp_postmeta` VALUES("229","27","_menu_item_object","page");
INSERT INTO `wp_postmeta` VALUES("230","27","_menu_item_target","");
INSERT INTO `wp_postmeta` VALUES("231","27","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `wp_postmeta` VALUES("232","27","_menu_item_xfn","");
INSERT INTO `wp_postmeta` VALUES("233","27","_menu_item_url","");
INSERT INTO `wp_postmeta` VALUES("235","28","_menu_item_type","post_type");
INSERT INTO `wp_postmeta` VALUES("236","28","_menu_item_menu_item_parent","30");
INSERT INTO `wp_postmeta` VALUES("237","28","_menu_item_object_id","11");
INSERT INTO `wp_postmeta` VALUES("238","28","_menu_item_object","page");
INSERT INTO `wp_postmeta` VALUES("239","28","_menu_item_target","");
INSERT INTO `wp_postmeta` VALUES("240","28","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `wp_postmeta` VALUES("241","28","_menu_item_xfn","");
INSERT INTO `wp_postmeta` VALUES("242","28","_menu_item_url","");
INSERT INTO `wp_postmeta` VALUES("253","30","_menu_item_type","custom");
INSERT INTO `wp_postmeta` VALUES("254","30","_menu_item_menu_item_parent","0");
INSERT INTO `wp_postmeta` VALUES("255","30","_menu_item_object_id","30");
INSERT INTO `wp_postmeta` VALUES("256","30","_menu_item_object","custom");
INSERT INTO `wp_postmeta` VALUES("257","30","_menu_item_target","");
INSERT INTO `wp_postmeta` VALUES("258","30","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `wp_postmeta` VALUES("259","30","_menu_item_xfn","");
INSERT INTO `wp_postmeta` VALUES("260","30","_menu_item_url","http://ioptima.co.il/company/about/");
INSERT INTO `wp_postmeta` VALUES("271","32","_edit_last","2");
INSERT INTO `wp_postmeta` VALUES("272","32","_wp_page_template","default");
INSERT INTO `wp_postmeta` VALUES("273","32","_wpb_vc_js_status","false");
INSERT INTO `wp_postmeta` VALUES("274","32","_wpb_vc_js_interface_version","2");
INSERT INTO `wp_postmeta` VALUES("275","32","_peach_bkgd_color","#");
INSERT INTO `wp_postmeta` VALUES("276","32","_peach_bkgd_repeat","no-repeat");
INSERT INTO `wp_postmeta` VALUES("277","32","_peach_bkgd_position","top left");
INSERT INTO `wp_postmeta` VALUES("278","32","_peach_bkgd_attachment","scroll");
INSERT INTO `wp_postmeta` VALUES("279","32","_peach_header_bkgd_color","#");
INSERT INTO `wp_postmeta` VALUES("280","32","_peach_header_bkgd_repeat","no-repeat");
INSERT INTO `wp_postmeta` VALUES("281","32","_peach_header_bkgd_position","top left");
INSERT INTO `wp_postmeta` VALUES("282","32","_peach_header_bkgd_attachment","scroll");
INSERT INTO `wp_postmeta` VALUES("283","32","_peach_breadcrumb_align","left");
INSERT INTO `wp_postmeta` VALUES("284","32","_edit_lock","1426077901:2");
INSERT INTO `wp_postmeta` VALUES("285","33","_menu_item_type","post_type");
INSERT INTO `wp_postmeta` VALUES("286","33","_menu_item_menu_item_parent","0");
INSERT INTO `wp_postmeta` VALUES("287","33","_menu_item_object_id","32");
INSERT INTO `wp_postmeta` VALUES("288","33","_menu_item_object","page");
INSERT INTO `wp_postmeta` VALUES("289","33","_menu_item_target","");
INSERT INTO `wp_postmeta` VALUES("290","33","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `wp_postmeta` VALUES("291","33","_menu_item_xfn","");
INSERT INTO `wp_postmeta` VALUES("292","33","_menu_item_url","");
INSERT INTO `wp_postmeta` VALUES("296","36","_wp_attached_file","2014/03/Home-Image-Cropped.jpg");
INSERT INTO `wp_postmeta` VALUES("297","36","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1920;s:6:\"height\";i:750;s:4:\"file\";s:30:\"2014/03/Home-Image-Cropped.jpg\";s:5:\"sizes\";a:15:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:30:\"Home-Image-Cropped-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:30:\"Home-Image-Cropped-300x117.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:117;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:31:\"Home-Image-Cropped-1024x400.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:400;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"bones-thumb-600\";a:4:{s:4:\"file\";s:30:\"Home-Image-Cropped-600x150.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"bones-thumb-300\";a:4:{s:4:\"file\";s:30:\"Home-Image-Cropped-300x100.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:20:\"portfolio-one-column\";a:4:{s:4:\"file\";s:31:\"Home-Image-Cropped-1170x750.jpg\";s:5:\"width\";i:1170;s:6:\"height\";i:750;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:20:\"portfolio-two-column\";a:4:{s:4:\"file\";s:30:\"Home-Image-Cropped-570x416.jpg\";s:5:\"width\";i:570;s:6:\"height\";i:416;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:22:\"portfolio-three-column\";a:4:{s:4:\"file\";s:30:\"Home-Image-Cropped-370x270.jpg\";s:5:\"width\";i:370;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"portfolio-four-column\";a:4:{s:4:\"file\";s:30:\"Home-Image-Cropped-270x197.jpg\";s:5:\"width\";i:270;s:6:\"height\";i:197;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:17:\"portfolio-compact\";a:4:{s:4:\"file\";s:30:\"Home-Image-Cropped-770x513.jpg\";s:5:\"width\";i:770;s:6:\"height\";i:513;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:10:\"blog-large\";a:4:{s:4:\"file\";s:30:\"Home-Image-Cropped-770x270.jpg\";s:5:\"width\";i:770;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"blog-full-width\";a:4:{s:4:\"file\";s:31:\"Home-Image-Cropped-1170x270.jpg\";s:5:\"width\";i:1170;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"blog-medium\";a:4:{s:4:\"file\";s:30:\"Home-Image-Cropped-740x540.jpg\";s:5:\"width\";i:740;s:6:\"height\";i:540;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"blog-grid\";a:4:{s:4:\"file\";s:30:\"Home-Image-Cropped-370x270.jpg\";s:5:\"width\";i:370;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:30:\"Home-Image-Cropped-125x125.jpg\";s:5:\"width\";i:125;s:6:\"height\";i:125;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES("298","37","_wp_attached_file","2014/03/favicon.ico");
INSERT INTO `wp_postmeta` VALUES("302","12","_peach_hide_breadcrumb","on");
INSERT INTO `wp_postmeta` VALUES("303","13","_peach_hide_breadcrumb","on");
INSERT INTO `wp_postmeta` VALUES("304","32","_peach_hide_breadcrumb","on");
INSERT INTO `wp_postmeta` VALUES("306","5","_peach_hide_breadcrumb","on");
INSERT INTO `wp_postmeta` VALUES("309","11","_peach_hide_breadcrumb","on");
INSERT INTO `wp_postmeta` VALUES("310","19","_peach_hide_breadcrumb","on");
INSERT INTO `wp_postmeta` VALUES("312","38","_wp_attached_file","2014/03/Small-Logo.png");
INSERT INTO `wp_postmeta` VALUES("313","38","_wp_attachment_metadata","a:5:{s:5:\"width\";i:80;s:6:\"height\";i:80;s:4:\"file\";s:22:\"2014/03/Small-Logo.png\";s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES("314","38","_edit_lock","1395686627:2");
INSERT INTO `wp_postmeta` VALUES("325","39","_edit_last","2");
INSERT INTO `wp_postmeta` VALUES("326","39","_edit_lock","1409495600:2");
INSERT INTO `wp_postmeta` VALUES("327","39","_wp_page_template","page-sidebar-left-submenu.php");
INSERT INTO `wp_postmeta` VALUES("328","39","_wpb_vc_js_status","false");
INSERT INTO `wp_postmeta` VALUES("329","39","_wpb_vc_js_interface_version","2");
INSERT INTO `wp_postmeta` VALUES("330","39","_peach_bkgd_color","#");
INSERT INTO `wp_postmeta` VALUES("331","39","_peach_bkgd_repeat","no-repeat");
INSERT INTO `wp_postmeta` VALUES("332","39","_peach_bkgd_position","top left");
INSERT INTO `wp_postmeta` VALUES("333","39","_peach_bkgd_attachment","scroll");
INSERT INTO `wp_postmeta` VALUES("334","39","_peach_header_bkgd_color","#");
INSERT INTO `wp_postmeta` VALUES("335","39","_peach_header_bkgd_repeat","no-repeat");
INSERT INTO `wp_postmeta` VALUES("336","39","_peach_header_bkgd_position","top left");
INSERT INTO `wp_postmeta` VALUES("337","39","_peach_header_bkgd_attachment","scroll");
INSERT INTO `wp_postmeta` VALUES("338","39","_peach_breadcrumb_align","left");
INSERT INTO `wp_postmeta` VALUES("339","39","_peach_hide_breadcrumb","on");
INSERT INTO `wp_postmeta` VALUES("340","40","_edit_last","2");
INSERT INTO `wp_postmeta` VALUES("341","40","_edit_lock","1409037792:2");
INSERT INTO `wp_postmeta` VALUES("342","40","_wp_page_template","page-sidebar-left-submenu.php");
INSERT INTO `wp_postmeta` VALUES("343","40","_wpb_vc_js_status","false");
INSERT INTO `wp_postmeta` VALUES("344","40","_wpb_vc_js_interface_version","2");
INSERT INTO `wp_postmeta` VALUES("345","40","_peach_bkgd_color","#");
INSERT INTO `wp_postmeta` VALUES("346","40","_peach_bkgd_repeat","no-repeat");
INSERT INTO `wp_postmeta` VALUES("347","40","_peach_bkgd_position","top left");
INSERT INTO `wp_postmeta` VALUES("348","40","_peach_bkgd_attachment","scroll");
INSERT INTO `wp_postmeta` VALUES("349","40","_peach_header_bkgd_color","#");
INSERT INTO `wp_postmeta` VALUES("350","40","_peach_header_bkgd_repeat","no-repeat");
INSERT INTO `wp_postmeta` VALUES("351","40","_peach_header_bkgd_position","top left");
INSERT INTO `wp_postmeta` VALUES("352","40","_peach_header_bkgd_attachment","scroll");
INSERT INTO `wp_postmeta` VALUES("353","40","_peach_breadcrumb_align","left");
INSERT INTO `wp_postmeta` VALUES("354","40","_peach_hide_breadcrumb","on");
INSERT INTO `wp_postmeta` VALUES("355","41","_edit_last","2");
INSERT INTO `wp_postmeta` VALUES("356","41","_edit_lock","1430227088:2");
INSERT INTO `wp_postmeta` VALUES("357","41","_wp_page_template","page-sidebar-left-submenu.php");
INSERT INTO `wp_postmeta` VALUES("358","41","_wpb_vc_js_status","true");
INSERT INTO `wp_postmeta` VALUES("359","41","_wpb_vc_js_interface_version","2");
INSERT INTO `wp_postmeta` VALUES("360","41","_peach_bkgd_color","#");
INSERT INTO `wp_postmeta` VALUES("361","41","_peach_bkgd_repeat","no-repeat");
INSERT INTO `wp_postmeta` VALUES("362","41","_peach_bkgd_position","top left");
INSERT INTO `wp_postmeta` VALUES("363","41","_peach_bkgd_attachment","scroll");
INSERT INTO `wp_postmeta` VALUES("364","41","_peach_header_bkgd_color","#");
INSERT INTO `wp_postmeta` VALUES("365","41","_peach_header_bkgd_repeat","no-repeat");
INSERT INTO `wp_postmeta` VALUES("366","41","_peach_header_bkgd_position","top left");
INSERT INTO `wp_postmeta` VALUES("367","41","_peach_header_bkgd_attachment","scroll");
INSERT INTO `wp_postmeta` VALUES("368","41","_peach_breadcrumb_align","left");
INSERT INTO `wp_postmeta` VALUES("369","41","_peach_hide_breadcrumb","on");
INSERT INTO `wp_postmeta` VALUES("370","42","_edit_last","2");
INSERT INTO `wp_postmeta` VALUES("371","42","_edit_lock","1408967996:2");
INSERT INTO `wp_postmeta` VALUES("372","42","_wp_page_template","page-sidebar-left-submenu.php");
INSERT INTO `wp_postmeta` VALUES("373","42","_wpb_vc_js_status","true");
INSERT INTO `wp_postmeta` VALUES("374","42","_wpb_vc_js_interface_version","2");
INSERT INTO `wp_postmeta` VALUES("375","42","_peach_bkgd_color","#");
INSERT INTO `wp_postmeta` VALUES("376","42","_peach_bkgd_repeat","no-repeat");
INSERT INTO `wp_postmeta` VALUES("377","42","_peach_bkgd_position","top left");
INSERT INTO `wp_postmeta` VALUES("378","42","_peach_bkgd_attachment","scroll");
INSERT INTO `wp_postmeta` VALUES("379","42","_peach_header_bkgd_color","#");
INSERT INTO `wp_postmeta` VALUES("380","42","_peach_header_bkgd_repeat","no-repeat");
INSERT INTO `wp_postmeta` VALUES("381","42","_peach_header_bkgd_position","top left");
INSERT INTO `wp_postmeta` VALUES("382","42","_peach_header_bkgd_attachment","scroll");
INSERT INTO `wp_postmeta` VALUES("383","42","_peach_breadcrumb_align","left");
INSERT INTO `wp_postmeta` VALUES("384","42","_peach_hide_breadcrumb","on");
INSERT INTO `wp_postmeta` VALUES("385","43","_edit_last","2");
INSERT INTO `wp_postmeta` VALUES("386","43","_edit_lock","1408968160:2");
INSERT INTO `wp_postmeta` VALUES("387","43","_wp_page_template","page-sidebar-left-submenu.php");
INSERT INTO `wp_postmeta` VALUES("388","43","_wpb_vc_js_status","false");
INSERT INTO `wp_postmeta` VALUES("389","43","_wpb_vc_js_interface_version","2");
INSERT INTO `wp_postmeta` VALUES("390","43","_peach_bkgd_color","#");
INSERT INTO `wp_postmeta` VALUES("391","43","_peach_bkgd_repeat","no-repeat");
INSERT INTO `wp_postmeta` VALUES("392","43","_peach_bkgd_position","top left");
INSERT INTO `wp_postmeta` VALUES("393","43","_peach_bkgd_attachment","scroll");
INSERT INTO `wp_postmeta` VALUES("394","43","_peach_header_bkgd_color","#");
INSERT INTO `wp_postmeta` VALUES("395","43","_peach_header_bkgd_repeat","no-repeat");
INSERT INTO `wp_postmeta` VALUES("396","43","_peach_header_bkgd_position","top left");
INSERT INTO `wp_postmeta` VALUES("397","43","_peach_header_bkgd_attachment","scroll");
INSERT INTO `wp_postmeta` VALUES("398","43","_peach_breadcrumb_align","left");
INSERT INTO `wp_postmeta` VALUES("399","43","_peach_hide_breadcrumb","on");
INSERT INTO `wp_postmeta` VALUES("400","44","_edit_last","2");
INSERT INTO `wp_postmeta` VALUES("401","44","_edit_lock","1414684615:2");
INSERT INTO `wp_postmeta` VALUES("402","44","_wp_page_template","page-sidebar-left-submenu.php");
INSERT INTO `wp_postmeta` VALUES("403","44","_wpb_vc_js_status","false");
INSERT INTO `wp_postmeta` VALUES("404","44","_wpb_vc_js_interface_version","2");
INSERT INTO `wp_postmeta` VALUES("405","44","_peach_bkgd_color","#");
INSERT INTO `wp_postmeta` VALUES("406","44","_peach_bkgd_repeat","no-repeat");
INSERT INTO `wp_postmeta` VALUES("407","44","_peach_bkgd_position","top left");
INSERT INTO `wp_postmeta` VALUES("408","44","_peach_bkgd_attachment","scroll");
INSERT INTO `wp_postmeta` VALUES("409","44","_peach_header_bkgd_color","#");
INSERT INTO `wp_postmeta` VALUES("410","44","_peach_header_bkgd_repeat","no-repeat");
INSERT INTO `wp_postmeta` VALUES("411","44","_peach_header_bkgd_position","top left");
INSERT INTO `wp_postmeta` VALUES("412","44","_peach_header_bkgd_attachment","scroll");
INSERT INTO `wp_postmeta` VALUES("413","44","_peach_breadcrumb_align","left");
INSERT INTO `wp_postmeta` VALUES("414","44","_peach_hide_breadcrumb","on");
INSERT INTO `wp_postmeta` VALUES("415","46","_edit_last","2");
INSERT INTO `wp_postmeta` VALUES("416","46","_edit_lock","1422519666:2");
INSERT INTO `wp_postmeta` VALUES("417","46","_wp_page_template","page-sidebar-left-submenu.php");
INSERT INTO `wp_postmeta` VALUES("418","46","_wpb_vc_js_status","true");
INSERT INTO `wp_postmeta` VALUES("419","46","_wpb_vc_js_interface_version","2");
INSERT INTO `wp_postmeta` VALUES("420","46","_peach_bkgd_color","#");
INSERT INTO `wp_postmeta` VALUES("421","46","_peach_bkgd_repeat","no-repeat");
INSERT INTO `wp_postmeta` VALUES("422","46","_peach_bkgd_position","top left");
INSERT INTO `wp_postmeta` VALUES("423","46","_peach_bkgd_attachment","scroll");
INSERT INTO `wp_postmeta` VALUES("424","46","_peach_header_bkgd_color","#");
INSERT INTO `wp_postmeta` VALUES("425","46","_peach_header_bkgd_repeat","no-repeat");
INSERT INTO `wp_postmeta` VALUES("426","46","_peach_header_bkgd_position","top left");
INSERT INTO `wp_postmeta` VALUES("427","46","_peach_header_bkgd_attachment","scroll");
INSERT INTO `wp_postmeta` VALUES("428","46","_peach_breadcrumb_align","left");
INSERT INTO `wp_postmeta` VALUES("429","46","_peach_hide_breadcrumb","on");
INSERT INTO `wp_postmeta` VALUES("430","47","_edit_last","2");
INSERT INTO `wp_postmeta` VALUES("431","47","_edit_lock","1408886690:2");
INSERT INTO `wp_postmeta` VALUES("432","47","_wp_page_template","page-sidebar-left-submenu.php");
INSERT INTO `wp_postmeta` VALUES("433","47","_wpb_vc_js_status","true");
INSERT INTO `wp_postmeta` VALUES("434","47","_wpb_vc_js_interface_version","2");
INSERT INTO `wp_postmeta` VALUES("435","47","_peach_bkgd_color","#");
INSERT INTO `wp_postmeta` VALUES("436","47","_peach_bkgd_repeat","no-repeat");
INSERT INTO `wp_postmeta` VALUES("437","47","_peach_bkgd_position","top left");
INSERT INTO `wp_postmeta` VALUES("438","47","_peach_bkgd_attachment","scroll");
INSERT INTO `wp_postmeta` VALUES("439","47","_peach_header_bkgd_color","#");
INSERT INTO `wp_postmeta` VALUES("440","47","_peach_header_bkgd_repeat","no-repeat");
INSERT INTO `wp_postmeta` VALUES("441","47","_peach_header_bkgd_position","top left");
INSERT INTO `wp_postmeta` VALUES("442","47","_peach_header_bkgd_attachment","scroll");
INSERT INTO `wp_postmeta` VALUES("443","47","_peach_breadcrumb_align","left");
INSERT INTO `wp_postmeta` VALUES("444","47","_peach_hide_breadcrumb","on");
INSERT INTO `wp_postmeta` VALUES("445","48","_menu_item_type","post_type");
INSERT INTO `wp_postmeta` VALUES("446","48","_menu_item_menu_item_parent","30");
INSERT INTO `wp_postmeta` VALUES("447","48","_menu_item_object_id","39");
INSERT INTO `wp_postmeta` VALUES("448","48","_menu_item_object","page");
INSERT INTO `wp_postmeta` VALUES("449","48","_menu_item_target","");
INSERT INTO `wp_postmeta` VALUES("450","48","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `wp_postmeta` VALUES("451","48","_menu_item_xfn","");
INSERT INTO `wp_postmeta` VALUES("452","48","_menu_item_url","");
INSERT INTO `wp_postmeta` VALUES("454","49","_menu_item_type","post_type");
INSERT INTO `wp_postmeta` VALUES("455","49","_menu_item_menu_item_parent","66");
INSERT INTO `wp_postmeta` VALUES("456","49","_menu_item_object_id","47");
INSERT INTO `wp_postmeta` VALUES("457","49","_menu_item_object","page");
INSERT INTO `wp_postmeta` VALUES("458","49","_menu_item_target","");
INSERT INTO `wp_postmeta` VALUES("459","49","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `wp_postmeta` VALUES("460","49","_menu_item_xfn","");
INSERT INTO `wp_postmeta` VALUES("461","49","_menu_item_url","");
INSERT INTO `wp_postmeta` VALUES("463","50","_menu_item_type","post_type");
INSERT INTO `wp_postmeta` VALUES("464","50","_menu_item_menu_item_parent","66");
INSERT INTO `wp_postmeta` VALUES("465","50","_menu_item_object_id","46");
INSERT INTO `wp_postmeta` VALUES("466","50","_menu_item_object","page");
INSERT INTO `wp_postmeta` VALUES("467","50","_menu_item_target","");
INSERT INTO `wp_postmeta` VALUES("468","50","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `wp_postmeta` VALUES("469","50","_menu_item_xfn","");
INSERT INTO `wp_postmeta` VALUES("470","50","_menu_item_url","");
INSERT INTO `wp_postmeta` VALUES("472","51","_menu_item_type","post_type");
INSERT INTO `wp_postmeta` VALUES("473","51","_menu_item_menu_item_parent","59");
INSERT INTO `wp_postmeta` VALUES("474","51","_menu_item_object_id","44");
INSERT INTO `wp_postmeta` VALUES("475","51","_menu_item_object","page");
INSERT INTO `wp_postmeta` VALUES("476","51","_menu_item_target","");
INSERT INTO `wp_postmeta` VALUES("477","51","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `wp_postmeta` VALUES("478","51","_menu_item_xfn","");
INSERT INTO `wp_postmeta` VALUES("479","51","_menu_item_url","");
INSERT INTO `wp_postmeta` VALUES("481","52","_menu_item_type","post_type");
INSERT INTO `wp_postmeta` VALUES("482","52","_menu_item_menu_item_parent","59");
INSERT INTO `wp_postmeta` VALUES("483","52","_menu_item_object_id","43");
INSERT INTO `wp_postmeta` VALUES("484","52","_menu_item_object","page");
INSERT INTO `wp_postmeta` VALUES("485","52","_menu_item_target","");
INSERT INTO `wp_postmeta` VALUES("486","52","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `wp_postmeta` VALUES("487","52","_menu_item_xfn","");
INSERT INTO `wp_postmeta` VALUES("488","52","_menu_item_url","");
INSERT INTO `wp_postmeta` VALUES("490","53","_menu_item_type","post_type");
INSERT INTO `wp_postmeta` VALUES("491","53","_menu_item_menu_item_parent","58");
INSERT INTO `wp_postmeta` VALUES("492","53","_menu_item_object_id","42");
INSERT INTO `wp_postmeta` VALUES("493","53","_menu_item_object","page");
INSERT INTO `wp_postmeta` VALUES("494","53","_menu_item_target","");
INSERT INTO `wp_postmeta` VALUES("495","53","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `wp_postmeta` VALUES("496","53","_menu_item_xfn","");
INSERT INTO `wp_postmeta` VALUES("497","53","_menu_item_url","");
INSERT INTO `wp_postmeta` VALUES("499","54","_menu_item_type","post_type");
INSERT INTO `wp_postmeta` VALUES("500","54","_menu_item_menu_item_parent","58");
INSERT INTO `wp_postmeta` VALUES("501","54","_menu_item_object_id","41");
INSERT INTO `wp_postmeta` VALUES("502","54","_menu_item_object","page");
INSERT INTO `wp_postmeta` VALUES("503","54","_menu_item_target","");
INSERT INTO `wp_postmeta` VALUES("504","54","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `wp_postmeta` VALUES("505","54","_menu_item_xfn","");
INSERT INTO `wp_postmeta` VALUES("506","54","_menu_item_url","");
INSERT INTO `wp_postmeta` VALUES("508","55","_menu_item_type","post_type");
INSERT INTO `wp_postmeta` VALUES("509","55","_menu_item_menu_item_parent","30");
INSERT INTO `wp_postmeta` VALUES("510","55","_menu_item_object_id","40");
INSERT INTO `wp_postmeta` VALUES("511","55","_menu_item_object","page");
INSERT INTO `wp_postmeta` VALUES("512","55","_menu_item_target","");
INSERT INTO `wp_postmeta` VALUES("513","55","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `wp_postmeta` VALUES("514","55","_menu_item_xfn","");
INSERT INTO `wp_postmeta` VALUES("515","55","_menu_item_url","");
INSERT INTO `wp_postmeta` VALUES("517","56","_edit_last","2");
INSERT INTO `wp_postmeta` VALUES("518","56","_wp_page_template","page-sidebar-left-submenu.php");
INSERT INTO `wp_postmeta` VALUES("519","56","_wpb_vc_js_status","true");
INSERT INTO `wp_postmeta` VALUES("520","56","_wpb_vc_js_interface_version","2");
INSERT INTO `wp_postmeta` VALUES("521","56","_peach_bkgd_color","#");
INSERT INTO `wp_postmeta` VALUES("522","56","_peach_bkgd_repeat","no-repeat");
INSERT INTO `wp_postmeta` VALUES("523","56","_peach_bkgd_position","top left");
INSERT INTO `wp_postmeta` VALUES("524","56","_peach_bkgd_attachment","scroll");
INSERT INTO `wp_postmeta` VALUES("525","56","_peach_header_bkgd_color","#");
INSERT INTO `wp_postmeta` VALUES("526","56","_peach_header_bkgd_repeat","no-repeat");
INSERT INTO `wp_postmeta` VALUES("527","56","_peach_header_bkgd_position","top left");
INSERT INTO `wp_postmeta` VALUES("528","56","_peach_header_bkgd_attachment","scroll");
INSERT INTO `wp_postmeta` VALUES("529","56","_peach_breadcrumb_align","left");
INSERT INTO `wp_postmeta` VALUES("530","56","_peach_hide_breadcrumb","on");
INSERT INTO `wp_postmeta` VALUES("531","56","_edit_lock","1429697501:2");
INSERT INTO `wp_postmeta` VALUES("532","57","_menu_item_type","post_type");
INSERT INTO `wp_postmeta` VALUES("533","57","_menu_item_menu_item_parent","30");
INSERT INTO `wp_postmeta` VALUES("534","57","_menu_item_object_id","56");
INSERT INTO `wp_postmeta` VALUES("535","57","_menu_item_object","page");
INSERT INTO `wp_postmeta` VALUES("536","57","_menu_item_target","");
INSERT INTO `wp_postmeta` VALUES("537","57","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `wp_postmeta` VALUES("538","57","_menu_item_xfn","");
INSERT INTO `wp_postmeta` VALUES("539","57","_menu_item_url","");
INSERT INTO `wp_postmeta` VALUES("541","58","_menu_item_type","custom");
INSERT INTO `wp_postmeta` VALUES("542","58","_menu_item_menu_item_parent","0");
INSERT INTO `wp_postmeta` VALUES("543","58","_menu_item_object_id","58");
INSERT INTO `wp_postmeta` VALUES("544","58","_menu_item_object","custom");
INSERT INTO `wp_postmeta` VALUES("545","58","_menu_item_target","");
INSERT INTO `wp_postmeta` VALUES("546","58","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `wp_postmeta` VALUES("547","58","_menu_item_xfn","");
INSERT INTO `wp_postmeta` VALUES("548","58","_menu_item_url","http://ioptima.co.il/technology/class-procedure/");
INSERT INTO `wp_postmeta` VALUES("550","59","_menu_item_type","custom");
INSERT INTO `wp_postmeta` VALUES("551","59","_menu_item_menu_item_parent","0");
INSERT INTO `wp_postmeta` VALUES("552","59","_menu_item_object_id","59");
INSERT INTO `wp_postmeta` VALUES("553","59","_menu_item_object","custom");
INSERT INTO `wp_postmeta` VALUES("554","59","_menu_item_target","");
INSERT INTO `wp_postmeta` VALUES("555","59","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `wp_postmeta` VALUES("556","59","_menu_item_xfn","");
INSERT INTO `wp_postmeta` VALUES("557","59","_menu_item_url","http://ioptima.co.il/for-physicians/class-benefits/");
INSERT INTO `wp_postmeta` VALUES("559","60","_edit_last","2");
INSERT INTO `wp_postmeta` VALUES("560","60","_edit_lock","1420444673:2");
INSERT INTO `wp_postmeta` VALUES("561","60","_wp_page_template","page-sidebar-left-submenu.php");
INSERT INTO `wp_postmeta` VALUES("562","60","_wpb_vc_js_status","false");
INSERT INTO `wp_postmeta` VALUES("563","60","_wpb_vc_js_interface_version","2");
INSERT INTO `wp_postmeta` VALUES("564","60","_peach_bkgd_color","#");
INSERT INTO `wp_postmeta` VALUES("565","60","_peach_bkgd_repeat","no-repeat");
INSERT INTO `wp_postmeta` VALUES("566","60","_peach_bkgd_position","top left");
INSERT INTO `wp_postmeta` VALUES("567","60","_peach_bkgd_attachment","scroll");
INSERT INTO `wp_postmeta` VALUES("568","60","_peach_header_bkgd_color","#");
INSERT INTO `wp_postmeta` VALUES("569","60","_peach_header_bkgd_repeat","no-repeat");
INSERT INTO `wp_postmeta` VALUES("570","60","_peach_header_bkgd_position","top left");
INSERT INTO `wp_postmeta` VALUES("571","60","_peach_header_bkgd_attachment","scroll");
INSERT INTO `wp_postmeta` VALUES("572","60","_peach_breadcrumb_align","left");
INSERT INTO `wp_postmeta` VALUES("573","60","_peach_hide_breadcrumb","on");
INSERT INTO `wp_postmeta` VALUES("574","61","_menu_item_type","post_type");
INSERT INTO `wp_postmeta` VALUES("575","61","_menu_item_menu_item_parent","59");
INSERT INTO `wp_postmeta` VALUES("576","61","_menu_item_object_id","60");
INSERT INTO `wp_postmeta` VALUES("577","61","_menu_item_object","page");
INSERT INTO `wp_postmeta` VALUES("578","61","_menu_item_target","");
INSERT INTO `wp_postmeta` VALUES("579","61","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `wp_postmeta` VALUES("580","61","_menu_item_xfn","");
INSERT INTO `wp_postmeta` VALUES("581","61","_menu_item_url","");
INSERT INTO `wp_postmeta` VALUES("583","62","_edit_last","2");
INSERT INTO `wp_postmeta` VALUES("584","62","_edit_lock","1427631712:2");
INSERT INTO `wp_postmeta` VALUES("585","62","_wp_page_template","page-sidebar-left-submenu.php");
INSERT INTO `wp_postmeta` VALUES("586","62","_wpb_vc_js_status","true");
INSERT INTO `wp_postmeta` VALUES("587","62","_wpb_vc_js_interface_version","2");
INSERT INTO `wp_postmeta` VALUES("588","62","_peach_bkgd_color","#");
INSERT INTO `wp_postmeta` VALUES("589","62","_peach_bkgd_repeat","no-repeat");
INSERT INTO `wp_postmeta` VALUES("590","62","_peach_bkgd_position","top left");
INSERT INTO `wp_postmeta` VALUES("591","62","_peach_bkgd_attachment","scroll");
INSERT INTO `wp_postmeta` VALUES("592","62","_peach_header_bkgd_color","#");
INSERT INTO `wp_postmeta` VALUES("593","62","_peach_header_bkgd_repeat","no-repeat");
INSERT INTO `wp_postmeta` VALUES("594","62","_peach_header_bkgd_position","top left");
INSERT INTO `wp_postmeta` VALUES("595","62","_peach_header_bkgd_attachment","scroll");
INSERT INTO `wp_postmeta` VALUES("596","62","_peach_breadcrumb_align","left");
INSERT INTO `wp_postmeta` VALUES("597","62","_peach_hide_breadcrumb","on");
INSERT INTO `wp_postmeta` VALUES("598","63","_edit_last","2");
INSERT INTO `wp_postmeta` VALUES("599","63","_edit_lock","1414681915:2");
INSERT INTO `wp_postmeta` VALUES("600","63","_wp_page_template","page-sidebar-left-submenu.php");
INSERT INTO `wp_postmeta` VALUES("601","63","_wpb_vc_js_status","true");
INSERT INTO `wp_postmeta` VALUES("602","63","_wpb_vc_js_interface_version","2");
INSERT INTO `wp_postmeta` VALUES("603","63","_peach_bkgd_color","#");
INSERT INTO `wp_postmeta` VALUES("604","63","_peach_bkgd_repeat","no-repeat");
INSERT INTO `wp_postmeta` VALUES("605","63","_peach_bkgd_position","top left");
INSERT INTO `wp_postmeta` VALUES("606","63","_peach_bkgd_attachment","scroll");
INSERT INTO `wp_postmeta` VALUES("607","63","_peach_header_bkgd_color","#");
INSERT INTO `wp_postmeta` VALUES("608","63","_peach_header_bkgd_repeat","no-repeat");
INSERT INTO `wp_postmeta` VALUES("609","63","_peach_header_bkgd_position","top left");
INSERT INTO `wp_postmeta` VALUES("610","63","_peach_header_bkgd_attachment","scroll");
INSERT INTO `wp_postmeta` VALUES("611","63","_peach_breadcrumb_align","left");
INSERT INTO `wp_postmeta` VALUES("612","63","_peach_hide_breadcrumb","on");
INSERT INTO `wp_postmeta` VALUES("613","64","_menu_item_type","post_type");
INSERT INTO `wp_postmeta` VALUES("614","64","_menu_item_menu_item_parent","59");
INSERT INTO `wp_postmeta` VALUES("615","64","_menu_item_object_id","63");
INSERT INTO `wp_postmeta` VALUES("616","64","_menu_item_object","page");
INSERT INTO `wp_postmeta` VALUES("617","64","_menu_item_target","");
INSERT INTO `wp_postmeta` VALUES("618","64","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `wp_postmeta` VALUES("619","64","_menu_item_xfn","");
INSERT INTO `wp_postmeta` VALUES("620","64","_menu_item_url","");
INSERT INTO `wp_postmeta` VALUES("622","65","_menu_item_type","post_type");
INSERT INTO `wp_postmeta` VALUES("623","65","_menu_item_menu_item_parent","59");
INSERT INTO `wp_postmeta` VALUES("624","65","_menu_item_object_id","62");
INSERT INTO `wp_postmeta` VALUES("625","65","_menu_item_object","page");
INSERT INTO `wp_postmeta` VALUES("626","65","_menu_item_target","");
INSERT INTO `wp_postmeta` VALUES("627","65","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `wp_postmeta` VALUES("628","65","_menu_item_xfn","");
INSERT INTO `wp_postmeta` VALUES("629","65","_menu_item_url","");
INSERT INTO `wp_postmeta` VALUES("631","66","_menu_item_type","custom");
INSERT INTO `wp_postmeta` VALUES("632","66","_menu_item_menu_item_parent","0");
INSERT INTO `wp_postmeta` VALUES("633","66","_menu_item_object_id","66");
INSERT INTO `wp_postmeta` VALUES("634","66","_menu_item_object","custom");
INSERT INTO `wp_postmeta` VALUES("635","66","_menu_item_target","");
INSERT INTO `wp_postmeta` VALUES("636","66","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `wp_postmeta` VALUES("637","66","_menu_item_xfn","");
INSERT INTO `wp_postmeta` VALUES("638","66","_menu_item_url","http://ioptima.co.il/for-petients/about-glaucoma/");
INSERT INTO `wp_postmeta` VALUES("640","67","_form","<div class=\"row-fluid alternate-contact-form\">
<div class=\"span6\">

<p>[textarea your-message x8 placeholder \"Message\"]</p>

</div>
<div class=\"span6\">

<p>[text* your-name 1/40 placeholder \"Name (required)\"]</p>

<p>[email* your-email 1/40 placeholder \"Email (required)\"]</p>

<p>[captchac captcha] 
[captchar captcha]</p>
<div class=\"row-fluid form-large\">
	[submit \"Send message\"]
</div>
</div>
</div>

<script>
jQuery(\'[name=\"captcha\"]\').attr(\"placeholder\",\"Enter Code\")
</script>");
INSERT INTO `wp_postmeta` VALUES("641","67","_mail","a:7:{s:7:\"subject\";s:14:\"[your-subject]\";s:6:\"sender\";s:26:\"[your-name] <[your-email]>\";s:4:\"body\";s:172:\"From: [your-name] <[your-email]>
Subject: [your-subject]

Message Body:
[your-message]

--
This e-mail was sent from a contact form on IOPtima (http://ioptima.wpengine.com)\";s:9:\"recipient\";s:18:\"info@ioptima.co.il\";s:18:\"additional_headers\";s:0:\"\";s:11:\"attachments\";s:0:\"\";s:8:\"use_html\";b:0;}");
INSERT INTO `wp_postmeta` VALUES("642","67","_mail_2","a:8:{s:6:\"active\";b:0;s:7:\"subject\";s:14:\"[your-subject]\";s:6:\"sender\";s:26:\"[your-name] <[your-email]>\";s:4:\"body\";s:114:\"Message Body:
[your-message]

--
This e-mail was sent from a contact form on IOPtima (http://ioptima.wpengine.com)\";s:9:\"recipient\";s:12:\"[your-email]\";s:18:\"additional_headers\";s:0:\"\";s:11:\"attachments\";s:0:\"\";s:8:\"use_html\";b:0;}");
INSERT INTO `wp_postmeta` VALUES("643","67","_messages","a:21:{s:12:\"mail_sent_ok\";s:43:\"Your message was sent successfully. Thanks.\";s:12:\"mail_sent_ng\";s:93:\"Failed to send your message. Please try later or contact the administrator by another method.\";s:16:\"validation_error\";s:74:\"Validation errors occurred. Please confirm the fields and submit it again.\";s:4:\"spam\";s:93:\"Failed to send your message. Please try later or contact the administrator by another method.\";s:12:\"accept_terms\";s:35:\"Please accept the terms to proceed.\";s:16:\"invalid_required\";s:31:\"Please fill the required field.\";s:17:\"captcha_not_match\";s:31:\"Your entered code is incorrect.\";s:14:\"invalid_number\";s:28:\"Number format seems invalid.\";s:16:\"number_too_small\";s:25:\"This number is too small.\";s:16:\"number_too_large\";s:25:\"This number is too large.\";s:13:\"invalid_email\";s:28:\"Email address seems invalid.\";s:11:\"invalid_url\";s:18:\"URL seems invalid.\";s:11:\"invalid_tel\";s:31:\"Telephone number seems invalid.\";s:23:\"quiz_answer_not_correct\";s:27:\"Your answer is not correct.\";s:12:\"invalid_date\";s:26:\"Date format seems invalid.\";s:14:\"date_too_early\";s:23:\"This date is too early.\";s:13:\"date_too_late\";s:22:\"This date is too late.\";s:13:\"upload_failed\";s:22:\"Failed to upload file.\";s:24:\"upload_file_type_invalid\";s:30:\"This file type is not allowed.\";s:21:\"upload_file_too_large\";s:23:\"This file is too large.\";s:23:\"upload_failed_php_error\";s:38:\"Failed to upload file. Error occurred.\";}");
INSERT INTO `wp_postmeta` VALUES("644","67","_additional_settings","");
INSERT INTO `wp_postmeta` VALUES("645","67","_locale","en_US");
INSERT INTO `wp_postmeta` VALUES("646","70","_wp_attached_file","2014/04/favicon.png");
INSERT INTO `wp_postmeta` VALUES("647","70","_wp_attachment_metadata","a:5:{s:5:\"width\";i:16;s:6:\"height\";i:16;s:4:\"file\";s:19:\"2014/04/favicon.png\";s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES("651","74","_wp_attached_file","2014/04/Home-Image-clean.jpg");
INSERT INTO `wp_postmeta` VALUES("652","74","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1917;s:6:\"height\";i:567;s:4:\"file\";s:28:\"2014/04/Home-Image-clean.jpg\";s:5:\"sizes\";a:15:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:28:\"Home-Image-clean-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:27:\"Home-Image-clean-300x88.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:88;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:29:\"Home-Image-clean-1024x302.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:302;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"bones-thumb-600\";a:4:{s:4:\"file\";s:28:\"Home-Image-clean-600x150.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"bones-thumb-300\";a:4:{s:4:\"file\";s:28:\"Home-Image-clean-300x100.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:20:\"portfolio-one-column\";a:4:{s:4:\"file\";s:29:\"Home-Image-clean-1170x567.jpg\";s:5:\"width\";i:1170;s:6:\"height\";i:567;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:20:\"portfolio-two-column\";a:4:{s:4:\"file\";s:28:\"Home-Image-clean-570x416.jpg\";s:5:\"width\";i:570;s:6:\"height\";i:416;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:22:\"portfolio-three-column\";a:4:{s:4:\"file\";s:28:\"Home-Image-clean-370x270.jpg\";s:5:\"width\";i:370;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"portfolio-four-column\";a:4:{s:4:\"file\";s:28:\"Home-Image-clean-270x197.jpg\";s:5:\"width\";i:270;s:6:\"height\";i:197;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:17:\"portfolio-compact\";a:4:{s:4:\"file\";s:28:\"Home-Image-clean-770x513.jpg\";s:5:\"width\";i:770;s:6:\"height\";i:513;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:10:\"blog-large\";a:4:{s:4:\"file\";s:28:\"Home-Image-clean-770x270.jpg\";s:5:\"width\";i:770;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"blog-full-width\";a:4:{s:4:\"file\";s:29:\"Home-Image-clean-1170x270.jpg\";s:5:\"width\";i:1170;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"blog-medium\";a:4:{s:4:\"file\";s:28:\"Home-Image-clean-740x540.jpg\";s:5:\"width\";i:740;s:6:\"height\";i:540;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"blog-grid\";a:4:{s:4:\"file\";s:28:\"Home-Image-clean-370x270.jpg\";s:5:\"width\";i:370;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:28:\"Home-Image-clean-125x125.jpg\";s:5:\"width\";i:125;s:6:\"height\";i:125;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES("653","74","_wp_attachment_image_alt","");
INSERT INTO `wp_postmeta` VALUES("654","75","_wp_attached_file","2014/04/New-Slide.jpg");
INSERT INTO `wp_postmeta` VALUES("655","75","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1900;s:6:\"height\";i:512;s:4:\"file\";s:21:\"2014/04/New-Slide.jpg\";s:5:\"sizes\";a:15:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:21:\"New-Slide-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:20:\"New-Slide-300x80.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:80;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:22:\"New-Slide-1024x275.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:275;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"bones-thumb-600\";a:4:{s:4:\"file\";s:21:\"New-Slide-600x150.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"bones-thumb-300\";a:4:{s:4:\"file\";s:21:\"New-Slide-300x100.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:20:\"portfolio-one-column\";a:4:{s:4:\"file\";s:22:\"New-Slide-1170x512.jpg\";s:5:\"width\";i:1170;s:6:\"height\";i:512;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:20:\"portfolio-two-column\";a:4:{s:4:\"file\";s:21:\"New-Slide-570x416.jpg\";s:5:\"width\";i:570;s:6:\"height\";i:416;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:22:\"portfolio-three-column\";a:4:{s:4:\"file\";s:21:\"New-Slide-370x270.jpg\";s:5:\"width\";i:370;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"portfolio-four-column\";a:4:{s:4:\"file\";s:21:\"New-Slide-270x197.jpg\";s:5:\"width\";i:270;s:6:\"height\";i:197;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:17:\"portfolio-compact\";a:4:{s:4:\"file\";s:21:\"New-Slide-770x512.jpg\";s:5:\"width\";i:770;s:6:\"height\";i:512;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:10:\"blog-large\";a:4:{s:4:\"file\";s:21:\"New-Slide-770x270.jpg\";s:5:\"width\";i:770;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"blog-full-width\";a:4:{s:4:\"file\";s:22:\"New-Slide-1170x270.jpg\";s:5:\"width\";i:1170;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"blog-medium\";a:4:{s:4:\"file\";s:21:\"New-Slide-740x512.jpg\";s:5:\"width\";i:740;s:6:\"height\";i:512;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"blog-grid\";a:4:{s:4:\"file\";s:21:\"New-Slide-370x270.jpg\";s:5:\"width\";i:370;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:21:\"New-Slide-125x125.jpg\";s:5:\"width\";i:125;s:6:\"height\";i:125;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:7:\"moonrun\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES("660","81","_wp_attached_file","2014/03/Scanner-2.jpg");
INSERT INTO `wp_postmeta` VALUES("661","81","_wp_attachment_metadata","a:5:{s:5:\"width\";i:300;s:6:\"height\";i:225;s:4:\"file\";s:21:\"2014/03/Scanner-2.jpg\";s:5:\"sizes\";a:5:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:21:\"Scanner-2-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"bones-thumb-600\";a:4:{s:4:\"file\";s:21:\"Scanner-2-300x150.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"bones-thumb-300\";a:4:{s:4:\"file\";s:21:\"Scanner-2-300x100.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"portfolio-four-column\";a:4:{s:4:\"file\";s:21:\"Scanner-2-270x197.jpg\";s:5:\"width\";i:270;s:6:\"height\";i:197;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:21:\"Scanner-2-125x125.jpg\";s:5:\"width\";i:125;s:6:\"height\";i:125;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES("662","82","_wp_attached_file","2014/03/Scanner-1.jpg");
INSERT INTO `wp_postmeta` VALUES("663","82","_wp_attachment_metadata","a:5:{s:5:\"width\";i:300;s:6:\"height\";i:225;s:4:\"file\";s:21:\"2014/03/Scanner-1.jpg\";s:5:\"sizes\";a:5:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:21:\"Scanner-1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"bones-thumb-600\";a:4:{s:4:\"file\";s:21:\"Scanner-1-300x150.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"bones-thumb-300\";a:4:{s:4:\"file\";s:21:\"Scanner-1-300x100.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"portfolio-four-column\";a:4:{s:4:\"file\";s:21:\"Scanner-1-270x197.jpg\";s:5:\"width\";i:270;s:6:\"height\";i:197;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:21:\"Scanner-1-125x125.jpg\";s:5:\"width\";i:125;s:6:\"height\";i:125;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES("664","84","_wp_attached_file","2014/03/CLASS-principle-of-Operation.jpg");
INSERT INTO `wp_postmeta` VALUES("665","84","_wp_attachment_metadata","a:5:{s:5:\"width\";i:471;s:6:\"height\";i:134;s:4:\"file\";s:40:\"2014/03/CLASS-principle-of-Operation.jpg\";s:5:\"sizes\";a:7:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:40:\"CLASS-principle-of-Operation-150x134.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:134;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:39:\"CLASS-principle-of-Operation-300x85.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:85;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"bones-thumb-300\";a:4:{s:4:\"file\";s:40:\"CLASS-principle-of-Operation-300x100.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:22:\"portfolio-three-column\";a:4:{s:4:\"file\";s:40:\"CLASS-principle-of-Operation-370x134.jpg\";s:5:\"width\";i:370;s:6:\"height\";i:134;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"portfolio-four-column\";a:4:{s:4:\"file\";s:40:\"CLASS-principle-of-Operation-270x134.jpg\";s:5:\"width\";i:270;s:6:\"height\";i:134;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"blog-grid\";a:4:{s:4:\"file\";s:40:\"CLASS-principle-of-Operation-370x134.jpg\";s:5:\"width\";i:370;s:6:\"height\";i:134;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:40:\"CLASS-principle-of-Operation-125x125.jpg\";s:5:\"width\";i:125;s:6:\"height\";i:125;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES("666","85","_wp_attached_file","2014/03/procedure-6.jpg");
INSERT INTO `wp_postmeta` VALUES("667","85","_wp_attachment_metadata","a:5:{s:5:\"width\";i:151;s:6:\"height\";i:102;s:4:\"file\";s:23:\"2014/03/procedure-6.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:23:\"procedure-6-150x102.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:102;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"bones-thumb-300\";a:4:{s:4:\"file\";s:23:\"procedure-6-151x100.jpg\";s:5:\"width\";i:151;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:23:\"procedure-6-125x102.jpg\";s:5:\"width\";i:125;s:6:\"height\";i:102;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES("668","86","_wp_attached_file","2014/03/procedure-1.jpg");
INSERT INTO `wp_postmeta` VALUES("669","86","_wp_attachment_metadata","a:5:{s:5:\"width\";i:151;s:6:\"height\";i:102;s:4:\"file\";s:23:\"2014/03/procedure-1.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:23:\"procedure-1-150x102.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:102;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"bones-thumb-300\";a:4:{s:4:\"file\";s:23:\"procedure-1-151x100.jpg\";s:5:\"width\";i:151;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:23:\"procedure-1-125x102.jpg\";s:5:\"width\";i:125;s:6:\"height\";i:102;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES("670","87","_wp_attached_file","2014/03/procedure-2.jpg");
INSERT INTO `wp_postmeta` VALUES("671","87","_wp_attachment_metadata","a:5:{s:5:\"width\";i:151;s:6:\"height\";i:102;s:4:\"file\";s:23:\"2014/03/procedure-2.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:23:\"procedure-2-150x102.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:102;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"bones-thumb-300\";a:4:{s:4:\"file\";s:23:\"procedure-2-151x100.jpg\";s:5:\"width\";i:151;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:23:\"procedure-2-125x102.jpg\";s:5:\"width\";i:125;s:6:\"height\";i:102;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES("672","88","_wp_attached_file","2014/03/procedure-3.jpg");
INSERT INTO `wp_postmeta` VALUES("673","88","_wp_attachment_metadata","a:5:{s:5:\"width\";i:151;s:6:\"height\";i:102;s:4:\"file\";s:23:\"2014/03/procedure-3.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:23:\"procedure-3-150x102.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:102;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"bones-thumb-300\";a:4:{s:4:\"file\";s:23:\"procedure-3-151x100.jpg\";s:5:\"width\";i:151;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:23:\"procedure-3-125x102.jpg\";s:5:\"width\";i:125;s:6:\"height\";i:102;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES("674","89","_wp_attached_file","2014/03/procedure-4.jpg");
INSERT INTO `wp_postmeta` VALUES("675","89","_wp_attachment_metadata","a:5:{s:5:\"width\";i:151;s:6:\"height\";i:102;s:4:\"file\";s:23:\"2014/03/procedure-4.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:23:\"procedure-4-150x102.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:102;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"bones-thumb-300\";a:4:{s:4:\"file\";s:23:\"procedure-4-151x100.jpg\";s:5:\"width\";i:151;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:23:\"procedure-4-125x102.jpg\";s:5:\"width\";i:125;s:6:\"height\";i:102;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES("676","90","_wp_attached_file","2014/03/procedure-5.jpg");
INSERT INTO `wp_postmeta` VALUES("677","90","_wp_attachment_metadata","a:5:{s:5:\"width\";i:151;s:6:\"height\";i:102;s:4:\"file\";s:23:\"2014/03/procedure-5.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:23:\"procedure-5-150x102.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:102;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"bones-thumb-300\";a:4:{s:4:\"file\";s:23:\"procedure-5-151x100.jpg\";s:5:\"width\";i:151;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:23:\"procedure-5-125x102.jpg\";s:5:\"width\";i:125;s:6:\"height\";i:102;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES("678","91","_edit_last","2");
INSERT INTO `wp_postmeta` VALUES("679","91","_wp_page_template","default");
INSERT INTO `wp_postmeta` VALUES("680","91","_wpb_vc_js_status","false");
INSERT INTO `wp_postmeta` VALUES("681","91","_wpb_vc_js_interface_version","2");
INSERT INTO `wp_postmeta` VALUES("682","91","_peach_bkgd_color","#");
INSERT INTO `wp_postmeta` VALUES("683","91","_peach_bkgd_repeat","no-repeat");
INSERT INTO `wp_postmeta` VALUES("684","91","_peach_bkgd_position","top left");
INSERT INTO `wp_postmeta` VALUES("685","91","_peach_bkgd_attachment","scroll");
INSERT INTO `wp_postmeta` VALUES("686","91","_peach_header_bkgd_color","#");
INSERT INTO `wp_postmeta` VALUES("687","91","_peach_header_bkgd_repeat","no-repeat");
INSERT INTO `wp_postmeta` VALUES("688","91","_peach_header_bkgd_position","top left");
INSERT INTO `wp_postmeta` VALUES("689","91","_peach_header_bkgd_attachment","scroll");
INSERT INTO `wp_postmeta` VALUES("690","91","_peach_breadcrumb_align","left");
INSERT INTO `wp_postmeta` VALUES("691","91","_edit_lock","1409495627:2");
INSERT INTO `wp_postmeta` VALUES("692","92","_edit_last","2");
INSERT INTO `wp_postmeta` VALUES("693","92","_wp_page_template","default");
INSERT INTO `wp_postmeta` VALUES("694","92","_wpb_vc_js_status","false");
INSERT INTO `wp_postmeta` VALUES("695","92","_wpb_vc_js_interface_version","2");
INSERT INTO `wp_postmeta` VALUES("696","92","_peach_bkgd_color","#");
INSERT INTO `wp_postmeta` VALUES("697","92","_peach_bkgd_repeat","no-repeat");
INSERT INTO `wp_postmeta` VALUES("698","92","_peach_bkgd_position","top left");
INSERT INTO `wp_postmeta` VALUES("699","92","_peach_bkgd_attachment","scroll");
INSERT INTO `wp_postmeta` VALUES("700","92","_peach_header_bkgd_color","#");
INSERT INTO `wp_postmeta` VALUES("701","92","_peach_header_bkgd_repeat","no-repeat");
INSERT INTO `wp_postmeta` VALUES("702","92","_peach_header_bkgd_position","top left");
INSERT INTO `wp_postmeta` VALUES("703","92","_peach_header_bkgd_attachment","scroll");
INSERT INTO `wp_postmeta` VALUES("704","92","_peach_breadcrumb_align","left");
INSERT INTO `wp_postmeta` VALUES("705","92","_edit_lock","1409482555:2");
INSERT INTO `wp_postmeta` VALUES("706","93","_edit_last","2");
INSERT INTO `wp_postmeta` VALUES("707","93","_edit_lock","1409483479:2");
INSERT INTO `wp_postmeta` VALUES("708","93","_wp_page_template","default");
INSERT INTO `wp_postmeta` VALUES("709","93","_wpb_vc_js_status","false");
INSERT INTO `wp_postmeta` VALUES("710","93","_wpb_vc_js_interface_version","2");
INSERT INTO `wp_postmeta` VALUES("711","93","_peach_bkgd_color","#");
INSERT INTO `wp_postmeta` VALUES("712","93","_peach_bkgd_repeat","no-repeat");
INSERT INTO `wp_postmeta` VALUES("713","93","_peach_bkgd_position","top left");
INSERT INTO `wp_postmeta` VALUES("714","93","_peach_bkgd_attachment","scroll");
INSERT INTO `wp_postmeta` VALUES("715","93","_peach_header_bkgd_color","#");
INSERT INTO `wp_postmeta` VALUES("716","93","_peach_header_bkgd_repeat","no-repeat");
INSERT INTO `wp_postmeta` VALUES("717","93","_peach_header_bkgd_position","top left");
INSERT INTO `wp_postmeta` VALUES("718","93","_peach_header_bkgd_attachment","scroll");
INSERT INTO `wp_postmeta` VALUES("719","93","_peach_breadcrumb_align","left");
INSERT INTO `wp_postmeta` VALUES("720","94","_edit_last","2");
INSERT INTO `wp_postmeta` VALUES("721","94","_edit_lock","1426078571:2");
INSERT INTO `wp_postmeta` VALUES("722","94","_wp_page_template","default");
INSERT INTO `wp_postmeta` VALUES("723","94","_wpb_vc_js_status","false");
INSERT INTO `wp_postmeta` VALUES("724","94","_wpb_vc_js_interface_version","2");
INSERT INTO `wp_postmeta` VALUES("725","94","_peach_bkgd_color","#");
INSERT INTO `wp_postmeta` VALUES("726","94","_peach_bkgd_repeat","no-repeat");
INSERT INTO `wp_postmeta` VALUES("727","94","_peach_bkgd_position","top left");
INSERT INTO `wp_postmeta` VALUES("728","94","_peach_bkgd_attachment","scroll");
INSERT INTO `wp_postmeta` VALUES("729","94","_peach_header_bkgd_color","#");
INSERT INTO `wp_postmeta` VALUES("730","94","_peach_header_bkgd_repeat","no-repeat");
INSERT INTO `wp_postmeta` VALUES("731","94","_peach_header_bkgd_position","top left");
INSERT INTO `wp_postmeta` VALUES("732","94","_peach_header_bkgd_attachment","scroll");
INSERT INTO `wp_postmeta` VALUES("733","94","_peach_breadcrumb_align","left");
INSERT INTO `wp_postmeta` VALUES("735","96","_edit_lock","1415202019:2");
INSERT INTO `wp_postmeta` VALUES("736","96","_edit_last","2");
INSERT INTO `wp_postmeta` VALUES("737","96","_wp_page_template","page-sidebar-left-submenu.php");
INSERT INTO `wp_postmeta` VALUES("738","96","_wpb_vc_js_status","true");
INSERT INTO `wp_postmeta` VALUES("739","96","_wpb_vc_js_interface_version","2");
INSERT INTO `wp_postmeta` VALUES("740","96","_peach_bkgd_color","#");
INSERT INTO `wp_postmeta` VALUES("741","96","_peach_bkgd_repeat","no-repeat");
INSERT INTO `wp_postmeta` VALUES("742","96","_peach_bkgd_position","top left");
INSERT INTO `wp_postmeta` VALUES("743","96","_peach_bkgd_attachment","scroll");
INSERT INTO `wp_postmeta` VALUES("744","96","_peach_header_bkgd_color","#");
INSERT INTO `wp_postmeta` VALUES("745","96","_peach_header_bkgd_repeat","no-repeat");
INSERT INTO `wp_postmeta` VALUES("746","96","_peach_header_bkgd_position","top left");
INSERT INTO `wp_postmeta` VALUES("747","96","_peach_header_bkgd_attachment","scroll");
INSERT INTO `wp_postmeta` VALUES("748","96","_peach_breadcrumb_align","left");
INSERT INTO `wp_postmeta` VALUES("751","98","_wp_attached_file","2014/03/Quality.jpg");
INSERT INTO `wp_postmeta` VALUES("752","98","_wp_attachment_metadata","a:5:{s:5:\"width\";i:770;s:6:\"height\";i:149;s:4:\"file\";s:19:\"2014/03/Quality.jpg\";s:5:\"sizes\";a:10:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:19:\"Quality-150x149.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:149;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:18:\"Quality-300x58.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:58;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"bones-thumb-600\";a:4:{s:4:\"file\";s:19:\"Quality-600x149.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:149;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"bones-thumb-300\";a:4:{s:4:\"file\";s:19:\"Quality-300x100.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:20:\"portfolio-two-column\";a:4:{s:4:\"file\";s:19:\"Quality-570x149.jpg\";s:5:\"width\";i:570;s:6:\"height\";i:149;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:22:\"portfolio-three-column\";a:4:{s:4:\"file\";s:19:\"Quality-370x149.jpg\";s:5:\"width\";i:370;s:6:\"height\";i:149;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"portfolio-four-column\";a:4:{s:4:\"file\";s:19:\"Quality-270x149.jpg\";s:5:\"width\";i:270;s:6:\"height\";i:149;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"blog-medium\";a:4:{s:4:\"file\";s:19:\"Quality-740x149.jpg\";s:5:\"width\";i:740;s:6:\"height\";i:149;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"blog-grid\";a:4:{s:4:\"file\";s:19:\"Quality-370x149.jpg\";s:5:\"width\";i:370;s:6:\"height\";i:149;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:19:\"Quality-125x125.jpg\";s:5:\"width\";i:125;s:6:\"height\";i:125;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES("763","100","_menu_item_type","post_type");
INSERT INTO `wp_postmeta` VALUES("764","100","_menu_item_menu_item_parent","58");
INSERT INTO `wp_postmeta` VALUES("765","100","_menu_item_object_id","96");
INSERT INTO `wp_postmeta` VALUES("766","100","_menu_item_object","page");
INSERT INTO `wp_postmeta` VALUES("767","100","_menu_item_target","");
INSERT INTO `wp_postmeta` VALUES("768","100","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `wp_postmeta` VALUES("769","100","_menu_item_xfn","");
INSERT INTO `wp_postmeta` VALUES("770","100","_menu_item_url","");
INSERT INTO `wp_postmeta` VALUES("772","96","_peach_hide_breadcrumb","on");
INSERT INTO `wp_postmeta` VALUES("777","104","_wp_attached_file","2014/03/venn-diagram.png");
INSERT INTO `wp_postmeta` VALUES("778","104","_wp_attachment_metadata","a:5:{s:5:\"width\";i:260;s:6:\"height\";i:260;s:4:\"file\";s:24:\"2014/03/venn-diagram.png\";s:5:\"sizes\";a:5:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:24:\"venn-diagram-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:15:\"bones-thumb-600\";a:4:{s:4:\"file\";s:24:\"venn-diagram-260x150.png\";s:5:\"width\";i:260;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:15:\"bones-thumb-300\";a:4:{s:4:\"file\";s:24:\"venn-diagram-260x100.png\";s:5:\"width\";i:260;s:6:\"height\";i:100;s:9:\"mime-type\";s:9:\"image/png\";}s:21:\"portfolio-four-column\";a:4:{s:4:\"file\";s:24:\"venn-diagram-260x197.png\";s:5:\"width\";i:260;s:6:\"height\";i:197;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:24:\"venn-diagram-125x125.png\";s:5:\"width\";i:125;s:6:\"height\";i:125;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES("779","105","_wp_attached_file","2014/03/The-Surgical-Procedure.jpg");
INSERT INTO `wp_postmeta` VALUES("780","105","_wp_attachment_metadata","a:5:{s:5:\"width\";i:632;s:6:\"height\";i:500;s:4:\"file\";s:34:\"2014/03/The-Surgical-Procedure.jpg\";s:5:\"sizes\";a:11:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:34:\"The-Surgical-Procedure-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:34:\"The-Surgical-Procedure-300x237.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:237;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"bones-thumb-600\";a:4:{s:4:\"file\";s:34:\"The-Surgical-Procedure-600x150.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"bones-thumb-300\";a:4:{s:4:\"file\";s:34:\"The-Surgical-Procedure-300x100.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:20:\"portfolio-two-column\";a:4:{s:4:\"file\";s:34:\"The-Surgical-Procedure-570x416.jpg\";s:5:\"width\";i:570;s:6:\"height\";i:416;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:22:\"portfolio-three-column\";a:4:{s:4:\"file\";s:34:\"The-Surgical-Procedure-370x270.jpg\";s:5:\"width\";i:370;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"portfolio-four-column\";a:4:{s:4:\"file\";s:34:\"The-Surgical-Procedure-270x197.jpg\";s:5:\"width\";i:270;s:6:\"height\";i:197;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:10:\"blog-large\";a:4:{s:4:\"file\";s:34:\"The-Surgical-Procedure-632x270.jpg\";s:5:\"width\";i:632;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"blog-full-width\";a:4:{s:4:\"file\";s:34:\"The-Surgical-Procedure-632x270.jpg\";s:5:\"width\";i:632;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"blog-grid\";a:4:{s:4:\"file\";s:34:\"The-Surgical-Procedure-370x270.jpg\";s:5:\"width\";i:370;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:34:\"The-Surgical-Procedure-125x125.jpg\";s:5:\"width\";i:125;s:6:\"height\";i:125;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES("781","107","_wp_attached_file","2014/03/CLASS-a-novel-filtration-treatment-for-glaucoma-patients-2.jpg");
INSERT INTO `wp_postmeta` VALUES("782","107","_wp_attachment_metadata","a:5:{s:5:\"width\";i:304;s:6:\"height\";i:150;s:4:\"file\";s:70:\"2014/03/CLASS-a-novel-filtration-treatment-for-glaucoma-patients-2.jpg\";s:5:\"sizes\";a:5:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:70:\"CLASS-a-novel-filtration-treatment-for-glaucoma-patients-2-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:70:\"CLASS-a-novel-filtration-treatment-for-glaucoma-patients-2-300x148.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:148;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"bones-thumb-300\";a:4:{s:4:\"file\";s:70:\"CLASS-a-novel-filtration-treatment-for-glaucoma-patients-2-300x100.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"portfolio-four-column\";a:4:{s:4:\"file\";s:70:\"CLASS-a-novel-filtration-treatment-for-glaucoma-patients-2-270x150.jpg\";s:5:\"width\";i:270;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:70:\"CLASS-a-novel-filtration-treatment-for-glaucoma-patients-2-125x125.jpg\";s:5:\"width\";i:125;s:6:\"height\";i:125;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES("783","108","_wp_attached_file","2014/03/CLASS-CO2-Laser-Assisted-Sclerectomy-Surgery.jpg");
INSERT INTO `wp_postmeta` VALUES("784","108","_wp_attachment_metadata","a:5:{s:5:\"width\";i:249;s:6:\"height\";i:168;s:4:\"file\";s:56:\"2014/03/CLASS-CO2-Laser-Assisted-Sclerectomy-Surgery.jpg\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:56:\"CLASS-CO2-Laser-Assisted-Sclerectomy-Surgery-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"bones-thumb-600\";a:4:{s:4:\"file\";s:56:\"CLASS-CO2-Laser-Assisted-Sclerectomy-Surgery-249x150.jpg\";s:5:\"width\";i:249;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"bones-thumb-300\";a:4:{s:4:\"file\";s:56:\"CLASS-CO2-Laser-Assisted-Sclerectomy-Surgery-249x100.jpg\";s:5:\"width\";i:249;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:56:\"CLASS-CO2-Laser-Assisted-Sclerectomy-Surgery-125x125.jpg\";s:5:\"width\";i:125;s:6:\"height\";i:125;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES("785","109","_wp_attached_file","2014/03/CLASS-­y-Laser-Treats-Glaucoma.jpg");
INSERT INTO `wp_postmeta` VALUES("786","109","_wp_attachment_metadata","a:5:{s:5:\"width\";i:295;s:6:\"height\";i:312;s:4:\"file\";s:43:\"2014/03/CLASS-­y-Laser-Treats-Glaucoma.jpg\";s:5:\"sizes\";a:10:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:43:\"CLASS-­y-Laser-Treats-Glaucoma-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:43:\"CLASS-­y-Laser-Treats-Glaucoma-283x300.jpg\";s:5:\"width\";i:283;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"bones-thumb-600\";a:4:{s:4:\"file\";s:43:\"CLASS-­y-Laser-Treats-Glaucoma-295x150.jpg\";s:5:\"width\";i:295;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"bones-thumb-300\";a:4:{s:4:\"file\";s:43:\"CLASS-­y-Laser-Treats-Glaucoma-295x100.jpg\";s:5:\"width\";i:295;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:22:\"portfolio-three-column\";a:4:{s:4:\"file\";s:43:\"CLASS-­y-Laser-Treats-Glaucoma-295x270.jpg\";s:5:\"width\";i:295;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"portfolio-four-column\";a:4:{s:4:\"file\";s:43:\"CLASS-­y-Laser-Treats-Glaucoma-270x197.jpg\";s:5:\"width\";i:270;s:6:\"height\";i:197;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:10:\"blog-large\";a:4:{s:4:\"file\";s:43:\"CLASS-­y-Laser-Treats-Glaucoma-295x270.jpg\";s:5:\"width\";i:295;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"blog-full-width\";a:4:{s:4:\"file\";s:43:\"CLASS-­y-Laser-Treats-Glaucoma-295x270.jpg\";s:5:\"width\";i:295;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"blog-grid\";a:4:{s:4:\"file\";s:43:\"CLASS-­y-Laser-Treats-Glaucoma-295x270.jpg\";s:5:\"width\";i:295;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:43:\"CLASS-­y-Laser-Treats-Glaucoma-125x125.jpg\";s:5:\"width\";i:125;s:6:\"height\";i:125;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES("787","110","_wp_attached_file","2014/03/CO2-Laser-assisted-Deep-Sclerectomy-in.jpg");
INSERT INTO `wp_postmeta` VALUES("788","110","_wp_attachment_metadata","a:5:{s:5:\"width\";i:188;s:6:\"height\";i:252;s:4:\"file\";s:50:\"2014/03/CO2-Laser-assisted-Deep-Sclerectomy-in.jpg\";s:5:\"sizes\";a:5:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:50:\"CO2-Laser-assisted-Deep-Sclerectomy-in-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"bones-thumb-600\";a:4:{s:4:\"file\";s:50:\"CO2-Laser-assisted-Deep-Sclerectomy-in-188x150.jpg\";s:5:\"width\";i:188;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"bones-thumb-300\";a:4:{s:4:\"file\";s:50:\"CO2-Laser-assisted-Deep-Sclerectomy-in-188x100.jpg\";s:5:\"width\";i:188;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"portfolio-four-column\";a:4:{s:4:\"file\";s:50:\"CO2-Laser-assisted-Deep-Sclerectomy-in-188x197.jpg\";s:5:\"width\";i:188;s:6:\"height\";i:197;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:50:\"CO2-Laser-assisted-Deep-Sclerectomy-in-125x125.jpg\";s:5:\"width\";i:125;s:6:\"height\";i:125;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES("789","111","_wp_attached_file","2014/03/CO2-Laser-assisted-Sclerectomy-Surgery-Part-II.jpg");
INSERT INTO `wp_postmeta` VALUES("790","111","_wp_attachment_metadata","a:5:{s:5:\"width\";i:188;s:6:\"height\";i:252;s:4:\"file\";s:58:\"2014/03/CO2-Laser-assisted-Sclerectomy-Surgery-Part-II.jpg\";s:5:\"sizes\";a:5:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:58:\"CO2-Laser-assisted-Sclerectomy-Surgery-Part-II-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"bones-thumb-600\";a:4:{s:4:\"file\";s:58:\"CO2-Laser-assisted-Sclerectomy-Surgery-Part-II-188x150.jpg\";s:5:\"width\";i:188;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"bones-thumb-300\";a:4:{s:4:\"file\";s:58:\"CO2-Laser-assisted-Sclerectomy-Surgery-Part-II-188x100.jpg\";s:5:\"width\";i:188;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"portfolio-four-column\";a:4:{s:4:\"file\";s:58:\"CO2-Laser-assisted-Sclerectomy-Surgery-Part-II-188x197.jpg\";s:5:\"width\";i:188;s:6:\"height\";i:197;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:58:\"CO2-Laser-assisted-Sclerectomy-Surgery-Part-II-125x125.jpg\";s:5:\"width\";i:125;s:6:\"height\";i:125;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES("791","112","_wp_attached_file","2014/03/CO2-Laser-assisted-Sclerectomy-Surgery.jpg");
INSERT INTO `wp_postmeta` VALUES("792","112","_wp_attachment_metadata","a:5:{s:5:\"width\";i:188;s:6:\"height\";i:252;s:4:\"file\";s:50:\"2014/03/CO2-Laser-assisted-Sclerectomy-Surgery.jpg\";s:5:\"sizes\";a:5:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:50:\"CO2-Laser-assisted-Sclerectomy-Surgery-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"bones-thumb-600\";a:4:{s:4:\"file\";s:50:\"CO2-Laser-assisted-Sclerectomy-Surgery-188x150.jpg\";s:5:\"width\";i:188;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"bones-thumb-300\";a:4:{s:4:\"file\";s:50:\"CO2-Laser-assisted-Sclerectomy-Surgery-188x100.jpg\";s:5:\"width\";i:188;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"portfolio-four-column\";a:4:{s:4:\"file\";s:50:\"CO2-Laser-assisted-Sclerectomy-Surgery-188x197.jpg\";s:5:\"width\";i:188;s:6:\"height\";i:197;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:50:\"CO2-Laser-assisted-Sclerectomy-Surgery-125x125.jpg\";s:5:\"width\";i:125;s:6:\"height\";i:125;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES("793","113","_wp_attached_file","2014/03/CO2-Laser-assisted-Sclerectomy-Surgery-Part-I.jpg");
INSERT INTO `wp_postmeta` VALUES("794","113","_wp_attachment_metadata","a:5:{s:5:\"width\";i:188;s:6:\"height\";i:252;s:4:\"file\";s:57:\"2014/03/CO2-Laser-assisted-Sclerectomy-Surgery-Part-I.jpg\";s:5:\"sizes\";a:5:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:57:\"CO2-Laser-assisted-Sclerectomy-Surgery-Part-I-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"bones-thumb-600\";a:4:{s:4:\"file\";s:57:\"CO2-Laser-assisted-Sclerectomy-Surgery-Part-I-188x150.jpg\";s:5:\"width\";i:188;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"bones-thumb-300\";a:4:{s:4:\"file\";s:57:\"CO2-Laser-assisted-Sclerectomy-Surgery-Part-I-188x100.jpg\";s:5:\"width\";i:188;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"portfolio-four-column\";a:4:{s:4:\"file\";s:57:\"CO2-Laser-assisted-Sclerectomy-Surgery-Part-I-188x197.jpg\";s:5:\"width\";i:188;s:6:\"height\";i:197;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:57:\"CO2-Laser-assisted-Sclerectomy-Surgery-Part-I-125x125.jpg\";s:5:\"width\";i:125;s:6:\"height\";i:125;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES("795","114","_wp_attached_file","2014/03/Long-term-results-of-CLASS.jpg");
INSERT INTO `wp_postmeta` VALUES("796","114","_wp_attachment_metadata","a:5:{s:5:\"width\";i:191;s:6:\"height\";i:350;s:4:\"file\";s:38:\"2014/03/Long-term-results-of-CLASS.jpg\";s:5:\"sizes\";a:10:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:38:\"Long-term-results-of-CLASS-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:38:\"Long-term-results-of-CLASS-163x300.jpg\";s:5:\"width\";i:163;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"bones-thumb-600\";a:4:{s:4:\"file\";s:38:\"Long-term-results-of-CLASS-191x150.jpg\";s:5:\"width\";i:191;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"bones-thumb-300\";a:4:{s:4:\"file\";s:38:\"Long-term-results-of-CLASS-191x100.jpg\";s:5:\"width\";i:191;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:22:\"portfolio-three-column\";a:4:{s:4:\"file\";s:38:\"Long-term-results-of-CLASS-191x270.jpg\";s:5:\"width\";i:191;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"portfolio-four-column\";a:4:{s:4:\"file\";s:38:\"Long-term-results-of-CLASS-191x197.jpg\";s:5:\"width\";i:191;s:6:\"height\";i:197;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:10:\"blog-large\";a:4:{s:4:\"file\";s:38:\"Long-term-results-of-CLASS-191x270.jpg\";s:5:\"width\";i:191;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"blog-full-width\";a:4:{s:4:\"file\";s:38:\"Long-term-results-of-CLASS-191x270.jpg\";s:5:\"width\";i:191;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"blog-grid\";a:4:{s:4:\"file\";s:38:\"Long-term-results-of-CLASS-191x270.jpg\";s:5:\"width\";i:191;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:38:\"Long-term-results-of-CLASS-125x125.jpg\";s:5:\"width\";i:125;s:6:\"height\";i:125;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES("797","115","_wp_attached_file","2014/03/CLASS-a-novel-filtration-treatment-for-glaucoma-patients.jpg");
INSERT INTO `wp_postmeta` VALUES("798","115","_wp_attachment_metadata","a:5:{s:5:\"width\";i:321;s:6:\"height\";i:159;s:4:\"file\";s:68:\"2014/03/CLASS-a-novel-filtration-treatment-for-glaucoma-patients.jpg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:68:\"CLASS-a-novel-filtration-treatment-for-glaucoma-patients-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:68:\"CLASS-a-novel-filtration-treatment-for-glaucoma-patients-300x148.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:148;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"bones-thumb-600\";a:4:{s:4:\"file\";s:68:\"CLASS-a-novel-filtration-treatment-for-glaucoma-patients-321x150.jpg\";s:5:\"width\";i:321;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"bones-thumb-300\";a:4:{s:4:\"file\";s:68:\"CLASS-a-novel-filtration-treatment-for-glaucoma-patients-300x100.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"portfolio-four-column\";a:4:{s:4:\"file\";s:68:\"CLASS-a-novel-filtration-treatment-for-glaucoma-patients-270x159.jpg\";s:5:\"width\";i:270;s:6:\"height\";i:159;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:68:\"CLASS-a-novel-filtration-treatment-for-glaucoma-patients-125x125.jpg\";s:5:\"width\";i:125;s:6:\"height\";i:125;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES("799","116","_wp_attached_file","2014/04/CLASS-Poster-AGS_NYC_Feb-2012.pdf");
INSERT INTO `wp_postmeta` VALUES("800","117","_wp_attached_file","2014/04/CLASS-Poster-at-WGC-2013-Switzerland.pdf");
INSERT INTO `wp_postmeta` VALUES("801","118","_wp_attached_file","2014/04/CLASS-y-Laser-Treats-Glaucoma-Asia.pdf");
INSERT INTO `wp_postmeta` VALUES("802","119","_wp_attached_file","2014/04/CO2-Laser-assisted-Sclerectomy-Surgery-Part-I-Concept-and-Experimental-Models_JOG_FEB2012.pdf");
INSERT INTO `wp_postmeta` VALUES("803","120","_wp_attached_file","2014/04/CO2-Laser-assisted-Sclerectomy-Surgery-Part-II-Multicenter-Clinical-Preliminary-Study_JOG_MAR2012.pdf");
INSERT INTO `wp_postmeta` VALUES("804","121","_wp_attached_file","2014/04/CO2-Laser-assisted-Sclerectomy-Surgery.pdf");
INSERT INTO `wp_postmeta` VALUES("805","122","_wp_attached_file","2014/04/IOptima_Poster_Asia-ICGS-2014.pdf");
INSERT INTO `wp_postmeta` VALUES("806","123","_wp_attached_file","2014/04/IOptima_Poster_Choka-WGC-2013.pdf");
INSERT INTO `wp_postmeta` VALUES("807","124","_wp_attached_file","2014/04/Skaat-CO2-Laser-assisted-Deep-Sclerectomy-in-Glaucoma-Patients.pdf");
INSERT INTO `wp_postmeta` VALUES("808","124","_edit_lock","1397753189:2");
INSERT INTO `wp_postmeta` VALUES("809","119","_edit_lock","1397752981:2");
INSERT INTO `wp_postmeta` VALUES("811","120","_edit_lock","1397753007:2");
INSERT INTO `wp_postmeta` VALUES("812","121","_edit_lock","1397753139:2");
INSERT INTO `wp_postmeta` VALUES("813","121","_edit_last","2");
INSERT INTO `wp_postmeta` VALUES("814","118","_edit_lock","1397753318:2");
INSERT INTO `wp_postmeta` VALUES("815","122","_edit_lock","1397753384:2");
INSERT INTO `wp_postmeta` VALUES("816","123","_edit_lock","1397753462:2");
INSERT INTO `wp_postmeta` VALUES("817","117","_edit_lock","1397753513:2");
INSERT INTO `wp_postmeta` VALUES("818","116","_edit_lock","1397753551:2");
INSERT INTO `wp_postmeta` VALUES("820","127","_wp_attached_file","2014/03/The-Laser-Control-Unit.jpg");
INSERT INTO `wp_postmeta` VALUES("821","127","_wp_attachment_metadata","a:5:{s:5:\"width\";i:600;s:6:\"height\";i:873;s:4:\"file\";s:34:\"2014/03/The-Laser-Control-Unit.jpg\";s:5:\"sizes\";a:14:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:34:\"The-Laser-Control-Unit-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:34:\"The-Laser-Control-Unit-206x300.jpg\";s:5:\"width\";i:206;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"bones-thumb-600\";a:4:{s:4:\"file\";s:34:\"The-Laser-Control-Unit-600x150.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"bones-thumb-300\";a:4:{s:4:\"file\";s:34:\"The-Laser-Control-Unit-300x100.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:20:\"portfolio-one-column\";a:4:{s:4:\"file\";s:34:\"The-Laser-Control-Unit-600x854.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:854;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:20:\"portfolio-two-column\";a:4:{s:4:\"file\";s:34:\"The-Laser-Control-Unit-570x416.jpg\";s:5:\"width\";i:570;s:6:\"height\";i:416;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:22:\"portfolio-three-column\";a:4:{s:4:\"file\";s:34:\"The-Laser-Control-Unit-370x270.jpg\";s:5:\"width\";i:370;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"portfolio-four-column\";a:4:{s:4:\"file\";s:34:\"The-Laser-Control-Unit-270x197.jpg\";s:5:\"width\";i:270;s:6:\"height\";i:197;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:17:\"portfolio-compact\";a:4:{s:4:\"file\";s:34:\"The-Laser-Control-Unit-600x513.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:513;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:10:\"blog-large\";a:4:{s:4:\"file\";s:34:\"The-Laser-Control-Unit-600x270.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"blog-full-width\";a:4:{s:4:\"file\";s:34:\"The-Laser-Control-Unit-600x270.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"blog-medium\";a:4:{s:4:\"file\";s:34:\"The-Laser-Control-Unit-600x540.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:540;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"blog-grid\";a:4:{s:4:\"file\";s:34:\"The-Laser-Control-Unit-370x270.jpg\";s:5:\"width\";i:370;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:34:\"The-Laser-Control-Unit-125x125.jpg\";s:5:\"width\";i:125;s:6:\"height\";i:125;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:10:\"Yoav Peled\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES("822","128","_wp_attached_file","2014/03/The-Scanner.jpg");
INSERT INTO `wp_postmeta` VALUES("823","128","_wp_attachment_metadata","a:5:{s:5:\"width\";i:600;s:6:\"height\";i:394;s:4:\"file\";s:23:\"2014/03/The-Scanner.jpg\";s:5:\"sizes\";a:11:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:23:\"The-Scanner-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:23:\"The-Scanner-300x197.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:197;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"bones-thumb-600\";a:4:{s:4:\"file\";s:23:\"The-Scanner-600x150.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"bones-thumb-300\";a:4:{s:4:\"file\";s:23:\"The-Scanner-300x100.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:20:\"portfolio-two-column\";a:4:{s:4:\"file\";s:23:\"The-Scanner-570x394.jpg\";s:5:\"width\";i:570;s:6:\"height\";i:394;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:22:\"portfolio-three-column\";a:4:{s:4:\"file\";s:23:\"The-Scanner-370x270.jpg\";s:5:\"width\";i:370;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"portfolio-four-column\";a:4:{s:4:\"file\";s:23:\"The-Scanner-270x197.jpg\";s:5:\"width\";i:270;s:6:\"height\";i:197;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:10:\"blog-large\";a:4:{s:4:\"file\";s:23:\"The-Scanner-600x270.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"blog-full-width\";a:4:{s:4:\"file\";s:23:\"The-Scanner-600x270.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"blog-grid\";a:4:{s:4:\"file\";s:23:\"The-Scanner-370x270.jpg\";s:5:\"width\";i:370;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:23:\"The-Scanner-125x125.jpg\";s:5:\"width\";i:125;s:6:\"height\";i:125;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:10:\"Yoav Peled\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES("824","129","_wp_attached_file","2014/04/Ablation-Patterns.jpg");
INSERT INTO `wp_postmeta` VALUES("825","129","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1000;s:6:\"height\";i:945;s:4:\"file\";s:29:\"2014/04/Ablation-Patterns.jpg\";s:5:\"sizes\";a:14:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:29:\"Ablation-Patterns-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:29:\"Ablation-Patterns-300x283.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:283;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"bones-thumb-600\";a:4:{s:4:\"file\";s:29:\"Ablation-Patterns-600x150.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"bones-thumb-300\";a:4:{s:4:\"file\";s:29:\"Ablation-Patterns-300x100.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:20:\"portfolio-one-column\";a:4:{s:4:\"file\";s:30:\"Ablation-Patterns-1000x854.jpg\";s:5:\"width\";i:1000;s:6:\"height\";i:854;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:20:\"portfolio-two-column\";a:4:{s:4:\"file\";s:29:\"Ablation-Patterns-570x416.jpg\";s:5:\"width\";i:570;s:6:\"height\";i:416;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:22:\"portfolio-three-column\";a:4:{s:4:\"file\";s:29:\"Ablation-Patterns-370x270.jpg\";s:5:\"width\";i:370;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"portfolio-four-column\";a:4:{s:4:\"file\";s:29:\"Ablation-Patterns-270x197.jpg\";s:5:\"width\";i:270;s:6:\"height\";i:197;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:17:\"portfolio-compact\";a:4:{s:4:\"file\";s:29:\"Ablation-Patterns-770x513.jpg\";s:5:\"width\";i:770;s:6:\"height\";i:513;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:10:\"blog-large\";a:4:{s:4:\"file\";s:29:\"Ablation-Patterns-770x270.jpg\";s:5:\"width\";i:770;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"blog-full-width\";a:4:{s:4:\"file\";s:30:\"Ablation-Patterns-1000x270.jpg\";s:5:\"width\";i:1000;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"blog-medium\";a:4:{s:4:\"file\";s:29:\"Ablation-Patterns-740x540.jpg\";s:5:\"width\";i:740;s:6:\"height\";i:540;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"blog-grid\";a:4:{s:4:\"file\";s:29:\"Ablation-Patterns-370x270.jpg\";s:5:\"width\";i:370;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:29:\"Ablation-Patterns-125x125.jpg\";s:5:\"width\";i:125;s:6:\"height\";i:125;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES("826","129","_edit_lock","1397755259:2");
INSERT INTO `wp_postmeta` VALUES("827","130","_wp_attached_file","2014/03/CLASS-principle-of-Operation.png");
INSERT INTO `wp_postmeta` VALUES("828","130","_wp_attachment_metadata","a:5:{s:5:\"width\";i:471;s:6:\"height\";i:243;s:4:\"file\";s:40:\"2014/03/CLASS-principle-of-Operation.png\";s:5:\"sizes\";a:8:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:40:\"CLASS-principle-of-Operation-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:40:\"CLASS-principle-of-Operation-300x154.png\";s:5:\"width\";i:300;s:6:\"height\";i:154;s:9:\"mime-type\";s:9:\"image/png\";}s:15:\"bones-thumb-600\";a:4:{s:4:\"file\";s:40:\"CLASS-principle-of-Operation-471x150.png\";s:5:\"width\";i:471;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:15:\"bones-thumb-300\";a:4:{s:4:\"file\";s:40:\"CLASS-principle-of-Operation-300x100.png\";s:5:\"width\";i:300;s:6:\"height\";i:100;s:9:\"mime-type\";s:9:\"image/png\";}s:22:\"portfolio-three-column\";a:4:{s:4:\"file\";s:40:\"CLASS-principle-of-Operation-370x243.png\";s:5:\"width\";i:370;s:6:\"height\";i:243;s:9:\"mime-type\";s:9:\"image/png\";}s:21:\"portfolio-four-column\";a:4:{s:4:\"file\";s:40:\"CLASS-principle-of-Operation-270x197.png\";s:5:\"width\";i:270;s:6:\"height\";i:197;s:9:\"mime-type\";s:9:\"image/png\";}s:9:\"blog-grid\";a:4:{s:4:\"file\";s:40:\"CLASS-principle-of-Operation-370x243.png\";s:5:\"width\";i:370;s:6:\"height\";i:243;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:40:\"CLASS-principle-of-Operation-125x125.png\";s:5:\"width\";i:125;s:6:\"height\";i:125;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES("833","132","_menu_item_type","custom");
INSERT INTO `wp_postmeta` VALUES("834","132","_menu_item_menu_item_parent","0");
INSERT INTO `wp_postmeta` VALUES("835","132","_menu_item_object_id","132");
INSERT INTO `wp_postmeta` VALUES("836","132","_menu_item_object","custom");
INSERT INTO `wp_postmeta` VALUES("837","132","_menu_item_target","");
INSERT INTO `wp_postmeta` VALUES("838","132","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `wp_postmeta` VALUES("839","132","_menu_item_xfn","");
INSERT INTO `wp_postmeta` VALUES("840","132","_menu_item_url","http://ioptima.co.il/news/in-the-news/");
INSERT INTO `wp_postmeta` VALUES("842","133","_edit_last","2");
INSERT INTO `wp_postmeta` VALUES("843","133","_edit_lock","1429424676:2");
INSERT INTO `wp_postmeta` VALUES("844","133","_wp_page_template","page-sidebar-left-submenu.php");
INSERT INTO `wp_postmeta` VALUES("845","133","_wpb_vc_js_status","true");
INSERT INTO `wp_postmeta` VALUES("846","133","_wpb_vc_js_interface_version","2");
INSERT INTO `wp_postmeta` VALUES("847","133","_peach_bkgd_color","#");
INSERT INTO `wp_postmeta` VALUES("848","133","_peach_bkgd_repeat","no-repeat");
INSERT INTO `wp_postmeta` VALUES("849","133","_peach_bkgd_position","top left");
INSERT INTO `wp_postmeta` VALUES("850","133","_peach_bkgd_attachment","scroll");
INSERT INTO `wp_postmeta` VALUES("851","133","_peach_header_bkgd_color","#");
INSERT INTO `wp_postmeta` VALUES("852","133","_peach_header_bkgd_repeat","no-repeat");
INSERT INTO `wp_postmeta` VALUES("853","133","_peach_header_bkgd_position","top left");
INSERT INTO `wp_postmeta` VALUES("854","133","_peach_header_bkgd_attachment","scroll");
INSERT INTO `wp_postmeta` VALUES("855","133","_peach_breadcrumb_align","left");
INSERT INTO `wp_postmeta` VALUES("856","134","_edit_last","2");
INSERT INTO `wp_postmeta` VALUES("857","134","_wp_page_template","default");
INSERT INTO `wp_postmeta` VALUES("858","134","_wpb_vc_js_status","false");
INSERT INTO `wp_postmeta` VALUES("859","134","_wpb_vc_js_interface_version","2");
INSERT INTO `wp_postmeta` VALUES("860","134","_peach_bkgd_color","#");
INSERT INTO `wp_postmeta` VALUES("861","134","_peach_bkgd_repeat","no-repeat");
INSERT INTO `wp_postmeta` VALUES("862","134","_peach_bkgd_position","top left");
INSERT INTO `wp_postmeta` VALUES("863","134","_peach_bkgd_attachment","scroll");
INSERT INTO `wp_postmeta` VALUES("864","134","_peach_header_bkgd_color","#");
INSERT INTO `wp_postmeta` VALUES("865","134","_peach_header_bkgd_repeat","no-repeat");
INSERT INTO `wp_postmeta` VALUES("866","134","_peach_header_bkgd_position","top left");
INSERT INTO `wp_postmeta` VALUES("867","134","_peach_header_bkgd_attachment","scroll");
INSERT INTO `wp_postmeta` VALUES("868","134","_peach_breadcrumb_align","left");
INSERT INTO `wp_postmeta` VALUES("869","134","_edit_lock","1417338450:2");
INSERT INTO `wp_postmeta` VALUES("870","135","_menu_item_type","post_type");
INSERT INTO `wp_postmeta` VALUES("871","135","_menu_item_menu_item_parent","132");
INSERT INTO `wp_postmeta` VALUES("872","135","_menu_item_object_id","133");
INSERT INTO `wp_postmeta` VALUES("873","135","_menu_item_object","page");
INSERT INTO `wp_postmeta` VALUES("874","135","_menu_item_target","");
INSERT INTO `wp_postmeta` VALUES("875","135","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `wp_postmeta` VALUES("876","135","_menu_item_xfn","");
INSERT INTO `wp_postmeta` VALUES("877","135","_menu_item_url","");
INSERT INTO `wp_postmeta` VALUES("907","137","_wp_attached_file","2014/04/ioptima.jpg");
INSERT INTO `wp_postmeta` VALUES("908","137","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1900;s:6:\"height\";i:512;s:4:\"file\";s:19:\"2014/04/ioptima.jpg\";s:5:\"sizes\";a:15:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:19:\"ioptima-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:18:\"ioptima-300x80.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:80;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:20:\"ioptima-1024x275.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:275;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"bones-thumb-600\";a:4:{s:4:\"file\";s:19:\"ioptima-600x150.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"bones-thumb-300\";a:4:{s:4:\"file\";s:19:\"ioptima-300x100.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:20:\"portfolio-one-column\";a:4:{s:4:\"file\";s:20:\"ioptima-1170x512.jpg\";s:5:\"width\";i:1170;s:6:\"height\";i:512;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:20:\"portfolio-two-column\";a:4:{s:4:\"file\";s:19:\"ioptima-570x416.jpg\";s:5:\"width\";i:570;s:6:\"height\";i:416;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:22:\"portfolio-three-column\";a:4:{s:4:\"file\";s:19:\"ioptima-370x270.jpg\";s:5:\"width\";i:370;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"portfolio-four-column\";a:4:{s:4:\"file\";s:19:\"ioptima-270x197.jpg\";s:5:\"width\";i:270;s:6:\"height\";i:197;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:17:\"portfolio-compact\";a:4:{s:4:\"file\";s:19:\"ioptima-770x512.jpg\";s:5:\"width\";i:770;s:6:\"height\";i:512;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:10:\"blog-large\";a:4:{s:4:\"file\";s:19:\"ioptima-770x270.jpg\";s:5:\"width\";i:770;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"blog-full-width\";a:4:{s:4:\"file\";s:20:\"ioptima-1170x270.jpg\";s:5:\"width\";i:1170;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"blog-medium\";a:4:{s:4:\"file\";s:19:\"ioptima-740x512.jpg\";s:5:\"width\";i:740;s:6:\"height\";i:512;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"blog-grid\";a:4:{s:4:\"file\";s:19:\"ioptima-370x270.jpg\";s:5:\"width\";i:370;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:19:\"ioptima-125x125.jpg\";s:5:\"width\";i:125;s:6:\"height\";i:125;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:7:\"moonrun\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES("909","138","_wp_attached_file","2014/04/logo_fixed.jpg");
INSERT INTO `wp_postmeta` VALUES("910","138","_wp_attachment_metadata","a:5:{s:5:\"width\";i:208;s:6:\"height\";i:75;s:4:\"file\";s:22:\"2014/04/logo_fixed.jpg\";s:5:\"sizes\";a:2:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:21:\"logo_fixed-150x75.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:75;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:21:\"logo_fixed-125x75.jpg\";s:5:\"width\";i:125;s:6:\"height\";i:75;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES("911","139","_edit_lock","1408953141:2");
INSERT INTO `wp_postmeta` VALUES("912","139","_edit_last","2");
INSERT INTO `wp_postmeta` VALUES("913","139","_wp_page_template","page-sidebar-left-submenu.php");
INSERT INTO `wp_postmeta` VALUES("914","139","_wpb_vc_js_status","true");
INSERT INTO `wp_postmeta` VALUES("915","139","_wpb_vc_js_interface_version","2");
INSERT INTO `wp_postmeta` VALUES("916","139","_peach_bkgd_color","#");
INSERT INTO `wp_postmeta` VALUES("917","139","_peach_bkgd_repeat","no-repeat");
INSERT INTO `wp_postmeta` VALUES("918","139","_peach_bkgd_position","top left");
INSERT INTO `wp_postmeta` VALUES("919","139","_peach_bkgd_attachment","scroll");
INSERT INTO `wp_postmeta` VALUES("920","139","_peach_header_bkgd_color","#");
INSERT INTO `wp_postmeta` VALUES("921","139","_peach_header_bkgd_repeat","no-repeat");
INSERT INTO `wp_postmeta` VALUES("922","139","_peach_header_bkgd_position","top left");
INSERT INTO `wp_postmeta` VALUES("923","139","_peach_header_bkgd_attachment","scroll");
INSERT INTO `wp_postmeta` VALUES("924","139","_peach_breadcrumb_align","left");
INSERT INTO `wp_postmeta` VALUES("925","139","_peach_hide_breadcrumb","on");
INSERT INTO `wp_postmeta` VALUES("926","140","_menu_item_type","post_type");
INSERT INTO `wp_postmeta` VALUES("927","140","_menu_item_menu_item_parent","66");
INSERT INTO `wp_postmeta` VALUES("928","140","_menu_item_object_id","139");
INSERT INTO `wp_postmeta` VALUES("929","140","_menu_item_object","page");
INSERT INTO `wp_postmeta` VALUES("930","140","_menu_item_target","");
INSERT INTO `wp_postmeta` VALUES("931","140","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `wp_postmeta` VALUES("932","140","_menu_item_xfn","");
INSERT INTO `wp_postmeta` VALUES("933","140","_menu_item_url","");
INSERT INTO `wp_postmeta` VALUES("935","142","_wp_attached_file","2014/04/Procedure-Steps-4.jpg");
INSERT INTO `wp_postmeta` VALUES("936","142","_wp_attachment_metadata","a:5:{s:5:\"width\";i:401;s:6:\"height\";i:294;s:4:\"file\";s:29:\"2014/04/Procedure-Steps-4.jpg\";s:5:\"sizes\";a:10:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:29:\"Procedure-Steps-4-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:29:\"Procedure-Steps-4-300x219.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:219;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"bones-thumb-600\";a:4:{s:4:\"file\";s:29:\"Procedure-Steps-4-401x150.jpg\";s:5:\"width\";i:401;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"bones-thumb-300\";a:4:{s:4:\"file\";s:29:\"Procedure-Steps-4-300x100.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:22:\"portfolio-three-column\";a:4:{s:4:\"file\";s:29:\"Procedure-Steps-4-370x270.jpg\";s:5:\"width\";i:370;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"portfolio-four-column\";a:4:{s:4:\"file\";s:29:\"Procedure-Steps-4-270x197.jpg\";s:5:\"width\";i:270;s:6:\"height\";i:197;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:10:\"blog-large\";a:4:{s:4:\"file\";s:29:\"Procedure-Steps-4-401x270.jpg\";s:5:\"width\";i:401;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"blog-full-width\";a:4:{s:4:\"file\";s:29:\"Procedure-Steps-4-401x270.jpg\";s:5:\"width\";i:401;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"blog-grid\";a:4:{s:4:\"file\";s:29:\"Procedure-Steps-4-370x270.jpg\";s:5:\"width\";i:370;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:29:\"Procedure-Steps-4-125x125.jpg\";s:5:\"width\";i:125;s:6:\"height\";i:125;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES("937","143","_wp_attached_file","2014/04/Procedure-Steps-1.jpg");
INSERT INTO `wp_postmeta` VALUES("938","143","_wp_attachment_metadata","a:5:{s:5:\"width\";i:401;s:6:\"height\";i:265;s:4:\"file\";s:29:\"2014/04/Procedure-Steps-1.jpg\";s:5:\"sizes\";a:8:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:29:\"Procedure-Steps-1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:29:\"Procedure-Steps-1-300x198.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:198;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"bones-thumb-600\";a:4:{s:4:\"file\";s:29:\"Procedure-Steps-1-401x150.jpg\";s:5:\"width\";i:401;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"bones-thumb-300\";a:4:{s:4:\"file\";s:29:\"Procedure-Steps-1-300x100.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:22:\"portfolio-three-column\";a:4:{s:4:\"file\";s:29:\"Procedure-Steps-1-370x265.jpg\";s:5:\"width\";i:370;s:6:\"height\";i:265;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"portfolio-four-column\";a:4:{s:4:\"file\";s:29:\"Procedure-Steps-1-270x197.jpg\";s:5:\"width\";i:270;s:6:\"height\";i:197;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"blog-grid\";a:4:{s:4:\"file\";s:29:\"Procedure-Steps-1-370x265.jpg\";s:5:\"width\";i:370;s:6:\"height\";i:265;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:29:\"Procedure-Steps-1-125x125.jpg\";s:5:\"width\";i:125;s:6:\"height\";i:125;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES("939","144","_wp_attached_file","2014/04/Procedure-Steps-2.jpg");
INSERT INTO `wp_postmeta` VALUES("940","144","_wp_attachment_metadata","a:5:{s:5:\"width\";i:401;s:6:\"height\";i:221;s:4:\"file\";s:29:\"2014/04/Procedure-Steps-2.jpg\";s:5:\"sizes\";a:8:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:29:\"Procedure-Steps-2-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:29:\"Procedure-Steps-2-300x165.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:165;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"bones-thumb-600\";a:4:{s:4:\"file\";s:29:\"Procedure-Steps-2-401x150.jpg\";s:5:\"width\";i:401;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"bones-thumb-300\";a:4:{s:4:\"file\";s:29:\"Procedure-Steps-2-300x100.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:22:\"portfolio-three-column\";a:4:{s:4:\"file\";s:29:\"Procedure-Steps-2-370x221.jpg\";s:5:\"width\";i:370;s:6:\"height\";i:221;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"portfolio-four-column\";a:4:{s:4:\"file\";s:29:\"Procedure-Steps-2-270x197.jpg\";s:5:\"width\";i:270;s:6:\"height\";i:197;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"blog-grid\";a:4:{s:4:\"file\";s:29:\"Procedure-Steps-2-370x221.jpg\";s:5:\"width\";i:370;s:6:\"height\";i:221;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:29:\"Procedure-Steps-2-125x125.jpg\";s:5:\"width\";i:125;s:6:\"height\";i:125;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES("941","145","_wp_attached_file","2014/04/Procedure-Steps-3.jpg");
INSERT INTO `wp_postmeta` VALUES("942","145","_wp_attachment_metadata","a:5:{s:5:\"width\";i:401;s:6:\"height\";i:294;s:4:\"file\";s:29:\"2014/04/Procedure-Steps-3.jpg\";s:5:\"sizes\";a:10:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:29:\"Procedure-Steps-3-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:29:\"Procedure-Steps-3-300x219.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:219;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"bones-thumb-600\";a:4:{s:4:\"file\";s:29:\"Procedure-Steps-3-401x150.jpg\";s:5:\"width\";i:401;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"bones-thumb-300\";a:4:{s:4:\"file\";s:29:\"Procedure-Steps-3-300x100.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:22:\"portfolio-three-column\";a:4:{s:4:\"file\";s:29:\"Procedure-Steps-3-370x270.jpg\";s:5:\"width\";i:370;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"portfolio-four-column\";a:4:{s:4:\"file\";s:29:\"Procedure-Steps-3-270x197.jpg\";s:5:\"width\";i:270;s:6:\"height\";i:197;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:10:\"blog-large\";a:4:{s:4:\"file\";s:29:\"Procedure-Steps-3-401x270.jpg\";s:5:\"width\";i:401;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"blog-full-width\";a:4:{s:4:\"file\";s:29:\"Procedure-Steps-3-401x270.jpg\";s:5:\"width\";i:401;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"blog-grid\";a:4:{s:4:\"file\";s:29:\"Procedure-Steps-3-370x270.jpg\";s:5:\"width\";i:370;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:29:\"Procedure-Steps-3-125x125.jpg\";s:5:\"width\";i:125;s:6:\"height\";i:125;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES("943","147","_wp_attached_file","2014/03/Shaarawy-Tarek.png");
INSERT INTO `wp_postmeta` VALUES("944","147","_wp_attachment_metadata","a:5:{s:5:\"width\";i:79;s:6:\"height\";i:77;s:4:\"file\";s:26:\"2014/03/Shaarawy-Tarek.png\";s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES("945","148","_wp_attached_file","2014/03/Assia-Ehud.jpg");
INSERT INTO `wp_postmeta` VALUES("946","148","_wp_attachment_metadata","a:5:{s:5:\"width\";i:79;s:6:\"height\";i:77;s:4:\"file\";s:22:\"2014/03/Assia-Ehud.jpg\";s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES("947","149","_wp_attached_file","2014/03/Félix-Gil-Carrasco.jpg");
INSERT INTO `wp_postmeta` VALUES("948","149","_wp_attachment_metadata","a:5:{s:5:\"width\";i:79;s:6:\"height\";i:77;s:4:\"file\";s:31:\"2014/03/Félix-Gil-Carrasco.jpg\";s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES("949","150","_wp_attached_file","2014/03/Melamed-Shlomo.jpg");
INSERT INTO `wp_postmeta` VALUES("950","150","_wp_attachment_metadata","a:5:{s:5:\"width\";i:79;s:6:\"height\";i:77;s:4:\"file\";s:26:\"2014/03/Melamed-Shlomo.jpg\";s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES("951","151","_wp_attached_file","2014/03/Mermoud-Andre.jpg");
INSERT INTO `wp_postmeta` VALUES("952","151","_wp_attachment_metadata","a:5:{s:5:\"width\";i:79;s:6:\"height\";i:77;s:4:\"file\";s:25:\"2014/03/Mermoud-Andre.jpg\";s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES("953","152","_wp_attached_file","2014/03/Muñoz-Gonzalo.jpg");
INSERT INTO `wp_postmeta` VALUES("954","152","_wp_attachment_metadata","a:5:{s:5:\"width\";i:79;s:6:\"height\";i:77;s:4:\"file\";s:26:\"2014/03/Muñoz-Gonzalo.jpg\";s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES("955","133","_peach_hide_breadcrumb","on");
INSERT INTO `wp_postmeta` VALUES("956","153","_wp_attached_file","2014/03/venn-diagram1.png");
INSERT INTO `wp_postmeta` VALUES("957","153","_wp_attachment_metadata","a:5:{s:5:\"width\";i:260;s:6:\"height\";i:260;s:4:\"file\";s:25:\"2014/03/venn-diagram1.png\";s:5:\"sizes\";a:5:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:25:\"venn-diagram1-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:15:\"bones-thumb-600\";a:4:{s:4:\"file\";s:25:\"venn-diagram1-260x150.png\";s:5:\"width\";i:260;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:15:\"bones-thumb-300\";a:4:{s:4:\"file\";s:25:\"venn-diagram1-260x100.png\";s:5:\"width\";i:260;s:6:\"height\";i:100;s:9:\"mime-type\";s:9:\"image/png\";}s:21:\"portfolio-four-column\";a:4:{s:4:\"file\";s:25:\"venn-diagram1-260x197.png\";s:5:\"width\";i:260;s:6:\"height\";i:197;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:25:\"venn-diagram1-125x125.png\";s:5:\"width\";i:125;s:6:\"height\";i:125;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES("958","154","_wp_attached_file","2014/04/Log.png");
INSERT INTO `wp_postmeta` VALUES("959","154","_wp_attachment_metadata","a:5:{s:5:\"width\";i:205;s:6:\"height\";i:80;s:4:\"file\";s:15:\"2014/04/Log.png\";s:5:\"sizes\";a:2:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:14:\"Log-150x80.png\";s:5:\"width\";i:150;s:6:\"height\";i:80;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:14:\"Log-125x80.png\";s:5:\"width\";i:125;s:6:\"height\";i:80;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES("982","165","_wp_attached_file","2014/05/Black-Background-big.png");
INSERT INTO `wp_postmeta` VALUES("983","165","_wp_attachment_metadata","a:5:{s:5:\"width\";i:700;s:6:\"height\";i:746;s:4:\"file\";s:32:\"2014/05/Black-Background-big.png\";s:5:\"sizes\";a:13:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:32:\"Black-Background-big-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:32:\"Black-Background-big-281x300.png\";s:5:\"width\";i:281;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";}s:15:\"bones-thumb-600\";a:4:{s:4:\"file\";s:32:\"Black-Background-big-600x150.png\";s:5:\"width\";i:600;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:15:\"bones-thumb-300\";a:4:{s:4:\"file\";s:32:\"Black-Background-big-300x100.png\";s:5:\"width\";i:300;s:6:\"height\";i:100;s:9:\"mime-type\";s:9:\"image/png\";}s:20:\"portfolio-two-column\";a:4:{s:4:\"file\";s:32:\"Black-Background-big-570x416.png\";s:5:\"width\";i:570;s:6:\"height\";i:416;s:9:\"mime-type\";s:9:\"image/png\";}s:22:\"portfolio-three-column\";a:4:{s:4:\"file\";s:32:\"Black-Background-big-370x270.png\";s:5:\"width\";i:370;s:6:\"height\";i:270;s:9:\"mime-type\";s:9:\"image/png\";}s:21:\"portfolio-four-column\";a:4:{s:4:\"file\";s:32:\"Black-Background-big-270x197.png\";s:5:\"width\";i:270;s:6:\"height\";i:197;s:9:\"mime-type\";s:9:\"image/png\";}s:17:\"portfolio-compact\";a:4:{s:4:\"file\";s:32:\"Black-Background-big-700x513.png\";s:5:\"width\";i:700;s:6:\"height\";i:513;s:9:\"mime-type\";s:9:\"image/png\";}s:10:\"blog-large\";a:4:{s:4:\"file\";s:32:\"Black-Background-big-700x270.png\";s:5:\"width\";i:700;s:6:\"height\";i:270;s:9:\"mime-type\";s:9:\"image/png\";}s:15:\"blog-full-width\";a:4:{s:4:\"file\";s:32:\"Black-Background-big-700x270.png\";s:5:\"width\";i:700;s:6:\"height\";i:270;s:9:\"mime-type\";s:9:\"image/png\";}s:11:\"blog-medium\";a:4:{s:4:\"file\";s:32:\"Black-Background-big-700x540.png\";s:5:\"width\";i:700;s:6:\"height\";i:540;s:9:\"mime-type\";s:9:\"image/png\";}s:9:\"blog-grid\";a:4:{s:4:\"file\";s:32:\"Black-Background-big-370x270.png\";s:5:\"width\";i:370;s:6:\"height\";i:270;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:32:\"Black-Background-big-125x125.png\";s:5:\"width\";i:125;s:6:\"height\";i:125;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES("984","137","_edit_lock","1398933425:2");
INSERT INTO `wp_postmeta` VALUES("987","168","_wp_attached_file","2014/05/IOPtimas-solution.jpg");
INSERT INTO `wp_postmeta` VALUES("988","168","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1900;s:6:\"height\";i:512;s:4:\"file\";s:29:\"2014/05/IOPtimas-solution.jpg\";s:5:\"sizes\";a:15:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:29:\"IOPtimas-solution-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:28:\"IOPtimas-solution-300x80.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:80;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:30:\"IOPtimas-solution-1024x275.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:275;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"bones-thumb-600\";a:4:{s:4:\"file\";s:29:\"IOPtimas-solution-600x150.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"bones-thumb-300\";a:4:{s:4:\"file\";s:29:\"IOPtimas-solution-300x100.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:20:\"portfolio-one-column\";a:4:{s:4:\"file\";s:30:\"IOPtimas-solution-1170x512.jpg\";s:5:\"width\";i:1170;s:6:\"height\";i:512;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:20:\"portfolio-two-column\";a:4:{s:4:\"file\";s:29:\"IOPtimas-solution-570x416.jpg\";s:5:\"width\";i:570;s:6:\"height\";i:416;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:22:\"portfolio-three-column\";a:4:{s:4:\"file\";s:29:\"IOPtimas-solution-370x270.jpg\";s:5:\"width\";i:370;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"portfolio-four-column\";a:4:{s:4:\"file\";s:29:\"IOPtimas-solution-270x197.jpg\";s:5:\"width\";i:270;s:6:\"height\";i:197;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:17:\"portfolio-compact\";a:4:{s:4:\"file\";s:29:\"IOPtimas-solution-770x512.jpg\";s:5:\"width\";i:770;s:6:\"height\";i:512;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:10:\"blog-large\";a:4:{s:4:\"file\";s:29:\"IOPtimas-solution-770x270.jpg\";s:5:\"width\";i:770;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"blog-full-width\";a:4:{s:4:\"file\";s:30:\"IOPtimas-solution-1170x270.jpg\";s:5:\"width\";i:1170;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"blog-medium\";a:4:{s:4:\"file\";s:29:\"IOPtimas-solution-740x512.jpg\";s:5:\"width\";i:740;s:6:\"height\";i:512;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"blog-grid\";a:4:{s:4:\"file\";s:29:\"IOPtimas-solution-370x270.jpg\";s:5:\"width\";i:370;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:29:\"IOPtimas-solution-125x125.jpg\";s:5:\"width\";i:125;s:6:\"height\";i:125;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES("991","170","_wp_attached_file","2014/05/CLASS-benefits-1.jpg");
INSERT INTO `wp_postmeta` VALUES("992","170","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1900;s:6:\"height\";i:512;s:4:\"file\";s:28:\"2014/05/CLASS-benefits-1.jpg\";s:5:\"sizes\";a:15:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:28:\"CLASS-benefits-1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:27:\"CLASS-benefits-1-300x80.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:80;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:29:\"CLASS-benefits-1-1024x275.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:275;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"bones-thumb-600\";a:4:{s:4:\"file\";s:28:\"CLASS-benefits-1-600x150.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"bones-thumb-300\";a:4:{s:4:\"file\";s:28:\"CLASS-benefits-1-300x100.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:20:\"portfolio-one-column\";a:4:{s:4:\"file\";s:29:\"CLASS-benefits-1-1170x512.jpg\";s:5:\"width\";i:1170;s:6:\"height\";i:512;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:20:\"portfolio-two-column\";a:4:{s:4:\"file\";s:28:\"CLASS-benefits-1-570x416.jpg\";s:5:\"width\";i:570;s:6:\"height\";i:416;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:22:\"portfolio-three-column\";a:4:{s:4:\"file\";s:28:\"CLASS-benefits-1-370x270.jpg\";s:5:\"width\";i:370;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"portfolio-four-column\";a:4:{s:4:\"file\";s:28:\"CLASS-benefits-1-270x197.jpg\";s:5:\"width\";i:270;s:6:\"height\";i:197;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:17:\"portfolio-compact\";a:4:{s:4:\"file\";s:28:\"CLASS-benefits-1-770x512.jpg\";s:5:\"width\";i:770;s:6:\"height\";i:512;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:10:\"blog-large\";a:4:{s:4:\"file\";s:28:\"CLASS-benefits-1-770x270.jpg\";s:5:\"width\";i:770;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"blog-full-width\";a:4:{s:4:\"file\";s:29:\"CLASS-benefits-1-1170x270.jpg\";s:5:\"width\";i:1170;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"blog-medium\";a:4:{s:4:\"file\";s:28:\"CLASS-benefits-1-740x512.jpg\";s:5:\"width\";i:740;s:6:\"height\";i:512;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"blog-grid\";a:4:{s:4:\"file\";s:28:\"CLASS-benefits-1-370x270.jpg\";s:5:\"width\";i:370;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:28:\"CLASS-benefits-1-125x125.jpg\";s:5:\"width\";i:125;s:6:\"height\";i:125;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES("995","172","_wp_attached_file","2014/05/surgeon.png");
INSERT INTO `wp_postmeta` VALUES("996","172","_wp_attachment_metadata","a:5:{s:5:\"width\";i:408;s:6:\"height\";i:600;s:4:\"file\";s:19:\"2014/05/surgeon.png\";s:5:\"sizes\";a:13:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:19:\"surgeon-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:19:\"surgeon-204x300.png\";s:5:\"width\";i:204;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";}s:15:\"bones-thumb-600\";a:4:{s:4:\"file\";s:19:\"surgeon-408x150.png\";s:5:\"width\";i:408;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:15:\"bones-thumb-300\";a:4:{s:4:\"file\";s:19:\"surgeon-300x100.png\";s:5:\"width\";i:300;s:6:\"height\";i:100;s:9:\"mime-type\";s:9:\"image/png\";}s:20:\"portfolio-two-column\";a:4:{s:4:\"file\";s:19:\"surgeon-408x416.png\";s:5:\"width\";i:408;s:6:\"height\";i:416;s:9:\"mime-type\";s:9:\"image/png\";}s:22:\"portfolio-three-column\";a:4:{s:4:\"file\";s:19:\"surgeon-370x270.png\";s:5:\"width\";i:370;s:6:\"height\";i:270;s:9:\"mime-type\";s:9:\"image/png\";}s:21:\"portfolio-four-column\";a:4:{s:4:\"file\";s:19:\"surgeon-270x197.png\";s:5:\"width\";i:270;s:6:\"height\";i:197;s:9:\"mime-type\";s:9:\"image/png\";}s:17:\"portfolio-compact\";a:4:{s:4:\"file\";s:19:\"surgeon-408x513.png\";s:5:\"width\";i:408;s:6:\"height\";i:513;s:9:\"mime-type\";s:9:\"image/png\";}s:10:\"blog-large\";a:4:{s:4:\"file\";s:19:\"surgeon-408x270.png\";s:5:\"width\";i:408;s:6:\"height\";i:270;s:9:\"mime-type\";s:9:\"image/png\";}s:15:\"blog-full-width\";a:4:{s:4:\"file\";s:19:\"surgeon-408x270.png\";s:5:\"width\";i:408;s:6:\"height\";i:270;s:9:\"mime-type\";s:9:\"image/png\";}s:11:\"blog-medium\";a:4:{s:4:\"file\";s:19:\"surgeon-408x540.png\";s:5:\"width\";i:408;s:6:\"height\";i:540;s:9:\"mime-type\";s:9:\"image/png\";}s:9:\"blog-grid\";a:4:{s:4:\"file\";s:19:\"surgeon-370x270.png\";s:5:\"width\";i:370;s:6:\"height\";i:270;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:19:\"surgeon-125x125.png\";s:5:\"width\";i:125;s:6:\"height\";i:125;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES("997","173","_wp_attached_file","2014/05/surgeon1.png");
INSERT INTO `wp_postmeta` VALUES("998","173","_wp_attachment_metadata","a:5:{s:5:\"width\";i:485;s:6:\"height\";i:600;s:4:\"file\";s:20:\"2014/05/surgeon1.png\";s:5:\"sizes\";a:13:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:20:\"surgeon1-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:20:\"surgeon1-242x300.png\";s:5:\"width\";i:242;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";}s:15:\"bones-thumb-600\";a:4:{s:4:\"file\";s:20:\"surgeon1-485x150.png\";s:5:\"width\";i:485;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:15:\"bones-thumb-300\";a:4:{s:4:\"file\";s:20:\"surgeon1-300x100.png\";s:5:\"width\";i:300;s:6:\"height\";i:100;s:9:\"mime-type\";s:9:\"image/png\";}s:20:\"portfolio-two-column\";a:4:{s:4:\"file\";s:20:\"surgeon1-485x416.png\";s:5:\"width\";i:485;s:6:\"height\";i:416;s:9:\"mime-type\";s:9:\"image/png\";}s:22:\"portfolio-three-column\";a:4:{s:4:\"file\";s:20:\"surgeon1-370x270.png\";s:5:\"width\";i:370;s:6:\"height\";i:270;s:9:\"mime-type\";s:9:\"image/png\";}s:21:\"portfolio-four-column\";a:4:{s:4:\"file\";s:20:\"surgeon1-270x197.png\";s:5:\"width\";i:270;s:6:\"height\";i:197;s:9:\"mime-type\";s:9:\"image/png\";}s:17:\"portfolio-compact\";a:4:{s:4:\"file\";s:20:\"surgeon1-485x513.png\";s:5:\"width\";i:485;s:6:\"height\";i:513;s:9:\"mime-type\";s:9:\"image/png\";}s:10:\"blog-large\";a:4:{s:4:\"file\";s:20:\"surgeon1-485x270.png\";s:5:\"width\";i:485;s:6:\"height\";i:270;s:9:\"mime-type\";s:9:\"image/png\";}s:15:\"blog-full-width\";a:4:{s:4:\"file\";s:20:\"surgeon1-485x270.png\";s:5:\"width\";i:485;s:6:\"height\";i:270;s:9:\"mime-type\";s:9:\"image/png\";}s:11:\"blog-medium\";a:4:{s:4:\"file\";s:20:\"surgeon1-485x540.png\";s:5:\"width\";i:485;s:6:\"height\";i:540;s:9:\"mime-type\";s:9:\"image/png\";}s:9:\"blog-grid\";a:4:{s:4:\"file\";s:20:\"surgeon1-370x270.png\";s:5:\"width\";i:370;s:6:\"height\";i:270;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:20:\"surgeon1-125x125.png\";s:5:\"width\";i:125;s:6:\"height\";i:125;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES("1003","176","_wp_attached_file","2014/05/Black-Background-big1.png");
INSERT INTO `wp_postmeta` VALUES("1004","176","_wp_attachment_metadata","a:5:{s:5:\"width\";i:640;s:6:\"height\";i:746;s:4:\"file\";s:33:\"2014/05/Black-Background-big1.png\";s:5:\"sizes\";a:13:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:33:\"Black-Background-big1-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:33:\"Black-Background-big1-257x300.png\";s:5:\"width\";i:257;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";}s:15:\"bones-thumb-600\";a:4:{s:4:\"file\";s:33:\"Black-Background-big1-600x150.png\";s:5:\"width\";i:600;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:15:\"bones-thumb-300\";a:4:{s:4:\"file\";s:33:\"Black-Background-big1-300x100.png\";s:5:\"width\";i:300;s:6:\"height\";i:100;s:9:\"mime-type\";s:9:\"image/png\";}s:20:\"portfolio-two-column\";a:4:{s:4:\"file\";s:33:\"Black-Background-big1-570x416.png\";s:5:\"width\";i:570;s:6:\"height\";i:416;s:9:\"mime-type\";s:9:\"image/png\";}s:22:\"portfolio-three-column\";a:4:{s:4:\"file\";s:33:\"Black-Background-big1-370x270.png\";s:5:\"width\";i:370;s:6:\"height\";i:270;s:9:\"mime-type\";s:9:\"image/png\";}s:21:\"portfolio-four-column\";a:4:{s:4:\"file\";s:33:\"Black-Background-big1-270x197.png\";s:5:\"width\";i:270;s:6:\"height\";i:197;s:9:\"mime-type\";s:9:\"image/png\";}s:17:\"portfolio-compact\";a:4:{s:4:\"file\";s:33:\"Black-Background-big1-640x513.png\";s:5:\"width\";i:640;s:6:\"height\";i:513;s:9:\"mime-type\";s:9:\"image/png\";}s:10:\"blog-large\";a:4:{s:4:\"file\";s:33:\"Black-Background-big1-640x270.png\";s:5:\"width\";i:640;s:6:\"height\";i:270;s:9:\"mime-type\";s:9:\"image/png\";}s:15:\"blog-full-width\";a:4:{s:4:\"file\";s:33:\"Black-Background-big1-640x270.png\";s:5:\"width\";i:640;s:6:\"height\";i:270;s:9:\"mime-type\";s:9:\"image/png\";}s:11:\"blog-medium\";a:4:{s:4:\"file\";s:33:\"Black-Background-big1-640x540.png\";s:5:\"width\";i:640;s:6:\"height\";i:540;s:9:\"mime-type\";s:9:\"image/png\";}s:9:\"blog-grid\";a:4:{s:4:\"file\";s:33:\"Black-Background-big1-370x270.png\";s:5:\"width\";i:370;s:6:\"height\";i:270;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:33:\"Black-Background-big1-125x125.png\";s:5:\"width\";i:125;s:6:\"height\";i:125;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES("1005","177","_wp_attached_file","2014/05/Blue-Background.png");
INSERT INTO `wp_postmeta` VALUES("1006","177","_wp_attachment_metadata","a:5:{s:5:\"width\";i:640;s:6:\"height\";i:746;s:4:\"file\";s:27:\"2014/05/Blue-Background.png\";s:5:\"sizes\";a:13:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:27:\"Blue-Background-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:27:\"Blue-Background-257x300.png\";s:5:\"width\";i:257;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";}s:15:\"bones-thumb-600\";a:4:{s:4:\"file\";s:27:\"Blue-Background-600x150.png\";s:5:\"width\";i:600;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:15:\"bones-thumb-300\";a:4:{s:4:\"file\";s:27:\"Blue-Background-300x100.png\";s:5:\"width\";i:300;s:6:\"height\";i:100;s:9:\"mime-type\";s:9:\"image/png\";}s:20:\"portfolio-two-column\";a:4:{s:4:\"file\";s:27:\"Blue-Background-570x416.png\";s:5:\"width\";i:570;s:6:\"height\";i:416;s:9:\"mime-type\";s:9:\"image/png\";}s:22:\"portfolio-three-column\";a:4:{s:4:\"file\";s:27:\"Blue-Background-370x270.png\";s:5:\"width\";i:370;s:6:\"height\";i:270;s:9:\"mime-type\";s:9:\"image/png\";}s:21:\"portfolio-four-column\";a:4:{s:4:\"file\";s:27:\"Blue-Background-270x197.png\";s:5:\"width\";i:270;s:6:\"height\";i:197;s:9:\"mime-type\";s:9:\"image/png\";}s:17:\"portfolio-compact\";a:4:{s:4:\"file\";s:27:\"Blue-Background-640x513.png\";s:5:\"width\";i:640;s:6:\"height\";i:513;s:9:\"mime-type\";s:9:\"image/png\";}s:10:\"blog-large\";a:4:{s:4:\"file\";s:27:\"Blue-Background-640x270.png\";s:5:\"width\";i:640;s:6:\"height\";i:270;s:9:\"mime-type\";s:9:\"image/png\";}s:15:\"blog-full-width\";a:4:{s:4:\"file\";s:27:\"Blue-Background-640x270.png\";s:5:\"width\";i:640;s:6:\"height\";i:270;s:9:\"mime-type\";s:9:\"image/png\";}s:11:\"blog-medium\";a:4:{s:4:\"file\";s:27:\"Blue-Background-640x540.png\";s:5:\"width\";i:640;s:6:\"height\";i:540;s:9:\"mime-type\";s:9:\"image/png\";}s:9:\"blog-grid\";a:4:{s:4:\"file\";s:27:\"Blue-Background-370x270.png\";s:5:\"width\";i:370;s:6:\"height\";i:270;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:27:\"Blue-Background-125x125.png\";s:5:\"width\";i:125;s:6:\"height\";i:125;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES("1010","180","_wp_attached_file","2014/05/EyeWorld-May-2014_CLASS-act-Why-a-new-CO2-laser-is-competing-with-the-gold-standard.pdf");
INSERT INTO `wp_postmeta` VALUES("1011","180","_edit_lock","1400762119:2");
INSERT INTO `wp_postmeta` VALUES("1013","113","_edit_lock","1400762122:2");
INSERT INTO `wp_postmeta` VALUES("1021","185","_wp_attached_file","2014/05/Eurotimes-P43.pdf");
INSERT INTO `wp_postmeta` VALUES("1022","185","_edit_lock","1401093068:2");
INSERT INTO `wp_postmeta` VALUES("1035","193","_wp_attached_file","2014/06/Eyewire-Today-IOPtima-...tiMate-Systems-in-China”.pdf");
INSERT INTO `wp_postmeta` VALUES("1038","195","_wp_attached_file","2014/03/Nurit-Radin-–-VP-Marketing-Sales.jpg");
INSERT INTO `wp_postmeta` VALUES("1039","195","_wp_attachment_metadata","a:5:{s:5:\"width\";i:178;s:6:\"height\";i:178;s:4:\"file\";s:46:\"2014/03/Nurit-Radin-–-VP-Marketing-Sales.jpg\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:46:\"Nurit-Radin-–-VP-Marketing-Sales-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"bones-thumb-600\";a:4:{s:4:\"file\";s:46:\"Nurit-Radin-–-VP-Marketing-Sales-178x150.jpg\";s:5:\"width\";i:178;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"bones-thumb-300\";a:4:{s:4:\"file\";s:46:\"Nurit-Radin-–-VP-Marketing-Sales-178x100.jpg\";s:5:\"width\";i:178;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:46:\"Nurit-Radin-–-VP-Marketing-Sales-125x125.jpg\";s:5:\"width\";i:125;s:6:\"height\";i:125;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";d:7.0999999999999996447286321199499070644378662109375;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:5:\"NEX-7\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:1400766076;s:9:\"copyright\";s:13:\"Peled Studios\";s:12:\"focal_length\";s:2:\"56\";s:3:\"iso\";s:3:\"200\";s:13:\"shutter_speed\";s:4:\"0.05\";s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES("1040","196","_wp_attached_file","2014/03/Ronen-Castro-–-CEO.jpg");
INSERT INTO `wp_postmeta` VALUES("1041","196","_wp_attachment_metadata","a:5:{s:5:\"width\";i:178;s:6:\"height\";i:178;s:4:\"file\";s:32:\"2014/03/Ronen-Castro-–-CEO.jpg\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:32:\"Ronen-Castro-–-CEO-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"bones-thumb-600\";a:4:{s:4:\"file\";s:32:\"Ronen-Castro-–-CEO-178x150.jpg\";s:5:\"width\";i:178;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"bones-thumb-300\";a:4:{s:4:\"file\";s:32:\"Ronen-Castro-–-CEO-178x100.jpg\";s:5:\"width\";i:178;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:32:\"Ronen-Castro-–-CEO-125x125.jpg\";s:5:\"width\";i:125;s:6:\"height\";i:125;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";d:5;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:5:\"NEX-7\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:1400763152;s:9:\"copyright\";s:13:\"Peled Studios\";s:12:\"focal_length\";s:2:\"61\";s:3:\"iso\";s:3:\"100\";s:13:\"shutter_speed\";s:4:\"0.04\";s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES("1042","197","_wp_attached_file","2014/03/Amnon-Nahum-Sharon-–-COO.jpg");
INSERT INTO `wp_postmeta` VALUES("1043","197","_wp_attachment_metadata","a:5:{s:5:\"width\";i:178;s:6:\"height\";i:178;s:4:\"file\";s:38:\"2014/03/Amnon-Nahum-Sharon-–-COO.jpg\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:38:\"Amnon-Nahum-Sharon-–-COO-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"bones-thumb-600\";a:4:{s:4:\"file\";s:38:\"Amnon-Nahum-Sharon-–-COO-178x150.jpg\";s:5:\"width\";i:178;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"bones-thumb-300\";a:4:{s:4:\"file\";s:38:\"Amnon-Nahum-Sharon-–-COO-178x100.jpg\";s:5:\"width\";i:178;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:38:\"Amnon-Nahum-Sharon-–-COO-125x125.jpg\";s:5:\"width\";i:125;s:6:\"height\";i:125;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";d:7.0999999999999996447286321199499070644378662109375;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:5:\"NEX-7\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:1400764319;s:9:\"copyright\";s:13:\"Peled Studios\";s:12:\"focal_length\";s:2:\"61\";s:3:\"iso\";s:3:\"200\";s:13:\"shutter_speed\";s:4:\"0.05\";s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES("1044","198","_wp_attached_file","2014/03/Assaf-Gur-–-CTO.jpg");
INSERT INTO `wp_postmeta` VALUES("1045","198","_wp_attachment_metadata","a:5:{s:5:\"width\";i:178;s:6:\"height\";i:178;s:4:\"file\";s:29:\"2014/03/Assaf-Gur-–-CTO.jpg\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:29:\"Assaf-Gur-–-CTO-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"bones-thumb-600\";a:4:{s:4:\"file\";s:29:\"Assaf-Gur-–-CTO-178x150.jpg\";s:5:\"width\";i:178;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"bones-thumb-300\";a:4:{s:4:\"file\";s:29:\"Assaf-Gur-–-CTO-178x100.jpg\";s:5:\"width\";i:178;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:29:\"Assaf-Gur-–-CTO-125x125.jpg\";s:5:\"width\";i:125;s:6:\"height\";i:125;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";d:7.0999999999999996447286321199499070644378662109375;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:5:\"NEX-7\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:1400764499;s:9:\"copyright\";s:13:\"Peled Studios\";s:12:\"focal_length\";s:2:\"56\";s:3:\"iso\";s:3:\"200\";s:13:\"shutter_speed\";s:4:\"0.05\";s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES("1046","199","_wp_attached_file","2014/03/Itai-Bar-Natan-–-CFO.jpg");
INSERT INTO `wp_postmeta` VALUES("1047","199","_wp_attachment_metadata","a:5:{s:5:\"width\";i:178;s:6:\"height\";i:178;s:4:\"file\";s:34:\"2014/03/Itai-Bar-Natan-–-CFO.jpg\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:34:\"Itai-Bar-Natan-–-CFO-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"bones-thumb-600\";a:4:{s:4:\"file\";s:34:\"Itai-Bar-Natan-–-CFO-178x150.jpg\";s:5:\"width\";i:178;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"bones-thumb-300\";a:4:{s:4:\"file\";s:34:\"Itai-Bar-Natan-–-CFO-178x100.jpg\";s:5:\"width\";i:178;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:34:\"Itai-Bar-Natan-–-CFO-125x125.jpg\";s:5:\"width\";i:125;s:6:\"height\";i:125;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";d:7.0999999999999996447286321199499070644378662109375;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:5:\"NEX-7\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:1400763973;s:9:\"copyright\";s:13:\"Peled Studios\";s:12:\"focal_length\";s:2:\"61\";s:3:\"iso\";s:3:\"200\";s:13:\"shutter_speed\";s:4:\"0.05\";s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES("1048","200","_wp_attached_file","2014/06/Ophthalmology-time-US-CO2-laser-surgery-a-new-option-for-glaucoma.pdf");
INSERT INTO `wp_postmeta` VALUES("1049","201","_wp_attached_file","2014/06/Ophthalmology-time-EU-CLASS_May14_pdf-Assia-and-Melamed.pdf");
INSERT INTO `wp_postmeta` VALUES("1053","201","_edit_lock","1402318244:2");
INSERT INTO `wp_postmeta` VALUES("1054","200","_edit_lock","1402318667:2");
INSERT INTO `wp_postmeta` VALUES("1055","205","_wp_attached_file","2014/06/Ablation-Patterns_1.jpg");
INSERT INTO `wp_postmeta` VALUES("1056","205","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1000;s:6:\"height\";i:945;s:4:\"file\";s:31:\"2014/06/Ablation-Patterns_1.jpg\";s:5:\"sizes\";a:14:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:31:\"Ablation-Patterns_1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:31:\"Ablation-Patterns_1-300x283.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:283;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"bones-thumb-600\";a:4:{s:4:\"file\";s:31:\"Ablation-Patterns_1-600x150.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"bones-thumb-300\";a:4:{s:4:\"file\";s:31:\"Ablation-Patterns_1-300x100.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:20:\"portfolio-one-column\";a:4:{s:4:\"file\";s:32:\"Ablation-Patterns_1-1000x854.jpg\";s:5:\"width\";i:1000;s:6:\"height\";i:854;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:20:\"portfolio-two-column\";a:4:{s:4:\"file\";s:31:\"Ablation-Patterns_1-570x416.jpg\";s:5:\"width\";i:570;s:6:\"height\";i:416;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:22:\"portfolio-three-column\";a:4:{s:4:\"file\";s:31:\"Ablation-Patterns_1-370x270.jpg\";s:5:\"width\";i:370;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"portfolio-four-column\";a:4:{s:4:\"file\";s:31:\"Ablation-Patterns_1-270x197.jpg\";s:5:\"width\";i:270;s:6:\"height\";i:197;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:17:\"portfolio-compact\";a:4:{s:4:\"file\";s:31:\"Ablation-Patterns_1-770x513.jpg\";s:5:\"width\";i:770;s:6:\"height\";i:513;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:10:\"blog-large\";a:4:{s:4:\"file\";s:31:\"Ablation-Patterns_1-770x270.jpg\";s:5:\"width\";i:770;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"blog-full-width\";a:4:{s:4:\"file\";s:32:\"Ablation-Patterns_1-1000x270.jpg\";s:5:\"width\";i:1000;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"blog-medium\";a:4:{s:4:\"file\";s:31:\"Ablation-Patterns_1-740x540.jpg\";s:5:\"width\";i:740;s:6:\"height\";i:540;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"blog-grid\";a:4:{s:4:\"file\";s:31:\"Ablation-Patterns_1-370x270.jpg\";s:5:\"width\";i:370;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:31:\"Ablation-Patterns_1-125x125.jpg\";s:5:\"width\";i:125;s:6:\"height\";i:125;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES("1057","205","_edit_lock","1402319352:2");
INSERT INTO `wp_postmeta` VALUES("1058","208","_wp_attached_file","2014/03/Ronen-Castro-–-CEO-2.jpg");
INSERT INTO `wp_postmeta` VALUES("1059","208","_wp_attachment_metadata","a:5:{s:5:\"width\";i:178;s:6:\"height\";i:178;s:4:\"file\";s:34:\"2014/03/Ronen-Castro-–-CEO-2.jpg\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:34:\"Ronen-Castro-–-CEO-2-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"bones-thumb-600\";a:4:{s:4:\"file\";s:34:\"Ronen-Castro-–-CEO-2-178x150.jpg\";s:5:\"width\";i:178;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"bones-thumb-300\";a:4:{s:4:\"file\";s:34:\"Ronen-Castro-–-CEO-2-178x100.jpg\";s:5:\"width\";i:178;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:34:\"Ronen-Castro-–-CEO-2-125x125.jpg\";s:5:\"width\";i:125;s:6:\"height\";i:125;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";d:5;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:5:\"NEX-7\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:1400763152;s:9:\"copyright\";s:13:\"Peled Studios\";s:12:\"focal_length\";s:2:\"61\";s:3:\"iso\";s:3:\"100\";s:13:\"shutter_speed\";s:4:\"0.04\";s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES("1063","211","_wp_attached_file","2014/06/Maital.jpg");
INSERT INTO `wp_postmeta` VALUES("1064","211","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1500;s:6:\"height\";i:1000;s:4:\"file\";s:18:\"2014/06/Maital.jpg\";s:5:\"sizes\";a:15:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"Maital-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:18:\"Maital-300x200.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:200;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:19:\"Maital-1024x682.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:682;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"bones-thumb-600\";a:4:{s:4:\"file\";s:18:\"Maital-600x150.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"bones-thumb-300\";a:4:{s:4:\"file\";s:18:\"Maital-300x100.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:20:\"portfolio-one-column\";a:4:{s:4:\"file\";s:19:\"Maital-1170x854.jpg\";s:5:\"width\";i:1170;s:6:\"height\";i:854;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:20:\"portfolio-two-column\";a:4:{s:4:\"file\";s:18:\"Maital-570x416.jpg\";s:5:\"width\";i:570;s:6:\"height\";i:416;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:22:\"portfolio-three-column\";a:4:{s:4:\"file\";s:18:\"Maital-370x270.jpg\";s:5:\"width\";i:370;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"portfolio-four-column\";a:4:{s:4:\"file\";s:18:\"Maital-270x197.jpg\";s:5:\"width\";i:270;s:6:\"height\";i:197;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:17:\"portfolio-compact\";a:4:{s:4:\"file\";s:18:\"Maital-770x513.jpg\";s:5:\"width\";i:770;s:6:\"height\";i:513;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:10:\"blog-large\";a:4:{s:4:\"file\";s:18:\"Maital-770x270.jpg\";s:5:\"width\";i:770;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"blog-full-width\";a:4:{s:4:\"file\";s:19:\"Maital-1170x270.jpg\";s:5:\"width\";i:1170;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"blog-medium\";a:4:{s:4:\"file\";s:18:\"Maital-740x540.jpg\";s:5:\"width\";i:740;s:6:\"height\";i:540;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"blog-grid\";a:4:{s:4:\"file\";s:18:\"Maital-370x270.jpg\";s:5:\"width\";i:370;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:18:\"Maital-125x125.jpg\";s:5:\"width\";i:125;s:6:\"height\";i:125;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";d:7.0999999999999996447286321199499070644378662109375;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:5:\"NEX-7\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:1400764724;s:9:\"copyright\";s:13:\"Peled Studios\";s:12:\"focal_length\";s:2:\"56\";s:3:\"iso\";s:3:\"200\";s:13:\"shutter_speed\";s:4:\"0.05\";s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES("1065","211","_edit_lock","1403506693:2");
INSERT INTO `wp_postmeta` VALUES("1066","212","_wp_attached_file","2014/03/Maital-Ben-Hur-–-Clinical-Manager-2.jpg");
INSERT INTO `wp_postmeta` VALUES("1067","212","_wp_attachment_metadata","a:5:{s:5:\"width\";i:178;s:6:\"height\";i:178;s:4:\"file\";s:49:\"2014/03/Maital-Ben-Hur-–-Clinical-Manager-2.jpg\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:49:\"Maital-Ben-Hur-–-Clinical-Manager-2-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"bones-thumb-600\";a:4:{s:4:\"file\";s:49:\"Maital-Ben-Hur-–-Clinical-Manager-2-178x150.jpg\";s:5:\"width\";i:178;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"bones-thumb-300\";a:4:{s:4:\"file\";s:49:\"Maital-Ben-Hur-–-Clinical-Manager-2-178x100.jpg\";s:5:\"width\";i:178;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:49:\"Maital-Ben-Hur-–-Clinical-Manager-2-125x125.jpg\";s:5:\"width\";i:125;s:6:\"height\";i:125;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";d:7.0999999999999996447286321199499070644378662109375;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:5:\"NEX-7\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:1400764752;s:9:\"copyright\";s:13:\"Peled Studios\";s:12:\"focal_length\";s:2:\"56\";s:3:\"iso\";s:3:\"200\";s:13:\"shutter_speed\";s:4:\"0.05\";s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES("1068","213","_wp_attached_file","2014/03/Maital-Ben-Hur-–-Clinical-Manager-3.jpg");
INSERT INTO `wp_postmeta` VALUES("1069","213","_wp_attachment_metadata","a:5:{s:5:\"width\";i:178;s:6:\"height\";i:178;s:4:\"file\";s:49:\"2014/03/Maital-Ben-Hur-–-Clinical-Manager-3.jpg\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:49:\"Maital-Ben-Hur-–-Clinical-Manager-3-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"bones-thumb-600\";a:4:{s:4:\"file\";s:49:\"Maital-Ben-Hur-–-Clinical-Manager-3-178x150.jpg\";s:5:\"width\";i:178;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"bones-thumb-300\";a:4:{s:4:\"file\";s:49:\"Maital-Ben-Hur-–-Clinical-Manager-3-178x100.jpg\";s:5:\"width\";i:178;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:49:\"Maital-Ben-Hur-–-Clinical-Manager-3-125x125.jpg\";s:5:\"width\";i:125;s:6:\"height\";i:125;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";d:7.0999999999999996447286321199499070644378662109375;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:5:\"NEX-7\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:1400764752;s:9:\"copyright\";s:13:\"Peled Studios\";s:12:\"focal_length\";s:2:\"56\";s:3:\"iso\";s:3:\"200\";s:13:\"shutter_speed\";s:4:\"0.05\";s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES("1072","217","_wp_attached_file","2014/03/P254-Mauricio-Turati.pdf");
INSERT INTO `wp_postmeta` VALUES("1073","217","_edit_lock","1404281217:2");
INSERT INTO `wp_postmeta` VALUES("1074","218","_wp_attached_file","2014/07/P254-Mauricio-Turati-page-001.jpg");
INSERT INTO `wp_postmeta` VALUES("1075","218","_wp_attachment_metadata","a:5:{s:5:\"width\";i:5316;s:6:\"height\";i:8400;s:4:\"file\";s:41:\"2014/07/P254-Mauricio-Turati-page-001.jpg\";s:5:\"sizes\";a:15:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:41:\"P254-Mauricio-Turati-page-001-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:41:\"P254-Mauricio-Turati-page-001-189x300.jpg\";s:5:\"width\";i:189;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:42:\"P254-Mauricio-Turati-page-001-648x1024.jpg\";s:5:\"width\";i:648;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"bones-thumb-600\";a:4:{s:4:\"file\";s:41:\"P254-Mauricio-Turati-page-001-600x150.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"bones-thumb-300\";a:4:{s:4:\"file\";s:41:\"P254-Mauricio-Turati-page-001-300x100.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:20:\"portfolio-one-column\";a:4:{s:4:\"file\";s:42:\"P254-Mauricio-Turati-page-001-1170x854.jpg\";s:5:\"width\";i:1170;s:6:\"height\";i:854;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:20:\"portfolio-two-column\";a:4:{s:4:\"file\";s:41:\"P254-Mauricio-Turati-page-001-570x416.jpg\";s:5:\"width\";i:570;s:6:\"height\";i:416;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:22:\"portfolio-three-column\";a:4:{s:4:\"file\";s:41:\"P254-Mauricio-Turati-page-001-370x270.jpg\";s:5:\"width\";i:370;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"portfolio-four-column\";a:4:{s:4:\"file\";s:41:\"P254-Mauricio-Turati-page-001-270x197.jpg\";s:5:\"width\";i:270;s:6:\"height\";i:197;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:17:\"portfolio-compact\";a:4:{s:4:\"file\";s:41:\"P254-Mauricio-Turati-page-001-770x513.jpg\";s:5:\"width\";i:770;s:6:\"height\";i:513;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:10:\"blog-large\";a:4:{s:4:\"file\";s:41:\"P254-Mauricio-Turati-page-001-770x270.jpg\";s:5:\"width\";i:770;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"blog-full-width\";a:4:{s:4:\"file\";s:42:\"P254-Mauricio-Turati-page-001-1170x270.jpg\";s:5:\"width\";i:1170;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"blog-medium\";a:4:{s:4:\"file\";s:41:\"P254-Mauricio-Turati-page-001-740x540.jpg\";s:5:\"width\";i:740;s:6:\"height\";i:540;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"blog-grid\";a:4:{s:4:\"file\";s:41:\"P254-Mauricio-Turati-page-001-370x270.jpg\";s:5:\"width\";i:370;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:41:\"P254-Mauricio-Turati-page-001-125x125.jpg\";s:5:\"width\";i:125;s:6:\"height\";i:125;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES("1076","219","_wp_attached_file","2014/03/P254-Mauricio-Turati-page-001.jpg");
INSERT INTO `wp_postmeta` VALUES("1077","219","_wp_attachment_metadata","a:5:{s:5:\"width\";i:5316;s:6:\"height\";i:8400;s:4:\"file\";s:41:\"2014/03/P254-Mauricio-Turati-page-001.jpg\";s:5:\"sizes\";a:15:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:41:\"P254-Mauricio-Turati-page-001-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:41:\"P254-Mauricio-Turati-page-001-189x300.jpg\";s:5:\"width\";i:189;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:42:\"P254-Mauricio-Turati-page-001-648x1024.jpg\";s:5:\"width\";i:648;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"bones-thumb-600\";a:4:{s:4:\"file\";s:41:\"P254-Mauricio-Turati-page-001-600x150.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"bones-thumb-300\";a:4:{s:4:\"file\";s:41:\"P254-Mauricio-Turati-page-001-300x100.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:20:\"portfolio-one-column\";a:4:{s:4:\"file\";s:42:\"P254-Mauricio-Turati-page-001-1170x854.jpg\";s:5:\"width\";i:1170;s:6:\"height\";i:854;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:20:\"portfolio-two-column\";a:4:{s:4:\"file\";s:41:\"P254-Mauricio-Turati-page-001-570x416.jpg\";s:5:\"width\";i:570;s:6:\"height\";i:416;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:22:\"portfolio-three-column\";a:4:{s:4:\"file\";s:41:\"P254-Mauricio-Turati-page-001-370x270.jpg\";s:5:\"width\";i:370;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"portfolio-four-column\";a:4:{s:4:\"file\";s:41:\"P254-Mauricio-Turati-page-001-270x197.jpg\";s:5:\"width\";i:270;s:6:\"height\";i:197;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:17:\"portfolio-compact\";a:4:{s:4:\"file\";s:41:\"P254-Mauricio-Turati-page-001-770x513.jpg\";s:5:\"width\";i:770;s:6:\"height\";i:513;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:10:\"blog-large\";a:4:{s:4:\"file\";s:41:\"P254-Mauricio-Turati-page-001-770x270.jpg\";s:5:\"width\";i:770;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"blog-full-width\";a:4:{s:4:\"file\";s:42:\"P254-Mauricio-Turati-page-001-1170x270.jpg\";s:5:\"width\";i:1170;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"blog-medium\";a:4:{s:4:\"file\";s:41:\"P254-Mauricio-Turati-page-001-740x540.jpg\";s:5:\"width\";i:740;s:6:\"height\";i:540;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"blog-grid\";a:4:{s:4:\"file\";s:41:\"P254-Mauricio-Turati-page-001-370x270.jpg\";s:5:\"width\";i:370;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:41:\"P254-Mauricio-Turati-page-001-125x125.jpg\";s:5:\"width\";i:125;s:6:\"height\";i:125;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES("1078","220","_wp_attached_file","2014/03/EyeWorld-May-2014_CLASS-act-Why-a-new-CO2-laser-is-competing-with-the-gold-standard-page-001.jpg");
INSERT INTO `wp_postmeta` VALUES("1079","220","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1500;s:6:\"height\";i:1950;s:4:\"file\";s:104:\"2014/03/EyeWorld-May-2014_CLASS-act-Why-a-new-CO2-laser-is-competing-with-the-gold-standard-page-001.jpg\";s:5:\"sizes\";a:15:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:104:\"EyeWorld-May-2014_CLASS-act-Why-a-new-CO2-laser-is-competing-with-the-gold-standard-page-001-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:104:\"EyeWorld-May-2014_CLASS-act-Why-a-new-CO2-laser-is-competing-with-the-gold-standard-page-001-230x300.jpg\";s:5:\"width\";i:230;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:105:\"EyeWorld-May-2014_CLASS-act-Why-a-new-CO2-laser-is-competing-with-the-gold-standard-page-001-787x1024.jpg\";s:5:\"width\";i:787;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"bones-thumb-600\";a:4:{s:4:\"file\";s:104:\"EyeWorld-May-2014_CLASS-act-Why-a-new-CO2-laser-is-competing-with-the-gold-standard-page-001-600x150.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"bones-thumb-300\";a:4:{s:4:\"file\";s:104:\"EyeWorld-May-2014_CLASS-act-Why-a-new-CO2-laser-is-competing-with-the-gold-standard-page-001-300x100.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:20:\"portfolio-one-column\";a:4:{s:4:\"file\";s:105:\"EyeWorld-May-2014_CLASS-act-Why-a-new-CO2-laser-is-competing-with-the-gold-standard-page-001-1170x854.jpg\";s:5:\"width\";i:1170;s:6:\"height\";i:854;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:20:\"portfolio-two-column\";a:4:{s:4:\"file\";s:104:\"EyeWorld-May-2014_CLASS-act-Why-a-new-CO2-laser-is-competing-with-the-gold-standard-page-001-570x416.jpg\";s:5:\"width\";i:570;s:6:\"height\";i:416;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:22:\"portfolio-three-column\";a:4:{s:4:\"file\";s:104:\"EyeWorld-May-2014_CLASS-act-Why-a-new-CO2-laser-is-competing-with-the-gold-standard-page-001-370x270.jpg\";s:5:\"width\";i:370;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"portfolio-four-column\";a:4:{s:4:\"file\";s:104:\"EyeWorld-May-2014_CLASS-act-Why-a-new-CO2-laser-is-competing-with-the-gold-standard-page-001-270x197.jpg\";s:5:\"width\";i:270;s:6:\"height\";i:197;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:17:\"portfolio-compact\";a:4:{s:4:\"file\";s:104:\"EyeWorld-May-2014_CLASS-act-Why-a-new-CO2-laser-is-competing-with-the-gold-standard-page-001-770x513.jpg\";s:5:\"width\";i:770;s:6:\"height\";i:513;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:10:\"blog-large\";a:4:{s:4:\"file\";s:104:\"EyeWorld-May-2014_CLASS-act-Why-a-new-CO2-laser-is-competing-with-the-gold-standard-page-001-770x270.jpg\";s:5:\"width\";i:770;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"blog-full-width\";a:4:{s:4:\"file\";s:105:\"EyeWorld-May-2014_CLASS-act-Why-a-new-CO2-laser-is-competing-with-the-gold-standard-page-001-1170x270.jpg\";s:5:\"width\";i:1170;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"blog-medium\";a:4:{s:4:\"file\";s:104:\"EyeWorld-May-2014_CLASS-act-Why-a-new-CO2-laser-is-competing-with-the-gold-standard-page-001-740x540.jpg\";s:5:\"width\";i:740;s:6:\"height\";i:540;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"blog-grid\";a:4:{s:4:\"file\";s:104:\"EyeWorld-May-2014_CLASS-act-Why-a-new-CO2-laser-is-competing-with-the-gold-standard-page-001-370x270.jpg\";s:5:\"width\";i:370;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:104:\"EyeWorld-May-2014_CLASS-act-Why-a-new-CO2-laser-is-competing-with-the-gold-standard-page-001-125x125.jpg\";s:5:\"width\";i:125;s:6:\"height\";i:125;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES("1080","221","_wp_attached_file","2014/03/CLASS-y-Laser-Treats-Glaucoma-Asia-page-001.jpg");
INSERT INTO `wp_postmeta` VALUES("1081","221","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1650;s:6:\"height\";i:1275;s:4:\"file\";s:55:\"2014/03/CLASS-y-Laser-Treats-Glaucoma-Asia-page-001.jpg\";s:5:\"sizes\";a:15:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:55:\"CLASS-y-Laser-Treats-Glaucoma-Asia-page-001-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:55:\"CLASS-y-Laser-Treats-Glaucoma-Asia-page-001-300x231.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:231;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:56:\"CLASS-y-Laser-Treats-Glaucoma-Asia-page-001-1024x791.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:791;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"bones-thumb-600\";a:4:{s:4:\"file\";s:55:\"CLASS-y-Laser-Treats-Glaucoma-Asia-page-001-600x150.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"bones-thumb-300\";a:4:{s:4:\"file\";s:55:\"CLASS-y-Laser-Treats-Glaucoma-Asia-page-001-300x100.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:20:\"portfolio-one-column\";a:4:{s:4:\"file\";s:56:\"CLASS-y-Laser-Treats-Glaucoma-Asia-page-001-1170x854.jpg\";s:5:\"width\";i:1170;s:6:\"height\";i:854;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:20:\"portfolio-two-column\";a:4:{s:4:\"file\";s:55:\"CLASS-y-Laser-Treats-Glaucoma-Asia-page-001-570x416.jpg\";s:5:\"width\";i:570;s:6:\"height\";i:416;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:22:\"portfolio-three-column\";a:4:{s:4:\"file\";s:55:\"CLASS-y-Laser-Treats-Glaucoma-Asia-page-001-370x270.jpg\";s:5:\"width\";i:370;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"portfolio-four-column\";a:4:{s:4:\"file\";s:55:\"CLASS-y-Laser-Treats-Glaucoma-Asia-page-001-270x197.jpg\";s:5:\"width\";i:270;s:6:\"height\";i:197;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:17:\"portfolio-compact\";a:4:{s:4:\"file\";s:55:\"CLASS-y-Laser-Treats-Glaucoma-Asia-page-001-770x513.jpg\";s:5:\"width\";i:770;s:6:\"height\";i:513;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:10:\"blog-large\";a:4:{s:4:\"file\";s:55:\"CLASS-y-Laser-Treats-Glaucoma-Asia-page-001-770x270.jpg\";s:5:\"width\";i:770;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"blog-full-width\";a:4:{s:4:\"file\";s:56:\"CLASS-y-Laser-Treats-Glaucoma-Asia-page-001-1170x270.jpg\";s:5:\"width\";i:1170;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"blog-medium\";a:4:{s:4:\"file\";s:55:\"CLASS-y-Laser-Treats-Glaucoma-Asia-page-001-740x540.jpg\";s:5:\"width\";i:740;s:6:\"height\";i:540;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"blog-grid\";a:4:{s:4:\"file\";s:55:\"CLASS-y-Laser-Treats-Glaucoma-Asia-page-001-370x270.jpg\";s:5:\"width\";i:370;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:55:\"CLASS-y-Laser-Treats-Glaucoma-Asia-page-001-125x125.jpg\";s:5:\"width\";i:125;s:6:\"height\";i:125;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES("1082","222","_wp_attached_file","2014/03/Ophthalmology-time-EU-CLASS_May14_pdf-Assia-and-Melamed-page-001.jpg");
INSERT INTO `wp_postmeta` VALUES("1083","222","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1275;s:6:\"height\";i:1650;s:4:\"file\";s:76:\"2014/03/Ophthalmology-time-EU-CLASS_May14_pdf-Assia-and-Melamed-page-001.jpg\";s:5:\"sizes\";a:15:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:76:\"Ophthalmology-time-EU-CLASS_May14_pdf-Assia-and-Melamed-page-001-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:76:\"Ophthalmology-time-EU-CLASS_May14_pdf-Assia-and-Melamed-page-001-231x300.jpg\";s:5:\"width\";i:231;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:77:\"Ophthalmology-time-EU-CLASS_May14_pdf-Assia-and-Melamed-page-001-791x1024.jpg\";s:5:\"width\";i:791;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"bones-thumb-600\";a:4:{s:4:\"file\";s:76:\"Ophthalmology-time-EU-CLASS_May14_pdf-Assia-and-Melamed-page-001-600x150.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"bones-thumb-300\";a:4:{s:4:\"file\";s:76:\"Ophthalmology-time-EU-CLASS_May14_pdf-Assia-and-Melamed-page-001-300x100.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:20:\"portfolio-one-column\";a:4:{s:4:\"file\";s:77:\"Ophthalmology-time-EU-CLASS_May14_pdf-Assia-and-Melamed-page-001-1170x854.jpg\";s:5:\"width\";i:1170;s:6:\"height\";i:854;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:20:\"portfolio-two-column\";a:4:{s:4:\"file\";s:76:\"Ophthalmology-time-EU-CLASS_May14_pdf-Assia-and-Melamed-page-001-570x416.jpg\";s:5:\"width\";i:570;s:6:\"height\";i:416;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:22:\"portfolio-three-column\";a:4:{s:4:\"file\";s:76:\"Ophthalmology-time-EU-CLASS_May14_pdf-Assia-and-Melamed-page-001-370x270.jpg\";s:5:\"width\";i:370;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"portfolio-four-column\";a:4:{s:4:\"file\";s:76:\"Ophthalmology-time-EU-CLASS_May14_pdf-Assia-and-Melamed-page-001-270x197.jpg\";s:5:\"width\";i:270;s:6:\"height\";i:197;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:17:\"portfolio-compact\";a:4:{s:4:\"file\";s:76:\"Ophthalmology-time-EU-CLASS_May14_pdf-Assia-and-Melamed-page-001-770x513.jpg\";s:5:\"width\";i:770;s:6:\"height\";i:513;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:10:\"blog-large\";a:4:{s:4:\"file\";s:76:\"Ophthalmology-time-EU-CLASS_May14_pdf-Assia-and-Melamed-page-001-770x270.jpg\";s:5:\"width\";i:770;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"blog-full-width\";a:4:{s:4:\"file\";s:77:\"Ophthalmology-time-EU-CLASS_May14_pdf-Assia-and-Melamed-page-001-1170x270.jpg\";s:5:\"width\";i:1170;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"blog-medium\";a:4:{s:4:\"file\";s:76:\"Ophthalmology-time-EU-CLASS_May14_pdf-Assia-and-Melamed-page-001-740x540.jpg\";s:5:\"width\";i:740;s:6:\"height\";i:540;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"blog-grid\";a:4:{s:4:\"file\";s:76:\"Ophthalmology-time-EU-CLASS_May14_pdf-Assia-and-Melamed-page-001-370x270.jpg\";s:5:\"width\";i:370;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:76:\"Ophthalmology-time-EU-CLASS_May14_pdf-Assia-and-Melamed-page-001-125x125.jpg\";s:5:\"width\";i:125;s:6:\"height\";i:125;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES("1084","223","_wp_attached_file","2014/07/Ophthalmology-time-EU-CLASS_May14_pdf-Assia-and-Melamed.pdf");
INSERT INTO `wp_postmeta` VALUES("1085","223","_edit_lock","1404287277:2");
INSERT INTO `wp_postmeta` VALUES("1086","224","_wp_attached_file","2014/03/Ophthalmology-time-US-CO2-laser-surgery-a-new-option-for-glaucoma-page-001.jpg");
INSERT INTO `wp_postmeta` VALUES("1087","224","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1240;s:6:\"height\";i:1754;s:4:\"file\";s:86:\"2014/03/Ophthalmology-time-US-CO2-laser-surgery-a-new-option-for-glaucoma-page-001.jpg\";s:5:\"sizes\";a:15:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:86:\"Ophthalmology-time-US-CO2-laser-surgery-a-new-option-for-glaucoma-page-001-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:86:\"Ophthalmology-time-US-CO2-laser-surgery-a-new-option-for-glaucoma-page-001-212x300.jpg\";s:5:\"width\";i:212;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:87:\"Ophthalmology-time-US-CO2-laser-surgery-a-new-option-for-glaucoma-page-001-723x1024.jpg\";s:5:\"width\";i:723;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"bones-thumb-600\";a:4:{s:4:\"file\";s:86:\"Ophthalmology-time-US-CO2-laser-surgery-a-new-option-for-glaucoma-page-001-600x150.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"bones-thumb-300\";a:4:{s:4:\"file\";s:86:\"Ophthalmology-time-US-CO2-laser-surgery-a-new-option-for-glaucoma-page-001-300x100.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:20:\"portfolio-one-column\";a:4:{s:4:\"file\";s:87:\"Ophthalmology-time-US-CO2-laser-surgery-a-new-option-for-glaucoma-page-001-1170x854.jpg\";s:5:\"width\";i:1170;s:6:\"height\";i:854;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:20:\"portfolio-two-column\";a:4:{s:4:\"file\";s:86:\"Ophthalmology-time-US-CO2-laser-surgery-a-new-option-for-glaucoma-page-001-570x416.jpg\";s:5:\"width\";i:570;s:6:\"height\";i:416;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:22:\"portfolio-three-column\";a:4:{s:4:\"file\";s:86:\"Ophthalmology-time-US-CO2-laser-surgery-a-new-option-for-glaucoma-page-001-370x270.jpg\";s:5:\"width\";i:370;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"portfolio-four-column\";a:4:{s:4:\"file\";s:86:\"Ophthalmology-time-US-CO2-laser-surgery-a-new-option-for-glaucoma-page-001-270x197.jpg\";s:5:\"width\";i:270;s:6:\"height\";i:197;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:17:\"portfolio-compact\";a:4:{s:4:\"file\";s:86:\"Ophthalmology-time-US-CO2-laser-surgery-a-new-option-for-glaucoma-page-001-770x513.jpg\";s:5:\"width\";i:770;s:6:\"height\";i:513;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:10:\"blog-large\";a:4:{s:4:\"file\";s:86:\"Ophthalmology-time-US-CO2-laser-surgery-a-new-option-for-glaucoma-page-001-770x270.jpg\";s:5:\"width\";i:770;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"blog-full-width\";a:4:{s:4:\"file\";s:87:\"Ophthalmology-time-US-CO2-laser-surgery-a-new-option-for-glaucoma-page-001-1170x270.jpg\";s:5:\"width\";i:1170;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"blog-medium\";a:4:{s:4:\"file\";s:86:\"Ophthalmology-time-US-CO2-laser-surgery-a-new-option-for-glaucoma-page-001-740x540.jpg\";s:5:\"width\";i:740;s:6:\"height\";i:540;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"blog-grid\";a:4:{s:4:\"file\";s:86:\"Ophthalmology-time-US-CO2-laser-surgery-a-new-option-for-glaucoma-page-001-370x270.jpg\";s:5:\"width\";i:370;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:86:\"Ophthalmology-time-US-CO2-laser-surgery-a-new-option-for-glaucoma-page-001-125x125.jpg\";s:5:\"width\";i:125;s:6:\"height\";i:125;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES("1088","225","_wp_attached_file","2014/07/Ophthalmology-time-US-CO2-laser-surgery-a-new-option-for-glaucoma.pdf");
INSERT INTO `wp_postmeta` VALUES("1089","225","_edit_lock","1404292494:2");
INSERT INTO `wp_postmeta` VALUES("1090","226","_wp_attached_file","2014/03/eurotimes-industy-brief-may-2014-p-43-page-001.jpg");
INSERT INTO `wp_postmeta` VALUES("1091","226","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1240;s:6:\"height\";i:1754;s:4:\"file\";s:58:\"2014/03/eurotimes-industy-brief-may-2014-p-43-page-001.jpg\";s:5:\"sizes\";a:15:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:58:\"eurotimes-industy-brief-may-2014-p-43-page-001-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:58:\"eurotimes-industy-brief-may-2014-p-43-page-001-212x300.jpg\";s:5:\"width\";i:212;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:59:\"eurotimes-industy-brief-may-2014-p-43-page-001-723x1024.jpg\";s:5:\"width\";i:723;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"bones-thumb-600\";a:4:{s:4:\"file\";s:58:\"eurotimes-industy-brief-may-2014-p-43-page-001-600x150.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"bones-thumb-300\";a:4:{s:4:\"file\";s:58:\"eurotimes-industy-brief-may-2014-p-43-page-001-300x100.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:20:\"portfolio-one-column\";a:4:{s:4:\"file\";s:59:\"eurotimes-industy-brief-may-2014-p-43-page-001-1170x854.jpg\";s:5:\"width\";i:1170;s:6:\"height\";i:854;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:20:\"portfolio-two-column\";a:4:{s:4:\"file\";s:58:\"eurotimes-industy-brief-may-2014-p-43-page-001-570x416.jpg\";s:5:\"width\";i:570;s:6:\"height\";i:416;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:22:\"portfolio-three-column\";a:4:{s:4:\"file\";s:58:\"eurotimes-industy-brief-may-2014-p-43-page-001-370x270.jpg\";s:5:\"width\";i:370;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"portfolio-four-column\";a:4:{s:4:\"file\";s:58:\"eurotimes-industy-brief-may-2014-p-43-page-001-270x197.jpg\";s:5:\"width\";i:270;s:6:\"height\";i:197;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:17:\"portfolio-compact\";a:4:{s:4:\"file\";s:58:\"eurotimes-industy-brief-may-2014-p-43-page-001-770x513.jpg\";s:5:\"width\";i:770;s:6:\"height\";i:513;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:10:\"blog-large\";a:4:{s:4:\"file\";s:58:\"eurotimes-industy-brief-may-2014-p-43-page-001-770x270.jpg\";s:5:\"width\";i:770;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"blog-full-width\";a:4:{s:4:\"file\";s:59:\"eurotimes-industy-brief-may-2014-p-43-page-001-1170x270.jpg\";s:5:\"width\";i:1170;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"blog-medium\";a:4:{s:4:\"file\";s:58:\"eurotimes-industy-brief-may-2014-p-43-page-001-740x540.jpg\";s:5:\"width\";i:740;s:6:\"height\";i:540;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"blog-grid\";a:4:{s:4:\"file\";s:58:\"eurotimes-industy-brief-may-2014-p-43-page-001-370x270.jpg\";s:5:\"width\";i:370;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:58:\"eurotimes-industy-brief-may-2014-p-43-page-001-125x125.jpg\";s:5:\"width\";i:125;s:6:\"height\";i:125;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES("1092","227","_wp_attached_file","2014/07/eurotimes-industy-brief-may-2014-p-43.pdf");
INSERT INTO `wp_postmeta` VALUES("1093","227","_edit_lock","1404305436:2");
INSERT INTO `wp_postmeta` VALUES("1094","228","_wp_attached_file","2014/07/Ophthalmology-time-US-CO2-laser-surgery-a-new-option-for-glaucoma1.pdf");
INSERT INTO `wp_postmeta` VALUES("1095","228","_edit_lock","1405451028:2");
INSERT INTO `wp_postmeta` VALUES("1195","243","_edit_last","2");
INSERT INTO `wp_postmeta` VALUES("1196","243","_wp_page_template","default");
INSERT INTO `wp_postmeta` VALUES("1197","243","_wpb_vc_js_status","true");
INSERT INTO `wp_postmeta` VALUES("1198","243","_wpb_vc_js_interface_version","2");
INSERT INTO `wp_postmeta` VALUES("1199","243","_peach_bkgd_color","#");
INSERT INTO `wp_postmeta` VALUES("1200","243","_peach_bkgd_repeat","no-repeat");
INSERT INTO `wp_postmeta` VALUES("1201","243","_peach_bkgd_position","top left");
INSERT INTO `wp_postmeta` VALUES("1202","243","_peach_bkgd_attachment","scroll");
INSERT INTO `wp_postmeta` VALUES("1203","243","_peach_header_bkgd_color","#");
INSERT INTO `wp_postmeta` VALUES("1204","243","_peach_header_bkgd_repeat","no-repeat");
INSERT INTO `wp_postmeta` VALUES("1205","243","_peach_header_bkgd_position","top left");
INSERT INTO `wp_postmeta` VALUES("1206","243","_peach_header_bkgd_attachment","scroll");
INSERT INTO `wp_postmeta` VALUES("1207","243","_peach_breadcrumb_align","left");
INSERT INTO `wp_postmeta` VALUES("1208","243","_edit_lock","1422199957:2");
INSERT INTO `wp_postmeta` VALUES("1241","247","_menu_item_type","post_type");
INSERT INTO `wp_postmeta` VALUES("1242","247","_menu_item_menu_item_parent","0");
INSERT INTO `wp_postmeta` VALUES("1243","247","_menu_item_object_id","243");
INSERT INTO `wp_postmeta` VALUES("1244","247","_menu_item_object","page");
INSERT INTO `wp_postmeta` VALUES("1245","247","_menu_item_target","");
INSERT INTO `wp_postmeta` VALUES("1246","247","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `wp_postmeta` VALUES("1247","247","_menu_item_xfn","");
INSERT INTO `wp_postmeta` VALUES("1248","247","_menu_item_url","");
INSERT INTO `wp_postmeta` VALUES("1293","258","_edit_lock","1409482405:2");
INSERT INTO `wp_postmeta` VALUES("1294","258","_edit_last","2");
INSERT INTO `wp_postmeta` VALUES("1295","258","_wp_page_template","page-sidebar-left-submenu.php");
INSERT INTO `wp_postmeta` VALUES("1296","258","_wpb_vc_js_status","true");
INSERT INTO `wp_postmeta` VALUES("1297","258","_wpb_vc_js_interface_version","0");
INSERT INTO `wp_postmeta` VALUES("1298","258","_peach_bkgd_color","#");
INSERT INTO `wp_postmeta` VALUES("1299","258","_peach_bkgd_repeat","no-repeat");
INSERT INTO `wp_postmeta` VALUES("1300","258","_peach_bkgd_position","top left");
INSERT INTO `wp_postmeta` VALUES("1301","258","_peach_bkgd_attachment","scroll");
INSERT INTO `wp_postmeta` VALUES("1302","258","_peach_header_bkgd_color","#");
INSERT INTO `wp_postmeta` VALUES("1303","258","_peach_header_bkgd_repeat","no-repeat");
INSERT INTO `wp_postmeta` VALUES("1304","258","_peach_header_bkgd_position","top left");
INSERT INTO `wp_postmeta` VALUES("1305","258","_peach_header_bkgd_attachment","scroll");
INSERT INTO `wp_postmeta` VALUES("1306","258","_peach_breadcrumb_align","left");
INSERT INTO `wp_postmeta` VALUES("1307","260","_edit_lock","1416390529:2");
INSERT INTO `wp_postmeta` VALUES("1308","260","_edit_last","2");
INSERT INTO `wp_postmeta` VALUES("1309","260","_wp_page_template","page-sidebar-left-submenu.php");
INSERT INTO `wp_postmeta` VALUES("1310","260","_wpb_vc_js_status","true");
INSERT INTO `wp_postmeta` VALUES("1311","260","_wpb_vc_js_interface_version","0");
INSERT INTO `wp_postmeta` VALUES("1312","260","_peach_bkgd_color","#");
INSERT INTO `wp_postmeta` VALUES("1313","260","_peach_bkgd_repeat","no-repeat");
INSERT INTO `wp_postmeta` VALUES("1314","260","_peach_bkgd_position","top left");
INSERT INTO `wp_postmeta` VALUES("1315","260","_peach_bkgd_attachment","scroll");
INSERT INTO `wp_postmeta` VALUES("1316","260","_peach_header_bkgd_color","#");
INSERT INTO `wp_postmeta` VALUES("1317","260","_peach_header_bkgd_repeat","no-repeat");
INSERT INTO `wp_postmeta` VALUES("1318","260","_peach_header_bkgd_position","top left");
INSERT INTO `wp_postmeta` VALUES("1319","260","_peach_header_bkgd_attachment","scroll");
INSERT INTO `wp_postmeta` VALUES("1320","260","_peach_breadcrumb_align","left");
INSERT INTO `wp_postmeta` VALUES("1321","262","_edit_lock","1416389519:2");
INSERT INTO `wp_postmeta` VALUES("1322","262","_edit_last","2");
INSERT INTO `wp_postmeta` VALUES("1323","262","_wp_page_template","page-sidebar-left-submenu.php");
INSERT INTO `wp_postmeta` VALUES("1324","262","_wpb_vc_js_status","true");
INSERT INTO `wp_postmeta` VALUES("1325","262","_wpb_vc_js_interface_version","0");
INSERT INTO `wp_postmeta` VALUES("1326","262","_peach_bkgd_color","#");
INSERT INTO `wp_postmeta` VALUES("1327","262","_peach_bkgd_repeat","no-repeat");
INSERT INTO `wp_postmeta` VALUES("1328","262","_peach_bkgd_position","top left");
INSERT INTO `wp_postmeta` VALUES("1329","262","_peach_bkgd_attachment","scroll");
INSERT INTO `wp_postmeta` VALUES("1330","262","_peach_header_bkgd_color","#");
INSERT INTO `wp_postmeta` VALUES("1331","262","_peach_header_bkgd_repeat","no-repeat");
INSERT INTO `wp_postmeta` VALUES("1332","262","_peach_header_bkgd_position","top left");
INSERT INTO `wp_postmeta` VALUES("1333","262","_peach_header_bkgd_attachment","scroll");
INSERT INTO `wp_postmeta` VALUES("1334","262","_peach_breadcrumb_align","left");
INSERT INTO `wp_postmeta` VALUES("1335","263","_edit_lock","1416391995:2");
INSERT INTO `wp_postmeta` VALUES("1336","263","_edit_last","2");
INSERT INTO `wp_postmeta` VALUES("1337","263","_wp_page_template","page-sidebar-left-submenu.php");
INSERT INTO `wp_postmeta` VALUES("1338","263","_wpb_vc_js_status","true");
INSERT INTO `wp_postmeta` VALUES("1339","263","_wpb_vc_js_interface_version","0");
INSERT INTO `wp_postmeta` VALUES("1340","263","_peach_bkgd_color","#");
INSERT INTO `wp_postmeta` VALUES("1341","263","_peach_bkgd_repeat","no-repeat");
INSERT INTO `wp_postmeta` VALUES("1342","263","_peach_bkgd_position","top left");
INSERT INTO `wp_postmeta` VALUES("1343","263","_peach_bkgd_attachment","scroll");
INSERT INTO `wp_postmeta` VALUES("1344","263","_peach_header_bkgd_color","#");
INSERT INTO `wp_postmeta` VALUES("1345","263","_peach_header_bkgd_repeat","no-repeat");
INSERT INTO `wp_postmeta` VALUES("1346","263","_peach_header_bkgd_position","top left");
INSERT INTO `wp_postmeta` VALUES("1347","263","_peach_header_bkgd_attachment","scroll");
INSERT INTO `wp_postmeta` VALUES("1348","263","_peach_breadcrumb_align","left");
INSERT INTO `wp_postmeta` VALUES("1349","264","_edit_lock","1426079098:2");
INSERT INTO `wp_postmeta` VALUES("1350","264","_edit_last","2");
INSERT INTO `wp_postmeta` VALUES("1351","264","_wp_page_template","page-sidebar-left-submenu.php");
INSERT INTO `wp_postmeta` VALUES("1352","264","_wpb_vc_js_status","true");
INSERT INTO `wp_postmeta` VALUES("1353","264","_wpb_vc_js_interface_version","0");
INSERT INTO `wp_postmeta` VALUES("1354","264","_peach_bkgd_color","#");
INSERT INTO `wp_postmeta` VALUES("1355","264","_peach_bkgd_repeat","no-repeat");
INSERT INTO `wp_postmeta` VALUES("1356","264","_peach_bkgd_position","top left");
INSERT INTO `wp_postmeta` VALUES("1357","264","_peach_bkgd_attachment","scroll");
INSERT INTO `wp_postmeta` VALUES("1358","264","_peach_header_bkgd_color","#");
INSERT INTO `wp_postmeta` VALUES("1359","264","_peach_header_bkgd_repeat","no-repeat");
INSERT INTO `wp_postmeta` VALUES("1360","264","_peach_header_bkgd_position","top left");
INSERT INTO `wp_postmeta` VALUES("1361","264","_peach_header_bkgd_attachment","scroll");
INSERT INTO `wp_postmeta` VALUES("1362","264","_peach_breadcrumb_align","left");
INSERT INTO `wp_postmeta` VALUES("1363","265","_edit_lock","1423467208:2");
INSERT INTO `wp_postmeta` VALUES("1364","265","_edit_last","2");
INSERT INTO `wp_postmeta` VALUES("1365","265","_wp_page_template","page-sidebar-left-submenu.php");
INSERT INTO `wp_postmeta` VALUES("1366","265","_wpb_vc_js_status","true");
INSERT INTO `wp_postmeta` VALUES("1367","265","_wpb_vc_js_interface_version","0");
INSERT INTO `wp_postmeta` VALUES("1368","265","_peach_bkgd_color","#");
INSERT INTO `wp_postmeta` VALUES("1369","265","_peach_bkgd_repeat","no-repeat");
INSERT INTO `wp_postmeta` VALUES("1370","265","_peach_bkgd_position","top left");
INSERT INTO `wp_postmeta` VALUES("1371","265","_peach_bkgd_attachment","scroll");
INSERT INTO `wp_postmeta` VALUES("1372","265","_peach_header_bkgd_color","#");
INSERT INTO `wp_postmeta` VALUES("1373","265","_peach_header_bkgd_repeat","no-repeat");
INSERT INTO `wp_postmeta` VALUES("1374","265","_peach_header_bkgd_position","top left");
INSERT INTO `wp_postmeta` VALUES("1375","265","_peach_header_bkgd_attachment","scroll");
INSERT INTO `wp_postmeta` VALUES("1376","265","_peach_breadcrumb_align","left");
INSERT INTO `wp_postmeta` VALUES("1379","272","_edit_lock","1409482383:2");
INSERT INTO `wp_postmeta` VALUES("1380","272","_edit_last","2");
INSERT INTO `wp_postmeta` VALUES("1381","272","_wp_page_template","page-sidebar-left-submenu.php");
INSERT INTO `wp_postmeta` VALUES("1382","272","_wpb_vc_js_status","false");
INSERT INTO `wp_postmeta` VALUES("1383","272","_wpb_vc_js_interface_version","0");
INSERT INTO `wp_postmeta` VALUES("1384","272","_peach_bkgd_color","#");
INSERT INTO `wp_postmeta` VALUES("1385","272","_peach_bkgd_repeat","no-repeat");
INSERT INTO `wp_postmeta` VALUES("1386","272","_peach_bkgd_position","top left");
INSERT INTO `wp_postmeta` VALUES("1387","272","_peach_bkgd_attachment","scroll");
INSERT INTO `wp_postmeta` VALUES("1388","272","_peach_header_bkgd_color","#");
INSERT INTO `wp_postmeta` VALUES("1389","272","_peach_header_bkgd_repeat","no-repeat");
INSERT INTO `wp_postmeta` VALUES("1390","272","_peach_header_bkgd_position","top left");
INSERT INTO `wp_postmeta` VALUES("1391","272","_peach_header_bkgd_attachment","scroll");
INSERT INTO `wp_postmeta` VALUES("1392","272","_peach_breadcrumb_align","left");
INSERT INTO `wp_postmeta` VALUES("1393","275","_wp_attached_file","2014/07/IOPtima-Eye-Anatomy-background.zip");
INSERT INTO `wp_postmeta` VALUES("1394","276","_wp_attached_file","2014/07/IOPtima-Glaucoma-background.zip");
INSERT INTO `wp_postmeta` VALUES("1395","277","_wp_attached_file","2014/07/IOPtima-Treatment-Options.zip");
INSERT INTO `wp_postmeta` VALUES("1396","278","_wp_attached_file","2014/07/IOPtima-Competative-Analysis.zip");
INSERT INTO `wp_postmeta` VALUES("1397","275","_edit_lock","1405490641:2");
INSERT INTO `wp_postmeta` VALUES("1398","276","_edit_lock","1405490799:2");
INSERT INTO `wp_postmeta` VALUES("1399","277","_edit_lock","1405490990:2");
INSERT INTO `wp_postmeta` VALUES("1400","278","_edit_lock","1405492328:2");
INSERT INTO `wp_postmeta` VALUES("1401","281","_wp_attached_file","2014/07/Brochure-CLASS-by-IOPtima-for-print.pdf");
INSERT INTO `wp_postmeta` VALUES("1402","282","_wp_attached_file","2014/07/IOPtima-New-Site-Qualification.zip");
INSERT INTO `wp_postmeta` VALUES("1403","283","_wp_attached_file","2014/07/IOPtima-Troubleshooting.zip");
INSERT INTO `wp_postmeta` VALUES("1407","287","_wp_attached_file","2014/07/CLASS-Marketing-Introduction.zip");
INSERT INTO `wp_postmeta` VALUES("1408","287","_edit_lock","1405493116:2");
INSERT INTO `wp_postmeta` VALUES("1409","281","_edit_lock","1405494316:2");
INSERT INTO `wp_postmeta` VALUES("1410","281","_edit_last","2");
INSERT INTO `wp_postmeta` VALUES("1414","283","_edit_lock","1405494545:2");
INSERT INTO `wp_postmeta` VALUES("1415","282","_edit_lock","1405494945:2");
INSERT INTO `wp_postmeta` VALUES("1418","258","_peach_hide_breadcrumb","on");
INSERT INTO `wp_postmeta` VALUES("1419","260","_peach_hide_breadcrumb","on");
INSERT INTO `wp_postmeta` VALUES("1420","263","_peach_hide_breadcrumb","on");
INSERT INTO `wp_postmeta` VALUES("1421","262","_peach_hide_breadcrumb","on");
INSERT INTO `wp_postmeta` VALUES("1422","264","_peach_hide_breadcrumb","on");
INSERT INTO `wp_postmeta` VALUES("1423","265","_peach_hide_breadcrumb","on");
INSERT INTO `wp_postmeta` VALUES("1424","272","_peach_hide_breadcrumb","on");
INSERT INTO `wp_postmeta` VALUES("1425","243","_peach_hide_breadcrumb","on");
INSERT INTO `wp_postmeta` VALUES("1426","5","_yoast_wpseo_focuskw","nonpenetrating glaucoma surgery");
INSERT INTO `wp_postmeta` VALUES("1427","5","_yoast_wpseo_linkdex","37");
INSERT INTO `wp_postmeta` VALUES("1428","301","_wp_attached_file","2014/07/CLASS-procedure-offers-alternative-treatment-for-glaucoma-_-Ocular-Surgery-News.pdf");
INSERT INTO `wp_postmeta` VALUES("1429","301","_edit_lock","1406572276:2");
INSERT INTO `wp_postmeta` VALUES("1430","303","_wp_attached_file","2014/07/CLASS-procedure-offers-alternative-treatment-for-glaucoma-_-Ocular-Surgery-News-page-001.jpg");
INSERT INTO `wp_postmeta` VALUES("1431","303","_wp_attachment_metadata","a:5:{s:5:\"width\";i:2483;s:6:\"height\";i:3508;s:4:\"file\";s:100:\"2014/07/CLASS-procedure-offers-alternative-treatment-for-glaucoma-_-Ocular-Surgery-News-page-001.jpg\";s:5:\"sizes\";a:15:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:100:\"CLASS-procedure-offers-alternative-treatment-for-glaucoma-_-Ocular-Surgery-News-page-001-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:100:\"CLASS-procedure-offers-alternative-treatment-for-glaucoma-_-Ocular-Surgery-News-page-001-212x300.jpg\";s:5:\"width\";i:212;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:101:\"CLASS-procedure-offers-alternative-treatment-for-glaucoma-_-Ocular-Surgery-News-page-001-724x1024.jpg\";s:5:\"width\";i:724;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"bones-thumb-600\";a:4:{s:4:\"file\";s:100:\"CLASS-procedure-offers-alternative-treatment-for-glaucoma-_-Ocular-Surgery-News-page-001-600x150.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"bones-thumb-300\";a:4:{s:4:\"file\";s:100:\"CLASS-procedure-offers-alternative-treatment-for-glaucoma-_-Ocular-Surgery-News-page-001-300x100.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:20:\"portfolio-one-column\";a:4:{s:4:\"file\";s:101:\"CLASS-procedure-offers-alternative-treatment-for-glaucoma-_-Ocular-Surgery-News-page-001-1170x854.jpg\";s:5:\"width\";i:1170;s:6:\"height\";i:854;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:20:\"portfolio-two-column\";a:4:{s:4:\"file\";s:100:\"CLASS-procedure-offers-alternative-treatment-for-glaucoma-_-Ocular-Surgery-News-page-001-570x416.jpg\";s:5:\"width\";i:570;s:6:\"height\";i:416;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:22:\"portfolio-three-column\";a:4:{s:4:\"file\";s:100:\"CLASS-procedure-offers-alternative-treatment-for-glaucoma-_-Ocular-Surgery-News-page-001-370x270.jpg\";s:5:\"width\";i:370;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"portfolio-four-column\";a:4:{s:4:\"file\";s:100:\"CLASS-procedure-offers-alternative-treatment-for-glaucoma-_-Ocular-Surgery-News-page-001-270x197.jpg\";s:5:\"width\";i:270;s:6:\"height\";i:197;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:17:\"portfolio-compact\";a:4:{s:4:\"file\";s:100:\"CLASS-procedure-offers-alternative-treatment-for-glaucoma-_-Ocular-Surgery-News-page-001-770x513.jpg\";s:5:\"width\";i:770;s:6:\"height\";i:513;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:10:\"blog-large\";a:4:{s:4:\"file\";s:100:\"CLASS-procedure-offers-alternative-treatment-for-glaucoma-_-Ocular-Surgery-News-page-001-770x270.jpg\";s:5:\"width\";i:770;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"blog-full-width\";a:4:{s:4:\"file\";s:101:\"CLASS-procedure-offers-alternative-treatment-for-glaucoma-_-Ocular-Surgery-News-page-001-1170x270.jpg\";s:5:\"width\";i:1170;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"blog-medium\";a:4:{s:4:\"file\";s:100:\"CLASS-procedure-offers-alternative-treatment-for-glaucoma-_-Ocular-Surgery-News-page-001-740x540.jpg\";s:5:\"width\";i:740;s:6:\"height\";i:540;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"blog-grid\";a:4:{s:4:\"file\";s:100:\"CLASS-procedure-offers-alternative-treatment-for-glaucoma-_-Ocular-Surgery-News-page-001-370x270.jpg\";s:5:\"width\";i:370;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:100:\"CLASS-procedure-offers-alternative-treatment-for-glaucoma-_-Ocular-Surgery-News-page-001-125x125.jpg\";s:5:\"width\";i:125;s:6:\"height\";i:125;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES("1432","303","_edit_lock","1406572218:2");
INSERT INTO `wp_postmeta` VALUES("1433","154","_edit_lock","1406614068:2");
INSERT INTO `wp_postmeta` VALUES("1434","82","_edit_lock","1406615441:2");
INSERT INTO `wp_postmeta` VALUES("1450","208","_edit_lock","1407163511:2");
INSERT INTO `wp_postmeta` VALUES("1451","199","_edit_lock","1407163532:2");
INSERT INTO `wp_postmeta` VALUES("1467","197","_edit_lock","1407176186:2");
INSERT INTO `wp_postmeta` VALUES("1476","325","_wp_attached_file","2014/08/353984-JulyAugust-201_selected-pages-page-001.jpg");
INSERT INTO `wp_postmeta` VALUES("1477","325","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1238;s:6:\"height\";i:1856;s:4:\"file\";s:57:\"2014/08/353984-JulyAugust-201_selected-pages-page-001.jpg\";s:5:\"sizes\";a:15:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:57:\"353984-JulyAugust-201_selected-pages-page-001-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:57:\"353984-JulyAugust-201_selected-pages-page-001-200x300.jpg\";s:5:\"width\";i:200;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:58:\"353984-JulyAugust-201_selected-pages-page-001-683x1024.jpg\";s:5:\"width\";i:683;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"bones-thumb-600\";a:4:{s:4:\"file\";s:57:\"353984-JulyAugust-201_selected-pages-page-001-600x150.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"bones-thumb-300\";a:4:{s:4:\"file\";s:57:\"353984-JulyAugust-201_selected-pages-page-001-300x100.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:20:\"portfolio-one-column\";a:4:{s:4:\"file\";s:58:\"353984-JulyAugust-201_selected-pages-page-001-1170x854.jpg\";s:5:\"width\";i:1170;s:6:\"height\";i:854;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:20:\"portfolio-two-column\";a:4:{s:4:\"file\";s:57:\"353984-JulyAugust-201_selected-pages-page-001-570x416.jpg\";s:5:\"width\";i:570;s:6:\"height\";i:416;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:22:\"portfolio-three-column\";a:4:{s:4:\"file\";s:57:\"353984-JulyAugust-201_selected-pages-page-001-370x270.jpg\";s:5:\"width\";i:370;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"portfolio-four-column\";a:4:{s:4:\"file\";s:57:\"353984-JulyAugust-201_selected-pages-page-001-270x197.jpg\";s:5:\"width\";i:270;s:6:\"height\";i:197;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:17:\"portfolio-compact\";a:4:{s:4:\"file\";s:57:\"353984-JulyAugust-201_selected-pages-page-001-770x513.jpg\";s:5:\"width\";i:770;s:6:\"height\";i:513;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:10:\"blog-large\";a:4:{s:4:\"file\";s:57:\"353984-JulyAugust-201_selected-pages-page-001-770x270.jpg\";s:5:\"width\";i:770;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"blog-full-width\";a:4:{s:4:\"file\";s:58:\"353984-JulyAugust-201_selected-pages-page-001-1170x270.jpg\";s:5:\"width\";i:1170;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"blog-medium\";a:4:{s:4:\"file\";s:57:\"353984-JulyAugust-201_selected-pages-page-001-740x540.jpg\";s:5:\"width\";i:740;s:6:\"height\";i:540;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"blog-grid\";a:4:{s:4:\"file\";s:57:\"353984-JulyAugust-201_selected-pages-page-001-370x270.jpg\";s:5:\"width\";i:370;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:57:\"353984-JulyAugust-201_selected-pages-page-001-125x125.jpg\";s:5:\"width\";i:125;s:6:\"height\";i:125;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES("1478","325","_edit_lock","1407239061:2");
INSERT INTO `wp_postmeta` VALUES("1479","325","_edit_last","2");
INSERT INTO `wp_postmeta` VALUES("1480","326","_wp_attached_file","2014/08/OSN-Europe_july-august-14_Melamed_CLASS.pdf");
INSERT INTO `wp_postmeta` VALUES("1481","326","_edit_lock","1407240111:2");
INSERT INTO `wp_postmeta` VALUES("1485","329","_wp_attached_file","2014/08/Eran-Kaplan-2.jpg");
INSERT INTO `wp_postmeta` VALUES("1486","329","_wp_attachment_metadata","a:5:{s:5:\"width\";i:3325;s:6:\"height\";i:2882;s:4:\"file\";s:25:\"2014/08/Eran-Kaplan-2.jpg\";s:5:\"sizes\";a:15:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:25:\"Eran-Kaplan-2-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:25:\"Eran-Kaplan-2-300x260.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:260;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:26:\"Eran-Kaplan-2-1024x887.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:887;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"bones-thumb-600\";a:4:{s:4:\"file\";s:25:\"Eran-Kaplan-2-600x150.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"bones-thumb-300\";a:4:{s:4:\"file\";s:25:\"Eran-Kaplan-2-300x100.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:20:\"portfolio-one-column\";a:4:{s:4:\"file\";s:26:\"Eran-Kaplan-2-1170x854.jpg\";s:5:\"width\";i:1170;s:6:\"height\";i:854;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:20:\"portfolio-two-column\";a:4:{s:4:\"file\";s:25:\"Eran-Kaplan-2-570x416.jpg\";s:5:\"width\";i:570;s:6:\"height\";i:416;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:22:\"portfolio-three-column\";a:4:{s:4:\"file\";s:25:\"Eran-Kaplan-2-370x270.jpg\";s:5:\"width\";i:370;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"portfolio-four-column\";a:4:{s:4:\"file\";s:25:\"Eran-Kaplan-2-270x197.jpg\";s:5:\"width\";i:270;s:6:\"height\";i:197;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:17:\"portfolio-compact\";a:4:{s:4:\"file\";s:25:\"Eran-Kaplan-2-770x513.jpg\";s:5:\"width\";i:770;s:6:\"height\";i:513;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:10:\"blog-large\";a:4:{s:4:\"file\";s:25:\"Eran-Kaplan-2-770x270.jpg\";s:5:\"width\";i:770;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"blog-full-width\";a:4:{s:4:\"file\";s:26:\"Eran-Kaplan-2-1170x270.jpg\";s:5:\"width\";i:1170;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"blog-medium\";a:4:{s:4:\"file\";s:25:\"Eran-Kaplan-2-740x540.jpg\";s:5:\"width\";i:740;s:6:\"height\";i:540;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"blog-grid\";a:4:{s:4:\"file\";s:25:\"Eran-Kaplan-2-370x270.jpg\";s:5:\"width\";i:370;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:25:\"Eran-Kaplan-2-125x125.jpg\";s:5:\"width\";i:125;s:6:\"height\";i:125;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";d:7.0999999999999996447286321199499070644378662109375;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:5:\"NEX-7\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:1400764231;s:9:\"copyright\";s:13:\"Peled Studios\";s:12:\"focal_length\";s:2:\"61\";s:3:\"iso\";s:3:\"200\";s:13:\"shutter_speed\";s:4:\"0.05\";s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES("1487","98","_edit_lock","1407412663:2");
INSERT INTO `wp_postmeta` VALUES("1495","39","_yoast_wpseo_metadesc","IOPtima is a developer of minimally-invasive surgical ophthalmic devices. The company’s flagship product, is the IOPtimate™ for the treatment of Glaucoma.");
INSERT INTO `wp_postmeta` VALUES("1496","39","_yoast_wpseo_focuskw","glaucoma surgery");
INSERT INTO `wp_postmeta` VALUES("1497","39","_yoast_wpseo_linkdex","62");
INSERT INTO `wp_postmeta` VALUES("1498","5","_yoast_wpseo_sitemap-include","always");
INSERT INTO `wp_postmeta` VALUES("1499","5","_yoast_wpseo_sitemap-prio","0.8");
INSERT INTO `wp_postmeta` VALUES("1500","5","_yoast_wpseo_sitemap-html-include","always");
INSERT INTO `wp_postmeta` VALUES("1607","5","_yoast_wpseo_metadesc","A CO2 Laser-Assisted Sclerotomy Surgery, which is intended for treating primary Open-Angle Glaucoma (POAG) and Pseudo-Exfoliative Glaucoma (PEXG) patients.");
INSERT INTO `wp_postmeta` VALUES("1608","11","_yoast_wpseo_focuskw","Glaucoma experience");
INSERT INTO `wp_postmeta` VALUES("1609","11","_yoast_wpseo_metadesc","The IOPtima management team has years of cumulative experience in the Glaucoma field and in the Bio-medical world.");
INSERT INTO `wp_postmeta` VALUES("1610","11","_yoast_wpseo_linkdex","57");
INSERT INTO `wp_postmeta` VALUES("1611","12","_yoast_wpseo_focuskw","experienced board of directors");
INSERT INTO `wp_postmeta` VALUES("1612","12","_yoast_wpseo_title","Board of Directors - IOPtima");
INSERT INTO `wp_postmeta` VALUES("1613","12","_yoast_wpseo_metadesc","IOPtima\'s board of directors brings the knowledge and experience that was gained in companies such as Elron, Given Imaging, IceCure & TEVA Pharmaceuticals");
INSERT INTO `wp_postmeta` VALUES("1614","12","_yoast_wpseo_linkdex","54");
INSERT INTO `wp_postmeta` VALUES("1615","40","_yoast_wpseo_focuskw","glaucoma specialist");
INSERT INTO `wp_postmeta` VALUES("1616","40","_yoast_wpseo_title","Scientific Advisory Board - IOPtima");
INSERT INTO `wp_postmeta` VALUES("1617","40","_yoast_wpseo_metadesc","IOPtima has relied on several renowned key opinion leaders Glaucoma field to provide clinical and strategic advice and participate in clinical trials");
INSERT INTO `wp_postmeta` VALUES("1618","40","_yoast_wpseo_linkdex","54");
INSERT INTO `wp_postmeta` VALUES("1619","56","_yoast_wpseo_focuskw","glaucoma quality standards");
INSERT INTO `wp_postmeta` VALUES("1620","56","_yoast_wpseo_linkdex","48");
INSERT INTO `wp_postmeta` VALUES("1621","56","_yoast_wpseo_metadesc","IOPtima has CE mark, Israeli regulatory (AMAR) certification, COFEPRIS approval in Mexico, a CFDA approval in China and in registration in Canada and Taiwan");
INSERT INTO `wp_postmeta` VALUES("1622","41","_yoast_wpseo_focuskw","Schlemm’s Canal un-roofing");
INSERT INTO `wp_postmeta` VALUES("1623","41","_yoast_wpseo_linkdex","60");
INSERT INTO `wp_postmeta` VALUES("1624","41","_yoast_wpseo_metadesc","The CLASS procedure utilizes the particular properties of the CO2 laser to ablates scleral tissues without penetrating into the eye");
INSERT INTO `wp_postmeta` VALUES("1625","96","_yoast_wpseo_focuskw","simple to performe glaucoma surgery");
INSERT INTO `wp_postmeta` VALUES("1626","96","_yoast_wpseo_linkdex","48");
INSERT INTO `wp_postmeta` VALUES("1627","96","_yoast_wpseo_metadesc","The procedure flow: Creation of the standard flap & scleral bed, tissue ablation until fluid percolation, leaving a thin layer remains intact and Suturing");
INSERT INTO `wp_postmeta` VALUES("1628","41","_oembed_58b0c7958d6813894fb23ea2722cad18","<iframe width=\"1170\" height=\"658\" src=\"http://www.youtube.com/embed/ejQbUMjxUI0?feature=oembed\" frameborder=\"0\" allowfullscreen></iframe>");
INSERT INTO `wp_postmeta` VALUES("1629","42","_yoast_wpseo_focuskw","easily adaptable system");
INSERT INTO `wp_postmeta` VALUES("1630","42","_yoast_wpseo_linkdex","61");
INSERT INTO `wp_postmeta` VALUES("1631","42","_yoast_wpseo_metadesc","The IOPtimate system consists of The CO2 Laser, Control Unit with the procedure parameters and the scanner that translate the laser beam");
INSERT INTO `wp_postmeta` VALUES("1632","43","_yoast_wpseo_focuskw","Simple safe and effective surgery");
INSERT INTO `wp_postmeta` VALUES("1633","43","_yoast_wpseo_linkdex","36");
INSERT INTO `wp_postmeta` VALUES("1634","43","_yoast_wpseo_title","CLASS Benefits - IOPtima");
INSERT INTO `wp_postmeta` VALUES("1635","60","_yoast_wpseo_focuskw","intraocular surgery complications");
INSERT INTO `wp_postmeta` VALUES("1636","60","_yoast_wpseo_linkdex","56");
INSERT INTO `wp_postmeta` VALUES("1637","62","_yoast_wpseo_focuskw","Glaucoma clinical publications");
INSERT INTO `wp_postmeta` VALUES("1638","62","_yoast_wpseo_linkdex","57");
INSERT INTO `wp_postmeta` VALUES("1639","62","_yoast_wpseo_metadesc","IOPTima Clinical Publications | Magazine Articles | Academic Posters");
INSERT INTO `wp_postmeta` VALUES("1640","44","_yoast_wpseo_focuskw","surgery demonstration");
INSERT INTO `wp_postmeta` VALUES("1641","44","_yoast_wpseo_linkdex","37");
INSERT INTO `wp_postmeta` VALUES("1642","44","_yoast_wpseo_metadesc","IOPtimate Device | CLASS Procedure | CLASS Performed by Prof Ehud Assia | CLASS Performed by Dr Andre Mermoud |Combined Phaco CLASS by Dr Rengarai Venkatesh");
INSERT INTO `wp_postmeta` VALUES("1645","272","_yoast_wpseo_meta-robots-adv","none");
INSERT INTO `wp_postmeta` VALUES("1646","272","_yoast_wpseo_meta-robots-noindex","1");
INSERT INTO `wp_postmeta` VALUES("1647","272","_yoast_wpseo_sitemap-include","never");
INSERT INTO `wp_postmeta` VALUES("1648","272","_yoast_wpseo_sitemap-html-include","never");
INSERT INTO `wp_postmeta` VALUES("1649","243","_yoast_wpseo_meta-robots-noindex","1");
INSERT INTO `wp_postmeta` VALUES("1650","243","_yoast_wpseo_meta-robots-nofollow","1");
INSERT INTO `wp_postmeta` VALUES("1651","243","_yoast_wpseo_sitemap-include","never");
INSERT INTO `wp_postmeta` VALUES("1652","243","_yoast_wpseo_sitemap-html-include","never");
INSERT INTO `wp_postmeta` VALUES("1653","258","_yoast_wpseo_meta-robots-noindex","1");
INSERT INTO `wp_postmeta` VALUES("1654","258","_yoast_wpseo_meta-robots-nofollow","1");
INSERT INTO `wp_postmeta` VALUES("1655","258","_yoast_wpseo_sitemap-include","never");
INSERT INTO `wp_postmeta` VALUES("1656","258","_yoast_wpseo_sitemap-html-include","never");
INSERT INTO `wp_postmeta` VALUES("1657","260","_yoast_wpseo_meta-robots-noindex","1");
INSERT INTO `wp_postmeta` VALUES("1658","260","_yoast_wpseo_meta-robots-nofollow","1");
INSERT INTO `wp_postmeta` VALUES("1659","260","_yoast_wpseo_sitemap-include","never");
INSERT INTO `wp_postmeta` VALUES("1660","260","_yoast_wpseo_sitemap-html-include","never");
INSERT INTO `wp_postmeta` VALUES("1661","263","_yoast_wpseo_meta-robots-noindex","1");
INSERT INTO `wp_postmeta` VALUES("1662","263","_yoast_wpseo_meta-robots-nofollow","1");
INSERT INTO `wp_postmeta` VALUES("1663","263","_yoast_wpseo_sitemap-include","never");
INSERT INTO `wp_postmeta` VALUES("1664","263","_yoast_wpseo_sitemap-html-include","never");
INSERT INTO `wp_postmeta` VALUES("1665","262","_yoast_wpseo_meta-robots-noindex","1");
INSERT INTO `wp_postmeta` VALUES("1666","262","_yoast_wpseo_meta-robots-nofollow","1");
INSERT INTO `wp_postmeta` VALUES("1667","262","_yoast_wpseo_sitemap-include","never");
INSERT INTO `wp_postmeta` VALUES("1668","262","_yoast_wpseo_sitemap-html-include","never");
INSERT INTO `wp_postmeta` VALUES("1669","264","_yoast_wpseo_meta-robots-noindex","1");
INSERT INTO `wp_postmeta` VALUES("1670","264","_yoast_wpseo_meta-robots-nofollow","1");
INSERT INTO `wp_postmeta` VALUES("1671","264","_yoast_wpseo_sitemap-include","never");
INSERT INTO `wp_postmeta` VALUES("1672","264","_yoast_wpseo_sitemap-html-include","never");
INSERT INTO `wp_postmeta` VALUES("1673","265","_yoast_wpseo_meta-robots-noindex","1");
INSERT INTO `wp_postmeta` VALUES("1674","265","_yoast_wpseo_meta-robots-nofollow","1");
INSERT INTO `wp_postmeta` VALUES("1675","265","_yoast_wpseo_sitemap-include","never");
INSERT INTO `wp_postmeta` VALUES("1676","265","_yoast_wpseo_sitemap-html-include","never");
INSERT INTO `wp_postmeta` VALUES("1677","44","_oembed_f4a3d734c75cdd67e43f44bdfffdc106","<iframe width=\"1170\" height=\"658\" src=\"https://www.youtube.com/embed/ejQbUMjxUI0?feature=oembed\" frameborder=\"0\" allowfullscreen></iframe>");
INSERT INTO `wp_postmeta` VALUES("1678","44","_oembed_2848aaf75285adec380414f3dc09d349","<iframe width=\"1170\" height=\"878\" src=\"https://www.youtube.com/embed/yZK5eH1NtDI?feature=oembed\" frameborder=\"0\" allowfullscreen></iframe>");
INSERT INTO `wp_postmeta` VALUES("1679","44","_oembed_7f4dcce0c21f3752b7b298820347256b","<iframe width=\"1170\" height=\"878\" src=\"http://www.youtube.com/embed/NGvrPYrwGxA?feature=oembed\" frameborder=\"0\" allowfullscreen></iframe>");
INSERT INTO `wp_postmeta` VALUES("1680","44","_oembed_06e22fe620ab7420e5cb8a569252cac6","<iframe width=\"1170\" height=\"878\" src=\"https://www.youtube.com/embed/ZIkuKRkirag?feature=oembed\" frameborder=\"0\" allowfullscreen></iframe>");
INSERT INTO `wp_postmeta` VALUES("1681","44","_oembed_d5be4dcf346ca4bf79eec569cdb1c26b","<iframe width=\"1170\" height=\"878\" src=\"https://www.youtube.com/embed/GUvffmK-isY?feature=oembed\" frameborder=\"0\" allowfullscreen></iframe>");
INSERT INTO `wp_postmeta` VALUES("1682","63","_yoast_wpseo_focuskw","professional references");
INSERT INTO `wp_postmeta` VALUES("1683","63","_yoast_wpseo_linkdex","62");
INSERT INTO `wp_postmeta` VALUES("1684","63","_yoast_wpseo_metadesc","Testimonials by: Prof. Assia Ehud | Prof. Mermoud Andre | Dr. Muñoz Gonzalo | Prof. Shaarawy Tarek | Dr. Félix Gil Carrasco");
INSERT INTO `wp_postmeta` VALUES("1685","46","_yoast_wpseo_focuskw","glaucoma diagnosis and treatment");
INSERT INTO `wp_postmeta` VALUES("1686","46","_yoast_wpseo_linkdex","49");
INSERT INTO `wp_postmeta` VALUES("1687","46","_yoast_wpseo_metadesc","Glaucoma is a group of eye disorders characterized by progressive loss of nerve tissue, leading to blindness. It is the second leading cause of vision loss.");
INSERT INTO `wp_postmeta` VALUES("1688","47","_yoast_wpseo_focuskw","how to treat glaucoma");
INSERT INTO `wp_postmeta` VALUES("1689","47","_yoast_wpseo_linkdex","56");
INSERT INTO `wp_postmeta` VALUES("1690","139","_yoast_wpseo_focuskw","Surgical Procedures IOP Reduction");
INSERT INTO `wp_postmeta` VALUES("1691","139","_yoast_wpseo_metadesc","IOPtima Ltd. has developed the IOPtimate system, a unique, minimally invasive CO2 laser-assisted system for the treatment of Glaucoma.");
INSERT INTO `wp_postmeta` VALUES("1692","139","_yoast_wpseo_linkdex","60");
INSERT INTO `wp_postmeta` VALUES("1693","19","_yoast_wpseo_focuskw","IOPtima news coverage");
INSERT INTO `wp_postmeta` VALUES("1694","19","_yoast_wpseo_linkdex","66");
INSERT INTO `wp_postmeta` VALUES("1695","19","_yoast_wpseo_metadesc","OSN EU Edition | OSN U.S. Edition | Ophthalmology Times US | Ophthalmology Times EU | Distribution Agreement in China | Eurotimes | Eyeworld | Healio");
INSERT INTO `wp_postmeta` VALUES("1696","133","_yoast_wpseo_focuskw","glaucoma congress");
INSERT INTO `wp_postmeta` VALUES("1697","133","_yoast_wpseo_linkdex","55");
INSERT INTO `wp_postmeta` VALUES("1698","133","_yoast_wpseo_metadesc","Please visit us at the upcoming events: APGC-ISHOK September 26-28, 2014, Hong-Kong | ESCRS September 13-17, 2014, London | EGS June 7-11, 2014, Nice");
INSERT INTO `wp_postmeta` VALUES("1699","94","_yoast_wpseo_focuskw","glaucoma patient information");
INSERT INTO `wp_postmeta` VALUES("1701","357","_wp_attached_file","2014/08/CLASS-logo-wo-background.png");
INSERT INTO `wp_postmeta` VALUES("1702","357","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1031;s:6:\"height\";i:482;s:4:\"file\";s:36:\"2014/08/CLASS-logo-wo-background.png\";s:5:\"sizes\";a:14:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:36:\"CLASS-logo-wo-background-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:36:\"CLASS-logo-wo-background-300x140.png\";s:5:\"width\";i:300;s:6:\"height\";i:140;s:9:\"mime-type\";s:9:\"image/png\";}s:5:\"large\";a:4:{s:4:\"file\";s:37:\"CLASS-logo-wo-background-1024x478.png\";s:5:\"width\";i:1024;s:6:\"height\";i:478;s:9:\"mime-type\";s:9:\"image/png\";}s:15:\"bones-thumb-600\";a:4:{s:4:\"file\";s:36:\"CLASS-logo-wo-background-600x150.png\";s:5:\"width\";i:600;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:15:\"bones-thumb-300\";a:4:{s:4:\"file\";s:36:\"CLASS-logo-wo-background-300x100.png\";s:5:\"width\";i:300;s:6:\"height\";i:100;s:9:\"mime-type\";s:9:\"image/png\";}s:20:\"portfolio-two-column\";a:4:{s:4:\"file\";s:36:\"CLASS-logo-wo-background-570x416.png\";s:5:\"width\";i:570;s:6:\"height\";i:416;s:9:\"mime-type\";s:9:\"image/png\";}s:22:\"portfolio-three-column\";a:4:{s:4:\"file\";s:36:\"CLASS-logo-wo-background-370x270.png\";s:5:\"width\";i:370;s:6:\"height\";i:270;s:9:\"mime-type\";s:9:\"image/png\";}s:21:\"portfolio-four-column\";a:4:{s:4:\"file\";s:36:\"CLASS-logo-wo-background-270x197.png\";s:5:\"width\";i:270;s:6:\"height\";i:197;s:9:\"mime-type\";s:9:\"image/png\";}s:17:\"portfolio-compact\";a:4:{s:4:\"file\";s:36:\"CLASS-logo-wo-background-770x482.png\";s:5:\"width\";i:770;s:6:\"height\";i:482;s:9:\"mime-type\";s:9:\"image/png\";}s:10:\"blog-large\";a:4:{s:4:\"file\";s:36:\"CLASS-logo-wo-background-770x270.png\";s:5:\"width\";i:770;s:6:\"height\";i:270;s:9:\"mime-type\";s:9:\"image/png\";}s:15:\"blog-full-width\";a:4:{s:4:\"file\";s:37:\"CLASS-logo-wo-background-1031x270.png\";s:5:\"width\";i:1031;s:6:\"height\";i:270;s:9:\"mime-type\";s:9:\"image/png\";}s:11:\"blog-medium\";a:4:{s:4:\"file\";s:36:\"CLASS-logo-wo-background-740x482.png\";s:5:\"width\";i:740;s:6:\"height\";i:482;s:9:\"mime-type\";s:9:\"image/png\";}s:9:\"blog-grid\";a:4:{s:4:\"file\";s:36:\"CLASS-logo-wo-background-370x270.png\";s:5:\"width\";i:370;s:6:\"height\";i:270;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:36:\"CLASS-logo-wo-background-125x125.png\";s:5:\"width\";i:125;s:6:\"height\";i:125;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES("1703","358","_wp_attached_file","2014/08/CLASS-logo.jpg");
INSERT INTO `wp_postmeta` VALUES("1704","358","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1031;s:6:\"height\";i:482;s:4:\"file\";s:22:\"2014/08/CLASS-logo.jpg\";s:5:\"sizes\";a:14:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:22:\"CLASS-logo-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:22:\"CLASS-logo-300x140.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:140;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:23:\"CLASS-logo-1024x478.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:478;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"bones-thumb-600\";a:4:{s:4:\"file\";s:22:\"CLASS-logo-600x150.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"bones-thumb-300\";a:4:{s:4:\"file\";s:22:\"CLASS-logo-300x100.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:20:\"portfolio-two-column\";a:4:{s:4:\"file\";s:22:\"CLASS-logo-570x416.jpg\";s:5:\"width\";i:570;s:6:\"height\";i:416;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:22:\"portfolio-three-column\";a:4:{s:4:\"file\";s:22:\"CLASS-logo-370x270.jpg\";s:5:\"width\";i:370;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"portfolio-four-column\";a:4:{s:4:\"file\";s:22:\"CLASS-logo-270x197.jpg\";s:5:\"width\";i:270;s:6:\"height\";i:197;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:17:\"portfolio-compact\";a:4:{s:4:\"file\";s:22:\"CLASS-logo-770x482.jpg\";s:5:\"width\";i:770;s:6:\"height\";i:482;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:10:\"blog-large\";a:4:{s:4:\"file\";s:22:\"CLASS-logo-770x270.jpg\";s:5:\"width\";i:770;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"blog-full-width\";a:4:{s:4:\"file\";s:23:\"CLASS-logo-1031x270.jpg\";s:5:\"width\";i:1031;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"blog-medium\";a:4:{s:4:\"file\";s:22:\"CLASS-logo-740x482.jpg\";s:5:\"width\";i:740;s:6:\"height\";i:482;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"blog-grid\";a:4:{s:4:\"file\";s:22:\"CLASS-logo-370x270.jpg\";s:5:\"width\";i:370;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:22:\"CLASS-logo-125x125.jpg\";s:5:\"width\";i:125;s:6:\"height\";i:125;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES("1705","359","_wp_attached_file","2014/08/IOPtima-Brochure-2014.pdf");
INSERT INTO `wp_postmeta` VALUES("1706","359","_edit_lock","1408630073:2");
INSERT INTO `wp_postmeta` VALUES("1707","361","_wp_attached_file","2014/08/OSN-AP-JulyAugust-14_Melamed-CLASS-page-002.jpg");
INSERT INTO `wp_postmeta` VALUES("1708","361","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1238;s:6:\"height\";i:1856;s:4:\"file\";s:55:\"2014/08/OSN-AP-JulyAugust-14_Melamed-CLASS-page-002.jpg\";s:5:\"sizes\";a:15:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:55:\"OSN-AP-JulyAugust-14_Melamed-CLASS-page-002-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:55:\"OSN-AP-JulyAugust-14_Melamed-CLASS-page-002-200x300.jpg\";s:5:\"width\";i:200;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:56:\"OSN-AP-JulyAugust-14_Melamed-CLASS-page-002-683x1024.jpg\";s:5:\"width\";i:683;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"bones-thumb-600\";a:4:{s:4:\"file\";s:55:\"OSN-AP-JulyAugust-14_Melamed-CLASS-page-002-600x150.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"bones-thumb-300\";a:4:{s:4:\"file\";s:55:\"OSN-AP-JulyAugust-14_Melamed-CLASS-page-002-300x100.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:20:\"portfolio-one-column\";a:4:{s:4:\"file\";s:56:\"OSN-AP-JulyAugust-14_Melamed-CLASS-page-002-1170x854.jpg\";s:5:\"width\";i:1170;s:6:\"height\";i:854;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:20:\"portfolio-two-column\";a:4:{s:4:\"file\";s:55:\"OSN-AP-JulyAugust-14_Melamed-CLASS-page-002-570x416.jpg\";s:5:\"width\";i:570;s:6:\"height\";i:416;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:22:\"portfolio-three-column\";a:4:{s:4:\"file\";s:55:\"OSN-AP-JulyAugust-14_Melamed-CLASS-page-002-370x270.jpg\";s:5:\"width\";i:370;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"portfolio-four-column\";a:4:{s:4:\"file\";s:55:\"OSN-AP-JulyAugust-14_Melamed-CLASS-page-002-270x197.jpg\";s:5:\"width\";i:270;s:6:\"height\";i:197;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:17:\"portfolio-compact\";a:4:{s:4:\"file\";s:55:\"OSN-AP-JulyAugust-14_Melamed-CLASS-page-002-770x513.jpg\";s:5:\"width\";i:770;s:6:\"height\";i:513;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:10:\"blog-large\";a:4:{s:4:\"file\";s:55:\"OSN-AP-JulyAugust-14_Melamed-CLASS-page-002-770x270.jpg\";s:5:\"width\";i:770;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"blog-full-width\";a:4:{s:4:\"file\";s:56:\"OSN-AP-JulyAugust-14_Melamed-CLASS-page-002-1170x270.jpg\";s:5:\"width\";i:1170;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"blog-medium\";a:4:{s:4:\"file\";s:55:\"OSN-AP-JulyAugust-14_Melamed-CLASS-page-002-740x540.jpg\";s:5:\"width\";i:740;s:6:\"height\";i:540;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"blog-grid\";a:4:{s:4:\"file\";s:55:\"OSN-AP-JulyAugust-14_Melamed-CLASS-page-002-370x270.jpg\";s:5:\"width\";i:370;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:55:\"OSN-AP-JulyAugust-14_Melamed-CLASS-page-002-125x125.jpg\";s:5:\"width\";i:125;s:6:\"height\";i:125;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES("1709","362","_wp_attached_file","2014/08/OSN-AP-JulyAugust-14_Melamed-CLASS.pdf");
INSERT INTO `wp_postmeta` VALUES("1710","361","_edit_lock","1408861070:2");
INSERT INTO `wp_postmeta` VALUES("1711","362","_edit_lock","1408862049:2");
INSERT INTO `wp_postmeta` VALUES("1712","364","_edit_lock","1408954153:2");
INSERT INTO `wp_postmeta` VALUES("1713","364","_edit_last","2");
INSERT INTO `wp_postmeta` VALUES("1714","364","_wp_page_template","page-sidebar-left-submenu.php");
INSERT INTO `wp_postmeta` VALUES("1715","364","_wpb_vc_js_status","true");
INSERT INTO `wp_postmeta` VALUES("1716","364","_wpb_vc_js_interface_version","0");
INSERT INTO `wp_postmeta` VALUES("1717","364","_peach_bkgd_color","#");
INSERT INTO `wp_postmeta` VALUES("1718","364","_peach_bkgd_repeat","no-repeat");
INSERT INTO `wp_postmeta` VALUES("1719","364","_peach_bkgd_position","top left");
INSERT INTO `wp_postmeta` VALUES("1720","364","_peach_bkgd_attachment","scroll");
INSERT INTO `wp_postmeta` VALUES("1721","364","_peach_header_bkgd_color","#");
INSERT INTO `wp_postmeta` VALUES("1722","364","_peach_header_bkgd_repeat","no-repeat");
INSERT INTO `wp_postmeta` VALUES("1723","364","_peach_header_bkgd_position","top left");
INSERT INTO `wp_postmeta` VALUES("1724","364","_peach_header_bkgd_attachment","scroll");
INSERT INTO `wp_postmeta` VALUES("1725","364","_peach_breadcrumb_align","left");
INSERT INTO `wp_postmeta` VALUES("1726","364","_peach_hide_breadcrumb","on");
INSERT INTO `wp_postmeta` VALUES("1727","364","_yoast_wpseo_focuskw","glaucoma surgery candidate");
INSERT INTO `wp_postmeta` VALUES("1728","364","_yoast_wpseo_linkdex","39");
INSERT INTO `wp_postmeta` VALUES("1729","368","_menu_item_type","post_type");
INSERT INTO `wp_postmeta` VALUES("1730","368","_menu_item_menu_item_parent","66");
INSERT INTO `wp_postmeta` VALUES("1731","368","_menu_item_object_id","364");
INSERT INTO `wp_postmeta` VALUES("1732","368","_menu_item_object","page");
INSERT INTO `wp_postmeta` VALUES("1733","368","_menu_item_target","");
INSERT INTO `wp_postmeta` VALUES("1734","368","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `wp_postmeta` VALUES("1735","368","_menu_item_xfn","");
INSERT INTO `wp_postmeta` VALUES("1736","368","_menu_item_url","");
INSERT INTO `wp_postmeta` VALUES("1738","212","_edit_lock","1408950122:2");
INSERT INTO `wp_postmeta` VALUES("1743","96","_oembed_f4a3d734c75cdd67e43f44bdfffdc106","<iframe width=\"1170\" height=\"658\" src=\"https://www.youtube.com/embed/ejQbUMjxUI0?feature=oembed\" frameborder=\"0\" allowfullscreen></iframe>");
INSERT INTO `wp_postmeta` VALUES("1744","43","_yoast_wpseo_metadesc","Safe, minimally-invasive laser procedure, low post-operation complications rate, simple to perform, reduces the need for medications, cost effective.");
INSERT INTO `wp_postmeta` VALUES("1745","94","_yoast_wpseo_meta-robots-noindex","2");
INSERT INTO `wp_postmeta` VALUES("1747","134","_yoast_wpseo_meta-robots-noindex","1");
INSERT INTO `wp_postmeta` VALUES("1748","134","_yoast_wpseo_meta-robots-nofollow","1");
INSERT INTO `wp_postmeta` VALUES("1749","91","_yoast_wpseo_meta-robots-noindex","1");
INSERT INTO `wp_postmeta` VALUES("1750","91","_yoast_wpseo_meta-robots-nofollow","1");
INSERT INTO `wp_postmeta` VALUES("1751","92","_yoast_wpseo_meta-robots-noindex","1");
INSERT INTO `wp_postmeta` VALUES("1752","92","_yoast_wpseo_meta-robots-nofollow","1");
INSERT INTO `wp_postmeta` VALUES("1753","93","_yoast_wpseo_meta-robots-noindex","1");
INSERT INTO `wp_postmeta` VALUES("1754","93","_yoast_wpseo_meta-robots-nofollow","1");
INSERT INTO `wp_postmeta` VALUES("1755","381","_menu_item_type","post_type");
INSERT INTO `wp_postmeta` VALUES("1756","381","_menu_item_menu_item_parent","0");
INSERT INTO `wp_postmeta` VALUES("1757","381","_menu_item_object_id","5");
INSERT INTO `wp_postmeta` VALUES("1758","381","_menu_item_object","page");
INSERT INTO `wp_postmeta` VALUES("1759","381","_menu_item_target","");
INSERT INTO `wp_postmeta` VALUES("1760","381","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `wp_postmeta` VALUES("1761","381","_menu_item_xfn","");
INSERT INTO `wp_postmeta` VALUES("1762","381","_menu_item_url","");
INSERT INTO `wp_postmeta` VALUES("1766","385","_wp_attached_file","2014/09/AOC_CLASS_9.2014_Noecker_Robin.pdf");
INSERT INTO `wp_postmeta` VALUES("1767","386","_wp_attached_file","2014/09/OSN_CLASS_Venkatesh_9.17.14.pdf");
INSERT INTO `wp_postmeta` VALUES("1768","387","_wp_attached_file","2014/09/OSN_CLASS_Venkatesh_9.17.14-page-001.jpg");
INSERT INTO `wp_postmeta` VALUES("1769","387","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1275;s:6:\"height\";i:1650;s:4:\"file\";s:48:\"2014/09/OSN_CLASS_Venkatesh_9.17.14-page-001.jpg\";s:5:\"sizes\";a:15:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:48:\"OSN_CLASS_Venkatesh_9.17.14-page-001-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:48:\"OSN_CLASS_Venkatesh_9.17.14-page-001-231x300.jpg\";s:5:\"width\";i:231;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:49:\"OSN_CLASS_Venkatesh_9.17.14-page-001-791x1024.jpg\";s:5:\"width\";i:791;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"bones-thumb-600\";a:4:{s:4:\"file\";s:48:\"OSN_CLASS_Venkatesh_9.17.14-page-001-600x150.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"bones-thumb-300\";a:4:{s:4:\"file\";s:48:\"OSN_CLASS_Venkatesh_9.17.14-page-001-300x100.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:20:\"portfolio-one-column\";a:4:{s:4:\"file\";s:49:\"OSN_CLASS_Venkatesh_9.17.14-page-001-1170x854.jpg\";s:5:\"width\";i:1170;s:6:\"height\";i:854;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:20:\"portfolio-two-column\";a:4:{s:4:\"file\";s:48:\"OSN_CLASS_Venkatesh_9.17.14-page-001-570x416.jpg\";s:5:\"width\";i:570;s:6:\"height\";i:416;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:22:\"portfolio-three-column\";a:4:{s:4:\"file\";s:48:\"OSN_CLASS_Venkatesh_9.17.14-page-001-370x270.jpg\";s:5:\"width\";i:370;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"portfolio-four-column\";a:4:{s:4:\"file\";s:48:\"OSN_CLASS_Venkatesh_9.17.14-page-001-270x197.jpg\";s:5:\"width\";i:270;s:6:\"height\";i:197;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:17:\"portfolio-compact\";a:4:{s:4:\"file\";s:48:\"OSN_CLASS_Venkatesh_9.17.14-page-001-770x513.jpg\";s:5:\"width\";i:770;s:6:\"height\";i:513;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:10:\"blog-large\";a:4:{s:4:\"file\";s:48:\"OSN_CLASS_Venkatesh_9.17.14-page-001-770x270.jpg\";s:5:\"width\";i:770;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"blog-full-width\";a:4:{s:4:\"file\";s:49:\"OSN_CLASS_Venkatesh_9.17.14-page-001-1170x270.jpg\";s:5:\"width\";i:1170;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"blog-medium\";a:4:{s:4:\"file\";s:48:\"OSN_CLASS_Venkatesh_9.17.14-page-001-740x540.jpg\";s:5:\"width\";i:740;s:6:\"height\";i:540;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"blog-grid\";a:4:{s:4:\"file\";s:48:\"OSN_CLASS_Venkatesh_9.17.14-page-001-370x270.jpg\";s:5:\"width\";i:370;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:48:\"OSN_CLASS_Venkatesh_9.17.14-page-001-125x125.jpg\";s:5:\"width\";i:125;s:6:\"height\";i:125;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES("1770","388","_wp_attached_file","2014/09/AOC_CLASS_9.2014_Noecker_Robin-page-001.jpg");
INSERT INTO `wp_postmeta` VALUES("1771","388","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1275;s:6:\"height\";i:1650;s:4:\"file\";s:51:\"2014/09/AOC_CLASS_9.2014_Noecker_Robin-page-001.jpg\";s:5:\"sizes\";a:15:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:51:\"AOC_CLASS_9.2014_Noecker_Robin-page-001-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:51:\"AOC_CLASS_9.2014_Noecker_Robin-page-001-231x300.jpg\";s:5:\"width\";i:231;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:52:\"AOC_CLASS_9.2014_Noecker_Robin-page-001-791x1024.jpg\";s:5:\"width\";i:791;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"bones-thumb-600\";a:4:{s:4:\"file\";s:51:\"AOC_CLASS_9.2014_Noecker_Robin-page-001-600x150.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"bones-thumb-300\";a:4:{s:4:\"file\";s:51:\"AOC_CLASS_9.2014_Noecker_Robin-page-001-300x100.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:20:\"portfolio-one-column\";a:4:{s:4:\"file\";s:52:\"AOC_CLASS_9.2014_Noecker_Robin-page-001-1170x854.jpg\";s:5:\"width\";i:1170;s:6:\"height\";i:854;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:20:\"portfolio-two-column\";a:4:{s:4:\"file\";s:51:\"AOC_CLASS_9.2014_Noecker_Robin-page-001-570x416.jpg\";s:5:\"width\";i:570;s:6:\"height\";i:416;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:22:\"portfolio-three-column\";a:4:{s:4:\"file\";s:51:\"AOC_CLASS_9.2014_Noecker_Robin-page-001-370x270.jpg\";s:5:\"width\";i:370;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"portfolio-four-column\";a:4:{s:4:\"file\";s:51:\"AOC_CLASS_9.2014_Noecker_Robin-page-001-270x197.jpg\";s:5:\"width\";i:270;s:6:\"height\";i:197;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:17:\"portfolio-compact\";a:4:{s:4:\"file\";s:51:\"AOC_CLASS_9.2014_Noecker_Robin-page-001-770x513.jpg\";s:5:\"width\";i:770;s:6:\"height\";i:513;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:10:\"blog-large\";a:4:{s:4:\"file\";s:51:\"AOC_CLASS_9.2014_Noecker_Robin-page-001-770x270.jpg\";s:5:\"width\";i:770;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"blog-full-width\";a:4:{s:4:\"file\";s:52:\"AOC_CLASS_9.2014_Noecker_Robin-page-001-1170x270.jpg\";s:5:\"width\";i:1170;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"blog-medium\";a:4:{s:4:\"file\";s:51:\"AOC_CLASS_9.2014_Noecker_Robin-page-001-740x540.jpg\";s:5:\"width\";i:740;s:6:\"height\";i:540;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"blog-grid\";a:4:{s:4:\"file\";s:51:\"AOC_CLASS_9.2014_Noecker_Robin-page-001-370x270.jpg\";s:5:\"width\";i:370;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:51:\"AOC_CLASS_9.2014_Noecker_Robin-page-001-125x125.jpg\";s:5:\"width\";i:125;s:6:\"height\";i:125;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES("1772","387","_edit_lock","1411282130:2");
INSERT INTO `wp_postmeta` VALUES("1773","386","_edit_lock","1411282213:2");
INSERT INTO `wp_postmeta` VALUES("1774","385","_edit_lock","1411282531:2");
INSERT INTO `wp_postmeta` VALUES("1775","391","_wp_attached_file","2014/09/OSN_LA_CLASS-SeptOct2014_Turati.pdf");
INSERT INTO `wp_postmeta` VALUES("1776","391","_edit_lock","1411470435:2");
INSERT INTO `wp_postmeta` VALUES("1777","393","_wp_attached_file","2014/09/OSN_LA_CLASS-SeptOct2014_Turati-page-001.jpg");
INSERT INTO `wp_postmeta` VALUES("1778","393","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1275;s:6:\"height\";i:1650;s:4:\"file\";s:52:\"2014/09/OSN_LA_CLASS-SeptOct2014_Turati-page-001.jpg\";s:5:\"sizes\";a:15:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:52:\"OSN_LA_CLASS-SeptOct2014_Turati-page-001-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:52:\"OSN_LA_CLASS-SeptOct2014_Turati-page-001-231x300.jpg\";s:5:\"width\";i:231;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:53:\"OSN_LA_CLASS-SeptOct2014_Turati-page-001-791x1024.jpg\";s:5:\"width\";i:791;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"bones-thumb-600\";a:4:{s:4:\"file\";s:52:\"OSN_LA_CLASS-SeptOct2014_Turati-page-001-600x150.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"bones-thumb-300\";a:4:{s:4:\"file\";s:52:\"OSN_LA_CLASS-SeptOct2014_Turati-page-001-300x100.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:20:\"portfolio-one-column\";a:4:{s:4:\"file\";s:53:\"OSN_LA_CLASS-SeptOct2014_Turati-page-001-1170x854.jpg\";s:5:\"width\";i:1170;s:6:\"height\";i:854;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:20:\"portfolio-two-column\";a:4:{s:4:\"file\";s:52:\"OSN_LA_CLASS-SeptOct2014_Turati-page-001-570x416.jpg\";s:5:\"width\";i:570;s:6:\"height\";i:416;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:22:\"portfolio-three-column\";a:4:{s:4:\"file\";s:52:\"OSN_LA_CLASS-SeptOct2014_Turati-page-001-370x270.jpg\";s:5:\"width\";i:370;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"portfolio-four-column\";a:4:{s:4:\"file\";s:52:\"OSN_LA_CLASS-SeptOct2014_Turati-page-001-270x197.jpg\";s:5:\"width\";i:270;s:6:\"height\";i:197;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:17:\"portfolio-compact\";a:4:{s:4:\"file\";s:52:\"OSN_LA_CLASS-SeptOct2014_Turati-page-001-770x513.jpg\";s:5:\"width\";i:770;s:6:\"height\";i:513;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:10:\"blog-large\";a:4:{s:4:\"file\";s:52:\"OSN_LA_CLASS-SeptOct2014_Turati-page-001-770x270.jpg\";s:5:\"width\";i:770;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"blog-full-width\";a:4:{s:4:\"file\";s:53:\"OSN_LA_CLASS-SeptOct2014_Turati-page-001-1170x270.jpg\";s:5:\"width\";i:1170;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"blog-medium\";a:4:{s:4:\"file\";s:52:\"OSN_LA_CLASS-SeptOct2014_Turati-page-001-740x540.jpg\";s:5:\"width\";i:740;s:6:\"height\";i:540;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"blog-grid\";a:4:{s:4:\"file\";s:52:\"OSN_LA_CLASS-SeptOct2014_Turati-page-001-370x270.jpg\";s:5:\"width\";i:370;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:52:\"OSN_LA_CLASS-SeptOct2014_Turati-page-001-125x125.jpg\";s:5:\"width\";i:125;s:6:\"height\";i:125;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES("1779","393","_edit_lock","1411470319:2");
INSERT INTO `wp_postmeta` VALUES("1781","401","_wp_attached_file","2014/10/Certificates.bmp");
INSERT INTO `wp_postmeta` VALUES("1782","401","_wp_attachment_metadata","a:5:{s:5:\"width\";i:763;s:6:\"height\";i:134;s:4:\"file\";s:24:\"2014/10/Certificates.bmp\";s:5:\"sizes\";a:10:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:24:\"Certificates-150x134.bmp\";s:5:\"width\";i:150;s:6:\"height\";i:134;s:9:\"mime-type\";s:9:\"image/bmp\";}s:6:\"medium\";a:4:{s:4:\"file\";s:23:\"Certificates-300x52.bmp\";s:5:\"width\";i:300;s:6:\"height\";i:52;s:9:\"mime-type\";s:9:\"image/bmp\";}s:15:\"bones-thumb-600\";a:4:{s:4:\"file\";s:24:\"Certificates-600x134.bmp\";s:5:\"width\";i:600;s:6:\"height\";i:134;s:9:\"mime-type\";s:9:\"image/bmp\";}s:15:\"bones-thumb-300\";a:4:{s:4:\"file\";s:24:\"Certificates-300x100.bmp\";s:5:\"width\";i:300;s:6:\"height\";i:100;s:9:\"mime-type\";s:9:\"image/bmp\";}s:20:\"portfolio-two-column\";a:4:{s:4:\"file\";s:24:\"Certificates-570x134.bmp\";s:5:\"width\";i:570;s:6:\"height\";i:134;s:9:\"mime-type\";s:9:\"image/bmp\";}s:22:\"portfolio-three-column\";a:4:{s:4:\"file\";s:24:\"Certificates-370x134.bmp\";s:5:\"width\";i:370;s:6:\"height\";i:134;s:9:\"mime-type\";s:9:\"image/bmp\";}s:21:\"portfolio-four-column\";a:4:{s:4:\"file\";s:24:\"Certificates-270x134.bmp\";s:5:\"width\";i:270;s:6:\"height\";i:134;s:9:\"mime-type\";s:9:\"image/bmp\";}s:11:\"blog-medium\";a:4:{s:4:\"file\";s:24:\"Certificates-740x134.bmp\";s:5:\"width\";i:740;s:6:\"height\";i:134;s:9:\"mime-type\";s:9:\"image/bmp\";}s:9:\"blog-grid\";a:4:{s:4:\"file\";s:24:\"Certificates-370x134.bmp\";s:5:\"width\";i:370;s:6:\"height\";i:134;s:9:\"mime-type\";s:9:\"image/bmp\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:24:\"Certificates-125x125.bmp\";s:5:\"width\";i:125;s:6:\"height\";i:125;s:9:\"mime-type\";s:9:\"image/bmp\";}}s:10:\"image_meta\";a:11:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";s:11:\"orientation\";i:0;}}");
INSERT INTO `wp_postmeta` VALUES("1783","63","_oembed_de871ce525ea4b27a052ef1710eccf3a","{{unknown}}");
INSERT INTO `wp_postmeta` VALUES("1784","403","_wp_attached_file","2014/10/MERMOID.png");
INSERT INTO `wp_postmeta` VALUES("1785","403","_wp_attachment_metadata","a:5:{s:5:\"width\";i:125;s:6:\"height\";i:142;s:4:\"file\";s:19:\"2014/10/MERMOID.png\";s:5:\"sizes\";a:2:{s:15:\"bones-thumb-300\";a:4:{s:4:\"file\";s:19:\"MERMOID-125x100.png\";s:5:\"width\";i:125;s:6:\"height\";i:100;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:19:\"MERMOID-125x125.png\";s:5:\"width\";i:125;s:6:\"height\";i:125;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:11:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";s:11:\"orientation\";i:0;}}");
INSERT INTO `wp_postmeta` VALUES("1786","404","_wp_attached_file","2014/10/doctoruna-gonzalo-munoz-5133109b687f1.jpg");
INSERT INTO `wp_postmeta` VALUES("1787","404","_wp_attachment_metadata","a:5:{s:5:\"width\";i:848;s:6:\"height\";i:996;s:4:\"file\";s:49:\"2014/10/doctoruna-gonzalo-munoz-5133109b687f1.jpg\";s:5:\"sizes\";a:14:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:49:\"doctoruna-gonzalo-munoz-5133109b687f1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:49:\"doctoruna-gonzalo-munoz-5133109b687f1-255x300.jpg\";s:5:\"width\";i:255;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"bones-thumb-600\";a:4:{s:4:\"file\";s:49:\"doctoruna-gonzalo-munoz-5133109b687f1-600x150.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"bones-thumb-300\";a:4:{s:4:\"file\";s:49:\"doctoruna-gonzalo-munoz-5133109b687f1-300x100.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:20:\"portfolio-one-column\";a:4:{s:4:\"file\";s:49:\"doctoruna-gonzalo-munoz-5133109b687f1-848x854.jpg\";s:5:\"width\";i:848;s:6:\"height\";i:854;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:20:\"portfolio-two-column\";a:4:{s:4:\"file\";s:49:\"doctoruna-gonzalo-munoz-5133109b687f1-570x416.jpg\";s:5:\"width\";i:570;s:6:\"height\";i:416;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:22:\"portfolio-three-column\";a:4:{s:4:\"file\";s:49:\"doctoruna-gonzalo-munoz-5133109b687f1-370x270.jpg\";s:5:\"width\";i:370;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"portfolio-four-column\";a:4:{s:4:\"file\";s:49:\"doctoruna-gonzalo-munoz-5133109b687f1-270x197.jpg\";s:5:\"width\";i:270;s:6:\"height\";i:197;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:17:\"portfolio-compact\";a:4:{s:4:\"file\";s:49:\"doctoruna-gonzalo-munoz-5133109b687f1-770x513.jpg\";s:5:\"width\";i:770;s:6:\"height\";i:513;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:10:\"blog-large\";a:4:{s:4:\"file\";s:49:\"doctoruna-gonzalo-munoz-5133109b687f1-770x270.jpg\";s:5:\"width\";i:770;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"blog-full-width\";a:4:{s:4:\"file\";s:49:\"doctoruna-gonzalo-munoz-5133109b687f1-848x270.jpg\";s:5:\"width\";i:848;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"blog-medium\";a:4:{s:4:\"file\";s:49:\"doctoruna-gonzalo-munoz-5133109b687f1-740x540.jpg\";s:5:\"width\";i:740;s:6:\"height\";i:540;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"blog-grid\";a:4:{s:4:\"file\";s:49:\"doctoruna-gonzalo-munoz-5133109b687f1-370x270.jpg\";s:5:\"width\";i:370;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:49:\"doctoruna-gonzalo-munoz-5133109b687f1-125x125.jpg\";s:5:\"width\";i:125;s:6:\"height\";i:125;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:11:{s:8:\"aperture\";d:4.5;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:22:\"Canon EOS 350D DIGITAL\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:1089668510;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:2:\"28\";s:3:\"iso\";s:4:\"1600\";s:13:\"shutter_speed\";s:15:\"0.0333333333333\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";i:1;}}");
INSERT INTO `wp_postmeta` VALUES("1788","405","_wp_attached_file","2014/10/Shaarawy.jpg");
INSERT INTO `wp_postmeta` VALUES("1789","405","_wp_attachment_metadata","a:5:{s:5:\"width\";i:119;s:6:\"height\";i:150;s:4:\"file\";s:20:\"2014/10/Shaarawy.jpg\";s:5:\"sizes\";a:2:{s:15:\"bones-thumb-300\";a:4:{s:4:\"file\";s:20:\"Shaarawy-119x100.jpg\";s:5:\"width\";i:119;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:20:\"Shaarawy-119x125.jpg\";s:5:\"width\";i:119;s:6:\"height\";i:125;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:11:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";s:11:\"orientation\";i:0;}}");
INSERT INTO `wp_postmeta` VALUES("1790","406","_wp_attached_file","2014/10/felix-gil-carrasco1.jpg");
INSERT INTO `wp_postmeta` VALUES("1791","406","_wp_attachment_metadata","a:5:{s:5:\"width\";i:241;s:6:\"height\";i:327;s:4:\"file\";s:31:\"2014/10/felix-gil-carrasco1.jpg\";s:5:\"sizes\";a:10:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:31:\"felix-gil-carrasco1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:31:\"felix-gil-carrasco1-221x300.jpg\";s:5:\"width\";i:221;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"bones-thumb-600\";a:4:{s:4:\"file\";s:31:\"felix-gil-carrasco1-241x150.jpg\";s:5:\"width\";i:241;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"bones-thumb-300\";a:4:{s:4:\"file\";s:31:\"felix-gil-carrasco1-241x100.jpg\";s:5:\"width\";i:241;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:22:\"portfolio-three-column\";a:4:{s:4:\"file\";s:31:\"felix-gil-carrasco1-241x270.jpg\";s:5:\"width\";i:241;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"portfolio-four-column\";a:4:{s:4:\"file\";s:31:\"felix-gil-carrasco1-241x197.jpg\";s:5:\"width\";i:241;s:6:\"height\";i:197;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:10:\"blog-large\";a:4:{s:4:\"file\";s:31:\"felix-gil-carrasco1-241x270.jpg\";s:5:\"width\";i:241;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"blog-full-width\";a:4:{s:4:\"file\";s:31:\"felix-gil-carrasco1-241x270.jpg\";s:5:\"width\";i:241;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"blog-grid\";a:4:{s:4:\"file\";s:31:\"felix-gil-carrasco1-241x270.jpg\";s:5:\"width\";i:241;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:31:\"felix-gil-carrasco1-125x125.jpg\";s:5:\"width\";i:125;s:6:\"height\";i:125;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:11:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";s:11:\"orientation\";i:0;}}");
INSERT INTO `wp_postmeta` VALUES("1792","407","_wp_attached_file","2014/10/Assia.jpg");
INSERT INTO `wp_postmeta` VALUES("1793","407","_wp_attachment_metadata","a:5:{s:5:\"width\";i:127;s:6:\"height\";i:162;s:4:\"file\";s:17:\"2014/10/Assia.jpg\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:17:\"Assia-127x150.jpg\";s:5:\"width\";i:127;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"bones-thumb-600\";a:4:{s:4:\"file\";s:17:\"Assia-127x150.jpg\";s:5:\"width\";i:127;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"bones-thumb-300\";a:4:{s:4:\"file\";s:17:\"Assia-127x100.jpg\";s:5:\"width\";i:127;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:17:\"Assia-125x125.jpg\";s:5:\"width\";i:125;s:6:\"height\";i:125;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:11:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";s:11:\"orientation\";i:0;}}");
INSERT INTO `wp_postmeta` VALUES("1794","414","_wp_attached_file","2014/11/Glaucoma-Effect-Rich.png");
INSERT INTO `wp_postmeta` VALUES("1795","414","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1058;s:6:\"height\";i:530;s:4:\"file\";s:32:\"2014/11/Glaucoma-Effect-Rich.png\";s:5:\"sizes\";a:14:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:32:\"Glaucoma-Effect-Rich-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:32:\"Glaucoma-Effect-Rich-300x150.png\";s:5:\"width\";i:300;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:5:\"large\";a:4:{s:4:\"file\";s:33:\"Glaucoma-Effect-Rich-1024x512.png\";s:5:\"width\";i:1024;s:6:\"height\";i:512;s:9:\"mime-type\";s:9:\"image/png\";}s:15:\"bones-thumb-600\";a:4:{s:4:\"file\";s:32:\"Glaucoma-Effect-Rich-600x150.png\";s:5:\"width\";i:600;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:15:\"bones-thumb-300\";a:4:{s:4:\"file\";s:32:\"Glaucoma-Effect-Rich-300x100.png\";s:5:\"width\";i:300;s:6:\"height\";i:100;s:9:\"mime-type\";s:9:\"image/png\";}s:20:\"portfolio-two-column\";a:4:{s:4:\"file\";s:32:\"Glaucoma-Effect-Rich-570x416.png\";s:5:\"width\";i:570;s:6:\"height\";i:416;s:9:\"mime-type\";s:9:\"image/png\";}s:22:\"portfolio-three-column\";a:4:{s:4:\"file\";s:32:\"Glaucoma-Effect-Rich-370x270.png\";s:5:\"width\";i:370;s:6:\"height\";i:270;s:9:\"mime-type\";s:9:\"image/png\";}s:21:\"portfolio-four-column\";a:4:{s:4:\"file\";s:32:\"Glaucoma-Effect-Rich-270x197.png\";s:5:\"width\";i:270;s:6:\"height\";i:197;s:9:\"mime-type\";s:9:\"image/png\";}s:17:\"portfolio-compact\";a:4:{s:4:\"file\";s:32:\"Glaucoma-Effect-Rich-770x513.png\";s:5:\"width\";i:770;s:6:\"height\";i:513;s:9:\"mime-type\";s:9:\"image/png\";}s:10:\"blog-large\";a:4:{s:4:\"file\";s:32:\"Glaucoma-Effect-Rich-770x270.png\";s:5:\"width\";i:770;s:6:\"height\";i:270;s:9:\"mime-type\";s:9:\"image/png\";}s:15:\"blog-full-width\";a:4:{s:4:\"file\";s:33:\"Glaucoma-Effect-Rich-1058x270.png\";s:5:\"width\";i:1058;s:6:\"height\";i:270;s:9:\"mime-type\";s:9:\"image/png\";}s:11:\"blog-medium\";a:4:{s:4:\"file\";s:32:\"Glaucoma-Effect-Rich-740x530.png\";s:5:\"width\";i:740;s:6:\"height\";i:530;s:9:\"mime-type\";s:9:\"image/png\";}s:9:\"blog-grid\";a:4:{s:4:\"file\";s:32:\"Glaucoma-Effect-Rich-370x270.png\";s:5:\"width\";i:370;s:6:\"height\";i:270;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:32:\"Glaucoma-Effect-Rich-125x125.png\";s:5:\"width\";i:125;s:6:\"height\";i:125;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:11:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";s:11:\"orientation\";i:0;}}");
INSERT INTO `wp_postmeta` VALUES("1799","423","_wp_attached_file","2014/11/CLASS-Marketing-introduction.zip");
INSERT INTO `wp_postmeta` VALUES("1800","428","_wp_attached_file","2014/11/CRST-Europe-Nov-Dec-14_CLASS_Venkatesh-page-001.jpg");
INSERT INTO `wp_postmeta` VALUES("1801","428","_wp_attachment_metadata","a:5:{s:5:\"width\";i:2550;s:6:\"height\";i:3300;s:4:\"file\";s:59:\"2014/11/CRST-Europe-Nov-Dec-14_CLASS_Venkatesh-page-001.jpg\";s:5:\"sizes\";a:15:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:59:\"CRST-Europe-Nov-Dec-14_CLASS_Venkatesh-page-001-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:59:\"CRST-Europe-Nov-Dec-14_CLASS_Venkatesh-page-001-231x300.jpg\";s:5:\"width\";i:231;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:60:\"CRST-Europe-Nov-Dec-14_CLASS_Venkatesh-page-001-791x1024.jpg\";s:5:\"width\";i:791;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"bones-thumb-600\";a:4:{s:4:\"file\";s:59:\"CRST-Europe-Nov-Dec-14_CLASS_Venkatesh-page-001-600x150.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"bones-thumb-300\";a:4:{s:4:\"file\";s:59:\"CRST-Europe-Nov-Dec-14_CLASS_Venkatesh-page-001-300x100.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:20:\"portfolio-one-column\";a:4:{s:4:\"file\";s:60:\"CRST-Europe-Nov-Dec-14_CLASS_Venkatesh-page-001-1170x854.jpg\";s:5:\"width\";i:1170;s:6:\"height\";i:854;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:20:\"portfolio-two-column\";a:4:{s:4:\"file\";s:59:\"CRST-Europe-Nov-Dec-14_CLASS_Venkatesh-page-001-570x416.jpg\";s:5:\"width\";i:570;s:6:\"height\";i:416;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:22:\"portfolio-three-column\";a:4:{s:4:\"file\";s:59:\"CRST-Europe-Nov-Dec-14_CLASS_Venkatesh-page-001-370x270.jpg\";s:5:\"width\";i:370;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"portfolio-four-column\";a:4:{s:4:\"file\";s:59:\"CRST-Europe-Nov-Dec-14_CLASS_Venkatesh-page-001-270x197.jpg\";s:5:\"width\";i:270;s:6:\"height\";i:197;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:17:\"portfolio-compact\";a:4:{s:4:\"file\";s:59:\"CRST-Europe-Nov-Dec-14_CLASS_Venkatesh-page-001-770x513.jpg\";s:5:\"width\";i:770;s:6:\"height\";i:513;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:10:\"blog-large\";a:4:{s:4:\"file\";s:59:\"CRST-Europe-Nov-Dec-14_CLASS_Venkatesh-page-001-770x270.jpg\";s:5:\"width\";i:770;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"blog-full-width\";a:4:{s:4:\"file\";s:60:\"CRST-Europe-Nov-Dec-14_CLASS_Venkatesh-page-001-1170x270.jpg\";s:5:\"width\";i:1170;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"blog-medium\";a:4:{s:4:\"file\";s:59:\"CRST-Europe-Nov-Dec-14_CLASS_Venkatesh-page-001-740x540.jpg\";s:5:\"width\";i:740;s:6:\"height\";i:540;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"blog-grid\";a:4:{s:4:\"file\";s:59:\"CRST-Europe-Nov-Dec-14_CLASS_Venkatesh-page-001-370x270.jpg\";s:5:\"width\";i:370;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:59:\"CRST-Europe-Nov-Dec-14_CLASS_Venkatesh-page-001-125x125.jpg\";s:5:\"width\";i:125;s:6:\"height\";i:125;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:11:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";s:11:\"orientation\";i:0;}}");
INSERT INTO `wp_postmeta` VALUES("1802","429","_wp_attached_file","2014/11/GT-NovDec-14.CLASS.Robin-page-001.jpg");
INSERT INTO `wp_postmeta` VALUES("1803","429","_wp_attachment_metadata","a:5:{s:5:\"width\";i:2550;s:6:\"height\";i:3300;s:4:\"file\";s:45:\"2014/11/GT-NovDec-14.CLASS.Robin-page-001.jpg\";s:5:\"sizes\";a:15:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:45:\"GT-NovDec-14.CLASS.Robin-page-001-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:45:\"GT-NovDec-14.CLASS.Robin-page-001-231x300.jpg\";s:5:\"width\";i:231;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:46:\"GT-NovDec-14.CLASS.Robin-page-001-791x1024.jpg\";s:5:\"width\";i:791;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"bones-thumb-600\";a:4:{s:4:\"file\";s:45:\"GT-NovDec-14.CLASS.Robin-page-001-600x150.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"bones-thumb-300\";a:4:{s:4:\"file\";s:45:\"GT-NovDec-14.CLASS.Robin-page-001-300x100.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:20:\"portfolio-one-column\";a:4:{s:4:\"file\";s:46:\"GT-NovDec-14.CLASS.Robin-page-001-1170x854.jpg\";s:5:\"width\";i:1170;s:6:\"height\";i:854;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:20:\"portfolio-two-column\";a:4:{s:4:\"file\";s:45:\"GT-NovDec-14.CLASS.Robin-page-001-570x416.jpg\";s:5:\"width\";i:570;s:6:\"height\";i:416;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:22:\"portfolio-three-column\";a:4:{s:4:\"file\";s:45:\"GT-NovDec-14.CLASS.Robin-page-001-370x270.jpg\";s:5:\"width\";i:370;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"portfolio-four-column\";a:4:{s:4:\"file\";s:45:\"GT-NovDec-14.CLASS.Robin-page-001-270x197.jpg\";s:5:\"width\";i:270;s:6:\"height\";i:197;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:17:\"portfolio-compact\";a:4:{s:4:\"file\";s:45:\"GT-NovDec-14.CLASS.Robin-page-001-770x513.jpg\";s:5:\"width\";i:770;s:6:\"height\";i:513;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:10:\"blog-large\";a:4:{s:4:\"file\";s:45:\"GT-NovDec-14.CLASS.Robin-page-001-770x270.jpg\";s:5:\"width\";i:770;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"blog-full-width\";a:4:{s:4:\"file\";s:46:\"GT-NovDec-14.CLASS.Robin-page-001-1170x270.jpg\";s:5:\"width\";i:1170;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"blog-medium\";a:4:{s:4:\"file\";s:45:\"GT-NovDec-14.CLASS.Robin-page-001-740x540.jpg\";s:5:\"width\";i:740;s:6:\"height\";i:540;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"blog-grid\";a:4:{s:4:\"file\";s:45:\"GT-NovDec-14.CLASS.Robin-page-001-370x270.jpg\";s:5:\"width\";i:370;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:45:\"GT-NovDec-14.CLASS.Robin-page-001-125x125.jpg\";s:5:\"width\";i:125;s:6:\"height\";i:125;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:11:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";s:11:\"orientation\";i:0;}}");
INSERT INTO `wp_postmeta` VALUES("1804","430","_wp_attached_file","2014/11/GT-NovDec-14.CLASS.Robin_.pdf");
INSERT INTO `wp_postmeta` VALUES("1805","431","_wp_attached_file","2014/11/CRST-Europe-Nov-Dec-14_CLASS_Venkatesh.pdf");
INSERT INTO `wp_postmeta` VALUES("1806","433","_wp_attached_file","2014/11/IOPtima-Pattern-Positioning-Training.zip");
INSERT INTO `wp_postmeta` VALUES("1807","435","_wp_attached_file","2014/12/00061198-900000000-99206-page-001.jpg");
INSERT INTO `wp_postmeta` VALUES("1808","435","_wp_attachment_metadata","a:5:{s:5:\"width\";i:2325;s:6:\"height\";i:3225;s:4:\"file\";s:45:\"2014/12/00061198-900000000-99206-page-001.jpg\";s:5:\"sizes\";a:15:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:45:\"00061198-900000000-99206-page-001-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:45:\"00061198-900000000-99206-page-001-216x300.jpg\";s:5:\"width\";i:216;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:46:\"00061198-900000000-99206-page-001-738x1024.jpg\";s:5:\"width\";i:738;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"bones-thumb-600\";a:4:{s:4:\"file\";s:45:\"00061198-900000000-99206-page-001-600x150.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"bones-thumb-300\";a:4:{s:4:\"file\";s:45:\"00061198-900000000-99206-page-001-300x100.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:20:\"portfolio-one-column\";a:4:{s:4:\"file\";s:46:\"00061198-900000000-99206-page-001-1170x854.jpg\";s:5:\"width\";i:1170;s:6:\"height\";i:854;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:20:\"portfolio-two-column\";a:4:{s:4:\"file\";s:45:\"00061198-900000000-99206-page-001-570x416.jpg\";s:5:\"width\";i:570;s:6:\"height\";i:416;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:22:\"portfolio-three-column\";a:4:{s:4:\"file\";s:45:\"00061198-900000000-99206-page-001-370x270.jpg\";s:5:\"width\";i:370;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"portfolio-four-column\";a:4:{s:4:\"file\";s:45:\"00061198-900000000-99206-page-001-270x197.jpg\";s:5:\"width\";i:270;s:6:\"height\";i:197;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:17:\"portfolio-compact\";a:4:{s:4:\"file\";s:45:\"00061198-900000000-99206-page-001-770x513.jpg\";s:5:\"width\";i:770;s:6:\"height\";i:513;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:10:\"blog-large\";a:4:{s:4:\"file\";s:45:\"00061198-900000000-99206-page-001-770x270.jpg\";s:5:\"width\";i:770;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"blog-full-width\";a:4:{s:4:\"file\";s:46:\"00061198-900000000-99206-page-001-1170x270.jpg\";s:5:\"width\";i:1170;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"blog-medium\";a:4:{s:4:\"file\";s:45:\"00061198-900000000-99206-page-001-740x540.jpg\";s:5:\"width\";i:740;s:6:\"height\";i:540;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"blog-grid\";a:4:{s:4:\"file\";s:45:\"00061198-900000000-99206-page-001-370x270.jpg\";s:5:\"width\";i:370;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:45:\"00061198-900000000-99206-page-001-125x125.jpg\";s:5:\"width\";i:125;s:6:\"height\";i:125;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:11:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";s:11:\"orientation\";i:0;}}");
INSERT INTO `wp_postmeta` VALUES("1809","436","_wp_attached_file","2014/12/Results-of-CO2-Laser-assisted-Deep-Sclerectomy_Greifner-et-al.pdf");
INSERT INTO `wp_postmeta` VALUES("1818","444","_wp_attached_file","2015/01/Performing-accurate-CO2-laser-assisted-sclerectomy-surgery-Ton-Assia-Geffen-page-001-1.jpg");
INSERT INTO `wp_postmeta` VALUES("1819","444","_wp_attachment_metadata","a:5:{s:5:\"width\";i:2539;s:6:\"height\";i:3307;s:4:\"file\";s:98:\"2015/01/Performing-accurate-CO2-laser-assisted-sclerectomy-surgery-Ton-Assia-Geffen-page-001-1.jpg\";s:5:\"sizes\";a:15:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:98:\"Performing-accurate-CO2-laser-assisted-sclerectomy-surgery-Ton-Assia-Geffen-page-001-1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:98:\"Performing-accurate-CO2-laser-assisted-sclerectomy-surgery-Ton-Assia-Geffen-page-001-1-230x300.jpg\";s:5:\"width\";i:230;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:99:\"Performing-accurate-CO2-laser-assisted-sclerectomy-surgery-Ton-Assia-Geffen-page-001-1-786x1024.jpg\";s:5:\"width\";i:786;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"bones-thumb-600\";a:4:{s:4:\"file\";s:98:\"Performing-accurate-CO2-laser-assisted-sclerectomy-surgery-Ton-Assia-Geffen-page-001-1-600x150.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"bones-thumb-300\";a:4:{s:4:\"file\";s:98:\"Performing-accurate-CO2-laser-assisted-sclerectomy-surgery-Ton-Assia-Geffen-page-001-1-300x100.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:20:\"portfolio-one-column\";a:4:{s:4:\"file\";s:99:\"Performing-accurate-CO2-laser-assisted-sclerectomy-surgery-Ton-Assia-Geffen-page-001-1-1170x854.jpg\";s:5:\"width\";i:1170;s:6:\"height\";i:854;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:20:\"portfolio-two-column\";a:4:{s:4:\"file\";s:98:\"Performing-accurate-CO2-laser-assisted-sclerectomy-surgery-Ton-Assia-Geffen-page-001-1-570x416.jpg\";s:5:\"width\";i:570;s:6:\"height\";i:416;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:22:\"portfolio-three-column\";a:4:{s:4:\"file\";s:98:\"Performing-accurate-CO2-laser-assisted-sclerectomy-surgery-Ton-Assia-Geffen-page-001-1-370x270.jpg\";s:5:\"width\";i:370;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"portfolio-four-column\";a:4:{s:4:\"file\";s:98:\"Performing-accurate-CO2-laser-assisted-sclerectomy-surgery-Ton-Assia-Geffen-page-001-1-270x197.jpg\";s:5:\"width\";i:270;s:6:\"height\";i:197;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:17:\"portfolio-compact\";a:4:{s:4:\"file\";s:98:\"Performing-accurate-CO2-laser-assisted-sclerectomy-surgery-Ton-Assia-Geffen-page-001-1-770x513.jpg\";s:5:\"width\";i:770;s:6:\"height\";i:513;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:10:\"blog-large\";a:4:{s:4:\"file\";s:98:\"Performing-accurate-CO2-laser-assisted-sclerectomy-surgery-Ton-Assia-Geffen-page-001-1-770x270.jpg\";s:5:\"width\";i:770;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"blog-full-width\";a:4:{s:4:\"file\";s:99:\"Performing-accurate-CO2-laser-assisted-sclerectomy-surgery-Ton-Assia-Geffen-page-001-1-1170x270.jpg\";s:5:\"width\";i:1170;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"blog-medium\";a:4:{s:4:\"file\";s:98:\"Performing-accurate-CO2-laser-assisted-sclerectomy-surgery-Ton-Assia-Geffen-page-001-1-740x540.jpg\";s:5:\"width\";i:740;s:6:\"height\";i:540;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"blog-grid\";a:4:{s:4:\"file\";s:98:\"Performing-accurate-CO2-laser-assisted-sclerectomy-surgery-Ton-Assia-Geffen-page-001-1-370x270.jpg\";s:5:\"width\";i:370;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:98:\"Performing-accurate-CO2-laser-assisted-sclerectomy-surgery-Ton-Assia-Geffen-page-001-1-125x125.jpg\";s:5:\"width\";i:125;s:6:\"height\";i:125;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:11:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";s:11:\"orientation\";i:0;}}");
INSERT INTO `wp_postmeta` VALUES("1820","445","_wp_attached_file","2015/01/Performing-accurate-CO2-laser-assisted-sclerectomy-surgery-Ton-Assia-Geffen.pdf");
INSERT INTO `wp_postmeta` VALUES("1821","447","_wp_attached_file","2014/03/Glaucoma-surgery_-Taking-the-sub-conjunctival-route-_Tarek-Shaarawy-Middle-East-African-Journal-of-Ophthalmology-2-page-003.jpg");
INSERT INTO `wp_postmeta` VALUES("1822","447","_wp_attachment_metadata","a:5:{s:5:\"width\";i:2550;s:6:\"height\";i:3300;s:4:\"file\";s:135:\"2014/03/Glaucoma-surgery_-Taking-the-sub-conjunctival-route-_Tarek-Shaarawy-Middle-East-African-Journal-of-Ophthalmology-2-page-003.jpg\";s:5:\"sizes\";a:15:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:135:\"Glaucoma-surgery_-Taking-the-sub-conjunctival-route-_Tarek-Shaarawy-Middle-East-African-Journal-of-Ophthalmology-2-page-003-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:135:\"Glaucoma-surgery_-Taking-the-sub-conjunctival-route-_Tarek-Shaarawy-Middle-East-African-Journal-of-Ophthalmology-2-page-003-231x300.jpg\";s:5:\"width\";i:231;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:136:\"Glaucoma-surgery_-Taking-the-sub-conjunctival-route-_Tarek-Shaarawy-Middle-East-African-Journal-of-Ophthalmology-2-page-003-791x1024.jpg\";s:5:\"width\";i:791;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"bones-thumb-600\";a:4:{s:4:\"file\";s:135:\"Glaucoma-surgery_-Taking-the-sub-conjunctival-route-_Tarek-Shaarawy-Middle-East-African-Journal-of-Ophthalmology-2-page-003-600x150.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"bones-thumb-300\";a:4:{s:4:\"file\";s:135:\"Glaucoma-surgery_-Taking-the-sub-conjunctival-route-_Tarek-Shaarawy-Middle-East-African-Journal-of-Ophthalmology-2-page-003-300x100.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:20:\"portfolio-one-column\";a:4:{s:4:\"file\";s:136:\"Glaucoma-surgery_-Taking-the-sub-conjunctival-route-_Tarek-Shaarawy-Middle-East-African-Journal-of-Ophthalmology-2-page-003-1170x854.jpg\";s:5:\"width\";i:1170;s:6:\"height\";i:854;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:20:\"portfolio-two-column\";a:4:{s:4:\"file\";s:135:\"Glaucoma-surgery_-Taking-the-sub-conjunctival-route-_Tarek-Shaarawy-Middle-East-African-Journal-of-Ophthalmology-2-page-003-570x416.jpg\";s:5:\"width\";i:570;s:6:\"height\";i:416;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:22:\"portfolio-three-column\";a:4:{s:4:\"file\";s:135:\"Glaucoma-surgery_-Taking-the-sub-conjunctival-route-_Tarek-Shaarawy-Middle-East-African-Journal-of-Ophthalmology-2-page-003-370x270.jpg\";s:5:\"width\";i:370;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"portfolio-four-column\";a:4:{s:4:\"file\";s:135:\"Glaucoma-surgery_-Taking-the-sub-conjunctival-route-_Tarek-Shaarawy-Middle-East-African-Journal-of-Ophthalmology-2-page-003-270x197.jpg\";s:5:\"width\";i:270;s:6:\"height\";i:197;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:17:\"portfolio-compact\";a:4:{s:4:\"file\";s:135:\"Glaucoma-surgery_-Taking-the-sub-conjunctival-route-_Tarek-Shaarawy-Middle-East-African-Journal-of-Ophthalmology-2-page-003-770x513.jpg\";s:5:\"width\";i:770;s:6:\"height\";i:513;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:10:\"blog-large\";a:4:{s:4:\"file\";s:135:\"Glaucoma-surgery_-Taking-the-sub-conjunctival-route-_Tarek-Shaarawy-Middle-East-African-Journal-of-Ophthalmology-2-page-003-770x270.jpg\";s:5:\"width\";i:770;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"blog-full-width\";a:4:{s:4:\"file\";s:136:\"Glaucoma-surgery_-Taking-the-sub-conjunctival-route-_Tarek-Shaarawy-Middle-East-African-Journal-of-Ophthalmology-2-page-003-1170x270.jpg\";s:5:\"width\";i:1170;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"blog-medium\";a:4:{s:4:\"file\";s:135:\"Glaucoma-surgery_-Taking-the-sub-conjunctival-route-_Tarek-Shaarawy-Middle-East-African-Journal-of-Ophthalmology-2-page-003-740x540.jpg\";s:5:\"width\";i:740;s:6:\"height\";i:540;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"blog-grid\";a:4:{s:4:\"file\";s:135:\"Glaucoma-surgery_-Taking-the-sub-conjunctival-route-_Tarek-Shaarawy-Middle-East-African-Journal-of-Ophthalmology-2-page-003-370x270.jpg\";s:5:\"width\";i:370;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:135:\"Glaucoma-surgery_-Taking-the-sub-conjunctival-route-_Tarek-Shaarawy-Middle-East-African-Journal-of-Ophthalmology-2-page-003-125x125.jpg\";s:5:\"width\";i:125;s:6:\"height\";i:125;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:11:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";s:11:\"orientation\";i:0;}}");
INSERT INTO `wp_postmeta` VALUES("1827","94","_yoast_wpseo_linkdex","37");
INSERT INTO `wp_postmeta` VALUES("1828","94","_yoast_wpseo_metadesc","Glaucoma, aka the silent thief of sight, is the second leading cause for irreversible blindness and results from optic nerve damage due to high IOP level");
INSERT INTO `wp_postmeta` VALUES("1829","454","_wp_attached_file","2015/02/OSN-2.10.2015.CLASS.Greifner.pdf");
INSERT INTO `wp_postmeta` VALUES("1830","454","_edit_lock","1423552028:2");
INSERT INTO `wp_postmeta` VALUES("1831","455","_wp_attached_file","2015/02/OSN-2.10.2015.CLASS.Greifner-page-001.jpg");
INSERT INTO `wp_postmeta` VALUES("1832","455","_wp_attachment_metadata","a:5:{s:5:\"width\";i:2550;s:6:\"height\";i:3300;s:4:\"file\";s:49:\"2015/02/OSN-2.10.2015.CLASS.Greifner-page-001.jpg\";s:5:\"sizes\";a:15:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:49:\"OSN-2.10.2015.CLASS.Greifner-page-001-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:49:\"OSN-2.10.2015.CLASS.Greifner-page-001-232x300.jpg\";s:5:\"width\";i:232;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:50:\"OSN-2.10.2015.CLASS.Greifner-page-001-791x1024.jpg\";s:5:\"width\";i:791;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"bones-thumb-600\";a:4:{s:4:\"file\";s:49:\"OSN-2.10.2015.CLASS.Greifner-page-001-600x150.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"bones-thumb-300\";a:4:{s:4:\"file\";s:49:\"OSN-2.10.2015.CLASS.Greifner-page-001-300x100.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:20:\"portfolio-one-column\";a:4:{s:4:\"file\";s:50:\"OSN-2.10.2015.CLASS.Greifner-page-001-1170x854.jpg\";s:5:\"width\";i:1170;s:6:\"height\";i:854;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:20:\"portfolio-two-column\";a:4:{s:4:\"file\";s:49:\"OSN-2.10.2015.CLASS.Greifner-page-001-570x416.jpg\";s:5:\"width\";i:570;s:6:\"height\";i:416;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:22:\"portfolio-three-column\";a:4:{s:4:\"file\";s:49:\"OSN-2.10.2015.CLASS.Greifner-page-001-370x270.jpg\";s:5:\"width\";i:370;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"portfolio-four-column\";a:4:{s:4:\"file\";s:49:\"OSN-2.10.2015.CLASS.Greifner-page-001-270x197.jpg\";s:5:\"width\";i:270;s:6:\"height\";i:197;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:17:\"portfolio-compact\";a:4:{s:4:\"file\";s:49:\"OSN-2.10.2015.CLASS.Greifner-page-001-770x513.jpg\";s:5:\"width\";i:770;s:6:\"height\";i:513;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:10:\"blog-large\";a:4:{s:4:\"file\";s:49:\"OSN-2.10.2015.CLASS.Greifner-page-001-770x270.jpg\";s:5:\"width\";i:770;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"blog-full-width\";a:4:{s:4:\"file\";s:50:\"OSN-2.10.2015.CLASS.Greifner-page-001-1170x270.jpg\";s:5:\"width\";i:1170;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"blog-medium\";a:4:{s:4:\"file\";s:49:\"OSN-2.10.2015.CLASS.Greifner-page-001-740x540.jpg\";s:5:\"width\";i:740;s:6:\"height\";i:540;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"blog-grid\";a:4:{s:4:\"file\";s:49:\"OSN-2.10.2015.CLASS.Greifner-page-001-370x270.jpg\";s:5:\"width\";i:370;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:49:\"OSN-2.10.2015.CLASS.Greifner-page-001-125x125.jpg\";s:5:\"width\";i:125;s:6:\"height\";i:125;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:11:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";s:11:\"orientation\";i:0;}}");
INSERT INTO `wp_postmeta` VALUES("1835","461","_wp_attached_file","2015/03/IOP-35-002-07-IOPtima-OT-135P2-ASS-35-102-TP-part-I-technical2.ppt");
INSERT INTO `wp_postmeta` VALUES("1836","461","_edit_lock","1426078671:2");
INSERT INTO `wp_postmeta` VALUES("1837","463","_wp_attached_file","2015/03/IOP-35-006-01-IOPtima-OT-135P2-ASS-35-102-TP-part-II-Daily-Testing.ppt");
INSERT INTO `wp_postmeta` VALUES("1838","464","_wp_attached_file","2015/03/IOP-35-00802-IOPtima-OT-135P2-ASS-35-102-TP-part-III-The-Procedure.ppt");
INSERT INTO `wp_postmeta` VALUES("1840","467","_wp_attached_file","2015/03/OSN-LA-MarchApril-CLASS-Greifner.pdf");
INSERT INTO `wp_postmeta` VALUES("1841","468","_wp_attached_file","2015/03/OSN-LA-MarchApril-CLASS-Greifner-page-003.jpg");
INSERT INTO `wp_postmeta` VALUES("1842","468","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1238;s:6:\"height\";i:1856;s:4:\"file\";s:53:\"2015/03/OSN-LA-MarchApril-CLASS-Greifner-page-003.jpg\";s:5:\"sizes\";a:15:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:53:\"OSN-LA-MarchApril-CLASS-Greifner-page-003-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:53:\"OSN-LA-MarchApril-CLASS-Greifner-page-003-200x300.jpg\";s:5:\"width\";i:200;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:54:\"OSN-LA-MarchApril-CLASS-Greifner-page-003-683x1024.jpg\";s:5:\"width\";i:683;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"bones-thumb-600\";a:4:{s:4:\"file\";s:53:\"OSN-LA-MarchApril-CLASS-Greifner-page-003-600x150.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"bones-thumb-300\";a:4:{s:4:\"file\";s:53:\"OSN-LA-MarchApril-CLASS-Greifner-page-003-300x100.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:20:\"portfolio-one-column\";a:4:{s:4:\"file\";s:54:\"OSN-LA-MarchApril-CLASS-Greifner-page-003-1170x854.jpg\";s:5:\"width\";i:1170;s:6:\"height\";i:854;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:20:\"portfolio-two-column\";a:4:{s:4:\"file\";s:53:\"OSN-LA-MarchApril-CLASS-Greifner-page-003-570x416.jpg\";s:5:\"width\";i:570;s:6:\"height\";i:416;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:22:\"portfolio-three-column\";a:4:{s:4:\"file\";s:53:\"OSN-LA-MarchApril-CLASS-Greifner-page-003-370x270.jpg\";s:5:\"width\";i:370;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"portfolio-four-column\";a:4:{s:4:\"file\";s:53:\"OSN-LA-MarchApril-CLASS-Greifner-page-003-270x197.jpg\";s:5:\"width\";i:270;s:6:\"height\";i:197;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:17:\"portfolio-compact\";a:4:{s:4:\"file\";s:53:\"OSN-LA-MarchApril-CLASS-Greifner-page-003-770x513.jpg\";s:5:\"width\";i:770;s:6:\"height\";i:513;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:10:\"blog-large\";a:4:{s:4:\"file\";s:53:\"OSN-LA-MarchApril-CLASS-Greifner-page-003-770x270.jpg\";s:5:\"width\";i:770;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"blog-full-width\";a:4:{s:4:\"file\";s:54:\"OSN-LA-MarchApril-CLASS-Greifner-page-003-1170x270.jpg\";s:5:\"width\";i:1170;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"blog-medium\";a:4:{s:4:\"file\";s:53:\"OSN-LA-MarchApril-CLASS-Greifner-page-003-740x540.jpg\";s:5:\"width\";i:740;s:6:\"height\";i:540;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"blog-grid\";a:4:{s:4:\"file\";s:53:\"OSN-LA-MarchApril-CLASS-Greifner-page-003-370x270.jpg\";s:5:\"width\";i:370;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:53:\"OSN-LA-MarchApril-CLASS-Greifner-page-003-125x125.jpg\";s:5:\"width\";i:125;s:6:\"height\";i:125;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:11:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";s:11:\"orientation\";i:0;}}");
INSERT INTO `wp_postmeta` VALUES("1843","468","_edit_lock","1427631317:2");
INSERT INTO `wp_postmeta` VALUES("1844","467","_edit_lock","1427631337:2");
INSERT INTO `wp_postmeta` VALUES("1845","475","_wp_attached_file","2015/05/WGC.jpg");
INSERT INTO `wp_postmeta` VALUES("1846","475","_wp_attachment_metadata","a:5:{s:5:\"width\";i:256;s:6:\"height\";i:256;s:4:\"file\";s:15:\"2015/05/WGC.jpg\";s:5:\"sizes\";a:5:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:15:\"WGC-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"bones-thumb-600\";a:4:{s:4:\"file\";s:15:\"WGC-256x150.jpg\";s:5:\"width\";i:256;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"bones-thumb-300\";a:4:{s:4:\"file\";s:15:\"WGC-256x100.jpg\";s:5:\"width\";i:256;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"portfolio-four-column\";a:4:{s:4:\"file\";s:15:\"WGC-256x197.jpg\";s:5:\"width\";i:256;s:6:\"height\";i:197;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:15:\"WGC-125x125.jpg\";s:5:\"width\";i:125;s:6:\"height\";i:125;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:11:{s:8:\"aperture\";d:6.29999999999999982236431605997495353221893310546875;s:6:\"credit\";s:10:\"Yoav Peled\";s:6:\"camera\";s:5:\"NEX-7\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:1396271733;s:9:\"copyright\";s:10:\"Yoav Peled\";s:12:\"focal_length\";s:2:\"26\";s:3:\"iso\";s:3:\"100\";s:13:\"shutter_speed\";s:5:\"0.025\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";i:1;}}");


DROP TABLE IF EXISTS `wp_posts`;

CREATE TABLE `wp_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8_unicode_ci NOT NULL,
  `post_title` text COLLATE utf8_unicode_ci NOT NULL,
  `post_excerpt` text COLLATE utf8_unicode_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `to_ping` text COLLATE utf8_unicode_ci NOT NULL,
  `pinged` text COLLATE utf8_unicode_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8_unicode_ci NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`),
  KEY `post_name` (`post_name`(191))
) ENGINE=InnoDB AUTO_INCREMENT=480 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `wp_posts` VALUES("5","2","2014-03-24 14:50:40","2014-03-24 14:50:40","&nbsp;

[vc_row full_width=\"true\" content_full_width=\"true\" background_transparent=\"false\" background_repeat=\"repeat\" background_position=\"top left\" background_attachment=\"scroll\" background_cover=\"true\" background_color=\"#7f7f7f\"][vc_column width=\"1/1\" full_width=\"true\" align=\"align-none\"][rev_slider_vc alias=\"Home\"][/vc_column][/vc_row][vc_row][vc_column width=\"1/1\"][spacer height=\"70\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][/vc_column][/vc_row]

<script>// <![CDATA[
(function(i,s,o,g,r,a,m){i[\'GoogleAnalyticsObject\']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,\'script\',\'//www.google-analytics.com/analytics.js\',\'ga\');

  ga(\'create\', \'UA-53735655-1\', \'auto\');
  ga(\'send\', \'pageview\');

// ]]></script>","Home","","publish","closed","open","","home","","","2014-10-30 09:26:06","2014-10-30 09:26:06","","0","http://ioptima.wpengine.com/?page_id=5","11","page","","0");
INSERT INTO `wp_posts` VALUES("6","2","2014-03-24 14:36:18","2014-03-24 14:36:18","<p>Your Name (required)<br />
    [text* your-name] </p>

<p>Your Email (required)<br />
    [email* your-email] </p>

<p>Subject<br />
    [text your-subject] </p>

<p>Your Message<br />
    [textarea your-message] </p>

<p>[submit \"Send\"]</p>
[your-subject]
[your-name] <[your-email]>
From: [your-name] <[your-email]>
Subject: [your-subject]

Message Body:
[your-message]

--
This e-mail was sent from a contact form on Ronen Castro Blog (http://ioptima.wpengine.com)
info@ioptima.co.il


0

[your-subject]
[your-name] <[your-email]>
Message Body:
[your-message]

--
This e-mail was sent from a contact form on Ronen Castro Blog (http://ioptima.wpengine.com)
[your-email]


0
Your message was sent successfully. Thanks.
Failed to send your message. Please try later or contact the administrator by another method.
Validation errors occurred. Please confirm the fields and submit it again.
Failed to send your message. Please try later or contact the administrator by another method.
Please accept the terms to proceed.
Please fill the required field.","Contact form 1","","publish","open","open","","contact-form-1","","","2014-03-24 14:36:18","2014-03-24 14:36:18","","0","http://ioptima.wpengine.com/?post_type=wpcf7_contact_form&p=6","11","wpcf7_contact_form","","0");
INSERT INTO `wp_posts` VALUES("10","2","2014-03-24 15:17:11","2014-03-24 15:17:11","","logo","","inherit","closed","open","","logo-2","","","2014-03-24 15:17:11","2014-03-24 15:17:11","","0","http://ioptima.wpengine.com/wp-content/uploads/2014/03/logo.jpg","11","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("11","2","2014-03-24 15:22:10","2014-03-24 15:22:10","[vc_row][vc_column width=\"1/4\"][spacer height=\"40\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][framed_image image=\"208\" img_size=\"full\" img_link_target=\"_self\" align=\"none\"][/vc_column][vc_column width=\"3/4\"][spacer height=\"25\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][vc_column_text]
<h3 style=\"text-align: justify; font-size: 18px;\"><span style=\"color: #1f3257;\">Ronen Castro - CEO </span></h3>
<p style=\"text-align: justify;\">Ronen Castro has vast experience in marketing &amp; sales, business development and managing positions in medical device companies. In the last 20 years he has served in companies like Contec-Medical (Rigid Endoscopy products), Versamed (Software based Ventilation Machines), SLP (SleepMedicine and Respiratory products) and MetaCure (Implantable Gastric Stimulator for Diabesity). For the last 3 years prior to joining IOPtima, he was the CEO of Allium Medical Solutions (TASE:ALMD), a manufacturer of various MIS products. 2 year before, he served as the CEO of C-Boot, a manufacturer of advanced compression therapy products. He is also the founder of DCS Medical and EZ-Tube. Ronen Castro holds an MBA degree from Ben-Gurion University.</p>
[/vc_column_text][/vc_column][/vc_row][vc_row][vc_column width=\"1/4\"][spacer height=\"40\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][framed_image image=\"199\" img_size=\"full\" img_link_target=\"_self\" align=\"none\"][/vc_column][vc_column width=\"3/4\"][spacer height=\"25\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][vc_column_text]
<h3 style=\"text-align: justify; font-size: 18px;\"><span style=\"color: #1f3257;\">Itai Bar-Natan - CFO</span></h3>
<p style=\"text-align: justify;\">Among his responsibilities in BIOLIGHT, Mr. Itai Bar-Natan serves as the CFO of IOPtima. Previously Mr. Bar-Natan worked at Ernst &amp; Young Israel and U.S for 10 years in several positions. His last role was a senior manager in the tech practice, leading diverse clients, including early stage through late stage, domestic, multinational and publically traded companies. Mr. Bar-Natan has vast experience in corporate finance, international corporate tax, fund raising to early stage clients , M&amp;As, IPOs and secondary capital raising. Mr. Bar-Natan holds a BA in Accounting (with honors) and Political Science from the Tel-Aviv University and is a CPA.</p>
[/vc_column_text][/vc_column][/vc_row][vc_row][vc_column width=\"1/4\"][spacer height=\"40\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][framed_image image=\"195\" img_size=\"full\" img_link_target=\"_self\" align=\"none\"][/vc_column][vc_column width=\"3/4\"][spacer height=\"25\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][vc_column_text]
<h3 style=\"text-align: justify; font-size: 18px;\"><span style=\"color: #1f3257;\">Nurit Radin - VP Marketing &amp; Sales</span></h3>
<p style=\"text-align: justify;\">Nurit brings 12 years of experience and proven track record in Business Development, Marketing &amp; Sales in Medical Device and Biotech companies. Among her previous positions, Nurit oversaw the European operations in Itamar Medical (publicly traded in TASE) and led the Global Business Development in Omrix Biopharmaceuticals (a J&amp;J company). Nurit holds a BA in Economics &amp; Far East studies from the Hebrew University and MBA from Ono Academic College.</p>
[/vc_column_text][/vc_column][/vc_row][vc_row][vc_column width=\"1/4\"][spacer height=\"40\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][framed_image image=\"197\" img_size=\"full\" img_link_target=\"_self\" align=\"none\"][/vc_column][vc_column width=\"3/4\"][spacer height=\"25\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][vc_column_text]
<h3 style=\"text-align: justify; font-size: 18px;\"><span style=\"color: #1f3257;\">Amnon Nahum-Sharon - COO</span></h3>
<p style=\"text-align: justify;\">32 years of work experience in the medical device industry. Proficient in all aspects of operations, quality and regulatory in companies which develop, manufacture and sell medical products. For many years, Amnon was part of LifaCare, a family-owned business which provide outsourced R&amp;D and manufacturing services. In parallel, he provided regulatory consultation services to medical device manufacturers. Amnon is with IOPtima since 2010.</p>
[/vc_column_text][/vc_column][/vc_row][vc_row][vc_column width=\"1/4\"][spacer height=\"40\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][framed_image image=\"213\" img_size=\"full\" img_link_target=\"_self\" align=\"none\"][/vc_column][vc_column width=\"3/4\"][spacer height=\"25\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][vc_column_text]
<h3 style=\"text-align: justify; font-size: 18px;\"><span style=\"color: #1f3257;\">Maital Ben Hur - Clinical Director</span></h3>
<p style=\"text-align: justify;\">Experienced industry clinical professional in the medical device field. An international and national network with strong background in ophthalmology.  Track record and proven ability to develop and manage multi-national, multi-center clinical studies from start to finish and successful management of international teams. Prior to joining IOPtima, Maital worked for the last 14 years in Optonol and Alcon. Recent career activities in new technology development, pre-clinical and clinical studies, introduction, application management, marketing and sales support nationally and internationally.</p>
[/vc_column_text][/vc_column][/vc_row][vc_row][vc_column width=\"1/4\"][spacer height=\"40\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][framed_image img_size=\"178*200\" img_link_target=\"_self\" align=\"none\" image=\"329\"][/vc_column][vc_column width=\"3/4\"][spacer height=\"25\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][vc_column_text]
<h3 style=\"text-align: justify; font-size: 18px;\"><span style=\"color: #1f3257;\">Eran Kaplan - Senior Projects Manager</span></h3>
<p style=\"text-align: justify;\">Eran brings vast academic and professional experience in the medical device field. Prior to joining IOPtima Ltd. Eran served as R&amp;D/Application engineer at Dune Medical Devices – a company engaged in the development of intraoperative, real-time cancer detection devices. Prior to that, Eran served as System &amp; Development engineer at Opticul Diagnostics – a company that develops a novel instant and specific bacterial optical-detection system. Eran holds a B.Sc. in Biomedical Engineering and M.Sc. in Medical Sciences both from Tel Aviv University.</p>
[/vc_column_text][spacer height=\"25\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][/vc_column][/vc_row][vc_row][vc_column][vc_column_text]

<script>// <![CDATA[
(function(i,s,o,g,r,a,m){i[\'GoogleAnalyticsObject\']=r;i[/vc_column_text][/vc_column][/vc_row][vc_row][vc_column][vc_column_text][r][/vc_column_text][/vc_column][/vc_row][vc_row][vc_column][vc_column_text]=i[/vc_column_text][/vc_column][/vc_row][vc_row][vc_column][vc_column_text][r][/vc_column_text][/vc_column][/vc_row][vc_row][vc_column][vc_column_text]||function(){   (i[/vc_column_text][/vc_column][/vc_row][vc_row][vc_column][vc_column_text][r][/vc_column_text][/vc_column][/vc_row][vc_row][vc_column][vc_column_text].q=i[/vc_column_text][/vc_column][/vc_row][vc_row][vc_column][vc_column_text][r][/vc_column_text][/vc_column][/vc_row][vc_row][vc_column][vc_column_text].q||[]).push(arguments)},i[/vc_column_text][/vc_column][/vc_row][vc_row][vc_column][vc_column_text][r][/vc_column_text][/vc_column][/vc_row][vc_row][vc_column][vc_column_text].l=1*new Date();a=s.createElement(o),   m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)   })(window,document,\'script\',\'//www.google-analytics.com/analytics.js\',\'ga\');   ga(\'create\', \'UA-53735655-1\', \'auto\');   ga(\'send\', \'pageview\');
// ]]></script>[/vc_column_text][/vc_column][/vc_row]","Management","","publish","closed","open","","management","","","2015-03-11 13:08:38","2015-03-11 13:08:38","","91","http://ioptima.wpengine.com/?page_id=11","3","page","","0");
INSERT INTO `wp_posts` VALUES("12","2","2014-03-24 15:22:26","2014-03-24 15:22:26","[vc_row][vc_column width=\"1/1\"][vc_column_text]
<h3 style=\"text-align: justify; font-size: 18px;\"><span style=\"color: #1e3156;\">Doron Birger – Chairman</span></h3>
<p style=\"text-align: justify;\">Doron is a seasoned executive of the Israeli high-tech industry serving as chairman ,director and advisor to variety of technology companies. Previously CEO of Elron Electronic Industries (Nasdaq: ELRNF and TASE) and until recently a director of Given Imaging (NASDAQ: GIVN) until it was sold to Covidian. Currently board member of IceCure and HBL Hadasit traded on TASE ,chairman of MST ,Sight DX and Magisto and advisor to verity of technology companies. Doron is also a director in none profit organizations (the Israeli board of electronics and software industries ,national science museum ,young entrepreneurs and DVI- dental volunteers for Israel).</p>
[/vc_column_text][spacer height=\"25\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][vc_column_text]
<h3 style=\"text-align: justify; font-size: 18px;\"><span style=\"color: #1e3156;\">Suzana Nahum Zilberberg</span></h3>
<p style=\"text-align: justify;\">Over a decade of experience as senior manager in life science . Currently CEO of BioLight. Previously dealt with BD and M&amp;As at TEVA Pharmaceuticals, including Vice President Asia and Pacific, in which role she led TEVA\'s penetration of Japan and China.</p>
[/vc_column_text][spacer height=\"25\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][vc_column_text]
<h3 style=\"text-align: justify; font-size: 18px;\"><span style=\"color: #1e3156;\">Eli Shohet</span></h3>
<p style=\"text-align: justify;\">Is a strategic and business advisor and owner of ADY Consultants. Prior to this role Mr. Shohet was a Co-CEO of Netafim. Previous to this, Mr. Shohet served in various senior positions at Teva Pharmaceuticals Industries Ltd over a 20 year period, including Senior Vice President of Business Development, Chief Integration Officer and VP Central and Eastern Europe.</p>
[/vc_column_text][spacer height=\"25\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][vc_column_text]
<h3 style=\"text-align: justify; font-size: 18px;\"><span style=\"color: #1e3156;\">Efrat Makov </span></h3>
<p style=\"text-align: justify;\">Has extensive financial experience and background. Ms. Makov had served in various senior financial positions the latest was CFO of Aladdin Information Systems Ltd and CFO of Alvarion.</p>
[/vc_column_text][spacer height=\"50\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][/vc_column][/vc_row]
<script>// <![CDATA[
(function(i,s,o,g,r,a,m){i[\'GoogleAnalyticsObject\']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,\'script\',\'//www.google-analytics.com/analytics.js\',\'ga\');

  ga(\'create\', \'UA-53735655-1\', \'auto\');
  ga(\'send\', \'pageview\');

// ]]></script>","Board of Directors","","publish","closed","open","","board-of-directors","","","2014-08-25 09:07:50","2014-08-25 09:07:50","","91","http://ioptima.wpengine.com/?page_id=12","5","page","","0");
INSERT INTO `wp_posts` VALUES("13","2","2014-03-24 15:22:46","2014-03-24 15:22:46","[vc_row][vc_column width=\"1/3\"][vc_column_text]
<h3>IOPtima Ltd.</h3>
Building 3, 5th Floor

Kiryat Atidim, Tel Aviv, 6158101

Israel

Tel: 972-73-2753400

Email:  <a href=\"mailto:info@ioptima.co.il\">info@ioptima.co.il</a>[/vc_column_text][/vc_column][vc_column width=\"2/3\"][spacer height=\"10\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][contact-form-7 id=\"67\"][/vc_column][/vc_row][vc_row][vc_column width=\"1/1\"][spacer height=\"20\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][vc_gmaps type=\"m\" zoom=\"15\" style=\"``border: 0``;\" src=\"``https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d13517.205912852858!2d34.84295899999999!3d32.11515949999997!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x151d49c0e1a57f07%3A0xfcb58dbb15ff5374!2sKiryat+Atidim!5e0!3m2!1sen!2s!4v1395950482649``\" height=\"300\" width=\"400\" size=\"450\" link=\"https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d13517.205912852853!2d34.842959!3d32.1151595!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x151d49c0e1a57f07%3A0xfcb58dbb15ff5374!2sKiryat+Atidim!5e0!3m2!1sen!2s!4v1396254075663\"][spacer height=\"50\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][/vc_column][/vc_row]

<script>
  (function(i,s,o,g,r,a,m){i[\'GoogleAnalyticsObject\']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,\'script\',\'//www.google-analytics.com/analytics.js\',\'ga\');

  ga(\'create\', \'UA-53735655-1\', \'auto\');
  ga(\'send\', \'pageview\');

</script>","Contact Us","","publish","closed","open","","contact-us","","","2014-08-12 11:29:22","2014-08-12 11:29:22","","0","http://ioptima.wpengine.com/?page_id=13","11","page","","0");
INSERT INTO `wp_posts` VALUES("19","2","2014-03-24 15:24:27","2014-03-24 15:24:27","[vc_row][vc_column width=\"1/1\"][vc_column_text]March 29<sup>th</sup> 2015

<b>CLASS aparecido en <i>Ocular Surgery News - Edición Latinoamericana (Español)</i></b>

Gabriel Greifner, MD entrevista de <b>\"Nova técnica para o glaucoma utiliza ablação a laser de CO<sub>2</sub> para a esclerotomia profunda\"</b>.

<a href=\"/wp-content/uploads/2015/03/OSN-LA-MarchApril-CLASS-Greifner.pdf\">Haga clic aquí para descargar</a>[/vc_column_text][spacer height=\"20\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][divider style=\"thin\"][spacer height=\"20\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][vc_column_text]February 10<sup>th</sup> 2015

<b>CLASS featured in <i>Cataract &amp; Ocular Surgery News</i></b>

Gabriel Greifner, MD interviewed over a <b>\"New glaucoma technique uses CO<sub>2</sub> laser ablation for deep sclerectomy\"</b>.

<a href=\"/wp-content/uploads/2015/02/OSN-2.10.2015.CLASS.Greifner.pdf\">Click here to download</a>[/vc_column_text][spacer height=\"20\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][divider style=\"thin\"][spacer height=\"20\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][vc_column_text]November 30<sup>th</sup> 2014

<b>CLASS featured in <i>The Ophthalmology Innovation Summit (OIS)</i></b>

<b>CLASS introductory lecture – Ronen Castro</b>

Ronen Castro, CEO, introduced the CLASS (CO<sub>2</sub> Laser-Assisted Sclerectomy Surgery) procedure for glaucoma, which has results comparable to trabeculectomy, but is non-invasive.

<a href=\"http://ois.net/ioptima-ois-2015/\">View video</a>[/vc_column_text][spacer height=\"20\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][divider style=\"thin\"][spacer height=\"20\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][vc_column_text]November 27<sup>th</sup> 2014

<b>CLASS featured in <i>Glaucoma Today</i></b>

Alan L. Robin, MD questions <b>\"Will the Cost of Clinical Trials Quash Change in Glaucoma Treatment?\"</b>.

<a href=\"/wp-content/uploads/2014/11/GT-NovDec-14.CLASS.Robin_.pdf\">Click here to download</a>[/vc_column_text][spacer height=\"20\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][divider style=\"thin\"][spacer height=\"20\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][vc_column_text]November 27<sup>th</sup> 2014

<b>CLASS featured in <i>Cataract &amp; Refractive Surgery Today, Europe</i></b>

Rengaraj Venkatesh, MD describes <b>\"Phacoemulisifcation Plus CO<sub>2</sub> Laser-Assisted Sclerectomy\"</b>.

<a href=\"/wp-content/uploads/2014/11/CRST-Europe-Nov-Dec-14_CLASS_Venkatesh.pdf\">Click here to download</a>[/vc_column_text][spacer height=\"20\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][divider style=\"thin\"][spacer height=\"20\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][vc_column_text]October 19<sup>th</sup> 2014

<b>CLASS featured in <i>Ocular Surgery News/Healio</i></b>

<b>CLASS procedure may be safe alternative to trabeculectomy – Ronen Castro</b>

Ronen Castro, CEO, discusses the CO<sub>2</sub> laser laser-assisted sclerectomy surgery (CLASS) as a safer option than trabeculectomy with similar IOP reduction at the Ophthalmology Innovation Summit in Chicago.

<a href=\"http://www.healio.com/ophthalmology/glaucoma/news/online/%7B9c739c11-db03-4b60-9a3c-b4297c63a4e1%7D/class-procedure-may-be-safe-alternative-to-trabeculectomy\">View video</a>

<a href=\"http://www.healio.com/ophthalmology/ophthalmic-business/news/online/%7Bb2ac069d-3716-4101-bfec-58717f11737d%7D/physicians-industry-investors-convene-for-the-ophthalmology-innovation-summit-part-2?page=2\">Click here to view article</a>[/vc_column_text][spacer height=\"20\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][divider style=\"thin\"][spacer height=\"20\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][vc_column_text]October 16<sup>th</sup> 2014

<b>CLASS featured in <i>ASCRS Eye World</i></b>

<b>IOPtima Update by CEO Ronen Castro</b>

Ronen Castro, CEO, gives an updates on IOPtima at the Ophthalmology Innovation Summit in Chicago.

<a href=\"http://ois.net/ioptima-update-ceo-ronen-castro/\">View video</a>[/vc_column_text][spacer height=\"20\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][divider style=\"thin\"][spacer height=\"20\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][vc_column_text]October 13<sup>th</sup> 2014

<b>CLASS presented in <i>EyeWorld Video Reporter</i></b>

<b>Surgeon describes glaucoma procedure using CO<sub>2</sub> laser – Ehud Assia </b>

Ehud Assia, MD, describes CLASS procedure to lower IOP in glaucoma during the European Society of Cataract aand Refractive Surgeons in London.

<a href=\"http://ewreplay.org/node/599?v=3784258285001\">View video</a>[/vc_column_text][spacer height=\"20\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][divider style=\"thin\"][spacer height=\"20\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][vc_column_text]September 23<sup>rd</sup> 2014

<b>CLASS featured in <i>Ocular Surgery News Latin America Edition (Spanish)</i></b>

Mauricio Turati, MD shows <b>\"La esclerotomia asistida por laser de CO<sub>2</sub> reduce la PIO y el uso de medicacion\"</b>.

<a href=\"/wp-content/uploads/2014/09/OSN_LA_CLASS-SeptOct2014_Turati.pdf\">Click here to download</a>[/vc_column_text][spacer height=\"20\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][divider style=\"thin\"][spacer height=\"20\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][vc_column_text]September 21<sup>th</sup> 2014

<b>CLASS featured in <i>Advanced Ocular Care</i></b>

Robert Noecker, MD and Alan Robin, MD review <b>\"A New Option in Nonpenetrating Glaucoma Surgery: Two US Perspectives\"</b>.

<a href=\"/wp-content/uploads/2014/09/AOC_CLASS_9.2014_Noecker_Robin.pdf\">Click here to download</a>[/vc_column_text][spacer height=\"20\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][divider style=\"thin\"][spacer height=\"20\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][vc_column_text]September 17<sup>th</sup> 2014

<b>CLASS featured in <i>Ocular Surgery News/Healio</i></b>

Rengaraj Venkatesh, MD explains <b>\"Combined phaco, CLASS procedure reduces IOP in patients with open-angle glaucoma\"</b>.

<a href=\"/wp-content/uploads/2014/09/OSN_CLASS_Venkatesh_9.17.14.pdf\">Click here to download</a>[/vc_column_text][spacer height=\"20\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][divider style=\"thin\"][spacer height=\"20\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][vc_column_text]August 24<sup>th</sup> 2014

<b>CLASS featured in <i>Ocular Surgery News APAO Edition</i></b>

Shlomo Melamed, MD illustrates <b>\"CLASS procedure offers alternative treatment for glaucoma\"</b>.

<a href=\"/wp-content/uploads/2014/08/OSN-AP-JulyAugust-14_Melamed-CLASS.pdf\">Click here to download</a>[/vc_column_text][spacer height=\"20\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][divider style=\"thin\"][spacer height=\"20\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][vc_column_text]August 5<sup>th</sup> 2014

<b>CLASS featured in <i>Ocular Surgery News EU Edition</i></b>

Shlomo Melamed, MD shows <b>\"CLASS procedure offers alternative treatment for glaucoma\"</b>.

<a href=\"/wp-content/uploads/2014/08/OSN-Europe_july-august-14_Melamed_CLASS.pdf\">Click here to download</a>[/vc_column_text][spacer height=\"20\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][divider style=\"thin\"][spacer height=\"20\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][vc_column_text]July 25<sup>th</sup> 2014

<b>CLASS featured in <i>Ocular Surgery News U.S. Edition</i></b>

Shlomo Melamed, MD describes <b>\"CLASS procedure offers alternative treatment for glaucoma\"</b>.

<a href=\"/wp-content/uploads/2014/07/CLASS-procedure-offers-alternative-treatment-for-glaucoma-_-Ocular-Surgery-News.pdf\">Click here to download</a>[/vc_column_text][spacer height=\"20\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][divider style=\"thin\"][spacer height=\"20\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][vc_column_text]June 9<sup>th</sup> 2014

<b>CLASS featured in <i>Ophthalmology Times US</i></b>

Shlomo Melamed, MD explains <b>\"CO<sub>2</sub> laser surgery a new option for glaucoma\"</b>.

<a href=\"/wp-content/uploads/2014/06/Ophthalmology-time-US-CO2-laser-surgery-a-new-option-for-glaucoma.pdf\">Click here to download</a>[/vc_column_text][spacer height=\"20\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][divider style=\"thin\"][spacer height=\"20\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][vc_column_text]June 5<sup>th</sup> 2014

<b>CLASS featured in <i>Ophthalmology Times EU </i></b>

Ehud Assia, MD and Shlomo Melamed, MD describe <b>\"Glaucoma surgery with CLASS\"</b>.

<a href=\"/wp-content/uploads/2014/06/Ophthalmology-time-EU-CLASS_May14_pdf-Assia-and-Melamed.pdf\">Click here to download</a>[/vc_column_text][spacer height=\"20\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][divider style=\"thin\"][spacer height=\"20\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][vc_column_text]
<p style=\"text-align: justify;\">June 2<sup>nd</sup> 2014</p>
<p style=\"text-align: justify;\"><b>IOPtima Announces Distribution Agreement for IOPtiMate™ Systems in China</b></p>
Receives purchase commitment of 100 or more systems in one of largest global markets.[/vc_column_text][vc_accordion style=\"style1\" item_heading_color=\"#4883bf\" el_class=\"simple_accordion\"][vc_accordion_tab title=\"Learn More:\"][vc_column_text]IOPtima Ltd. announced today that it has signed an exclusive distribution agreement for the sale and marketing of the IOPtiMate™ system in China, one of the world’s largest glaucoma markets. As part of the agreement, IOPtima received a commitment that at least 100 systems will be purchased during the initial term of the agreement.

The IOPtiMate™ system is a state-of-the-art system that is based on CO2 laser technology that enables the performance of a unique filtration surgery to treat glaucoma without penetrating the inner part of the eye. This allows for substantial reduction in post-operative complications and use of eye drops, compared with alternative treatments.

IOPtima\'s partner in China is a well-known distributor that represents leading global brands in the diagnosis and treatment of ophthalmic diseases. Leading ophthalmologists and medical centers throughout China are among their consumers. The four-year agreement includes a minimum purchase commitment, and may be extended to an additional four years should the minimum purchase obligation be met. Under the agreement, the distributor is responsible for all local marketing, advertising, and sales activity of the IOPtiMate™ system, including on-site installation, training, and support. Revenues will consist of system sales and per-procedure fees.

In March 2014, the China Food and Drug Administration, (CFDA), approved the marketing and sale of the IOPtiMate™ system, and initial sales are expected to begin following training and evaluation in key local medical centers over the next few months.

Ronen Castro, IOPtima’s chief executive officer said, “Entering into a strategic distribution agreement in China allows us to begin commercial activities in one of the world’s largest glaucoma markets and is a major step for our company. The distributor’s commitment to purchase at least 100 IOPtiMate™ systems during the initial term of the agreement reflects their full belief in our technology and its unique solution. This agreement is a significant advancement in our plan to penetrate developing markets in Asia where there is no available solution for a large population of patients.”[/vc_column_text][/vc_accordion_tab][/vc_accordion][spacer height=\"20\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][divider style=\"thin\"][spacer height=\"20\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][vc_column_text]May 25<sup>th</sup> 2014

<b>CLASS featured in <i>Eurotimes</i></b>

<b>An industry brief describes CLASS as an effective method for Glaucoma treatment</b>

<a href=\"/wp-content/uploads/2014/05/Eurotimes-P43.pdf\">Click here to view article</a>[/vc_column_text][spacer height=\"20\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][divider style=\"thin\"][spacer height=\"20\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][vc_column_text]May 22<sup>nd</sup> 2014

<b>CLASS featured in <i>Eyeworld</i></b>

<b>CLASS act: Why a new CO<sub>2</sub> laser is competing with the gold standard – by Matt Young EyeWorld Contributing Writer</b>

Ehud Assia, MD and Shlomo Melamed, MD, share their views and experience on the use of CLASS in the recent ICGS and WOC congresses.

<a href=\"/wp-content/uploads/2014/05/EyeWorld-May-2014_CLASS-act-Why-a-new-CO2-laser-is-competing-with-the-gold-standard.pdf\" target=\"_blank\">Click here to download</a>[/vc_column_text][spacer height=\"20\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][divider style=\"thin\"][spacer height=\"20\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][vc_column_text]April 11<sup>th</sup> 2014

<b>CLASS presented in <i>Healio Ophthalmology, OSN</i></b>

<b>Surgeon describes glaucoma procedure using CO<sub>2</sub> laser – Shlomo Melamed</b>

Shlomo Melamed, MD, shares his experience using CO<sub>2</sub> laser to “unroof” Schlemm’s canal to lower IOP in glaucoma during the World Ophthalmology Congress in Tokyo.

<a href=\"http://video.healio.com/video/Surgeon-describes-glaucoma-proc;Ophthalmology\" target=\"_blank\">View video</a>[/vc_column_text][spacer height=\"20\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][divider style=\"thin\"][spacer height=\"20\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][vc_column_text]March 2014

<b>CLASS featured in <i>the Ophthalmologist</i></b>

<b>CLASS-y Laser Treats Glaucoma - Ehud Assia</b>

Transforming complex, invasive and risky glaucoma surgery into a safe, elegant, and precise procedure.

<a href=\"/wp-content/uploads/2014/04/CLASS-y-Laser-Treats-Glaucoma-Asia.pdf\" target=\"_blank\">Click here to download</a>[/vc_column_text][spacer height=\"20\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][divider style=\"thin\"][spacer height=\"20\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][vc_column_text]
<p style=\"text-align: justify;\">March 4<sup>th</sup> 2014</p>
<p style=\"text-align: justify;\"><b>IOPtima, Ltd. Granted Regulatory Approval in China for Marketing and Sales of the IOPtimate™ System</b></p>
[/vc_column_text][vc_accordion style=\"style1\" item_heading_color=\"#4883bf\" el_class=\"simple_accordion\"][vc_accordion_tab title=\"Learn More:\"][vc_column_text]IOPtima, Ltd. received Chinese Food and Drug Administration (CFDA) approval to market and sell the IOPtimate™ system in China, the world\'s largest glaucoma market.

\"Securing the CFDA approval in China is a significant milestone for the company\", said IOPtima CEO Ronen Castro. \"Due to sheer size of the country\'s population, the number of glaucoma patients in China is the largest of any market in the world. This represents a great business opportunity for us. Beyond the large number of general care hospitals, in China there are approximately 600 hospitals that specialize in ophthalmology, a significantly greater number than in other markets. As a result of the many advantages of the IOPtimate™ system in performing non-penetrating glaucoma surgery in a very easy and safe manner, we expect that over time, the system will capture significant market share in these specialized hospitals.\"

The registration process in China was carried out by China Meheco Corporation, a company incorporated under the laws of People\'s Republic of China, which is expected to perform the importation into the country. IOPtima anticipates identifying a distributor to launch sales of IOPtimate™ in China in the near future.

IOPtima plans to officially launch the IOPtimate™ system in China at the International Congress of Ophthalmology and Optometry China (COOC), being held March 27-30, 2014 in Shanghai.[/vc_column_text][/vc_accordion_tab][/vc_accordion][spacer height=\"50\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][/vc_column][/vc_row][vc_row][vc_column][vc_column_text]

<script>// <![CDATA[
(function(i,s,o,g,r,a,m){i[\'GoogleAnalyticsObject\']=r;i[/vc_column_text][/vc_column][/vc_row][vc_row][vc_column][vc_column_text][r][/vc_column_text][/vc_column][/vc_row][vc_row][vc_column][vc_column_text]=i[/vc_column_text][/vc_column][/vc_row][vc_row][vc_column][vc_column_text][r][/vc_column_text][/vc_column][/vc_row][vc_row][vc_column][vc_column_text]||function(){   (i[/vc_column_text][/vc_column][/vc_row][vc_row][vc_column][vc_column_text][r][/vc_column_text][/vc_column][/vc_row][vc_row][vc_column][vc_column_text].q=i[/vc_column_text][/vc_column][/vc_row][vc_row][vc_column][vc_column_text][r][/vc_column_text][/vc_column][/vc_row][vc_row][vc_column][vc_column_text].q||[]).push(arguments)},i[/vc_column_text][/vc_column][/vc_row][vc_row][vc_column][vc_column_text][r][/vc_column_text][/vc_column][/vc_row][vc_row][vc_column][vc_column_text].l=1*new Date();a=s.createElement(o),   m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)   })(window,document,\'script\',\'//www.google-analytics.com/analytics.js\',\'ga\');   ga(\'create\', \'UA-53735655-1\', \'auto\');   ga(\'send\', \'pageview\');
// ]]></script>[/vc_column_text][/vc_column][/vc_row]","In the News","","publish","closed","open","","in-the-news","","","2015-03-29 12:24:35","2015-03-29 12:24:35","","134","http://ioptima.wpengine.com/?page_id=19","2","page","","0");
INSERT INTO `wp_posts` VALUES("20","2","2014-03-24 15:26:17","2014-03-24 15:26:17"," ","","","publish","closed","open","","20","","","2014-08-31 14:46:22","2014-08-31 14:46:22","","134","http://ioptima.wpengine.com/?p=20","25","nav_menu_item","","0");
INSERT INTO `wp_posts` VALUES("26","2","2014-03-24 15:26:17","2014-03-24 15:26:17"," ","","","publish","closed","open","","26","","","2014-08-31 14:46:22","2014-08-31 14:46:22","","0","http://ioptima.wpengine.com/?p=26","27","nav_menu_item","","0");
INSERT INTO `wp_posts` VALUES("27","2","2014-03-24 15:26:17","2014-03-24 15:26:17"," ","","","publish","closed","open","","27","","","2014-08-31 14:46:22","2014-08-31 14:46:22","","91","http://ioptima.wpengine.com/?p=27","5","nav_menu_item","","0");
INSERT INTO `wp_posts` VALUES("28","2","2014-03-24 15:26:17","2014-03-24 15:26:17"," ","","","publish","closed","open","","28","","","2014-08-31 14:46:22","2014-08-31 14:46:22","","91","http://ioptima.wpengine.com/?p=28","4","nav_menu_item","","0");
INSERT INTO `wp_posts` VALUES("30","2","2014-03-24 15:26:17","2014-03-24 15:26:17","","About Us","","publish","closed","open","","about","","","2014-08-31 14:46:22","2014-08-31 14:46:22","","0","http://ioptima.wpengine.com/?p=30","2","nav_menu_item","","0");
INSERT INTO `wp_posts` VALUES("32","2","2014-03-24 15:34:32","2014-03-24 15:34:32","<strong>IMPORTANT NOTICES</strong>

<strong>Website Terms of Use</strong>

<em>Please read carefully before accessing this website.</em>

This website is provided by IOPtima Ltd., as a general information service. By accessing, browsing, copying, and/or using any information contained at this website, you agree to be bound by the terms and conditions described herein.

IOPtima Ltd. maintains this website in exchange for accessing, browsing and/or using the website, you agree to be bound by these terms and to comply with all applicable laws and regulations. IOPtima Ltd. makes no representation that the content is without error or misstatements. IOPtima Ltd. will make reasonable efforts to correct any errors contained herein and reserves the right to change the content of the website at any time.

<strong>Copyright Notice
</strong>The content of this website is owned and copyrighted by IOPtima Ltd. Copyright © 2014 by IOPtima Ltd. As such, none of the material may be copied, reproduced, distributed, downloaded, displayed, posted or transmitted in any form without the prior written consent of IOPtima Ltd.

<strong>Privacy Statement
</strong>Thank you for your interest in our website. We recognize and respect the privacy expectations of today\'s consumers and the requirements of applicable Federal and State privacy laws. This Privacy Statement is to inform you of our practices with respect to how we collect and use personally identifiable information about individuals using our website. By using this website, you consent to the following terms.

We reserve the right to change this Privacy Statement from time to time consistent with applicable privacy laws.

<strong>What We Collect
</strong>You can access and browse our website without providing any personally identifying information. When you place an inquiry regarding our products, we maycollect personally identifiable information about you such as your name, company, title, address, telephone and facsimile numbers as well as other information that you may provide.

<strong>Use of Information
</strong>IOPtima Ltd. uses your personal identifiable information to respond to your requests for information and as may be otherwise necessary. IOPtima Ltd. may contact you with respect to services or products that may of interest to you. IOPtima Ltd. may also use information entered into our website as necessary to administer or provide customer support. IOPtima Ltd. does not provide any personally identifiable information to third parties.

<strong>Disclaimers</strong>

No Warranties
The documentation provided at this site is \"as-is\" without any expressed or implied warranty of any kind including warranties of merchantability, non-infringement of intellectual property, including patents, copyrights or otherwise or fitness for any particular purpose. IOPtima Ltd. will not be liable for any damages whatsoever arising out of the use or inability to use the documentation provided on the site.

*IOPtima provides CE approved CO<sub>2</sub> Lasers. Model may vary. ","Disclaimer","","publish","closed","open","","disclaimer","","","2015-03-11 12:47:16","2015-03-11 12:47:16","","0","http://ioptima.wpengine.com/?page_id=32","11","page","","0");
INSERT INTO `wp_posts` VALUES("33","2","2014-03-24 15:34:58","2014-03-24 15:34:58"," ","","","publish","closed","open","","33","","","2014-03-24 15:34:58","2014-03-24 15:34:58","","0","http://ioptima.wpengine.com/?p=33","12","nav_menu_item","","0");
INSERT INTO `wp_posts` VALUES("36","2","2014-03-24 18:23:43","2014-03-24 18:23:43","","Ioptima","","inherit","closed","open","","home-image-cropped","","","2014-03-24 18:23:43","2014-03-24 18:23:43","","0","http://ioptima.wpengine.com/wp-content/uploads/2014/03/Home-Image-Cropped.jpg","11","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("37","2","2014-03-24 18:28:05","2014-03-24 18:28:05","","favicon","","inherit","closed","open","","favicon","","","2014-03-24 18:28:05","2014-03-24 18:28:05","","0","http://ioptima.wpengine.com/wp-content/uploads/2014/03/favicon.ico","11","attachment","image/x-icon","0");
INSERT INTO `wp_posts` VALUES("38","2","2014-03-24 18:41:41","2014-03-24 18:41:41","","Small Logo","","inherit","closed","open","","small-logo","","","2014-03-24 18:41:41","2014-03-24 18:41:41","","0","http://ioptima.wpengine.com/wp-content/uploads/2014/03/Small-Logo.png","11","attachment","image/png","0");
INSERT INTO `wp_posts` VALUES("39","2","2014-03-27 09:12:31","2014-03-27 09:12:31","[vc_row][vc_column width=\"1/1\"][vc_column_text]
<p style=\"text-align: justify;\">IOPtima is a developer of minimally-invasive surgical ophthalmic devices. The company’s flagship product, the IOPtimate™, is a surgical system for the treatment of Glaucoma, which utilizes a CO<sub>2</sub> laser technology to significantly reduce internal eye pressure (“IOP”), by restoring the natural fluid percolation without penetrating into the eye.</p>
<p style=\"text-align: justify;\">With a mission to address the unmet needs and common safety problems in glaucoma surgery, the company has developed a procedure named CLASS (CO<sub>2</sub> Laser-Assisted Sclerotomy Surgery). In utilizing the particular properties of the CO<sub>2</sub> laser, the IOPtimate thins the sclera wall via ablating surges at the normal eye drainage area (Schlemm’s Canal region), in a simple and highly controlled and specific manner.</p>
<p style=\"text-align: justify;\"><b>“<i>The system transforms complex and highly risky Glaucoma surgery into a safe, elegant and precise laser-assisted procedure”</i></b></p>
<p style=\"text-align: justify;\">This elegant self-regulated procedure is possible because the IOPtimate system is designed to achieve functional, simple, safe, reproducible and optimal results from surgery, with minimal side effects and reduced recovery time. At the same time, the procedure is highly efficacious, with a minimal learning curve.</p>
<p style=\"text-align: justify;\">IOPtima is a Bio-Light company: <a href=\"http://www.bio-light.co.il/\">www.bio-light.co.il</a></p>
[/vc_column_text][spacer height=\"200\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][/vc_column][/vc_row]

<script>// <![CDATA[
(function(i,s,o,g,r,a,m){i[\'GoogleAnalyticsObject\']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,\'script\',\'//www.google-analytics.com/analytics.js\',\'ga\');

  ga(\'create\', \'UA-53735655-1\', \'auto\');
  ga(\'send\', \'pageview\');

// ]]></script>","Company","","publish","closed","open","","about","","","2014-08-31 14:35:04","2014-08-31 14:35:04","","91","http://ioptima.wpengine.com/?page_id=39","2","page","","0");
INSERT INTO `wp_posts` VALUES("40","2","2014-03-27 09:12:56","2014-03-27 09:12:56","[vc_row][vc_column width=\"1/1\"][vc_column_text]
<p style=\"text-align: justify;\"><span style=\"color: #000000;\">IOPtima has relied on several renowned key opinion leaders in the field of Glaucoma to provide clinical and strategic advice and participate in clinical trials. These individuals are listed below.</span></p>
<p style=\"text-align: justify;\"><span style=\"color: #000000;\"> </span></p>

<ul style=\"text-align: justify;\">
	<li><span style=\"color: #000000;\"><b>Prof. Ehud Assia, MD </b>– Inventor, CMO, Ophthalmic Surgeon, Israel: <b></b></span></li>
</ul>
<span style=\"color: #000000;\">Director, Ophthalmology Department, Meir Medical Center; Professor at Tel-Aviv University; Medical Director Ein Tal Eye Center</span>
<ul style=\"text-align: justify;\">
	<li><span style=\"color: #000000;\"><b>Prof. Alon Harris </b>– M.S., Ph.D., Ophthalmic Researcher, Indiana: </span></li>
</ul>
<span style=\"color: #000000;\"><span style=\"text-align: justify;\">Director, Clinical Research, the Eugene and Marilyn Glick Eye </span>Institute, Indiana University School of Medicine</span>
<ul style=\"text-align: justify;\">
	<li><span style=\"color: #000000;\"><b>Dr. Robert David, MD </b>- Glaucoma specialist, California:</span></li>
</ul>
Former Vice President at the Department of Opthalmology, Soroka Medical Center, Beer Sheba
<ul style=\"text-align: justify;\">
	<li><span style=\"color: #000000;\"><b>Prof. Howard Barnebey, MD </b>- Glaucoma specialist, Seattle:</span></li>
</ul>
<span style=\"color: #23190f;\">Clinical Assistant Professor Department of Ophthalmology, </span><span style=\"color: #23190f;\">University of Washington, Seattle, WA</span>
<ul style=\"text-align: justify;\">
	<li><span style=\"color: #000000;\"><b>Prof. Alan L. Robin, MD </b>- Glaucoma specialist, Baltimore:</span></li>
</ul>
<span style=\"color: #000000;\">Clinical Professor of Ophthalmology at the University of Maryland, Baltimore, Maryland </span>
<ul style=\"text-align: justify;\">
	<li><span style=\"color: #000000;\"><b>Prof. Shlomo (Choka) Melamed </b>- Glaucoma specialist, Israel:</span></li>
</ul>
Ophthalmology Specialist at the Goldschleger Eye Institute, The am Rothberg Glaucoma Center Chaim Sheba Medical Center Tel Hashomer
<p style=\"text-align: justify;\"><span style=\"color: #000000;\"> </span></p>
[/vc_column_text][spacer height=\"50\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][/vc_column][/vc_row]

<script>// <![CDATA[
(function(i,s,o,g,r,a,m){i[\'GoogleAnalyticsObject\']=r;i[r]=i[r]||function(){   (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),   m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)   })(window,document,\'script\',\'//www.google-analytics.com/analytics.js\',\'ga\');   ga(\'create\', \'UA-53735655-1\', \'auto\');   ga(\'send\', \'pageview\');
// ]]></script>","Scientific Advisory Board","","publish","closed","open","","scientific-advisory-board","","","2014-08-26 07:20:23","2014-08-26 07:20:23","","91","http://ioptima.wpengine.com/?page_id=40","6","page","","0");
INSERT INTO `wp_posts` VALUES("41","2","2014-03-27 09:13:18","2014-03-27 09:13:18","[vc_row][vc_column width=\"1/1\"][vc_column_text]
<h3 style=\"text-align: justify;\"><span style=\"color: #000000;\"><b>IOPtima CO<sub>2</sub> L</b>aser<b>-A</b>ssisted<b> S</b>clerectomy<b> S</b>urgery<b> (CLASS)</b>:<b></b></span></h3>
<p style=\"text-align: justify;\"><span style=\"color: #000000;\">IOPtima Ltd. has developed the IOPtimate system, a unique CO<sub>2</sub> laser-assisted system for the treatment of Glaucoma.</span></p>
<p style=\"text-align: justify;\"><span style=\"color: #000000;\">The IOPtimate system is intended to treat patients with primary Open-Angle Glaucoma (POAG) and Pseudo-Exfoliative Glaucoma (PEXG). Notwithstanding, IOPtima has already accumulated a very positive experience in combined surgeries (Cataract and Glaucoma).</span></p>
<p style=\"text-align: justify;\"><span style=\"color: #000000;\">In utilizing the particular properties of the CO<sub>2</sub> laser, the IOPtimate system, thins the sclera wall via ablating surges at the Schlemm’s Canal area without penetrating the scleral wall, thereby reducing IOP by facilitating adequate, functional percolation of intra-ocular fluid from the eye through the remaining membrane in a simple and highly controlled and specific manner.</span></p>
<p style=\"text-align: justify;\"><span style=\"color: #000000;\">As infrared CO<sub>2</sub> laser radiation is absorbed and blocked by water and aqueous solutions, it is therefore ineffective in ablating when applied over wet tissues, thus does not allow the procedure to penetrate into the eye like other invasive procedures.</span></p>
<p style=\"text-align: justify;\"><span style=\"color: #000000;\">Therefore, the remaining thin scleral layer remains intact, without penetration into the eye, which is known to be the source of most ophthalmic surgery complications, adverse events and side effects.</span></p>

[/vc_column_text][spacer height=\"50\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][vc_column_text]
<h3>CLASS Principle of Operation:</h3>
[/vc_column_text][spacer height=\"5\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][framed_image image=\"130\" img_size=\"full\" img_link_target=\"_self\" align=\"none\"][spacer height=\"15\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][vc_column_text]
<p style=\"text-align: justify;\">The CLASS procedure requires local anesthesia, is performed as an outpatient procedure and has minimal side effects, which are for the most part transient. At the same time, the CLASS procedure is highly efficacious, with a minimal learning curve.</p>
<p style=\"text-align: justify;\"><b>Differentiation from Trabeculectomy</b></p>
<p style=\"text-align: justify;\">Unlike Trabeculectomy, CLASS is non-invasive by nature and does not result in the perforation of any tissue. CLASS provides surgeons with enhanced control, regulation and therefore safety during the surgery. Because CLASS doesn’t penetrate into the eye like Trabeculectomy, the level of complications or potential side effects is much lower and the postoperative care following surgery requires significantly less office visits.</p>
<p style=\"text-align: justify;\"><b>Differentiation from Minimally-Invasive Devices (Shunts, GDD’s)</b></p>
<p style=\"text-align: justify;\">These stent-like devices were developed in order to regulate the manual trabeculectomy, creating a standardized canal for Aqueus Humor percolation. However, these are foreign bodies which can migrate, encourage inflammation and in some rare cases get blocked.</p>

[/vc_column_text][spacer height=\"30\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][/vc_column][/vc_row][vc_row][vc_column width=\"1/1\"][spacer height=\"50\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][/vc_column][/vc_row][vc_row][vc_column][vc_column_text]

<script>// <![CDATA[
(function(i,s,o,g,r,a,m){i[\'GoogleAnalyticsObject\']=r;i[/vc_column_text][/vc_column][/vc_row][vc_row][vc_column][vc_column_text][r][/vc_column_text][/vc_column][/vc_row][vc_row][vc_column][vc_column_text]=i[/vc_column_text][/vc_column][/vc_row][vc_row][vc_column][vc_column_text][r][/vc_column_text][/vc_column][/vc_row][vc_row][vc_column][vc_column_text]||function(){
  (i[/vc_column_text][/vc_column][/vc_row][vc_row][vc_column][vc_column_text][r][/vc_column_text][/vc_column][/vc_row][vc_row][vc_column][vc_column_text].q=i[/vc_column_text][/vc_column][/vc_row][vc_row][vc_column][vc_column_text][r][/vc_column_text][/vc_column][/vc_row][vc_row][vc_column][vc_column_text].q||[]).push(arguments)},i[/vc_column_text][/vc_column][/vc_row][vc_row][vc_column][vc_column_text][r][/vc_column_text][/vc_column][/vc_row][vc_row][vc_column][vc_column_text].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,\'script\',\'//www.google-analytics.com/analytics.js\',\'ga\');

  ga(\'create\', \'UA-53735655-1\', \'auto\');
  ga(\'send\', \'pageview\');

// ]]></script>[/vc_column_text][/vc_column][/vc_row]","CLASS Procedure","","publish","closed","open","","class-procedure","","","2014-11-05 15:43:57","2014-11-05 15:43:57","","92","http://ioptima.wpengine.com/?page_id=41","2","page","","0");
INSERT INTO `wp_posts` VALUES("42","2","2014-03-27 09:13:36","2014-03-27 09:13:36","[vc_row][vc_column width=\"1/1\"][vc_column_text]
<p style=\"text-align: justify;\">IOPtima Ltd. has developed the IOPtimate system; a unique laser based surgical system for the treatment of Glaucoma. The system utilizes a CO<sub>2</sub> laser technology to reduce internal eye pressure by allowing better flow of aqueous humor. In utilizing the particular properties of the CO<sub>2</sub> laser, the IOPtimate thins the sclera wall via ablating surges at the normal eye drainage area (Schlemm’s Canal region), in a simple and highly controlled and specific manner. The IOPtimate is highly effective in ablating dry tissue, and allows the surgeon to thin the sclera by gradually removing, layer by layer, most of the scleral tissue, leaving a thin intact layer which transforms the safety of the procedure to a higher level. The remaining layer is thin enough to allow the internal eye fluid to percolate through, thus relieving the eye of the inner excessive pressure. Because infrared CO<sub>2</sub> laser radiation is absorbed and blocked by nature by aqueous solutions, the laser energy does not penetrate into the eye. Therefore the remaining thin scleral layer remains intact, reducing the likelihood of surgery complications, adverse events and side effects.</p>
<p style=\"text-align: justify;\"><b><i>“This elegant self-regulated procedure is possible because the IOPtimate system is designed to achieve functional, simple, safe, reproducible and optimal results from surgery, with </i></b><b><i>minimal side effects and reduced recovery time. At the same time, the procedure is highly efficacious, with a minimal learning curve”</i></b></p>
[/vc_column_text][spacer height=\"50\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][vc_column_text]
<h3 style=\"text-align: left;\"><b>The IOPtimate</b><b> System Components: </b></h3>
[/vc_column_text][spacer height=\"30\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][/vc_column][/vc_row][vc_row][vc_column width=\"1/1\"][spacer height=\"30\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][/vc_column][/vc_row][vc_row][vc_column width=\"1/3\"][vc_column_text el_class=\"blackborder\"]
<p style=\"text-align: justify;\"><b>The Laser &amp; Control Unit
</b>The surgeon chooses the program parameters on the LCD touch-screen and initiate the laser operation.[/vc_column_text][/vc_column][vc_column width=\"2/3\"][framed_image image=\"127\" img_link_target=\"_self\" align=\"none\" img_size=\"full\"][/vc_column][/vc_row][vc_row][vc_column width=\"1/1\"][spacer height=\"30\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][/vc_column][/vc_row][vc_row][vc_column width=\"1/3\"][vc_column_text el_class=\"blackborder\"]</p>
<p style=\"text-align: justify;\"><b>The Scanner
</b>The Scanner is connected to the control unit, attached to the microscope and operated by a foot-switch. By using a sophisticated system of servo-engines and optics, the scanner takes the laser beam and accurately ablates the sclera as per the pre-selected area and <a href=\"http://ioptima.co.il/wp-content/uploads/2014/06/Ablation-Patterns_1.jpg\" target=\"_blank\">pattern</a>[/vc_column_text][/vc_column][vc_column width=\"2/3\"][framed_image image=\"128\" img_link_target=\"_self\" align=\"none\" img_size=\"full\"][/vc_column][/vc_row][vc_row][vc_column width=\"1/2\"][spacer height=\"30\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][framed_image image=\"82\" img_size=\"full\" img_link_target=\"_self\" align=\"none\"][/vc_column][vc_column width=\"1/2\"][spacer height=\"30\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][framed_image image=\"81\" img_size=\"full\" img_link_target=\"_self\" align=\"none\"][/vc_column][/vc_row][vc_row][vc_column width=\"1/1\"][spacer height=\"50\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][/vc_column][/vc_row]</p>
<script>// <![CDATA[
(function(i,s,o,g,r,a,m){i[\'GoogleAnalyticsObject\']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,\'script\',\'//www.google-analytics.com/analytics.js\',\'ga\');

  ga(\'create\', \'UA-53735655-1\', \'auto\');
  ga(\'send\', \'pageview\');

// ]]></script>","The IOPtimate System","","publish","closed","open","","the-ioptimate-system","","","2014-08-25 12:01:25","2014-08-25 12:01:25","","92","http://ioptima.wpengine.com/?page_id=42","5","page","","0");
INSERT INTO `wp_posts` VALUES("43","2","2014-03-27 09:13:50","2014-03-27 09:13:50","[vc_row full_width=\"false\" content_full_width=\"true\" background_transparent=\"false\" background_repeat=\"repeat\" background_position=\"top left\" background_attachment=\"scroll\" background_cover=\"true\"][vc_column width=\"2/3\"][vc_accordion style=\"style1\"][vc_accordion_tab title=\"Safe, minimally-invasive laser procedure\"][vc_column_text]<span style=\"color: #4883bf;\"><i>Unlike other surgical solutions, the CLASS procedure is non-penetrating and doesn’t involve foreign bodies</i></span>[/vc_column_text][/vc_accordion_tab][vc_accordion_tab title=\"Low post-operation complications rate\"][vc_column_text]<span style=\"color: #4883bf;\"><i>A 5-year clinical study with the IOPtimate shows a significantly reduced complications rate in comparison with other current surgical solutions</i></span>[/vc_column_text][/vc_accordion_tab][vc_accordion_tab title=\"Significant long-term reduction of IOP, stable over time \"][vc_column_text]<span style=\"color: #4883bf;\"><i>Clinical study results shows around 50% reduction in IOP over the years</i>[/vc_column_text][/vc_accordion_tab][vc_accordion_tab title=\"Simple to perform with short learning curve\"][vc_column_text]<span style=\"color: #4883bf;\"><i>The regulated laser scan and procedure makes it attractive also for less experienced surgeons</i>[/vc_column_text][/vc_accordion_tab][vc_accordion_tab title=\"One-time procedure reduces the need for medications\"][vc_column_text]<span style=\"color: #4883bf;\"><i>Clinical study results show significant reduction or elimination of medication consumption post</i>[/vc_column_text][/vc_accordion_tab][vc_accordion_tab title=\"Cost effective \"][vc_column_text]<span style=\"color: #4883bf;\"><i>Flexible business model that fit both private and public hospitals</i>[/vc_column_text][/vc_accordion_tab][/vc_accordion][/vc_column][vc_column width=\"1/3\" full_width=\"false\" align=\"align-center\"][spacer height=\"20\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][framed_image image=\"153\" img_size=\"full\" img_link_target=\"_self\" align=\"none\"][/vc_column][/vc_row][vc_row][vc_column][vc_column_text]</span></span></span></span>[/vc_column_text][spacer height=\"50\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][/vc_column][/vc_row]

<script>// <![CDATA[
(function(i,s,o,g,r,a,m){i[\'GoogleAnalyticsObject\']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,\'script\',\'//www.google-analytics.com/analytics.js\',\'ga\');

  ga(\'create\', \'UA-53735655-1\', \'auto\');
  ga(\'send\', \'pageview\');

// ]]></script>","CLASS Benefits","","publish","closed","open","","class-benefits","","","2014-08-25 12:04:38","2014-08-25 12:04:38","","93","http://ioptima.wpengine.com/?page_id=43","3","page","","0");
INSERT INTO `wp_posts` VALUES("44","2","2014-03-27 09:14:06","2014-03-27 09:14:06","[vc_row][vc_column width=\"1/1\"][vc_video title=\"IOPtimate Device\" link=\"https://www.youtube.com/watch?v=ejQbUMjxUI0\"][spacer height=\"50\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][vc_video title=\"IOPtima - CLASS Procedure - Better &amp; Safer Glaucoma Surgery\" link=\"https://www.youtube.com/watch?v=yZK5eH1NtDI&amp;feature=youtu.be\"][spacer height=\"50\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][vc_video link=\"http://www.youtube.com/watch?v=NGvrPYrwGxA&amp;feature=youtu.be\" title=\"CLASS Performed by Prof Ehud Assia\"][spacer height=\"50\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][vc_video title=\"CLASS Performed by Dr Andre Mermoud\" link=\"https://www.youtube.com/watch?v=ZIkuKRkirag&amp;list=PLiuK9gLj4jfYPcab-TSdbL5sAw9uoa7aH\"][spacer height=\"50\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][vc_video title=\"Combined Phaco CLASS Performed by Dr Rengarai Venkatesh\" link=\"https://www.youtube.com/watch?v=GUvffmK-isY&amp;list=PLiuK9gLj4jfYPcab-TSdbL5sAw9uoa7aH\"][spacer height=\"50\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][/vc_column][/vc_row]

<script>// <![CDATA[
(function(i,s,o,g,r,a,m){i[\'GoogleAnalyticsObject\']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,\'script\',\'//www.google-analytics.com/analytics.js\',\'ga\');

  ga(\'create\', \'UA-53735655-1\', \'auto\');
  ga(\'send\', \'pageview\');

// ]]></script>","Videos","","publish","closed","open","","videos","","","2014-08-19 08:43:55","2014-08-19 08:43:55","","93","http://ioptima.wpengine.com/?page_id=44","7","page","","0");
INSERT INTO `wp_posts` VALUES("46","2","2014-03-27 09:14:54","2014-03-27 09:14:54","[vc_row][vc_column width=\"1/1\"][vc_column_text]
<p style=\"text-align: justify;\">Glaucoma is a group of eye disorders characterized by progressive loss of nerve tissue, often leading to blindness. It is the second leading cause of vision loss in the world, and affects an estimated 68 million people globally, with over 5 million in the United States and 12 million in Europe. As is the case with most eye diseases, the elderly are most affected by Glaucoma with incidence of the disease growing as age advances.</p>
<p style=\"text-align: justify;\">Glaucoma is caused by an increase in pressure within the eye as a result of blockage of the flow of the intraocular fluid (also known as aqueous humor). Blockage of the aqueous humor flow causes increased pressure that if unrelieved causes vision impairment.</p>
<p style=\"text-align: justify;\">The disease is often called “the silent thief of sight” because most patients experience no symptoms at all; sometimes they do not know they have the disease until irreversible damage has occurred.</p>
[/vc_column_text][spacer height=\"20\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][framed_image image=\"414\" img_size=\"full\" img_link_target=\"_self\" align=\"none\"][spacer height=\"100\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][/vc_column][/vc_row]","About Glaucoma","","publish","closed","open","","about-glaucoma","","","2015-01-29 08:23:00","2015-01-29 08:23:00","","94","http://ioptima.wpengine.com/?page_id=46","2","page","","0");
INSERT INTO `wp_posts` VALUES("47","2","2014-03-27 09:15:08","2014-03-27 09:15:08","[vc_row][vc_column width=\"1/1\"][vc_column_text]
<p style=\"text-align: justify;\">It has been shown that the most effective means of preventing Glaucoma damage is to reduce IOP. By this, blood flow to the nerve tissue is improved and nerve damage progression is slowed down or stopped. Therefore, the primary goal of the treatment is to reduce the elevated intraocular pressure.</p>
<p style=\"text-align: justify;\">Current treatments for Open Angle Glaucoma (OAG) include  medications, Laser Trabeculoplasty, and a variety of surgical solutions. Treatment will depend on the progression of the disease, as well as both the patient’s tolerance to the course of therapy and its efficacy in reducing IOP.</p>
<p style=\"text-align: justify;\">Medicinal treatment is often considered the first line of defense. Given the complexity of regimens, the chronic use of multiple medications, the need for daily administration, the absence of a beneficial effect that can be observed by the patient and the side effects, patients often do not take their medication consistently, raising a significant problem of non-compliance. When medicine is no longer effective, many physicians will incorporate Laser Trabeculoplasty however it also has not be able to prove a long-term reduction of IOP. Once that fails, the standard of care of treatment is by a surgical procedure to increase the drainage.</p>
<p style=\"text-align: justify;\">CLASS procedure is just one of the surgical alternatives for the treatment of glaucoma and with its proven efficacy and elevated safety profile, is becoming a popular choice for surgeons and patients alike.</p>
<p style=\"text-align: justify;\">Your physician will plan the best treatment regimen suitable for your condition based on efficacy, safety and tolerability.</p>
[/vc_column_text][spacer height=\"23\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][vc_column_text]
<h3>Surgical Procedures for Reduction of IOP</h3>
All glaucoma surgical procedures are based on the creation of an alternative drainage pathway in the eye. Instead of draining into the normal drainage site of the eye (trabecular meshwork) which is blocked, the fluid is drained into a new space “the bleb” that is completely covered by the white outer covering (conjunctiva) of the eye.

The purpose of this alternative drainage is to achieve a significant IOP reduction that will reduce or halt the disease progression.[/vc_column_text][spacer height=\"40\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][/vc_column][/vc_row]","Treatment Methods","","publish","closed","open","","treatment-methods","","","2014-08-24 13:27:06","2014-08-24 13:27:06","","94","http://ioptima.wpengine.com/?page_id=47","3","page","","0");
INSERT INTO `wp_posts` VALUES("48","2","2014-03-27 09:17:13","2014-03-27 09:17:13"," ","","","publish","closed","open","","48","","","2014-08-31 14:46:22","2014-08-31 14:46:22","","91","http://ioptima.wpengine.com/?p=48","3","nav_menu_item","","0");
INSERT INTO `wp_posts` VALUES("49","2","2014-03-27 09:17:13","2014-03-27 09:17:13"," ","","","publish","closed","open","","49","","","2014-08-31 14:46:22","2014-08-31 14:46:22","","94","http://ioptima.wpengine.com/?p=49","20","nav_menu_item","","0");
INSERT INTO `wp_posts` VALUES("50","2","2014-03-27 09:17:13","2014-03-27 09:17:13"," ","","","publish","closed","open","","50","","","2014-08-31 14:46:22","2014-08-31 14:46:22","","94","http://ioptima.wpengine.com/?p=50","19","nav_menu_item","","0");
INSERT INTO `wp_posts` VALUES("51","2","2014-03-27 09:17:13","2014-03-27 09:17:13"," ","","","publish","closed","open","","51","","","2014-08-31 14:46:22","2014-08-31 14:46:22","","93","http://ioptima.wpengine.com/?p=51","16","nav_menu_item","","0");
INSERT INTO `wp_posts` VALUES("52","2","2014-03-27 09:17:13","2014-03-27 09:17:13"," ","","","publish","closed","open","","52","","","2014-08-31 14:46:22","2014-08-31 14:46:22","","93","http://ioptima.wpengine.com/?p=52","13","nav_menu_item","","0");
INSERT INTO `wp_posts` VALUES("53","2","2014-03-27 09:17:13","2014-03-27 09:17:13"," ","","","publish","closed","open","","53","","","2014-08-31 14:46:22","2014-08-31 14:46:22","","92","http://ioptima.wpengine.com/?p=53","11","nav_menu_item","","0");
INSERT INTO `wp_posts` VALUES("54","2","2014-03-27 09:17:13","2014-03-27 09:17:13"," ","","","publish","closed","open","","54","","","2014-08-31 14:46:22","2014-08-31 14:46:22","","92","http://ioptima.wpengine.com/?p=54","9","nav_menu_item","","0");
INSERT INTO `wp_posts` VALUES("55","2","2014-03-27 09:17:13","2014-03-27 09:17:13"," ","","","publish","closed","open","","55","","","2014-08-31 14:46:22","2014-08-31 14:46:22","","91","http://ioptima.wpengine.com/?p=55","6","nav_menu_item","","0");
INSERT INTO `wp_posts` VALUES("56","2","2014-03-27 09:17:10","2014-03-27 09:17:10","[vc_row][vc_column width=\"1/1\"][vc_column_text]
<p style=\"text-align: justify;\"><span style=\"line-height: 1.5em; color: #000000;\">We invest in our people and processes to continuously improve our products.</span></p>
<p style=\"text-align: justify;\"><span style=\"color: #000000;\">It is our guiding principle to provide our customers with a level of quality and service that consistently meets or exceeds expectations through the following philosophies:</span></p>
<p style=\"text-align: justify;\"><span style=\"color: #000000;\"> </span></p>
<p style=\"text-align: justify;\"><span style=\"color: #000000;\"><b>Products:</b> The products we manufacture and distribute that are reliable and comply with all CE &amp; international regulations. Our comprehensive warranty illustrates the confidence that we have in our products.</span></p>
<p style=\"text-align: justify;\"><span style=\"color: #000000;\"><b>Customers:</b> We focus on our customers\' requirements and are committed to their success.</span></p>
<p style=\"text-align: justify;\"><span style=\"color: #000000;\"><b>Distributors:</b> We work closely with our distributors to ensure they provide every customer with the same high quality standards that we insist on with our customers.</span></p>
<p style=\"text-align: justify;\"><span style=\"color: #000000;\"><b>System:</b> We continually maintain and improve the effectiveness of our quality control system. Periodic review of current policies and practices ensure the highest standards for our products and services.</span></p>
<p style=\"text-align: justify;\"><span style=\"color: #000000;\"><b>Quality: </b> The manufacturing process is subject to stringent standards of quality assurance. IOPtima products are approved for sale by the regulatory systems in Europe, Israel, Mexico and China. IOPtima is ISO 13485: 2003 certified.</span></p>
[/vc_column_text][spacer height=\"20\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][framed_image image=\"401\" img_size=\"full\" img_link_target=\"_self\" align=\"none\"][spacer height=\"50\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][/vc_column][/vc_row][vc_row][vc_column][vc_column_text]

<script>// <![CDATA[
(function(i,s,o,g,r,a,m){i[\'GoogleAnalyticsObject\']=r;i[/vc_column_text][/vc_column][/vc_row][vc_row][vc_column][vc_column_text][r][/vc_column_text][/vc_column][/vc_row][vc_row][vc_column][vc_column_text]=i[/vc_column_text][/vc_column][/vc_row][vc_row][vc_column][vc_column_text][r][/vc_column_text][/vc_column][/vc_row][vc_row][vc_column][vc_column_text]||function(){   (i[/vc_column_text][/vc_column][/vc_row][vc_row][vc_column][vc_column_text][r][/vc_column_text][/vc_column][/vc_row][vc_row][vc_column][vc_column_text].q=i[/vc_column_text][/vc_column][/vc_row][vc_row][vc_column][vc_column_text][r][/vc_column_text][/vc_column][/vc_row][vc_row][vc_column][vc_column_text].q||[]).push(arguments)},i[/vc_column_text][/vc_column][/vc_row][vc_row][vc_column][vc_column_text][r][/vc_column_text][/vc_column][/vc_row][vc_row][vc_column][vc_column_text].l=1*new Date();a=s.createElement(o),   m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)   })(window,document,\'script\',\'//www.google-analytics.com/analytics.js\',\'ga\');   ga(\'create\', \'UA-53735655-1\', \'auto\');   ga(\'send\', \'pageview\');
// ]]></script>[/vc_column_text][/vc_column][/vc_row]","Quality","","publish","closed","open","","quality","","","2014-10-30 09:19:44","2014-10-30 09:19:44","","91","http://ioptima.wpengine.com/?page_id=56","7","page","","0");
INSERT INTO `wp_posts` VALUES("57","2","2014-03-27 09:19:00","2014-03-27 09:19:00"," ","","","publish","closed","open","","57","","","2014-08-31 14:46:22","2014-08-31 14:46:22","","91","http://ioptima.wpengine.com/?p=57","7","nav_menu_item","","0");
INSERT INTO `wp_posts` VALUES("58","2","2014-03-27 09:19:00","2014-03-27 09:19:00","","Technology","","publish","closed","open","","technology","","","2014-08-31 14:46:22","2014-08-31 14:46:22","","0","http://ioptima.wpengine.com/?p=58","8","nav_menu_item","","0");
INSERT INTO `wp_posts` VALUES("59","2","2014-03-27 09:19:00","2014-03-27 09:19:00","","For Physicians","","publish","closed","open","","for-physicians","","","2014-08-31 14:46:22","2014-08-31 14:46:22","","0","http://ioptima.wpengine.com/?p=59","12","nav_menu_item","","0");
INSERT INTO `wp_posts` VALUES("60","2","2014-03-27 09:18:56","2014-03-27 09:18:56","[vc_row][vc_column width=\"1/1\" full_width=\"false\" align=\"align-center\"][vc_column_text]
<p style=\"text-align: justify;\">Lowering the intraocular pressure (IOP) is the only treatment modality for the management of glaucoma patients, aiming to arrest the irreversible visual field loss. Surgical treatment is usually indicated when the IOP is insufficiently lowered and/or glaucomatous optic neuropathy worsens and visual field defect progresses despite laser Trabeculoplasty or maximally tolerated medical therapy.</p>
<p style=\"text-align: justify;\">CLASS (CO<sub>2</sub> Laser Assisted Sclerectomy Surgery) procedure is similar to trabeculectomy, the major difference being that after the scleral flap is raised, the remaining sclera over the Schelm’s canal and trabecular meshwork is dissected by the CO2 laser probe until aqueous percolated over the entire dissected bed. The aqueous originated from the unroofed Schlemm’s canal and juxta-canalicular trabeculum and the dissection stops automatically by the aqueous in the bed and penetration in the AC is avoided. This way the procedure aimed to prevent intra ocular complications.</p>
<p style=\"text-align: justify;\">The procedure is performed under sub-conjunctival anesthesia. The perilimbal conjunctiva and tenon capsule are dissected. A half-thickness superior fornix-based scleral flap is fashioned with a crescent knife. A red laser aiming beam is used to mark the scanning area boundaries. Scan dimensions (width and length) can be changed within the range of 1 to 4 mm. Initially a wide scan area is used to repeatedly remove layers of sclera until a percolation zone can be readily identified. The CO2 laser is repeatedly applied with time intervals of 2 to 3 seconds between applications to allow percolation to take place and be detected, until sufficient percolation zone of at least 3 mm in region length is clearly evident. The scleral flap is then repositioned and sutured with 10-0 nylon sutures.</p>
[/vc_column_text][spacer height=\"35\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][framed_image image=\"105\" img_size=\"full\" img_link_target=\"_self\" align=\"none\"][spacer height=\"35\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][/vc_column][/vc_row]

<script>// <![CDATA[
(function(i,s,o,g,r,a,m){i[\'GoogleAnalyticsObject\']=r;i[r]=i[r]||function(){   (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),   m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)   })(window,document,\'script\',\'//www.google-analytics.com/analytics.js\',\'ga\');   ga(\'create\', \'UA-53735655-1\', \'auto\');   ga(\'send\', \'pageview\');
// ]]></script>","The Surgical Procedure","","publish","closed","open","","the-surgical-procedure","","","2015-01-05 08:00:06","2015-01-05 08:00:06","","93","http://ioptima.wpengine.com/?page_id=60","4","page","","0");
INSERT INTO `wp_posts` VALUES("61","2","2014-03-27 09:20:20","2014-03-27 09:20:20"," ","","","publish","closed","open","","61","","","2014-08-31 14:46:22","2014-08-31 14:46:22","","93","http://ioptima.wpengine.com/?p=61","14","nav_menu_item","","0");
INSERT INTO `wp_posts` VALUES("62","2","2014-03-27 09:19:50","2014-03-27 09:19:50","[vc_row][vc_column width=\"1/1\"][vc_column_text]
<h3>Clinical Publications:</h3>
[/vc_column_text][spacer height=\"20\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][/vc_column][/vc_row][vc_row][vc_column width=\"1/2\"][spacer height=\"50\" display_desktop=\"true\" display_tablet=\"false\" display_mobile=\"false\"][vc_column_text]Glaucoma surgery: Taking the sub-conjunctival route[/vc_column_text][/vc_column][vc_column width=\"1/2\"][framed_image img_size=\"188 × 252\" img_link_target=\"_blank\" align=\"none\" img_link=\"http://www.meajo.org/article.asp?issn=0974-9233;year=2015;volume=22;issue=1;spage=53;epage=58;aulast=Shaarawy\" image=\"447\"][/vc_column][/vc_row][vc_row][vc_column width=\"1/2\"][spacer height=\"50\" display_desktop=\"true\" display_tablet=\"false\" display_mobile=\"false\"][vc_column_text]Performing accurate CO<sub>²</sub> laser-assisted sclerectomy surgery[/vc_column_text][/vc_column][vc_column width=\"1/2\"][framed_image img_size=\"188 × 252\" img_link_target=\"_blank\" align=\"none\" img_link=\"/wp-content/uploads/2015/01/Performing-accurate-CO2-laser-assisted-sclerectomy-surgery-Ton-Assia-Geffen.pdf\" image=\"444\"][/vc_column][/vc_row][vc_row][vc_column width=\"1/2\"][spacer height=\"50\" display_desktop=\"true\" display_tablet=\"false\" display_mobile=\"false\"][vc_column_text]Results of CO<sub>²</sub> Laser-assisted Deep Sclerectomy as Compared With Conventional Deep Sclerectomy[/vc_column_text][/vc_column][vc_column width=\"1/2\"][framed_image image=\"435\" img_size=\"188 × 252\" img_link_target=\"_blank\" align=\"none\" img_link=\"/wp-content/uploads/2014/12/Results-of-CO2-Laser-assisted-Deep-Sclerectomy_Greifner-et-al.pdf\"][/vc_column][/vc_row][vc_row][vc_column width=\"1/2\"][spacer height=\"50\" display_desktop=\"true\" display_tablet=\"false\" display_mobile=\"false\"][vc_column_text]CO<sub>²</sub> Laser-assisted Deep Sclerectomy in

Glaucoma Patients[/vc_column_text][/vc_column][vc_column width=\"1/2\"][framed_image image=\"110\" img_size=\"full\" img_link_target=\"_blank\" align=\"none\" img_link=\"/wp-content/uploads/2014/04/Skaat-CO2-Laser-assisted-Deep-Sclerectomy-in-Glaucoma-Patients.pdf\"][/vc_column][/vc_row][vc_row][vc_column width=\"1/1\"][spacer height=\"30\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][/vc_column][/vc_row][vc_row][vc_column width=\"1/2\"][spacer height=\"50\" display_desktop=\"true\" display_tablet=\"false\" display_mobile=\"false\"][vc_column_text]CO<sub>²</sub> Laser-assisted Sclerectomy Surgery

For Open Angle Glaucoma[/vc_column_text][/vc_column][vc_column width=\"1/2\"][framed_image image=\"112\" img_size=\"full\" img_link_target=\"_blank\" align=\"none\" img_link=\"/wp-content/uploads/2014/04/CO2-Laser-assisted-Sclerectomy-Surgery.pdf\"][/vc_column][/vc_row][vc_row][vc_column width=\"1/1\"][spacer height=\"30\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][/vc_column][/vc_row][vc_row][vc_column width=\"1/2\"][spacer height=\"50\" display_desktop=\"true\" display_tablet=\"false\" display_mobile=\"false\"][vc_column_text]CO<sub>²</sub> Laser-assisted Sclerectomy Surgery, Part II: Multicenter Clinical Preliminary Study[/vc_column_text][/vc_column][vc_column width=\"1/2\"][framed_image image=\"111\" img_size=\"full\" img_link_target=\"_blank\" align=\"none\" img_link=\"/wp-content/uploads/2014/04/CO2-Laser-assisted-Sclerectomy-Surgery-Part-II-Multicenter-Clinical-Preliminary-Study_JOG_MAR2012.pdf\"][/vc_column][/vc_row][vc_row][vc_column width=\"1/1\"][spacer height=\"30\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][/vc_column][/vc_row][vc_row][vc_column width=\"1/2\"][spacer height=\"50\" display_desktop=\"true\" display_tablet=\"false\" display_mobile=\"false\"][vc_column_text]CO<sub>²</sub> Laser-assisted Sclerectomy Surgery Part I:
Concept and Experimental Models[/vc_column_text][/vc_column][vc_column width=\"1/2\"][framed_image image=\"113\" img_size=\"full\" img_link_target=\"_blank\" align=\"left\" img_link=\"/wp-content/uploads/2014/04/CO2-Laser-assisted-Sclerectomy-Surgery-Part-I-Concept-and-Experimental-Models_JOG_FEB2012.pdf\"][/vc_column][/vc_row][vc_row][vc_column width=\"1/1\"][spacer height=\"30\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][/vc_column][/vc_row][vc_row][vc_column width=\"1/1\"][vc_column_text]
<h3>Articles:</h3>
[/vc_column_text][spacer height=\"20\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][/vc_column][/vc_row][vc_row][vc_column width=\"1/2\"][spacer height=\"50\" display_desktop=\"true\" display_tablet=\"false\" display_mobile=\"false\"][vc_column_text]Nova técnica para o glaucoma utiliza ablação a laser de CO<sub>2</sub> para a esclerotomia profunda
<p style=\"text-align: justify; font-size: 12px;\">Ocular Surgery News - Latin American Edition (Spanish), March/April 2015</p>
[/vc_column_text][/vc_column][vc_column width=\"1/2\"][framed_image image=\"468\" img_size=\"medium\" img_link_target=\"_blank\" align=\"none\" img_link=\"/wp-content/uploads/2015/03/OSN-LA-MarchApril-CLASS-Greifner.pdf\"][spacer height=\"20\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][/vc_column][/vc_row][vc_row][vc_column width=\"1/2\"][spacer height=\"50\" display_desktop=\"true\" display_tablet=\"false\" display_mobile=\"false\"][vc_column_text]New glaucoma technique uses CO<sub>2</sub> laser ablation for deep sclerectomy
<p style=\"text-align: justify; font-size: 12px;\">Ocular Surgery News, February 2015</p>
[/vc_column_text][/vc_column][vc_column width=\"1/2\"][framed_image image=\"455\" img_size=\"medium\" img_link_target=\"_blank\" align=\"none\" img_link=\"/wp-content/uploads/2015/02/OSN-2.10.2015.CLASS.Greifner.pdf\"][spacer height=\"20\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][/vc_column][/vc_row][vc_row][vc_column width=\"1/2\"][spacer height=\"50\" display_desktop=\"true\" display_tablet=\"false\" display_mobile=\"false\"][vc_column_text]Will the Cost of Clinical Trials Quash Change in Glaucoma Treatment?
<p style=\"text-align: justify; font-size: 12px;\">Glaucoma Today, November/December 2014</p>
[/vc_column_text][/vc_column][vc_column width=\"1/2\"][framed_image image=\"429\" img_size=\"medium\" img_link_target=\"_blank\" align=\"none\" img_link=\"/wp-content/uploads/2014/11/GT-NovDec-14.CLASS.Robin_.pdf\"][spacer height=\"20\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][/vc_column][/vc_row][vc_row][vc_column width=\"1/2\"][spacer height=\"50\" display_desktop=\"true\" display_tablet=\"false\" display_mobile=\"false\"][vc_column_text]Phacoemulisifcation Plus CO<sub>2</sub> Laser-Assisted Sclerectomy
<p style=\"text-align: justify; font-size: 12px;\">Cataract &amp; Refractive Surgery Today - Europe, November/December 2014</p>
[/vc_column_text][/vc_column][vc_column width=\"1/2\"][framed_image image=\"428\" img_size=\"medium\" img_link_target=\"_blank\" align=\"none\" img_link=\"/wp-content/uploads/2014/11/CRST-Europe-Nov-Dec-14_CLASS_Venkatesh.pdf\"][spacer height=\"20\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][/vc_column][/vc_row][vc_row][vc_column width=\"1/2\"][spacer height=\"50\" display_desktop=\"true\" display_tablet=\"false\" display_mobile=\"false\"][vc_column_text]La esclerotomia asistida por laser de CO<sub>2</sub> reduce la PIO y el uso de medicacion
<p style=\"text-align: justify; font-size: 12px;\">Ocular Surgery News Latin America Edition (Spanish), September/October 2014</p>
[/vc_column_text][/vc_column][vc_column width=\"1/2\"][framed_image image=\"393\" img_size=\"medium\" img_link_target=\"_blank\" align=\"none\" img_link=\"/wp-content/uploads/2014/09/OSN_LA_CLASS-SeptOct2014_Turati.pdf\"][spacer height=\"20\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][/vc_column][/vc_row][vc_row][vc_column width=\"1/2\"][spacer height=\"50\" display_desktop=\"true\" display_tablet=\"false\" display_mobile=\"false\"][vc_column_text]A New Option in Nonpenetrating Glaucoma Surgery: Two US Perspectives
<p style=\"text-align: justify; font-size: 12px;\">Advanced Ocular Care, September 2014</p>
[/vc_column_text][/vc_column][vc_column width=\"1/2\"][framed_image image=\"388\" img_size=\"medium\" img_link_target=\"_blank\" align=\"none\" img_link=\"/wp-content/uploads/2014/09/AOC_CLASS_9.2014_Noecker_Robin.pdf\"][spacer height=\"20\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][/vc_column][/vc_row][vc_row][vc_column width=\"1/2\"][spacer height=\"50\" display_desktop=\"true\" display_tablet=\"false\" display_mobile=\"false\"][vc_column_text]Combined phaco, CLASS procedure reduces IOP in patients with open-angle glaucoma
<p style=\"text-align: justify; font-size: 12px;\">Ocular Surgery News/Healio, September 2014</p>
[/vc_column_text][/vc_column][vc_column width=\"1/2\"][framed_image image=\"387\" img_size=\"medium\" img_link_target=\"_blank\" align=\"none\" img_link=\"/wp-content/uploads/2014/09/OSN_CLASS_Venkatesh_9.17.14.pdf\"][spacer height=\"20\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][/vc_column][/vc_row][vc_row][vc_column width=\"1/2\"][spacer height=\"50\" display_desktop=\"true\" display_tablet=\"false\" display_mobile=\"false\"][vc_column_text]CLASS procedure offers alternative treatment for glaucoma
<p style=\"text-align: justify; font-size: 12px;\">Ocular Surgery News APAO Edition, July/August 2014</p>
[/vc_column_text][/vc_column][vc_column width=\"1/2\"][framed_image image=\"361\" img_size=\"medium\" img_link_target=\"_blank\" align=\"none\" img_link=\"/wp-content/uploads/2014/08/OSN-AP-JulyAugust-14_Melamed-CLASS.pdf\"][spacer height=\"20\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][/vc_column][/vc_row][vc_row][vc_column width=\"1/2\"][spacer height=\"50\" display_desktop=\"true\" display_tablet=\"false\" display_mobile=\"false\"][vc_column_text]CLASS procedure offers alternative treatment for glaucoma
<p style=\"text-align: justify; font-size: 12px;\">Ocular Surgery News EU Edition, July/August 2014</p>
[/vc_column_text][/vc_column][vc_column width=\"1/2\"][framed_image image=\"325\" img_size=\"medium\" img_link_target=\"_blank\" align=\"none\" img_link=\"/wp-content/uploads/2014/08/OSN-Europe_july-august-14_Melamed_CLASS.pdf\"][spacer height=\"20\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][/vc_column][/vc_row][vc_row][vc_column width=\"1/2\"][spacer height=\"50\" display_desktop=\"true\" display_tablet=\"false\" display_mobile=\"false\"][vc_column_text]CLASS procedure offers alternative treatment for glaucoma
<p style=\"text-align: justify; font-size: 12px;\">Ocular Surgery News U.S. Edition, July 2014</p>
[/vc_column_text][/vc_column][vc_column width=\"1/2\"][framed_image image=\"303\" img_size=\"medium\" img_link_target=\"_blank\" align=\"none\" img_link=\"/wp-content/uploads/2014/07/CLASS-procedure-offers-alternative-treatment-for-glaucoma-_-Ocular-Surgery-News.pdf\"][spacer height=\"20\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][/vc_column][/vc_row][vc_row][vc_column width=\"1/2\"][spacer height=\"50\" display_desktop=\"true\" display_tablet=\"false\" display_mobile=\"false\"][vc_column_text]Glaucoma Treatment
<p style=\"text-align: justify; font-size: 12px;\">Eurotimes Industry Brief, May 2014</p>
[/vc_column_text][/vc_column][vc_column width=\"1/2\"][framed_image image=\"226\" img_size=\"medium\" img_link_target=\"_blank\" align=\"none\" img_link=\"/wp-content/uploads/2014/07/eurotimes-industy-brief-may-2014-p-43.pdf\"][spacer height=\"20\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][/vc_column][/vc_row][vc_row][vc_column width=\"1/2\"][spacer height=\"50\" display_desktop=\"true\" display_tablet=\"false\" display_mobile=\"false\"][vc_column_text]CO2 laser surgery a new option for glaucoma
<p style=\"text-align: justify; font-size: 12px;\">Ophthalmology Times USA, May 2014</p>
[/vc_column_text][/vc_column][vc_column width=\"1/2\"][framed_image image=\"224\" img_size=\"medium\" img_link_target=\"_blank\" align=\"none\" img_link=\"/wp-content/uploads/2014/07/Ophthalmology-time-US-CO2-laser-surgery-a-new-option-for-glaucoma1.pdf\"][spacer height=\"20\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][/vc_column][/vc_row][vc_row][vc_column width=\"1/2\"][spacer height=\"50\" display_desktop=\"true\" display_tablet=\"false\" display_mobile=\"false\"][vc_column_text]Glaucoma Surgery with CLASS
<p style=\"text-align: justify; font-size: 12px;\">Ophthalmology Times Europe, May 2014</p>
[/vc_column_text][/vc_column][vc_column width=\"1/2\"][framed_image image=\"222\" img_size=\"medium\" img_link_target=\"_blank\" align=\"none\" img_link=\"/wp-content/uploads/2014/07/Ophthalmology-time-EU-CLASS_May14_pdf-Assia-and-Melamed.pdf\"][spacer height=\"20\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][/vc_column][/vc_row][vc_row][vc_column width=\"1/2\"][spacer height=\"50\" display_desktop=\"true\" display_tablet=\"false\" display_mobile=\"false\"][vc_column_text]CLASS act: Why a new CO<sub>2</sub> laser is competing with the gold standard
<p style=\"text-align: justify; font-size: 12px;\">Eyeworld, May 2014</p>
[/vc_column_text][/vc_column][vc_column width=\"1/2\"][framed_image image=\"220\" img_size=\"medium\" img_link_target=\"_blank\" align=\"none\" img_link=\"/wp-content/uploads/2014/05/EyeWorld-May-2014_CLASS-act-Why-a-new-CO2-laser-is-competing-with-the-gold-standard.pdf\"][/vc_column][/vc_row][vc_row][vc_column width=\"1/2\"][spacer height=\"50\" display_desktop=\"true\" display_tablet=\"false\" display_mobile=\"false\"][vc_column_text]CLASS-­y Laser Treats Glaucoma
<p style=\"text-align: justify; font-size: 12px;\">The Ophthalmologist, March 2014</p>
[/vc_column_text][/vc_column][vc_column width=\"1/2\"][framed_image image=\"109\" img_size=\"medium\" img_link_target=\"_blank\" align=\"none\" img_link=\"/wp-content/uploads/2014/04/CLASS-y-Laser-Treats-Glaucoma-Asia.pdf\"][/vc_column][/vc_row][vc_row][vc_column width=\"1/1\"][spacer height=\"30\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][/vc_column][/vc_row][vc_row][vc_column width=\"1/1\"][vc_column_text]
<h3>Posters:</h3>
[/vc_column_text][spacer height=\"20\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][/vc_column][/vc_row][vc_row][vc_column width=\"1/2\"][spacer height=\"50\" display_desktop=\"true\" display_tablet=\"false\" display_mobile=\"false\"][vc_column_text]CLASS in Mexican Patients with Open Angle Glaucoma
<p style=\"text-align: justify; font-size: 12px;\">Presented at EGS, Jun. 2014</p>
[/vc_column_text][/vc_column][vc_column width=\"1/2\"][framed_image image=\"219\" img_size=\"medium\" img_link_target=\"_blank\" align=\"none\" img_link=\"/wp-content/uploads/2014/03/P254-Mauricio-Turati.pdf\"][/vc_column][/vc_row][vc_row][vc_column width=\"1/2\"][spacer height=\"50\" display_desktop=\"true\" display_tablet=\"false\" display_mobile=\"false\"][vc_column_text]Long-term results of CLASS
<p style=\"text-align: justify; font-size: 12px;\">Presented at ICGS, Feb. 2014[/vc_column_text][/vc_column][vc_column width=\"1/2\"][framed_image image=\"114\" img_size=\"full\" img_link_target=\"_blank\" align=\"none\" img_link=\"/wp-content/uploads/2014/04/IOptima_Poster_Asia-ICGS-2014.pdf\"][/vc_column][/vc_row][vc_row][vc_column width=\"1/1\"][spacer height=\"30\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][/vc_column][/vc_row][vc_row][vc_column width=\"1/2\"][spacer height=\"50\" display_desktop=\"true\" display_tablet=\"false\" display_mobile=\"false\"][vc_column_text]CLASS – a novel filtration treatment for glaucoma patients</p>
<p style=\"text-align: justify; font-size: 12px;\">Presented at WGC, July 2013[/vc_column_text][/vc_column][vc_column width=\"1/2\"][framed_image image=\"115\" img_size=\"full\" img_link_target=\"_blank\" align=\"none\" img_link=\"/wp-content/uploads/2014/04/IOptima_Poster_Choka-WGC-2013.pdf\"][/vc_column][/vc_row][vc_row][vc_column width=\"1/1\"][spacer height=\"30\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][/vc_column][/vc_row][vc_row][vc_column width=\"1/2\"][spacer height=\"50\" display_desktop=\"true\" display_tablet=\"false\" display_mobile=\"false\"][vc_column_text]CLASS – CO<sub>²</sub> Laser-Assisted Sclerectomy Surgery</p>
<p style=\"text-align: justify; font-size: 12px;\">Presented at WGC, July 2013</p>
[/vc_column_text][/vc_column][vc_column width=\"1/2\"][framed_image image=\"108\" img_size=\"full\" img_link_target=\"_blank\" align=\"none\" img_link=\"/wp-content/uploads/2014/04/CLASS-Poster-at-WGC-2013-Switzerland.pdf\"][/vc_column][/vc_row][vc_row][vc_column width=\"1/1\"][spacer height=\"30\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][/vc_column][/vc_row][vc_row][vc_column width=\"1/2\"][spacer height=\"50\" display_desktop=\"true\" display_tablet=\"false\" display_mobile=\"false\"][vc_column_text]CLASS – a novel filtration treatment for glaucoma patients
<p style=\"text-align: justify; font-size: 12px;\">Presented at AGS, Feb. 2012[/vc_column_text][/vc_column][vc_column width=\"1/2\"][framed_image image=\"107\" img_size=\"full\" img_link_target=\"_blank\" align=\"none\" img_link=\"/wp-content/uploads/2014/04/CLASS-Poster-AGS_NYC_Feb-2012.pdf\"][/vc_column][/vc_row][vc_row][vc_column width=\"1/1\"][spacer height=\"30\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][/vc_column][/vc_row][vc_row][vc_column][vc_column_text]</p>
[/vc_column_text][/vc_column][/vc_row][vc_row][vc_column][vc_column_text]

<script>// <![CDATA[
(function(i,s,o,g,r,a,m){i[\'GoogleAnalyticsObject\']=r;i[/vc_column_text][/vc_column][/vc_row][vc_row][vc_column][vc_column_text][r][/vc_column_text][/vc_column][/vc_row][vc_row][vc_column][vc_column_text]=i[/vc_column_text][/vc_column][/vc_row][vc_row][vc_column][vc_column_text][r][/vc_column_text][/vc_column][/vc_row][vc_row][vc_column][vc_column_text]||function(){   (i[/vc_column_text][/vc_column][/vc_row][vc_row][vc_column][vc_column_text][r][/vc_column_text][/vc_column][/vc_row][vc_row][vc_column][vc_column_text].q=i[/vc_column_text][/vc_column][/vc_row][vc_row][vc_column][vc_column_text][r][/vc_column_text][/vc_column][/vc_row][vc_row][vc_column][vc_column_text].q||[]).push(arguments)},i[/vc_column_text][/vc_column][/vc_row][vc_row][vc_column][vc_column_text][r][/vc_column_text][/vc_column][/vc_row][vc_row][vc_column][vc_column_text].l=1*new Date();a=s.createElement(o),   m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)   })(window,document,\'script\',\'//www.google-analytics.com/analytics.js\',\'ga\');   ga(\'create\', \'UA-53735655-1\', \'auto\');   ga(\'send\', \'pageview\');
// ]]></script>[/vc_column_text][/vc_column][/vc_row]","Publications","","publish","closed","open","","publications","","","2015-03-29 12:18:16","2015-03-29 12:18:16","","93","http://ioptima.wpengine.com/?page_id=62","6","page","","0");
INSERT INTO `wp_posts` VALUES("63","2","2014-03-27 09:20:15","2014-03-27 09:20:15","[vc_row][vc_column width=\"1/4\"][framed_image image=\"407\" img_size=\"125×142\" img_link_target=\"_self\" align=\"right\"][/vc_column][vc_column width=\"3/4\"][vc_column_text]<i>\"The eye is normally quiet, and vision is maintained soon after surgery. CLASS learning curve is fast. The fluid percolation is titrated during surgery, and further laser applications are provided until a satisfactory clinical result is achieved.”</i>

<b>Prof. Assia Ehud – Meir Medical Center, Kfar Saba, Israel, Inventor</b><b></b>[/vc_column_text][/vc_column][/vc_row][vc_row][vc_column width=\"1/1\"][spacer height=\"30\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][/vc_column][/vc_row][vc_row][vc_column width=\"1/4\"][framed_image image=\"403\" img_size=\"full\" img_link_target=\"_self\" align=\"right\"][/vc_column][vc_column width=\"3/4\"][vc_column_text]<i>\"</i><i>IOPtima’s CLASS procedure has true advantages over the Trabeculectomy surgery as it offers an excellent safety profile with an ease of use. It can lower pressure into the lower teens and reduce the patient’s reliance on glaucoma medications without subjecting the eye to the risks of Trabeculectomy. It also reduces learning curve time for performing deep sclerectomy with very similar results to published data.\"</i>

<b>Prof. Mermoud Andre - Clinique de Montchoisi, Lausanne, Switzerland</b>[/vc_column_text][/vc_column][/vc_row][vc_row][vc_column width=\"1/1\"][spacer height=\"30\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][/vc_column][/vc_row][vc_row][vc_column width=\"1/4\"][framed_image image=\"404\" img_size=\"125 × 142\" img_link_target=\"_self\" align=\"right\"][/vc_column][vc_column width=\"3/4\"][vc_column_text]<i>\"In my experience, patient follow up (24 months) demonstrates consistent and sustained IOP lowering.  The efficacy and simplicity of the IOPtiMate procedure is remarkable.\"</i>

<b>Dr. Muñoz Gonzalo - Hospital Nisa Valencia al Mar, Valencia, Spain</b>[/vc_column_text][/vc_column][/vc_row][vc_row][vc_column width=\"1/1\"][spacer height=\"30\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][/vc_column][/vc_row][vc_row][vc_column width=\"1/4\"][framed_image image=\"405\" img_size=\"full\" img_link_target=\"_self\" align=\"right\"][/vc_column][vc_column width=\"3/4\"][vc_column_text]<i>\"While watching me do a CLASS procedure one of my fellows remarked that this is one surgery they can probably do at least as well as I, emphasizing the short learning curve of this procedure“.</i>

<b>Prof. Shaarawy Tarek - HUG Hospital, Genève, Switzerland</b>[/vc_column_text][/vc_column][/vc_row][vc_row][vc_column width=\"1/1\"][spacer height=\"30\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][/vc_column][/vc_row][vc_row][vc_column width=\"1/4\"][framed_image image=\"406\" img_size=\"125 × 142\" img_link_target=\"_self\" align=\"right\"][/vc_column][vc_column width=\"3/4\"][vc_column_text]<i>\"From my experience Using IOPtima’s CLASS, the procedure is (1) effective in lowering IOP, (2)  Easy to use with a short learning curve, (3)  high safety profile due to a its laser qualities and (4) reduced post-op recovery and complications associated with other penetrating surgeries.\"</i>

<b>Dr. Félix Gil Carrasco - Hospital Angeles del Pedreg, Mexico city, Mexico</b>[/vc_column_text][/vc_column][/vc_row][vc_row][vc_column width=\"1/1\"][spacer height=\"30\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][/vc_column][/vc_row][vc_row][vc_column][vc_column_text]

<script>// <![CDATA[
(function(i,s,o,g,r,a,m){i[\'GoogleAnalyticsObject\']=r;i[/vc_column_text][/vc_column][/vc_row][vc_row][vc_column][vc_column_text][r][/vc_column_text][/vc_column][/vc_row][vc_row][vc_column][vc_column_text]=i[/vc_column_text][/vc_column][/vc_row][vc_row][vc_column][vc_column_text][r][/vc_column_text][/vc_column][/vc_row][vc_row][vc_column][vc_column_text]||function(){   (i[/vc_column_text][/vc_column][/vc_row][vc_row][vc_column][vc_column_text][r][/vc_column_text][/vc_column][/vc_row][vc_row][vc_column][vc_column_text].q=i[/vc_column_text][/vc_column][/vc_row][vc_row][vc_column][vc_column_text][r][/vc_column_text][/vc_column][/vc_row][vc_row][vc_column][vc_column_text].q||[]).push(arguments)},i[/vc_column_text][/vc_column][/vc_row][vc_row][vc_column][vc_column_text][r][/vc_column_text][/vc_column][/vc_row][vc_row][vc_column][vc_column_text].l=1*new Date();a=s.createElement(o),   m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)   })(window,document,\'script\',\'//www.google-analytics.com/analytics.js\',\'ga\');   ga(\'create\', \'UA-53735655-1\', \'auto\');   ga(\'send\', \'pageview\');
// ]]></script>[/vc_column_text][/vc_column][/vc_row]","Testimonials","","publish","closed","open","","testimonials","","","2014-10-30 15:13:48","2014-10-30 15:13:48","","93","http://ioptima.wpengine.com/?page_id=63","8","page","","0");
INSERT INTO `wp_posts` VALUES("64","2","2014-03-27 09:22:08","2014-03-27 09:22:08"," ","","","publish","closed","open","","64","","","2014-08-31 14:46:22","2014-08-31 14:46:22","","93","http://ioptima.wpengine.com/?p=64","17","nav_menu_item","","0");
INSERT INTO `wp_posts` VALUES("65","2","2014-03-27 09:22:08","2014-03-27 09:22:08"," ","","","publish","closed","open","","65","","","2014-08-31 14:46:22","2014-08-31 14:46:22","","93","http://ioptima.wpengine.com/?p=65","15","nav_menu_item","","0");
INSERT INTO `wp_posts` VALUES("66","2","2014-03-27 09:22:08","2014-03-27 09:22:08","","For Patients","","publish","closed","open","","for-patients","","","2014-08-31 14:46:22","2014-08-31 14:46:22","","0","http://ioptima.wpengine.com/?p=66","18","nav_menu_item","","0");
INSERT INTO `wp_posts` VALUES("67","2","2014-03-27 19:40:08","2014-03-27 19:40:08","<div class=\"row-fluid alternate-contact-form\">
<div class=\"span6\">

<p>[textarea your-message x8 placeholder \"Message\"]</p>

</div>
<div class=\"span6\">

<p>[text* your-name 1/40 placeholder \"Name (required)\"]</p>

<p>[email* your-email 1/40 placeholder \"Email (required)\"]</p>

<p>[captchac captcha] 
[captchar captcha]</p>
<div class=\"row-fluid form-large\">
	[submit \"Send message\"]
</div>
</div>
</div>

<script>
jQuery(\'[name=\"captcha\"]\').attr(\"placeholder\",\"Enter Code\")
</script>
[your-subject]
[your-name] <[your-email]>
From: [your-name] <[your-email]>
Subject: [your-subject]

Message Body:
[your-message]

--
This e-mail was sent from a contact form on IOPtima (http://ioptima.wpengine.com)
info@ioptima.co.il




[your-subject]
[your-name] <[your-email]>
Message Body:
[your-message]

--
This e-mail was sent from a contact form on IOPtima (http://ioptima.wpengine.com)
[your-email]



Your message was sent successfully. Thanks.
Failed to send your message. Please try later or contact the administrator by another method.
Validation errors occurred. Please confirm the fields and submit it again.
Failed to send your message. Please try later or contact the administrator by another method.
Please accept the terms to proceed.
Please fill the required field.
Your entered code is incorrect.
Number format seems invalid.
This number is too small.
This number is too large.
Email address seems invalid.
URL seems invalid.
Telephone number seems invalid.
Your answer is not correct.
Date format seems invalid.
This date is too early.
This date is too late.
Failed to upload file.
This file type is not allowed.
This file is too large.
Failed to upload file. Error occurred.","Contact","","publish","closed","open","","untitled","","","2014-03-27 19:43:33","2014-03-27 19:43:33","","0","http://ioptima.wpengine.com/?post_type=wpcf7_contact_form&#038;p=67","11","wpcf7_contact_form","","0");
INSERT INTO `wp_posts` VALUES("70","2","2014-04-03 14:10:06","2014-04-03 14:10:06","","favicon","","inherit","closed","open","","favicon-2","","","2014-04-03 14:10:06","2014-04-03 14:10:06","","0","http://ioptima.wpengine.com/wp-content/uploads/2014/04/favicon.png","11","attachment","image/png","0");
INSERT INTO `wp_posts` VALUES("74","2","2014-04-04 15:59:19","2014-04-04 15:59:19","","Ioptima","","inherit","closed","open","","home-image-clean","","","2014-04-04 15:59:19","2014-04-04 15:59:19","","0","http://ioptima.wpengine.com/wp-content/uploads/2014/04/Home-Image-clean.jpg","11","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("75","2","2014-04-07 17:23:32","2014-04-07 17:23:32","","New-Slide","","inherit","closed","open","","new-slide","","","2014-04-07 17:23:32","2014-04-07 17:23:32","","0","http://ioptima.wpengine.com/wp-content/uploads/2014/04/New-Slide.jpg","11","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("81","2","2014-04-07 18:39:30","2014-04-07 18:39:30","","Scanner 2","","inherit","closed","open","","scanner-2","","","2014-04-07 18:39:30","2014-04-07 18:39:30","","42","http://ioptima.wpengine.com/wp-content/uploads/2014/03/Scanner-2.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("82","2","2014-04-07 18:39:32","2014-04-07 18:39:32","","Scanner 1","","inherit","closed","open","","scanner-1","","","2014-04-07 18:39:32","2014-04-07 18:39:32","","42","http://ioptima.wpengine.com/wp-content/uploads/2014/03/Scanner-1.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("84","2","2014-04-07 18:50:34","2014-04-07 18:50:34","","CLASS principle of Operation","","inherit","closed","open","","class-principle-of-operation","","","2014-04-07 18:50:34","2014-04-07 18:50:34","","41","http://ioptima.wpengine.com/wp-content/uploads/2014/03/CLASS-principle-of-Operation.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("85","2","2014-04-07 18:56:40","2014-04-07 18:56:40","","procedure 6","","inherit","closed","open","","procedure-6","","","2014-04-07 18:56:40","2014-04-07 18:56:40","","41","http://ioptima.wpengine.com/wp-content/uploads/2014/03/procedure-6.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("86","2","2014-04-07 18:56:42","2014-04-07 18:56:42","","procedure 1","","inherit","closed","open","","procedure-1","","","2014-04-07 18:56:42","2014-04-07 18:56:42","","41","http://ioptima.wpengine.com/wp-content/uploads/2014/03/procedure-1.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("87","2","2014-04-07 18:56:43","2014-04-07 18:56:43","","procedure 2","","inherit","closed","open","","procedure-2","","","2014-04-07 18:56:43","2014-04-07 18:56:43","","41","http://ioptima.wpengine.com/wp-content/uploads/2014/03/procedure-2.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("88","2","2014-04-07 18:56:45","2014-04-07 18:56:45","","procedure 3","","inherit","closed","open","","procedure-3","","","2014-04-07 18:56:45","2014-04-07 18:56:45","","41","http://ioptima.wpengine.com/wp-content/uploads/2014/03/procedure-3.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("89","2","2014-04-07 18:56:47","2014-04-07 18:56:47","","procedure 4","","inherit","closed","open","","procedure-4","","","2014-04-07 18:56:47","2014-04-07 18:56:47","","41","http://ioptima.wpengine.com/wp-content/uploads/2014/03/procedure-4.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("90","2","2014-04-07 18:56:48","2014-04-07 18:56:48","","procedure 5","","inherit","closed","open","","procedure-5","","","2014-04-07 18:56:48","2014-04-07 18:56:48","","41","http://ioptima.wpengine.com/wp-content/uploads/2014/03/procedure-5.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("91","2","2014-04-09 07:03:00","2014-04-09 07:03:00","","About Us","","publish","closed","open","","company","","","2014-08-31 14:34:48","2014-08-31 14:34:48","","0","http://ioptima.wpengine.com/?page_id=91","8","page","","0");
INSERT INTO `wp_posts` VALUES("92","2","2014-04-09 07:05:32","2014-04-09 07:05:32","","Technology","","publish","closed","open","","technology","","","2014-08-31 10:58:12","2014-08-31 10:58:12","","0","http://ioptima.wpengine.com/?page_id=92","11","page","","0");
INSERT INTO `wp_posts` VALUES("93","2","2014-04-09 07:06:38","2014-04-09 07:06:38","","For Physicians","","publish","closed","open","","for-physicians","","","2014-08-31 10:58:32","2014-08-31 10:58:32","","0","http://ioptima.wpengine.com/?page_id=93","11","page","","0");
INSERT INTO `wp_posts` VALUES("94","2","2014-04-09 07:08:23","2014-04-09 07:08:23","","For Petients","","publish","closed","open","","for-petients","","","2015-01-29 08:32:54","2015-01-29 08:32:54","","0","http://ioptima.wpengine.com/?page_id=94","3","page","","0");
INSERT INTO `wp_posts` VALUES("96","2","2014-04-17 15:23:00","2014-04-17 15:23:00","[vc_row][vc_column width=\"1/4\"][spacer height=\"30\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][framed_image image=\"86\" img_size=\"full\" img_link_target=\"_self\" align=\"right\"][/vc_column][vc_column width=\"3/4\"][spacer height=\"30\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][vc_column_text]
<p style=\"text-align: justify;\"><strong>Creation of the standard flap</strong></p>
<p style=\"text-align: justify;\">Following standard surgical preparation and eye fixation, the surgeon manually cuts open the conjunctiva and exposes the sclera. A standard scleral flap is then created above the desired percolation zone.</p>
[/vc_column_text][/vc_column][/vc_row][vc_row][vc_column width=\"1/4\"][spacer height=\"30\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][framed_image image=\"87\" img_size=\"full\" img_link_target=\"_self\" align=\"right\"][/vc_column][vc_column width=\"3/4\"][spacer height=\"30\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][vc_column_text]
<p style=\"text-align: justify;\"><strong>Creation of scleral bed - Reservoir</strong></p>
<p style=\"text-align: justify;\">The surgeon may elect to create a reservoir, using the IOPtimate® and the laser beam, to hold the fluid that percolates from the eye. This step is aimed to reduce bleb size to a diffused bleb.[/vc_column_text][/vc_column][/vc_row][vc_row][vc_column width=\"1/4\"][spacer height=\"30\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][framed_image image=\"88\" img_size=\"full\" img_link_target=\"_self\" align=\"right\"][/vc_column][vc_column width=\"3/4\"][spacer height=\"30\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][vc_column_text]</p>
<p style=\"text-align: justify;\"><strong>Tissue Ablation</strong></p>
<p style=\"text-align: justify;\">Utilizing the IOPtimate®, the laser beam is rapidly scanned in a pre-selected ablation pattern and repeatedly ablates thin layers of sclera (~30 microns), exposing and “un-roofing” the Schlemm’s Canal, until the desired level of percolation is achieved.</p>
[/vc_column_text][/vc_column][/vc_row][vc_row][vc_column width=\"1/4\"][spacer height=\"30\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][framed_image image=\"89\" img_size=\"full\" img_link_target=\"_self\" align=\"right\"][/vc_column][vc_column width=\"3/4\"][spacer height=\"30\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][vc_column_text]
<p style=\"text-align: justify;\"><strong>Fluid percolation</strong></p>
<p style=\"text-align: justify;\">Once the Schlemm\'s Canal is revealed, internal ocular fluid begins to percolate through the thinned, intact trabecular meshwork.</p>
[/vc_column_text][/vc_column][/vc_row][vc_row][vc_column width=\"1/4\"][spacer height=\"30\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][framed_image image=\"90\" img_size=\"full\" img_link_target=\"_self\" align=\"right\"][/vc_column][vc_column width=\"3/4\"][spacer height=\"30\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][vc_column_text]
<p style=\"text-align: justify;\"><strong>A thin layer remains intact; penetration of the eye is avoided</strong></p>
<p style=\"text-align: justify;\">Upon achieving percolation, the CO2 laser energy is absorbed by the percolating fluid, preventing further tissue ablation and inadvertent penetration into the anterior chamber.</p>
[/vc_column_text][/vc_column][/vc_row][vc_row][vc_column width=\"1/4\"][spacer height=\"30\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][framed_image image=\"85\" img_size=\"full\" img_link_target=\"_self\" align=\"right\"][/vc_column][vc_column width=\"3/4\"][spacer height=\"30\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][vc_column_text]
<p style=\"text-align: justify;\"><strong>Suturing</strong></p>
<p style=\"text-align: justify;\">Once the procedure has ended, the scleral flap and conjunctiva are closed and sutured</p>
[/vc_column_text][/vc_column][/vc_row][vc_row][vc_column width=\"1/1\"][spacer height=\"50\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][vc_video title=\"Animated CALSS Procedure Flow\" link=\"https://www.youtube.com/watch?v=ejQbUMjxUI0\"][/vc_column][/vc_row][vc_row][vc_column][vc_column_text]

<script>// <![CDATA[
(function(i,s,o,g,r,a,m){i[\'GoogleAnalyticsObject\']=r;i[/vc_column_text][/vc_column][/vc_row][vc_row][vc_column][vc_column_text][r][/vc_column_text][/vc_column][/vc_row][vc_row][vc_column][vc_column_text]=i[/vc_column_text][/vc_column][/vc_row][vc_row][vc_column][vc_column_text][r][/vc_column_text][/vc_column][/vc_row][vc_row][vc_column][vc_column_text]||function(){   (i[/vc_column_text][/vc_column][/vc_row][vc_row][vc_column][vc_column_text][r][/vc_column_text][/vc_column][/vc_row][vc_row][vc_column][vc_column_text].q=i[/vc_column_text][/vc_column][/vc_row][vc_row][vc_column][vc_column_text][r][/vc_column_text][/vc_column][/vc_row][vc_row][vc_column][vc_column_text].q||[]).push(arguments)},i[/vc_column_text][/vc_column][/vc_row][vc_row][vc_column][vc_column_text][r][/vc_column_text][/vc_column][/vc_row][vc_row][vc_column][vc_column_text].l=1*new Date();a=s.createElement(o),   m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)   })(window,document,\'script\',\'//www.google-analytics.com/analytics.js\',\'ga\');   ga(\'create\', \'UA-53735655-1\', \'auto\');   ga(\'send\', \'pageview\');
// ]]></script>[/vc_column_text][/vc_column][/vc_row]","CLASS Procedure Flow","","publish","closed","open","","class-procedure-flow","","","2014-08-25 10:34:34","2014-08-25 10:34:34","","92","http://ioptima.wpengine.com/?page_id=96","3","page","","0");
INSERT INTO `wp_posts` VALUES("98","2","2014-04-17 15:17:14","2014-04-17 15:17:14","","Quality","","inherit","closed","open","","quality-2","","","2014-04-17 15:17:14","2014-04-17 15:17:14","","56","http://ioptima.wpengine.com/wp-content/uploads/2014/03/Quality.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("100","2","2014-04-17 15:23:38","2014-04-17 15:23:38"," ","","","publish","closed","open","","100","","","2014-08-31 14:46:22","2014-08-31 14:46:22","","92","http://ioptima.wpengine.com/?p=100","10","nav_menu_item","","0");
INSERT INTO `wp_posts` VALUES("104","2","2014-04-17 15:52:15","2014-04-17 15:52:15","","venn diagram","","inherit","closed","open","","venn-diagram","","","2014-04-17 15:52:15","2014-04-17 15:52:15","","43","http://ioptima.wpengine.com/wp-content/uploads/2014/03/venn-diagram.png","0","attachment","image/png","0");
INSERT INTO `wp_posts` VALUES("105","2","2014-04-17 15:57:34","2014-04-17 15:57:34","","The-Surgical-Procedure","","inherit","closed","open","","the-surgical-procedure","","","2014-04-17 15:57:34","2014-04-17 15:57:34","","43","http://ioptima.wpengine.com/wp-content/uploads/2014/03/The-Surgical-Procedure.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("107","2","2014-04-17 16:13:57","2014-04-17 16:13:57","","CLASS-a-novel-filtration-treatment-for-glaucoma-patients-2","","inherit","closed","open","","class-a-novel-filtration-treatment-for-glaucoma-patients-2","","","2014-04-17 16:13:57","2014-04-17 16:13:57","","62","http://ioptima.wpengine.com/wp-content/uploads/2014/03/CLASS-a-novel-filtration-treatment-for-glaucoma-patients-2.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("108","2","2014-04-17 16:13:59","2014-04-17 16:13:59","","CLASS-CO2-Laser-Assisted-Sclerectomy-Surgery","","inherit","closed","open","","class-co2-laser-assisted-sclerectomy-surgery","","","2014-04-17 16:13:59","2014-04-17 16:13:59","","62","http://ioptima.wpengine.com/wp-content/uploads/2014/03/CLASS-CO2-Laser-Assisted-Sclerectomy-Surgery.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("109","2","2014-04-17 16:14:00","2014-04-17 16:14:00","","CLASS-­y-Laser-Treats-Glaucoma","","inherit","closed","open","","class-%c2%ady-laser-treats-glaucoma","","","2014-04-17 16:14:00","2014-04-17 16:14:00","","62","http://ioptima.wpengine.com/wp-content/uploads/2014/03/CLASS-­y-Laser-Treats-Glaucoma.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("110","2","2014-04-17 16:14:03","2014-04-17 16:14:03","","CO2-Laser-assisted-Deep-Sclerectomy-in","","inherit","closed","open","","co2-laser-assisted-deep-sclerectomy-in","","","2014-04-17 16:14:03","2014-04-17 16:14:03","","62","http://ioptima.wpengine.com/wp-content/uploads/2014/03/CO2-Laser-assisted-Deep-Sclerectomy-in.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("111","2","2014-04-17 16:14:05","2014-04-17 16:14:05","","CO2-Laser-assisted-Sclerectomy-Surgery,-Part-II","","inherit","closed","open","","co2-laser-assisted-sclerectomy-surgery-part-ii","","","2014-04-17 16:14:05","2014-04-17 16:14:05","","62","http://ioptima.wpengine.com/wp-content/uploads/2014/03/CO2-Laser-assisted-Sclerectomy-Surgery-Part-II.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("112","2","2014-04-17 16:14:06","2014-04-17 16:14:06","","CO2-Laser-assisted-Sclerectomy-Surgery","","inherit","closed","open","","co2-laser-assisted-sclerectomy-surgery","","","2014-04-17 16:14:06","2014-04-17 16:14:06","","62","http://ioptima.wpengine.com/wp-content/uploads/2014/03/CO2-Laser-assisted-Sclerectomy-Surgery.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("113","2","2014-04-17 16:14:08","2014-04-17 16:14:08","","CO2-Laser-assisted-Sclerectomy-Surgery-Part-I","","inherit","closed","open","","co2-laser-assisted-sclerectomy-surgery-part-i","","","2014-04-17 16:14:08","2014-04-17 16:14:08","","62","http://ioptima.wpengine.com/wp-content/uploads/2014/03/CO2-Laser-assisted-Sclerectomy-Surgery-Part-I.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("114","2","2014-04-17 16:14:09","2014-04-17 16:14:09","","Long-term-results-of-CLASS","","inherit","closed","open","","long-term-results-of-class","","","2014-04-17 16:14:09","2014-04-17 16:14:09","","62","http://ioptima.wpengine.com/wp-content/uploads/2014/03/Long-term-results-of-CLASS.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("115","2","2014-04-17 16:14:11","2014-04-17 16:14:11","","CLASS-a-novel-filtration-treatment-for-glaucoma-patients","","inherit","closed","open","","class-a-novel-filtration-treatment-for-glaucoma-patients","","","2014-04-17 16:14:11","2014-04-17 16:14:11","","62","http://ioptima.wpengine.com/wp-content/uploads/2014/03/CLASS-a-novel-filtration-treatment-for-glaucoma-patients.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("116","2","2014-04-17 16:27:38","2014-04-17 16:27:38","","CLASS Poster AGS_NYC_Feb 2012","","inherit","closed","open","","class-poster-ags_nyc_feb-2012","","","2014-04-17 16:27:38","2014-04-17 16:27:38","","0","http://ioptima.wpengine.com/wp-content/uploads/2014/04/CLASS-Poster-AGS_NYC_Feb-2012.pdf","11","attachment","application/pdf","0");
INSERT INTO `wp_posts` VALUES("117","2","2014-04-17 16:30:48","2014-04-17 16:30:48","","CLASS Poster at WGC 2013 - Switzerland","","inherit","closed","open","","class-poster-at-wgc-2013-switzerland","","","2014-04-17 16:30:48","2014-04-17 16:30:48","","0","http://ioptima.wpengine.com/wp-content/uploads/2014/04/CLASS-Poster-at-WGC-2013-Switzerland.pdf","11","attachment","application/pdf","0");
INSERT INTO `wp_posts` VALUES("118","2","2014-04-17 16:31:09","2014-04-17 16:31:09","","CLASS-y Laser Treats Glaucoma - Asia","","inherit","closed","open","","class-y-laser-treats-glaucoma-asia","","","2014-04-17 16:31:09","2014-04-17 16:31:09","","0","http://ioptima.wpengine.com/wp-content/uploads/2014/04/CLASS-y-Laser-Treats-Glaucoma-Asia.pdf","11","attachment","application/pdf","0");
INSERT INTO `wp_posts` VALUES("119","2","2014-04-17 16:31:15","2014-04-17 16:31:15","","CO2 Laser-assisted Sclerectomy Surgery Part I Concept and Experimental Models_JOG_FEB2012","","inherit","closed","open","","co2-laser-assisted-sclerectomy-surgery-part-i-concept-and-experimental-models_jog_feb2012","","","2014-04-17 16:31:15","2014-04-17 16:31:15","","0","http://ioptima.wpengine.com/wp-content/uploads/2014/04/CO2-Laser-assisted-Sclerectomy-Surgery-Part-I-Concept-and-Experimental-Models_JOG_FEB2012.pdf","11","attachment","application/pdf","0");
INSERT INTO `wp_posts` VALUES("120","2","2014-04-17 16:31:21","2014-04-17 16:31:21","","CO2 Laser-assisted Sclerectomy Surgery Part II Multicenter Clinical Preliminary Study_JOG_MAR2012","","inherit","closed","open","","co2-laser-assisted-sclerectomy-surgery-part-ii-multicenter-clinical-preliminary-study_jog_mar2012","","","2014-04-17 16:31:21","2014-04-17 16:31:21","","0","http://ioptima.wpengine.com/wp-content/uploads/2014/04/CO2-Laser-assisted-Sclerectomy-Surgery-Part-II-Multicenter-Clinical-Preliminary-Study_JOG_MAR2012.pdf","11","attachment","application/pdf","0");
INSERT INTO `wp_posts` VALUES("121","2","2014-04-17 16:31:45","2014-04-17 16:31:45","","CO2 Laser-assisted Sclerectomy Surgery For Open Angle Glaucoma","","inherit","closed","open","","co2-laser-assisted-sclerectomy-surgery-2","","","2014-04-17 16:31:45","2014-04-17 16:31:45","","0","http://ioptima.wpengine.com/wp-content/uploads/2014/04/CO2-Laser-assisted-Sclerectomy-Surgery.pdf","11","attachment","application/pdf","0");
INSERT INTO `wp_posts` VALUES("122","2","2014-04-17 16:32:06","2014-04-17 16:32:06","","IOptima_Poster_Asia ICGS 2014","","inherit","closed","open","","ioptima_poster_asia-icgs-2014","","","2014-04-17 16:32:06","2014-04-17 16:32:06","","0","http://ioptima.wpengine.com/wp-content/uploads/2014/04/IOptima_Poster_Asia-ICGS-2014.pdf","11","attachment","application/pdf","0");
INSERT INTO `wp_posts` VALUES("123","2","2014-04-17 16:32:19","2014-04-17 16:32:19","","IOptima_Poster_Choka WGC 2013","","inherit","closed","open","","ioptima_poster_choka-wgc-2013","","","2014-04-17 16:32:19","2014-04-17 16:32:19","","0","http://ioptima.wpengine.com/wp-content/uploads/2014/04/IOptima_Poster_Choka-WGC-2013.pdf","11","attachment","application/pdf","0");
INSERT INTO `wp_posts` VALUES("124","2","2014-04-17 16:32:23","2014-04-17 16:32:23","","Skaat - CO2 Laser-assisted Deep Sclerectomy in Glaucoma Patients","","inherit","closed","open","","skaat-co2-laser-assisted-deep-sclerectomy-in-glaucoma-patients","","","2014-04-17 16:32:23","2014-04-17 16:32:23","","0","http://ioptima.wpengine.com/wp-content/uploads/2014/04/Skaat-CO2-Laser-assisted-Deep-Sclerectomy-in-Glaucoma-Patients.pdf","11","attachment","application/pdf","0");
INSERT INTO `wp_posts` VALUES("127","2","2014-04-17 17:05:24","2014-04-17 17:05:24","","The-Laser-&-Control-Unit","","inherit","closed","open","","the-laser-control-unit","","","2014-04-17 17:05:24","2014-04-17 17:05:24","","42","http://ioptima.wpengine.com/wp-content/uploads/2014/03/The-Laser-Control-Unit.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("128","2","2014-04-17 17:07:22","2014-04-17 17:07:22","","The-Scanner","","inherit","closed","open","","the-scanner","","","2014-04-17 17:07:22","2014-04-17 17:07:22","","42","http://ioptima.wpengine.com/wp-content/uploads/2014/03/The-Scanner.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("129","2","2014-04-17 17:15:52","2014-04-17 17:15:52","","Ablation-Patterns","","inherit","closed","open","","ablation-patterns","","","2014-04-17 17:15:52","2014-04-17 17:15:52","","0","http://ioptima.wpengine.com/wp-content/uploads/2014/04/Ablation-Patterns.jpg","11","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("130","2","2014-04-17 17:38:21","2014-04-17 17:38:21","","CLASS-principle-of-Operation","","inherit","closed","open","","class-principle-of-operation-2","","","2014-04-17 17:38:21","2014-04-17 17:38:21","","41","http://ioptima.wpengine.com/wp-content/uploads/2014/03/CLASS-principle-of-Operation.png","0","attachment","image/png","0");
INSERT INTO `wp_posts` VALUES("132","2","2014-04-23 08:23:28","2014-04-23 08:23:28","","News","","publish","closed","open","","news","","","2014-08-31 14:46:22","2014-08-31 14:46:22","","0","http://ioptima.wpengine.com/?p=132","24","nav_menu_item","","0");
INSERT INTO `wp_posts` VALUES("133","2","2014-04-23 08:23:52","2014-04-23 08:23:52","[vc_row][vc_column width=\"1/1\"][vc_column_text]<b>Please visit us at the upcoming events:</b>

&nbsp;

<b>WGC    <span style=\"color: #4883bf;\"><i>June 6-9, 2015</i></span></b>

6<sup>th</sup> World Glaucoma Congress

Hong Kong, China

<i>Booth # 13</i>

<a href=\"http://www.worldglaucoma.org/WGC/WGC2015/index.php?page=welcome\">http://www.worldglaucoma.org/WGC/WGC2015/index.php?page=welcome</a>

&nbsp;

<b>ESCRS    <span style=\"color: #4883bf;\"><i>September 5-8, 2015</i></span></b>

XXXIII Congress of the European Society of Cataract and Refractive Surgeons

Barcelona, Spain

<i>Booth # TBD</i>

<a href=\"http://escrs.org/Barcelona2015/\">http://escrs.org/Barcelona2015/</a>

&nbsp;

<b>Exhibited in past events:</b>

&nbsp;

<b>APAO    <span style=\"color: #4883bf;\"><i>April 1-4, 2015</i></span></b>

30<sup>th</sup> Asia-Pacific Academy of Ophthalmology Congress

held in conjunction with the 20<sup>th</sup> Congress of the Chinese Ophthalmological Society

Guangzhou, China

<i>Booth # 1F B-593</i>

<a href=\"http://2015.apaophth.org/\">http://2015.apaophth.org/</a>

&nbsp;

<b>MEDinISRAEL    <span style=\"color: #4883bf;\"><i>March 23-26, 2015</i></span></b>

3<sup>rd</sup> Medical Devices &amp; HIT International Conference

Tel Aviv, Israel

<i>Booth # 3A</i>

<a href=\"http://www.medinisrael2015.com/index.ehtml\">http://www.medinisrael2015.com/index.ehtml</a>

&nbsp;

<b>APGC-ISHOK    <span style=\"color: #4883bf;\"><i>September 26-28, 2014</i></span></b>

2<sup>nd</sup> Asia-Pacific Glaucoma Congress

held in conjunction with

The 10<sup>th</sup> International Symposium of Ophthalmology

Hong Kong, China

<i>Booth # G2</i>

<a href=\"http://www.apgc-isohk-2014.org\">http://www.apgc-isohk-2014.org</a>

&nbsp;

<b>ESCRS    <span style=\"color: #4883bf;\"><i>September 13-17, 2014</i></span></b>

XXXII Congress of the European Society of Cataract and Refractive Surgeons

London, United Kingdom

<i>Booth # K22</i>

<a href=\"http://www.escrs.org/London2014/default.asp\">http://www.escrs.org/London2014/default.asp</a>

&nbsp;

<b>EGS       <span style=\"color: #4883bf;\"> <i>June 7-11, 2014</i></span></b>

11<sup>th</sup> European Glaucoma Society Congress

Nice, France

<i>Booth # 28</i>

<a href=\"http://www.eugs.org/\">www.eugs.org</a>[/vc_column_text][/vc_column][/vc_row][vc_row][vc_column width=\"1/1\"][spacer height=\"50\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][/vc_column][/vc_row]","Events","","publish","closed","open","","events","","","2015-04-19 06:25:25","2015-04-19 06:25:25","","134","http://ioptima.wpengine.com/?page_id=133","3","page","","0");
INSERT INTO `wp_posts` VALUES("134","2","2014-04-23 08:24:03","2014-04-23 08:24:03","","News","","publish","closed","open","","news","","","2014-08-31 10:56:52","2014-08-31 10:56:52","","0","http://ioptima.wpengine.com/?page_id=134","6","page","","0");
INSERT INTO `wp_posts` VALUES("135","2","2014-04-23 08:24:36","2014-04-23 08:24:36"," ","","","publish","closed","open","","135","","","2014-08-31 14:46:22","2014-08-31 14:46:22","","134","http://ioptima.wpengine.com/?p=135","26","nav_menu_item","","0");
INSERT INTO `wp_posts` VALUES("137","2","2014-04-24 17:39:53","2014-04-24 17:39:53","","ioptima","","inherit","closed","open","","ioptima","","","2014-04-24 17:39:53","2014-04-24 17:39:53","","0","http://ioptima.wpengine.com/wp-content/uploads/2014/04/ioptima.jpg","11","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("138","2","2014-04-24 17:42:53","2014-04-24 17:42:53","","logo_fixed","","inherit","closed","open","","logo_fixed","","","2014-04-24 17:42:53","2014-04-24 17:42:53","","0","http://ioptima.wpengine.com/wp-content/uploads/2014/04/logo_fixed.jpg","11","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("139","2","2014-04-24 18:07:34","2014-04-24 18:07:34","[vc_row][vc_column width=\"1/1\"][vc_column_text]<b>IOPtima CO<sub>2</sub> L</b>aser<b>-A</b>ssisted<b> S</b>clerectomy<b> S</b>urgery<b> (CLASS) </b>

IOPtima Ltd. has developed the IOPtimate system, a unique, minimally invasive CO<sub>2</sub> laser-assisted system for the treatment of Glaucoma.

In utilizing the particular properties of the CO<sub>2</sub> laser, CLASS procedure thins the white part of the eye (the sclera wall) by ablating surges at the natural drainage area (the Schlemm’s Canal) without penetrating into the eye. The use of the CO<sub>2</sub> laser facilitates adequate, functional percolation of intra-ocular fluid from the eye through the remaining membrane in a simple, highly controlled and specific manner.

As infrared CO<sub>2</sub> laser radiation is absorbed and blocked by water and aqueous solutions, it is ineffective in ablating when applied over wet tissues, thus does not allow the procedure to penetrate into the eye like other invasive procedures.

Following the CLASS procedure, the remaining thin scleral layer remains intact, without penetration into the eye, and with no insertion of foreign bodies, which is known to be the source of most ophthalmic surgery complications, adverse events and side effects.[/vc_column_text][spacer height=\"23\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][vc_column_text]
<h3>Clinical Evidence and Experience of the CLASS procedure</h3>
A multi-center clinical study was performed on 111 patients in 9 global sites (Switzerland, Spain, Italy, Israel, Russia, India and Mexico). Three-year follow up data consistently demonstrate tremendous efficacy in IOP reduction as well as drastic reduction in medication intake. Data also reveals an elevated safety profile by significantly reducing the risk of intra-operative and postoperative complications.

The IOPtimate system utilized for CLASS procedure has received regulatory approvals in Europe (CE Mark), China (CFDA) approval, Israel (AMAR) and Mexico (Cofepris).

CLASS is available in major medical centers across the world and over 700 CLASS procedures have been performed to date.[/vc_column_text][spacer height=\"23\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][vc_column_text]
<h3>The Advantage of performing the CLASS procedure</h3>
[/vc_column_text][spacer height=\"23\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][vc_accordion style=\"style1\"][vc_accordion_tab title=\"Safe, minimally-invasive laser procedure\"][vc_column_text]<span style=\"color: #4883bf;\"><i>Unlike other surgical solutions, the CLASS procedure is non-penetrating and doesn’t involve foreign bodies</i></span>[/vc_column_text][/vc_accordion_tab][vc_accordion_tab title=\"Low post-operation complications rate\"][vc_column_text]<span style=\"color: #4883bf;\"><i>A clinical study  of CLASS procedure with a 3-year follow up period shows significantly reduced complication rates in comparison with other current surgical solutions</i></span>[/vc_column_text][/vc_accordion_tab][vc_accordion_tab title=\"Significant long-term reduction of IOP, stable over time\"][vc_column_text]<span style=\"color: #4883bf;\"><i>Clinical study results show over 40% reduction in IOP over the years</i></span>[/vc_column_text][/vc_accordion_tab][vc_accordion_tab title=\"One-time procedure reduces the need for medications\"][vc_column_text]<span style=\"color: #4883bf;\"><i>Clinical study results show significant reduction or elimination of medication consumption post procedure</i></span>[/vc_column_text][/vc_accordion_tab][/vc_accordion][spacer height=\"23\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][vc_column_text]
<h3>Procedure Steps</h3>
[/vc_column_text][spacer height=\"10\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][vc_column_text]Creation of scleral flap[/vc_column_text][framed_image image=\"143\" img_size=\"full\" img_link_target=\"_self\" align=\"none\"][spacer height=\"23\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][vc_column_text]Laser ablation for thinning the sclera up to exposure of the drainage area (Schlemm’s canal)[/vc_column_text][framed_image image=\"144\" img_size=\"full\" img_link_target=\"_self\" align=\"none\"][spacer height=\"23\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][vc_column_text]Laser beam stops once percolation of fluid is achieved[/vc_column_text][framed_image image=\"145\" img_size=\"full\" img_link_target=\"_self\" align=\"none\"][spacer height=\"23\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][vc_column_text]Scleral and conjunctival closure[/vc_column_text][framed_image image=\"142\" img_size=\"full\" img_link_target=\"_self\" align=\"none\"][spacer height=\"40\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][/vc_column][/vc_row]","IOPtima’s Solution","","publish","closed","open","","ioptimas-solution","","","2014-08-24 13:27:24","2014-08-24 13:27:24","","94","http://ioptima.wpengine.com/?page_id=139","4","page","","0");
INSERT INTO `wp_posts` VALUES("140","2","2014-04-24 18:08:02","2014-04-24 18:08:02"," ","","","publish","closed","open","","140","","","2014-08-31 14:46:22","2014-08-31 14:46:22","","94","http://ioptima.wpengine.com/?p=140","21","nav_menu_item","","0");
INSERT INTO `wp_posts` VALUES("142","2","2014-04-24 18:23:03","2014-04-24 18:23:03","","Procedure-Steps-4","","inherit","closed","open","","procedure-steps-4","","","2014-04-24 18:23:03","2014-04-24 18:23:03","","139","http://ioptima.wpengine.com/wp-content/uploads/2014/04/Procedure-Steps-4.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("143","2","2014-04-24 18:23:05","2014-04-24 18:23:05","","Procedure-Steps-1","","inherit","closed","open","","procedure-steps-1","","","2014-04-24 18:23:05","2014-04-24 18:23:05","","139","http://ioptima.wpengine.com/wp-content/uploads/2014/04/Procedure-Steps-1.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("144","2","2014-04-24 18:23:07","2014-04-24 18:23:07","","Procedure-Steps-2","","inherit","closed","open","","procedure-steps-2","","","2014-04-24 18:23:07","2014-04-24 18:23:07","","139","http://ioptima.wpengine.com/wp-content/uploads/2014/04/Procedure-Steps-2.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("145","2","2014-04-24 18:23:09","2014-04-24 18:23:09","","Procedure-Steps-3","","inherit","closed","open","","procedure-steps-3","","","2014-04-24 18:23:09","2014-04-24 18:23:09","","139","http://ioptima.wpengine.com/wp-content/uploads/2014/04/Procedure-Steps-3.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("147","2","2014-04-27 13:28:57","2014-04-27 13:28:57","","Shaarawy Tarek","","inherit","closed","open","","shaarawy-tarek","","","2014-04-27 13:28:57","2014-04-27 13:28:57","","63","http://ioptima.co.il/wp-content/uploads/2014/03/Shaarawy-Tarek.png","0","attachment","image/png","0");
INSERT INTO `wp_posts` VALUES("148","2","2014-04-27 13:28:59","2014-04-27 13:28:59","","Assia Ehud","","inherit","closed","open","","assia-ehud","","","2014-04-27 13:28:59","2014-04-27 13:28:59","","63","http://ioptima.co.il/wp-content/uploads/2014/03/Assia-Ehud.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("149","2","2014-04-27 13:29:03","2014-04-27 13:29:03","","Félix Gil Carrasco","","inherit","closed","open","","felix-gil-carrasco","","","2014-04-27 13:29:03","2014-04-27 13:29:03","","63","http://ioptima.co.il/wp-content/uploads/2014/03/Félix-Gil-Carrasco.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("150","2","2014-04-27 13:29:05","2014-04-27 13:29:05","","Melamed Shlomo","","inherit","closed","open","","melamed-shlomo","","","2014-04-27 13:29:05","2014-04-27 13:29:05","","63","http://ioptima.co.il/wp-content/uploads/2014/03/Melamed-Shlomo.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("151","2","2014-04-27 13:29:07","2014-04-27 13:29:07","","Mermoud Andre","","inherit","closed","open","","mermoud-andre","","","2014-04-27 13:29:07","2014-04-27 13:29:07","","63","http://ioptima.co.il/wp-content/uploads/2014/03/Mermoud-Andre.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("152","2","2014-04-27 13:29:09","2014-04-27 13:29:09","","Muñoz Gonzalo","","inherit","closed","open","","munoz-gonzalo","","","2014-04-27 13:29:09","2014-04-27 13:29:09","","63","http://ioptima.co.il/wp-content/uploads/2014/03/Muñoz-Gonzalo.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("153","2","2014-04-27 13:46:09","2014-04-27 13:46:09","","venn diagram","","inherit","closed","open","","venn-diagram-2","","","2014-04-27 13:46:09","2014-04-27 13:46:09","","43","http://ioptima.co.il/wp-content/uploads/2014/03/venn-diagram1.png","0","attachment","image/png","0");
INSERT INTO `wp_posts` VALUES("154","2","2014-04-27 13:49:58","2014-04-27 13:49:58","","Log","","inherit","closed","open","","log","","","2014-04-27 13:49:58","2014-04-27 13:49:58","","0","http://ioptima.co.il/wp-content/uploads/2014/04/Log.png","11","attachment","image/png","0");
INSERT INTO `wp_posts` VALUES("165","2","2014-05-01 08:15:18","2014-05-01 08:15:18","","Black Background big","","inherit","closed","open","","black-background-big","","","2014-05-01 08:15:18","2014-05-01 08:15:18","","0","http://ioptima.co.il/wp-content/uploads/2014/05/Black-Background-big.png","11","attachment","image/png","0");
INSERT INTO `wp_posts` VALUES("168","2","2014-05-08 08:52:48","2014-05-08 08:52:48","","IOPtima\'s solution","","inherit","closed","open","","ioptimas-solution-2","","","2014-05-08 08:52:48","2014-05-08 08:52:48","","0","http://ioptima.co.il/wp-content/uploads/2014/05/IOPtimas-solution.jpg","11","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("170","2","2014-05-08 09:17:47","2014-05-08 09:17:47","","CLASS benefits-1","","inherit","closed","open","","class-benefits-1","","","2014-05-08 09:17:47","2014-05-08 09:17:47","","0","http://ioptima.co.il/wp-content/uploads/2014/05/CLASS-benefits-1.jpg","11","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("172","2","2014-05-08 09:24:41","2014-05-08 09:24:41","","surgeon","","inherit","closed","open","","surgeon","","","2014-05-08 09:24:41","2014-05-08 09:24:41","","0","http://ioptima.co.il/wp-content/uploads/2014/05/surgeon.png","11","attachment","image/png","0");
INSERT INTO `wp_posts` VALUES("173","2","2014-05-08 12:04:29","2014-05-08 12:04:29","","surgeon1","","inherit","closed","open","","surgeon1","","","2014-05-08 12:04:29","2014-05-08 12:04:29","","0","http://ioptima.co.il/wp-content/uploads/2014/05/surgeon1.png","11","attachment","image/png","0");
INSERT INTO `wp_posts` VALUES("176","2","2014-05-08 12:12:02","2014-05-08 12:12:02","","Black Background big","","inherit","closed","open","","black-background-big-2","","","2014-05-08 12:12:02","2014-05-08 12:12:02","","0","http://ioptima.co.il/wp-content/uploads/2014/05/Black-Background-big1.png","11","attachment","image/png","0");
INSERT INTO `wp_posts` VALUES("177","2","2014-05-08 14:55:23","2014-05-08 14:55:23","","Blue Background","","inherit","closed","open","","blue-background","","","2014-05-08 14:55:23","2014-05-08 14:55:23","","0","http://ioptima.co.il/wp-content/uploads/2014/05/Blue-Background.png","11","attachment","image/png","0");
INSERT INTO `wp_posts` VALUES("180","2","2014-05-22 11:43:13","2014-05-22 11:43:13","","EyeWorld May 2014_CLASS act - Why a new CO2 laser is competing with the gold standard","","inherit","closed","open","","eyeworld-may-2014_class-act-why-a-new-co2-laser-is-competing-with-the-gold-standard","","","2014-05-22 11:43:13","2014-05-22 11:43:13","","0","http://ioptima.co.il/wp-content/uploads/2014/05/EyeWorld-May-2014_CLASS-act-Why-a-new-CO2-laser-is-competing-with-the-gold-standard.pdf","11","attachment","application/pdf","0");
INSERT INTO `wp_posts` VALUES("185","2","2014-05-26 08:31:14","2014-05-26 08:31:14","","Eurotimes - P43","","inherit","closed","open","","eurotimes-p43","","","2014-05-26 08:31:14","2014-05-26 08:31:14","","0","http://ioptima.co.il/wp-content/uploads/2014/05/Eurotimes-P43.pdf","11","attachment","application/pdf","0");
INSERT INTO `wp_posts` VALUES("193","2","2014-06-02 15:01:34","2014-06-02 15:01:34","","Eyewire Today  IOPtima ...tiMate Systems in China”","","inherit","closed","open","","eyewire-today-ioptima-timate-systems-in-china","","","2014-06-02 15:01:34","2014-06-02 15:01:34","","0","http://ioptima.co.il/wp-content/uploads/2014/06/Eyewire-Today-IOPtima-...tiMate-Systems-in-China”.pdf","11","attachment","application/pdf","0");
INSERT INTO `wp_posts` VALUES("195","2","2014-06-02 18:18:07","2014-06-02 18:18:07","","Nurit Radin – VP Marketing & Sales","","inherit","closed","open","","nurit-radin-vp-marketing-sales","","","2014-06-02 18:18:07","2014-06-02 18:18:07","","11","http://ioptima.co.il/wp-content/uploads/2014/03/Nurit-Radin-–-VP-Marketing-Sales.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("196","2","2014-06-02 18:18:08","2014-06-02 18:18:08","","Ronen Castro – CEO","","inherit","closed","open","","ronen-castro-ceo","","","2014-06-02 18:18:08","2014-06-02 18:18:08","","11","http://ioptima.co.il/wp-content/uploads/2014/03/Ronen-Castro-–-CEO.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("197","2","2014-06-02 18:18:10","2014-06-02 18:18:10","","Amnon Nahum-Sharon – COO","","inherit","closed","open","","amnon-nahum-sharon-coo","","","2014-06-02 18:18:10","2014-06-02 18:18:10","","11","http://ioptima.co.il/wp-content/uploads/2014/03/Amnon-Nahum-Sharon-–-COO.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("198","2","2014-06-02 18:18:11","2014-06-02 18:18:11","","Assaf Gur – CTO","","inherit","closed","open","","assaf-gur-cto","","","2014-06-02 18:18:11","2014-06-02 18:18:11","","11","http://ioptima.co.il/wp-content/uploads/2014/03/Assaf-Gur-–-CTO.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("199","2","2014-06-02 18:18:13","2014-06-02 18:18:13","","Itai Bar-Natan – CFO","","inherit","closed","open","","itai-bar-natan-cfo","","","2014-06-02 18:18:13","2014-06-02 18:18:13","","11","http://ioptima.co.il/wp-content/uploads/2014/03/Itai-Bar-Natan-–-CFO.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("200","2","2014-06-09 12:34:46","2014-06-09 12:34:46","","Ophthalmology time US - CO2 laser surgery a new option for glaucoma","","inherit","closed","open","","ophthalmology-time-us-co2-laser-surgery-a-new-option-for-glaucoma","","","2014-06-09 12:34:46","2014-06-09 12:34:46","","0","http://ioptima.co.il/wp-content/uploads/2014/06/Ophthalmology-time-US-CO2-laser-surgery-a-new-option-for-glaucoma.pdf","11","attachment","application/pdf","0");
INSERT INTO `wp_posts` VALUES("201","2","2014-06-09 12:34:59","2014-06-09 12:34:59","","Ophthalmology time EU - CLASS_May14_pdf (Assia and Melamed)","","inherit","closed","open","","ophthalmology-time-eu-class_may14_pdf-assia-and-melamed","","","2014-06-09 12:34:59","2014-06-09 12:34:59","","0","http://ioptima.co.il/wp-content/uploads/2014/06/Ophthalmology-time-EU-CLASS_May14_pdf-Assia-and-Melamed.pdf","11","attachment","application/pdf","0");
INSERT INTO `wp_posts` VALUES("205","2","2014-06-09 13:10:16","2014-06-09 13:10:16","","Ablation-Patterns_1","","inherit","closed","open","","ablation-patterns_1","","","2014-06-09 13:10:16","2014-06-09 13:10:16","","0","http://ioptima.co.il/wp-content/uploads/2014/06/Ablation-Patterns_1.jpg","11","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("208","3","2014-06-16 07:10:17","2014-06-16 07:10:17","","Ronen Castro – CEO 2","","inherit","closed","open","","ronen-castro-ceo-2","","","2014-06-16 07:10:17","2014-06-16 07:10:17","","11","http://ioptima.co.il/wp-content/uploads/2014/03/Ronen-Castro-–-CEO-2.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("211","2","2014-06-23 06:58:25","2014-06-23 06:58:25","","Maital","","inherit","closed","open","","maital","","","2014-06-23 06:58:25","2014-06-23 06:58:25","","0","http://ioptima.co.il/wp-content/uploads/2014/06/Maital.jpg","11","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("212","2","2014-06-23 12:50:08","2014-06-23 12:50:08","","Maital Ben Hur – Clinical Manager (2)","","inherit","closed","open","","maital-ben-hur-clinical-manager-2","","","2014-06-23 12:50:08","2014-06-23 12:50:08","","11","http://ioptima.co.il/wp-content/uploads/2014/03/Maital-Ben-Hur-–-Clinical-Manager-2.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("213","2","2014-06-23 12:52:44","2014-06-23 12:52:44","","Maital Ben Hur – Clinical Manager (3)","","inherit","closed","open","","maital-ben-hur-clinical-manager-3","","","2014-06-23 12:52:44","2014-06-23 12:52:44","","11","http://ioptima.co.il/wp-content/uploads/2014/03/Maital-Ben-Hur-–-Clinical-Manager-3.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("217","2","2014-07-01 14:43:53","2014-07-01 14:43:53","","P254 Mauricio Turati","","inherit","closed","open","","p254-mauricio-turati-2","","","2014-07-01 14:43:53","2014-07-01 14:43:53","","62","http://ioptima.co.il/wp-content/uploads/2014/03/P254-Mauricio-Turati.pdf","0","attachment","application/pdf","0");
INSERT INTO `wp_posts` VALUES("218","2","2014-07-02 06:02:34","2014-07-02 06:02:34","","P254 Mauricio Turati-page-001","","inherit","closed","open","","p254-mauricio-turati-page-001","","","2014-07-02 06:02:34","2014-07-02 06:02:34","","0","http://ioptima.co.il/wp-content/uploads/2014/07/P254-Mauricio-Turati-page-001.jpg","11","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("219","2","2014-07-02 06:04:18","2014-07-02 06:04:18","","P254 Mauricio Turati-page-001","","inherit","closed","open","","p254-mauricio-turati-page-001-2","","","2014-07-02 06:04:18","2014-07-02 06:04:18","","62","http://ioptima.co.il/wp-content/uploads/2014/03/P254-Mauricio-Turati-page-001.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("220","2","2014-07-02 07:00:04","2014-07-02 07:00:04","","EyeWorld-May-2014_CLASS-act-Why-a-new-CO2-laser-is-competing-with-the-gold-standard-page-001","","inherit","closed","open","","eyeworld-may-2014_class-act-why-a-new-co2-laser-is-competing-with-the-gold-standard-page-001","","","2014-07-02 07:00:04","2014-07-02 07:00:04","","62","http://ioptima.co.il/wp-content/uploads/2014/03/EyeWorld-May-2014_CLASS-act-Why-a-new-CO2-laser-is-competing-with-the-gold-standard-page-001.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("221","2","2014-07-02 07:07:07","2014-07-02 07:07:07","","CLASS-y-Laser-Treats-Glaucoma-Asia-page-001","","inherit","closed","open","","class-y-laser-treats-glaucoma-asia-page-001","","","2014-07-02 07:07:07","2014-07-02 07:07:07","","62","http://ioptima.co.il/wp-content/uploads/2014/03/CLASS-y-Laser-Treats-Glaucoma-Asia-page-001.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("222","2","2014-07-02 07:43:51","2014-07-02 07:43:51","","Ophthalmology time EU - CLASS_May14_pdf (Assia and Melamed)-page-001","","inherit","closed","open","","ophthalmology-time-eu-class_may14_pdf-assia-and-melamed-page-001","","","2014-07-02 07:43:51","2014-07-02 07:43:51","","62","http://ioptima.co.il/wp-content/uploads/2014/03/Ophthalmology-time-EU-CLASS_May14_pdf-Assia-and-Melamed-page-001.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("223","2","2014-07-02 07:45:18","2014-07-02 07:45:18","","Ophthalmology time EU - CLASS_May14_pdf (Assia and Melamed)","","inherit","closed","open","","ophthalmology-time-eu-class_may14_pdf-assia-and-melamed-2","","","2014-07-02 07:45:18","2014-07-02 07:45:18","","0","http://ioptima.co.il/wp-content/uploads/2014/07/Ophthalmology-time-EU-CLASS_May14_pdf-Assia-and-Melamed.pdf","11","attachment","application/pdf","0");
INSERT INTO `wp_posts` VALUES("224","2","2014-07-02 09:10:39","2014-07-02 09:10:39","","Ophthalmology time US - CO2 laser surgery a new option for glaucoma-page-001","","inherit","closed","open","","ophthalmology-time-us-co2-laser-surgery-a-new-option-for-glaucoma-page-001","","","2014-07-02 09:10:39","2014-07-02 09:10:39","","62","http://ioptima.co.il/wp-content/uploads/2014/03/Ophthalmology-time-US-CO2-laser-surgery-a-new-option-for-glaucoma-page-001.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("225","2","2014-07-02 09:11:35","2014-07-02 09:11:35","","Ophthalmology time US - CO2 laser surgery a new option for glaucoma","","inherit","closed","open","","ophthalmology-time-us-co2-laser-surgery-a-new-option-for-glaucoma-2","","","2014-07-02 09:11:35","2014-07-02 09:11:35","","0","http://ioptima.co.il/wp-content/uploads/2014/07/Ophthalmology-time-US-CO2-laser-surgery-a-new-option-for-glaucoma.pdf","11","attachment","application/pdf","0");
INSERT INTO `wp_posts` VALUES("226","2","2014-07-02 09:17:04","2014-07-02 09:17:04","","eurotimes industy brief, may 2014, p 43-page-001","","inherit","closed","open","","eurotimes-industy-brief-may-2014-p-43-page-001","","","2014-07-02 09:17:04","2014-07-02 09:17:04","","62","http://ioptima.co.il/wp-content/uploads/2014/03/eurotimes-industy-brief-may-2014-p-43-page-001.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("227","2","2014-07-02 09:17:38","2014-07-02 09:17:38","","eurotimes industy brief, may 2014, p 43","","inherit","closed","open","","eurotimes-industy-brief-may-2014-p-43","","","2014-07-02 09:17:38","2014-07-02 09:17:38","","0","http://ioptima.co.il/wp-content/uploads/2014/07/eurotimes-industy-brief-may-2014-p-43.pdf","11","attachment","application/pdf","0");
INSERT INTO `wp_posts` VALUES("228","2","2014-07-02 12:45:43","2014-07-02 12:45:43","","Ophthalmology time US - CO2 laser surgery a new option for glaucoma","","inherit","closed","open","","ophthalmology-time-us-co2-laser-surgery-a-new-option-for-glaucoma-3","","","2014-07-02 12:45:43","2014-07-02 12:45:43","","0","http://ioptima.co.il/wp-content/uploads/2014/07/Ophthalmology-time-US-CO2-laser-surgery-a-new-option-for-glaucoma1.pdf","11","attachment","application/pdf","0");
INSERT INTO `wp_posts` VALUES("243","2","2014-07-15 14:30:42","2014-07-15 14:30:42","[vc_row][vc_column width=\"1/4\"][/vc_column][vc_column width=\"3/4\"][spacer height=\"20\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][vc_column_text]Press the link to get access to downloadable materials[/vc_column_text][spacer height=\"20\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][vc_column_text]<a title=\"Downloads\" href=\"http://ioptima.co.il/login-3/downloads-2/\">Downlaods</a>[/vc_column_text][/vc_column][/vc_row][vc_row][vc_column][spacer height=\"20\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][/vc_column][/vc_row][vc_row][vc_column][vc_column_text][/vc_column][/vc_row]","Login","","publish","closed","open","dis@iop","login-3","","","2014-11-11 12:57:28","2014-11-11 12:57:28","","0","http://ioptima.co.il/?page_id=243","8","page","","0");
INSERT INTO `wp_posts` VALUES("247","2","2014-07-15 14:32:24","2014-07-15 14:32:24"," ","","","publish","closed","open","","247","","","2014-08-31 14:46:22","2014-08-31 14:46:22","","0","http://ioptima.co.il/?p=247","23","nav_menu_item","","0");
INSERT INTO `wp_posts` VALUES("258","2","2014-07-15 18:27:04","2014-07-15 18:27:04","[vc_row][vc_column][spacer height=\"20\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][vc_column_text]<a title=\"IOPtima Eye Anatomy background\" href=\"http://ioptima.co.il/wp-content/uploads/2014/07/IOPtima-Eye-Anatomy-background.zip\">IOPtima-Eye-Anatomy-background.zip</a>[/vc_column_text][spacer height=\"20\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][vc_column_text]<a title=\"IOPtima Glaucoma background\" href=\"http://ioptima.co.il/wp-content/uploads/2014/07/IOPtima-Glaucoma-background.zip\">IOPtima Glaucoma background.zip</a>[/vc_column_text][spacer height=\"20\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][vc_column_text]<a title=\"IOPtima Treatment Options\" href=\"http://ioptima.co.il/wp-content/uploads/2014/07/IOPtima-Treatment-Options.zip\">IOPtima Treatment Options.zip</a>[/vc_column_text][spacer height=\"20\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][/vc_column][/vc_row]","Background Materials","","publish","closed","open","","xxx","","","2014-08-19 09:23:00","2014-08-19 09:23:00","","272","http://ioptima.co.il/?page_id=258","3","page","","0");
INSERT INTO `wp_posts` VALUES("260","2","2014-07-15 18:29:38","2014-07-15 18:29:38","[vc_row][vc_column][spacer height=\"20\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][vc_column_text]<a title=\"CLASS - Product Introduction &amp; Clinical\" href=\"https://www.amazon.com/clouddrive/share/kQ27R16IPmdgJv297775-tCAHbG4c3T1HCgP1_Zv-1g\">CLASS - Product Introduction &amp; Clinical.zip</a>
(Download via Amazon Cloud Drive)[/vc_column_text][spacer height=\"20\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][/vc_column][/vc_row]","Product ","","publish","closed","open","","general","","","2014-11-19 08:47:18","2014-11-19 08:47:18","","272","http://ioptima.co.il/?page_id=260","4","page","","0");
INSERT INTO `wp_posts` VALUES("262","2","2014-07-15 18:31:22","2014-07-15 18:31:22","[vc_row][vc_column][spacer height=\"20\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][vc_column_text]<a title=\"CLASS Marketing Introduction\" href=\"http://ioptima.co.il/wp-content/uploads/2014/11/CLASS-Marketing-introduction.zip\">CLASS Marketing Introduction.zip</a>[/vc_column_text][spacer height=\"20\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][/vc_column][/vc_row]","Marketing","","publish","closed","open","","marketing","","","2014-11-11 13:18:16","2014-11-11 13:18:16","","272","http://ioptima.co.il/?page_id=262","15","page","","0");
INSERT INTO `wp_posts` VALUES("263","2","2014-07-15 18:37:08","2014-07-15 18:37:08","[vc_row][vc_column][spacer height=\"20\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][vc_column_text]<a title=\"The Procedure and Post Operative Management\" href=\"https://www.amazon.com/clouddrive/share/X6vOZbBwVeLxJdvkUA-jRm2C_Jgfrsv1R0vWmnpgWIU\">The Procedure and Post Operative Management.zip</a>
(Download via Amazon Cloud Drive)[/vc_column_text][spacer height=\"20\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][vc_column_text]<a title=\"IOPtima Competative Analysis.zip\" href=\"http://ioptima.co.il/wp-content/uploads/2014/07/IOPtima-Competative-Analysis.zip\">IOPtima Competative Analysis.zip</a>[/vc_column_text][spacer height=\"20\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][/vc_column][/vc_row]","Clinical","","publish","closed","open","","clinical","","","2014-11-19 09:51:54","2014-11-19 09:51:54","","272","http://ioptima.co.il/?page_id=263","10","page","","0");
INSERT INTO `wp_posts` VALUES("264","2","2014-07-15 18:37:40","2014-07-15 18:37:40","[vc_row][vc_column width=\"1/1\"][spacer height=\"20\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][vc_column_text]<a title=\"IOPtima Part I - Technical\" href=\"http://ioptima.co.il/wp-content/uploads/2015/03/IOP-35-002-07-IOPtima-OT-135P2-ASS-35-102-TP-part-I-technical2.ppt\">IOPtima Part I - Technical.ppt</a>[/vc_column_text][/vc_column][/vc_row][vc_row][vc_column width=\"1/1\"][spacer height=\"20\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][vc_column_text]<a title=\"IOPtima Part II - Daily Testing\" href=\"http://ioptima.co.il/wp-content/uploads/2015/03/IOP-35-006-01-IOPtima-OT-135P2-ASS-35-102-TP-part-II-Daily-Testing.ppt\">IOPtima Part II - Daily Testing.ppt</a>[/vc_column_text][/vc_column][/vc_row][vc_row][vc_column width=\"1/1\"][spacer height=\"20\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][vc_column_text]<a title=\"IOPtima Part III - The Procedure\" href=\"http://ioptima.co.il/wp-content/uploads/2015/03/IOP-35-00802-IOPtima-OT-135P2-ASS-35-102-TP-part-III-The-Procedure.ppt\">IOPtima Part III - The Procedure.ppt</a>[/vc_column_text][/vc_column][/vc_row][vc_row][vc_column width=\"1/1\"][spacer height=\"20\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][vc_column_text]<a title=\"IOPtima - Troubleshooting\" href=\"http://ioptima.co.il/wp-content/uploads/2014/07/IOPtima-Troubleshooting.zip\">IOPtima - Troubleshooting.zip</a>[/vc_column_text][/vc_column][/vc_row][vc_row][vc_column width=\"1/1\"][spacer height=\"20\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][vc_column_text]<a title=\"IOPtima - New Site Qualification\" href=\"http://ioptima.co.il/wp-content/uploads/2014/07/IOPtima-New-Site-Qualification.zip\">IOPtima - New Site Qualification.zip</a>[/vc_column_text][/vc_column][/vc_row][vc_row][vc_column width=\"1/1\"][spacer height=\"20\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][vc_column_text]<a title=\"IOPtima - Pattern Positioning Training\" href=\"http://ioptima.co.il/wp-content/uploads/2014/11/IOPtima-Pattern-Positioning-Training.zip\">IOPtima - Pattern Positioning Training.zip</a>[/vc_column_text][spacer height=\"20\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][/vc_column][/vc_row]","Technical","","publish","closed","open","","technical","","","2015-03-11 13:07:10","2015-03-11 13:07:10","","272","http://ioptima.co.il/?page_id=264","16","page","","0");
INSERT INTO `wp_posts` VALUES("265","2","2014-07-15 18:38:30","2014-07-15 18:38:30","[vc_row][vc_column width=\"1/1\"][vc_column_text]
<h6>Brochures:</h6>
[/vc_column_text][spacer height=\"20\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][vc_column_text]<a title=\"New Brochure - CLASS by IOPtima (for print)\" href=\"http://ioptima.co.il/wp-content/uploads/2014/08/IOPtima-Brochure-2014.pdf\">New Brochure - CLASS by IOPtima (for print).pdf</a>[/vc_column_text][spacer height=\"20\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][/vc_column][/vc_row][vc_row][vc_column width=\"1/1\"][vc_column_text]
<h6>Marketing video (for exhibitions):</h6>
[/vc_column_text][spacer height=\"20\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][vc_column_text]<a title=\"Video - CLASS by IOPtima\" href=\"https://www.amazon.com/clouddrive/share?s=jjViH0iYRiUqqaFOLjVJSE\">Video - CLASS by IOPtima.mov</a>
(Download via Amazon Cloud Drive)[/vc_column_text][spacer height=\"20\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][vc_column_text]<a title=\"Video - CLASS by IOPtima\" href=\"https://www.amazon.com/clouddrive/share?s=n-aFNifdQ9osqkDS8MMEzg\">Video - CLASS by IOPtima.mpg</a>
(Download via Amazon Cloud Drive)[/vc_column_text][spacer height=\"20\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][vc_column_text]<a title=\"Video - CLASS by IOPtima\" href=\"https://www.amazon.com/clouddrive/share?s=V0J0aHveSJAgDdJgSNzQnE\">Video - CLASS by IOPtima.wmv</a>
(Download via Amazon Cloud Drive)[/vc_column_text][spacer height=\"20\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][/vc_column][/vc_row]","Miscellaneous","","publish","closed","open","","miscellaneous","","","2015-02-09 07:35:37","2015-02-09 07:35:37","","272","http://ioptima.co.il/?page_id=265","17","page","","0");
INSERT INTO `wp_posts` VALUES("272","2","2014-07-15 19:19:11","2014-07-15 19:19:11","<p style=\"color: #444444;\">[vc_row][vc_column][spacer height=\"40\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][vc_column_text]The directories on your left consist of product and procedure presentations as well as miscellaneous materials for your download.[/vc_column_text][spacer height=\"40\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][vc_column_text]Note: The presentations are packed in folders and compressed as *.zip folders. After downloading the *.zip folder, please extract the folder and choose the *.ppt file in the folder to start the presentation.[/vc_column_text][spacer height=\"40\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][/vc_column][/vc_row]</p>
&nbsp;","Downloads","","publish","closed","open","","downloads-2","","","2014-08-19 09:15:43","2014-08-19 09:15:43","","243","http://ioptima.co.il/?page_id=272","10","page","","0");
INSERT INTO `wp_posts` VALUES("275","2","2014-07-16 05:55:27","2014-07-16 05:55:27","","IOPtima Eye Anatomy background","","inherit","closed","open","","ioptima-eye-anatomy-background","","","2014-07-16 05:55:27","2014-07-16 05:55:27","","0","http://ioptima.co.il/wp-content/uploads/2014/07/IOPtima-Eye-Anatomy-background.zip","0","attachment","application/zip","0");
INSERT INTO `wp_posts` VALUES("276","2","2014-07-16 05:55:49","2014-07-16 05:55:49","","IOPtima Glaucoma background","","inherit","closed","open","","ioptima-glaucoma-background","","","2014-07-16 05:55:49","2014-07-16 05:55:49","","0","http://ioptima.co.il/wp-content/uploads/2014/07/IOPtima-Glaucoma-background.zip","0","attachment","application/zip","0");
INSERT INTO `wp_posts` VALUES("277","2","2014-07-16 05:57:05","2014-07-16 05:57:05","","IOPtima Treatment Options","","inherit","closed","open","","ioptima-treatment-options","","","2014-07-16 05:57:05","2014-07-16 05:57:05","","0","http://ioptima.co.il/wp-content/uploads/2014/07/IOPtima-Treatment-Options.zip","0","attachment","application/zip","0");
INSERT INTO `wp_posts` VALUES("278","2","2014-07-16 05:58:50","2014-07-16 05:58:50","","IOPtima Competative Analysis","","inherit","closed","open","","ioptima-competative-analysis","","","2014-07-16 05:58:50","2014-07-16 05:58:50","","0","http://ioptima.co.il/wp-content/uploads/2014/07/IOPtima-Competative-Analysis.zip","0","attachment","application/zip","0");
INSERT INTO `wp_posts` VALUES("281","2","2014-07-16 06:34:56","2014-07-16 06:34:56","","Brochure - CLASS by IOPtima (for print)","","inherit","closed","open","","brochure-class-by-ioptima-for-print","","","2014-07-16 06:34:56","2014-07-16 06:34:56","","0","http://ioptima.co.il/wp-content/uploads/2014/07/Brochure-CLASS-by-IOPtima-for-print.pdf","0","attachment","application/pdf","0");
INSERT INTO `wp_posts` VALUES("282","2","2014-07-16 06:35:50","2014-07-16 06:35:50","","IOPtima - New Site Qualification","","inherit","closed","open","","ioptima-new-site-qualification","","","2014-07-16 06:35:50","2014-07-16 06:35:50","","0","http://ioptima.co.il/wp-content/uploads/2014/07/IOPtima-New-Site-Qualification.zip","0","attachment","application/zip","0");
INSERT INTO `wp_posts` VALUES("283","2","2014-07-16 06:36:16","2014-07-16 06:36:16","","IOPtima - Troubleshooting","","inherit","closed","open","","ioptima-troubleshooting","","","2014-07-16 06:36:16","2014-07-16 06:36:16","","0","http://ioptima.co.il/wp-content/uploads/2014/07/IOPtima-Troubleshooting.zip","0","attachment","application/zip","0");
INSERT INTO `wp_posts` VALUES("287","2","2014-07-16 06:38:47","2014-07-16 06:38:47","","CLASS Marketing Introduction","","inherit","closed","open","","class-marketing-introduction","","","2014-07-16 06:38:47","2014-07-16 06:38:47","","0","http://ioptima.co.il/wp-content/uploads/2014/07/CLASS-Marketing-Introduction.zip","0","attachment","application/zip","0");
INSERT INTO `wp_posts` VALUES("301","2","2014-07-28 18:09:59","2014-07-28 18:09:59","","CLASS procedure offers alternative treatment for glaucoma _ Ocular Surgery News","","inherit","closed","open","","class-procedure-offers-alternative-treatment-for-glaucoma-_-ocular-surgery-news","","","2014-07-28 18:09:59","2014-07-28 18:09:59","","0","http://ioptima.co.il/wp-content/uploads/2014/07/CLASS-procedure-offers-alternative-treatment-for-glaucoma-_-Ocular-Surgery-News.pdf","0","attachment","application/pdf","0");
INSERT INTO `wp_posts` VALUES("303","2","2014-07-28 18:31:34","2014-07-28 18:31:34","","CLASS procedure offers alternative treatment for glaucoma _ Ocular Surgery News-page-001","","inherit","closed","open","","class-procedure-offers-alternative-treatment-for-glaucoma-_-ocular-surgery-news-page-001","","","2014-07-28 18:31:34","2014-07-28 18:31:34","","0","http://ioptima.co.il/wp-content/uploads/2014/07/CLASS-procedure-offers-alternative-treatment-for-glaucoma-_-Ocular-Surgery-News-page-001.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("325","2","2014-08-05 11:45:00","2014-08-05 11:45:00","","Ocular Surgery New EU Edition July/August 2014 - Cover","","inherit","closed","open","","353984-julyaugust-201_selected-pages-page-001","","","2014-08-05 11:45:00","2014-08-05 11:45:00","","0","http://ioptima.co.il/wp-content/uploads/2014/08/353984-JulyAugust-201_selected-pages-page-001.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("326","2","2014-08-05 11:46:55","2014-08-05 11:46:55","","OSN Europe_july august 14_Melamed_CLASS","","inherit","closed","open","","osn-europe_july-august-14_melamed_class","","","2014-08-05 11:46:55","2014-08-05 11:46:55","","0","http://ioptima.co.il/wp-content/uploads/2014/08/OSN-Europe_july-august-14_Melamed_CLASS.pdf","0","attachment","application/pdf","0");
INSERT INTO `wp_posts` VALUES("329","2","2014-08-05 12:27:15","2014-08-05 12:27:15","","Eran Kaplan 2","","inherit","closed","open","","eran-kaplan-2","","","2014-08-05 12:27:15","2014-08-05 12:27:15","","0","http://ioptima.co.il/wp-content/uploads/2014/08/Eran-Kaplan-2.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("357","2","2014-08-21 13:54:18","2014-08-21 13:54:18","","CLASS logo wo background","","inherit","closed","open","","class-logo-wo-background","","","2014-08-21 13:54:18","2014-08-21 13:54:18","","0","http://ioptima.co.il/wp-content/uploads/2014/08/CLASS-logo-wo-background.png","0","attachment","image/png","0");
INSERT INTO `wp_posts` VALUES("358","2","2014-08-21 13:54:22","2014-08-21 13:54:22","","CLASS logo","","inherit","closed","open","","class-logo","","","2014-08-21 13:54:22","2014-08-21 13:54:22","","0","http://ioptima.co.il/wp-content/uploads/2014/08/CLASS-logo.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("359","2","2014-08-21 14:03:06","2014-08-21 14:03:06","","IOPtima Brochure 2014","","inherit","closed","open","","ioptima-brochure-2014","","","2014-08-21 14:03:06","2014-08-21 14:03:06","","0","http://ioptima.co.il/wp-content/uploads/2014/08/IOPtima-Brochure-2014.pdf","0","attachment","application/pdf","0");
INSERT INTO `wp_posts` VALUES("361","2","2014-08-24 06:18:53","2014-08-24 06:18:53","","OSN AP-JulyAugust 14_Melamed CLASS-page-002","","inherit","closed","open","","osn-ap-julyaugust-14_melamed-class-page-002","","","2014-08-24 06:18:53","2014-08-24 06:18:53","","0","http://ioptima.co.il/wp-content/uploads/2014/08/OSN-AP-JulyAugust-14_Melamed-CLASS-page-002.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("362","2","2014-08-24 06:19:02","2014-08-24 06:19:02","","OSN AP-JulyAugust 14_Melamed CLASS","","inherit","closed","open","","osn-ap-julyaugust-14_melamed-class","","","2014-08-24 06:19:02","2014-08-24 06:19:02","","0","http://ioptima.co.il/wp-content/uploads/2014/08/OSN-AP-JulyAugust-14_Melamed-CLASS.pdf","0","attachment","application/pdf","0");
INSERT INTO `wp_posts` VALUES("364","2","2014-08-24 13:33:24","2014-08-24 13:33:24","[vc_row][vc_column width=\"1/1\"][vc_column_text]
<p style=\"text-align: justify;\">Many glaucoma patients are confronted with dissatisfaction of the current treatment available in the field. Application of eye drops is not always an easy task for the patient and inappropriate use eventually results in a limited compliance. Nevertheless, application of eye drops in the long term is proven ineffective and thus costly. On the surgical spectrum, though penetrative surgeries are effective in the long run they bare a high post-operation complication rate.</p>
<p style=\"text-align: justify;\">If you are diagnosed with primary open angle glaucoma (<strong>POAG</strong>) or pseudo exfoliative glaucoma (<strong>PEXG</strong>), and you would like to have your level of medications dropped, then you are a candidate for undergoing a CLASS procedure.</p>
<p style=\"text-align: justify;\"><strong><i style=\"color: #0a0a0a;\">“</i><i style=\"color: #0a0a0a;\">IOPtima’s CLASS procedure has true advantages over the Trabeculectomy surgery as it offers an excellent safety profile with an ease of use. It can lower pressure into the lower teens and reduce the patient’s reliance on glaucoma medications without subjecting the eye to the risks of Trabeculectomy.”</i></strong></p>
<p style=\"text-align: justify;\">The CLASS procedure is also suitable for patients with cataract and can be combined with cataract surgeries.</p>
<p style=\"text-align: justify;\">Please consult you ophthalmologist with the possibility of undergoing a CLASS procedure or combined cataract surgery.</p>
[/vc_column_text][spacer height=\"100\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][/vc_column][/vc_row][vc_row][vc_column][vc_column_text]

<i style=\"color: #0a0a0a; font-family: Raleway, sans-serif; font-size: 15px; line-height: 24px;\"> </i>[/vc_column_text][/vc_column][/vc_row]","Am I a CLASS Candidate? ","","publish","closed","open","","class-candidate","","","2014-08-24 14:01:39","2014-08-24 14:01:39","","94","http://ioptima.co.il/?page_id=364","5","page","","0");
INSERT INTO `wp_posts` VALUES("368","2","2014-08-24 13:50:25","2014-08-24 13:50:25"," ","","","publish","closed","open","","368","","","2014-08-31 14:46:22","2014-08-31 14:46:22","","94","http://ioptima.co.il/?p=368","22","nav_menu_item","","0");
INSERT INTO `wp_posts` VALUES("381","2","2014-08-31 14:28:18","2014-08-31 14:28:18"," ","","","publish","closed","open","","381","","","2014-08-31 14:46:22","2014-08-31 14:46:22","","0","http://ioptima.co.il/?p=381","1","nav_menu_item","","0");
INSERT INTO `wp_posts` VALUES("385","2","2014-09-21 06:36:23","2014-09-21 06:36:23","","AOC_CLASS_9.2014_Noecker_Robin","","inherit","closed","open","","aoc_class_9-2014_noecker_robin","","","2014-09-21 06:36:23","2014-09-21 06:36:23","","0","http://ioptima.co.il/wp-content/uploads/2014/09/AOC_CLASS_9.2014_Noecker_Robin.pdf","0","attachment","application/pdf","0");
INSERT INTO `wp_posts` VALUES("386","2","2014-09-21 06:36:24","2014-09-21 06:36:24","","OSN_CLASS_Venkatesh_9.17.14","","inherit","closed","open","","osn_class_venkatesh_9-17-14","","","2014-09-21 06:36:24","2014-09-21 06:36:24","","0","http://ioptima.co.il/wp-content/uploads/2014/09/OSN_CLASS_Venkatesh_9.17.14.pdf","0","attachment","application/pdf","0");
INSERT INTO `wp_posts` VALUES("387","2","2014-09-21 06:38:01","2014-09-21 06:38:01","","OSN_CLASS_Venkatesh_9.17.14-page-001","","inherit","closed","open","","osn_class_venkatesh_9-17-14-page-001","","","2014-09-21 06:38:01","2014-09-21 06:38:01","","0","http://ioptima.co.il/wp-content/uploads/2014/09/OSN_CLASS_Venkatesh_9.17.14-page-001.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("388","2","2014-09-21 06:39:53","2014-09-21 06:39:53","","AOC_CLASS_9.2014_Noecker_Robin-page-001","","inherit","closed","open","","aoc_class_9-2014_noecker_robin-page-001","","","2014-09-21 06:39:53","2014-09-21 06:39:53","","0","http://ioptima.co.il/wp-content/uploads/2014/09/AOC_CLASS_9.2014_Noecker_Robin-page-001.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("391","2","2014-09-23 10:57:14","2014-09-23 10:57:14","","OSN_LA_CLASS SeptOct2014_Turati","","inherit","closed","open","","osn_la_class-septoct2014_turati","","","2014-09-23 10:57:14","2014-09-23 10:57:14","","0","http://ioptima.co.il/wp-content/uploads/2014/09/OSN_LA_CLASS-SeptOct2014_Turati.pdf","0","attachment","application/pdf","0");
INSERT INTO `wp_posts` VALUES("393","2","2014-09-23 11:04:57","2014-09-23 11:04:57","","OSN_LA_CLASS SeptOct2014_Turati-page-001","","inherit","closed","open","","osn_la_class-septoct2014_turati-page-001","","","2014-09-23 11:04:57","2014-09-23 11:04:57","","0","http://ioptima.co.il/wp-content/uploads/2014/09/OSN_LA_CLASS-SeptOct2014_Turati-page-001.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("401","2","2014-10-30 09:18:38","2014-10-30 09:18:38","","Certificates","","inherit","closed","open","","certificates","","","2014-10-30 09:18:38","2014-10-30 09:18:38","","0","http://ioptima.co.il/wp-content/uploads/2014/10/Certificates.bmp","0","attachment","image/bmp","0");
INSERT INTO `wp_posts` VALUES("403","2","2014-10-30 15:01:22","2014-10-30 15:01:22","","MERMOID","","inherit","closed","open","","mermoid","","","2014-10-30 15:01:22","2014-10-30 15:01:22","","0","http://ioptima.co.il/wp-content/uploads/2014/10/MERMOID.png","0","attachment","image/png","0");
INSERT INTO `wp_posts` VALUES("404","2","2014-10-30 15:01:29","2014-10-30 15:01:29","","doctoruna-gonzalo-munoz-5133109b687f1","","inherit","closed","open","","doctoruna-gonzalo-munoz-5133109b687f1","","","2014-10-30 15:01:29","2014-10-30 15:01:29","","0","http://ioptima.co.il/wp-content/uploads/2014/10/doctoruna-gonzalo-munoz-5133109b687f1.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("405","2","2014-10-30 15:01:31","2014-10-30 15:01:31","","Shaarawy","","inherit","closed","open","","shaarawy","","","2014-10-30 15:01:31","2014-10-30 15:01:31","","0","http://ioptima.co.il/wp-content/uploads/2014/10/Shaarawy.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("406","2","2014-10-30 15:01:32","2014-10-30 15:01:32","","felix-gil-carrasco1","","inherit","closed","open","","felix-gil-carrasco1","","","2014-10-30 15:01:32","2014-10-30 15:01:32","","0","http://ioptima.co.il/wp-content/uploads/2014/10/felix-gil-carrasco1.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("407","2","2014-10-30 15:01:33","2014-10-30 15:01:33","","Assia","","inherit","closed","open","","assia","","","2014-10-30 15:01:33","2014-10-30 15:01:33","","0","http://ioptima.co.il/wp-content/uploads/2014/10/Assia.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("414","2","2014-11-05 15:49:01","2014-11-05 15:49:01","","Glaucoma Effect Rich","","inherit","closed","open","","glaucoma-effect-rich","","","2014-11-05 15:49:01","2014-11-05 15:49:01","","0","http://ioptima.co.il/wp-content/uploads/2014/11/Glaucoma-Effect-Rich.png","0","attachment","image/png","0");
INSERT INTO `wp_posts` VALUES("423","2","2014-11-11 13:17:56","2014-11-11 13:17:56","","CLASS Marketing introduction","","inherit","closed","open","","class-marketing-introduction-2","","","2014-11-11 13:17:56","2014-11-11 13:17:56","","0","http://ioptima.co.il/wp-content/uploads/2014/11/CLASS-Marketing-introduction.zip","0","attachment","application/zip","0");
INSERT INTO `wp_posts` VALUES("428","2","2014-11-27 09:59:33","2014-11-27 09:59:33","","CRST Europe Nov Dec 14_CLASS_Venkatesh-page-001","","inherit","closed","open","","crst-europe-nov-dec-14_class_venkatesh-page-001","","","2014-11-27 09:59:33","2014-11-27 09:59:33","","0","http://ioptima.co.il/wp-content/uploads/2014/11/CRST-Europe-Nov-Dec-14_CLASS_Venkatesh-page-001.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("429","2","2014-11-27 09:59:37","2014-11-27 09:59:37","","GT NovDec 14.CLASS.Robin-page-001","","inherit","closed","open","","gt-novdec-14-class-robin-page-001","","","2014-11-27 09:59:37","2014-11-27 09:59:37","","0","http://ioptima.co.il/wp-content/uploads/2014/11/GT-NovDec-14.CLASS.Robin-page-001.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("430","2","2014-11-27 09:59:50","2014-11-27 09:59:50","","GT NovDec 14.CLASS.Robin","","inherit","closed","open","","gt-novdec-14-class-robin","","","2014-11-27 09:59:50","2014-11-27 09:59:50","","0","http://ioptima.co.il/wp-content/uploads/2014/11/GT-NovDec-14.CLASS.Robin_.pdf","0","attachment","application/pdf","0");
INSERT INTO `wp_posts` VALUES("431","2","2014-11-27 09:59:52","2014-11-27 09:59:52","","CRST Europe Nov Dec 14_CLASS_Venkatesh","","inherit","closed","open","","crst-europe-nov-dec-14_class_venkatesh","","","2014-11-27 09:59:52","2014-11-27 09:59:52","","0","http://ioptima.co.il/wp-content/uploads/2014/11/CRST-Europe-Nov-Dec-14_CLASS_Venkatesh.pdf","0","attachment","application/pdf","0");
INSERT INTO `wp_posts` VALUES("433","2","2014-11-30 09:08:57","2014-11-30 09:08:57","","IOPtima - Pattern Positioning Training","","inherit","closed","open","","ioptima-pattern-positioning-training","","","2014-11-30 09:08:57","2014-11-30 09:08:57","","0","http://ioptima.co.il/wp-content/uploads/2014/11/IOPtima-Pattern-Positioning-Training.zip","0","attachment","application/zip","0");
INSERT INTO `wp_posts` VALUES("435","2","2014-12-03 14:33:03","2014-12-03 14:33:03","","00061198-900000000-99206-page-001","","inherit","closed","open","","00061198-900000000-99206-page-001","","","2014-12-03 14:33:03","2014-12-03 14:33:03","","0","http://ioptima.co.il/wp-content/uploads/2014/12/00061198-900000000-99206-page-001.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("436","2","2014-12-03 14:34:06","2014-12-03 14:34:06","","Results of CO2 Laser-assisted Deep Sclerectomy_Greifner et al","","inherit","closed","open","","results-of-co2-laser-assisted-deep-sclerectomy_greifner-et-al","","","2014-12-03 14:34:06","2014-12-03 14:34:06","","0","http://ioptima.co.il/wp-content/uploads/2014/12/Results-of-CO2-Laser-assisted-Deep-Sclerectomy_Greifner-et-al.pdf","0","attachment","application/pdf","0");
INSERT INTO `wp_posts` VALUES("444","2","2015-01-14 11:45:52","2015-01-14 11:45:52","","Performing  accurate CO2 laser-assisted sclerectomy surgery - Ton, Assia, Geffen-page-001 (1)","","inherit","closed","open","","performing-accurate-co2-laser-assisted-sclerectomy-surgery-ton-assia-geffen-page-001-1","","","2015-01-14 11:45:52","2015-01-14 11:45:52","","0","http://ioptima.co.il/wp-content/uploads/2015/01/Performing-accurate-CO2-laser-assisted-sclerectomy-surgery-Ton-Assia-Geffen-page-001-1.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("445","2","2015-01-14 11:46:08","2015-01-14 11:46:08","","Performing  accurate CO2 laser-assisted sclerectomy surgery - Ton, Assia, Geffen","","inherit","closed","open","","performing-accurate-co2-laser-assisted-sclerectomy-surgery-ton-assia-geffen","","","2015-01-14 11:46:08","2015-01-14 11:46:08","","0","http://ioptima.co.il/wp-content/uploads/2015/01/Performing-accurate-CO2-laser-assisted-sclerectomy-surgery-Ton-Assia-Geffen.pdf","0","attachment","application/pdf","0");
INSERT INTO `wp_posts` VALUES("447","2","2015-01-14 12:45:35","2015-01-14 12:45:35","","Glaucoma surgery_ Taking the sub-conjunctival route _Tarek Shaarawy, Middle East African Journal of Ophthalmology (2)-page-003","","inherit","closed","open","","glaucoma-surgery_-taking-the-sub-conjunctival-route-_tarek-shaarawy-middle-east-african-journal-of-ophthalmology-2-page-003","","","2015-01-14 12:45:35","2015-01-14 12:45:35","","62","http://ioptima.co.il/wp-content/uploads/2014/03/Glaucoma-surgery_-Taking-the-sub-conjunctival-route-_Tarek-Shaarawy-Middle-East-African-Journal-of-Ophthalmology-2-page-003.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("454","2","2015-02-10 07:06:50","2015-02-10 07:06:50","","OSN 2.10.2015.CLASS.Greifner","","inherit","closed","open","","osn-2-10-2015-class-greifner","","","2015-02-10 07:06:50","2015-02-10 07:06:50","","0","http://ioptima.co.il/wp-content/uploads/2015/02/OSN-2.10.2015.CLASS.Greifner.pdf","0","attachment","application/pdf","0");
INSERT INTO `wp_posts` VALUES("455","2","2015-02-10 07:10:23","2015-02-10 07:10:23","","OSN 2.10.2015.CLASS.Greifner-page-001","","inherit","closed","open","","osn-2-10-2015-class-greifner-page-001","","","2015-02-10 07:10:23","2015-02-10 07:10:23","","0","http://ioptima.co.il/wp-content/uploads/2015/02/OSN-2.10.2015.CLASS.Greifner-page-001.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("461","2","2015-03-11 12:59:09","2015-03-11 12:59:09","","IOP-35-002 (07) IOPtima OT-135P2 (ASS-35-102) TP - part I - technical","","inherit","closed","open","","iop-35-002-07-ioptima-ot-135p2-ass-35-102-tp-part-i-technical-3","","","2015-03-11 12:59:09","2015-03-11 12:59:09","","0","http://ioptima.co.il/wp-content/uploads/2015/03/IOP-35-002-07-IOPtima-OT-135P2-ASS-35-102-TP-part-I-technical2.ppt","0","attachment","application/vnd.ms-powerpoint","0");
INSERT INTO `wp_posts` VALUES("463","2","2015-03-11 13:03:02","2015-03-11 13:03:02","","IOP-35-006 (01) IOPtima OT-135P2 (ASS-35-102) TP - part II - Daily Testing","","inherit","closed","open","","iop-35-006-01-ioptima-ot-135p2-ass-35-102-tp-part-ii-daily-testing","","","2015-03-11 13:03:02","2015-03-11 13:03:02","","0","http://ioptima.co.il/wp-content/uploads/2015/03/IOP-35-006-01-IOPtima-OT-135P2-ASS-35-102-TP-part-II-Daily-Testing.ppt","0","attachment","application/vnd.ms-powerpoint","0");
INSERT INTO `wp_posts` VALUES("464","2","2015-03-11 13:05:13","2015-03-11 13:05:13","","IOP-35-008(02) IOPtima OT-135P2 (ASS-35-102) TP - part III - The Procedure","","inherit","closed","open","","iop-35-00802-ioptima-ot-135p2-ass-35-102-tp-part-iii-the-procedure","","","2015-03-11 13:05:13","2015-03-11 13:05:13","","0","http://ioptima.co.il/wp-content/uploads/2015/03/IOP-35-00802-IOPtima-OT-135P2-ASS-35-102-TP-part-III-The-Procedure.ppt","0","attachment","application/vnd.ms-powerpoint","0");
INSERT INTO `wp_posts` VALUES("467","2","2015-03-29 12:16:21","2015-03-29 12:16:21","","OSN LA MarchApril CLASS Greifner","","inherit","closed","open","","osn-la-marchapril-class-greifner","","","2015-03-29 12:16:21","2015-03-29 12:16:21","","0","http://ioptima.co.il/wp-content/uploads/2015/03/OSN-LA-MarchApril-CLASS-Greifner.pdf","0","attachment","application/pdf","0");
INSERT INTO `wp_posts` VALUES("468","2","2015-03-29 12:16:45","2015-03-29 12:16:45","","OSN LA MarchApril CLASS Greifner-page-003","","inherit","closed","open","","osn-la-marchapril-class-greifner-page-003","","","2015-03-29 12:16:45","2015-03-29 12:16:45","","0","http://ioptima.co.il/wp-content/uploads/2015/03/OSN-LA-MarchApril-CLASS-Greifner-page-003.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("470","2","2015-04-19 06:25:42","2015-04-19 06:25:42","[vc_row][vc_column width=\"1/1\"][vc_column_text]<b>Please visit us at the upcoming events:</b>

&nbsp;

<b>WGC    <span style=\"color: #4883bf;\"><i>June 6-9, 2015</i></span></b>

6<sup>th</sup> World Glaucoma Congress

Hong Kong, China

<i>Booth # 13</i>

<a href=\"http://www.worldglaucoma.org/WGC/WGC2015/index.php?page=welcome\">http://www.worldglaucoma.org/WGC/WGC2015/index.php?page=welcome</a>

&nbsp;

<b>ESCRS    <span style=\"color: #4883bf;\"><i>September 5-8, 2015</i></span></b>

XXXIII Congress of the European Society of Cataract and Refractive Surgeons

Barcelona, Spain

<i>Booth # TBD</i>

<a href=\"http://escrs.org/Barcelona2015/\">http://escrs.org/Barcelona2015/</a>

&nbsp;

<b>Exhibited in past events:</b>

&nbsp;

<b>APAO    <span style=\"color: #4883bf;\"><i>April 1-4, 2015</i></span></b>

30<sup>th</sup> Asia-Pacific Academy of Ophthalmology Congress

held in conjunction with the 20<sup>th</sup> Congress of the Chinese Ophthalmological Society

Guangzhou, China

<i>Booth # 1F B-593</i>

<a href=\"http://2015.apaophth.org/\">http://2015.apaophth.org/</a>

&nbsp;

<b>MEDinISRAEL    <span style=\"color: #4883bf;\"><i>March 23-26, 2015</i></span></b>

3<sup>rd</sup> Medical Devices &amp; HIT International Conference

Tel Aviv, Israel

<i>Booth # 3A</i>

<a href=\"http://www.medinisrael2015.com/index.ehtml\">http://www.medinisrael2015.com/index.ehtml</a>

&nbsp;

<b>APGC-ISHOK    <span style=\"color: #4883bf;\"><i>September 26-28, 2014</i></span></b>

2<sup>nd</sup> Asia-Pacific Glaucoma Congress

held in conjunction with

The 10<sup>th</sup> International Symposium of Ophthalmology

Hong Kong, China

<i>Booth # G2</i>

<a href=\"http://www.apgc-isohk-2014.org\">http://www.apgc-isohk-2014.org</a>

&nbsp;

<b>ESCRS    <span style=\"color: #4883bf;\"><i>September 13-17, 2014</i></span></b>

XXXII Congress of the European Society of Cataract and Refractive Surgeons

London, United Kingdom

<i>Booth # K22</i>

<a href=\"http://www.escrs.org/London2014/default.asp\">http://www.escrs.org/London2014/default.asp</a>

&nbsp;

<b>EGS       <span style=\"color: #4883bf;\"> <i>June 7-11, 2014</i></span></b>

11<sup>th</sup> European Glaucoma Society Congress

Nice, France

<i>Booth # 28</i>

<a href=\"http://www.eugs.org/\">www.eugs.org</a>[/vc_column_text][/vc_column][/vc_row][vc_row][vc_column width=\"1/1\"][spacer height=\"50\" display_desktop=\"true\" display_tablet=\"true\" display_mobile=\"true\"][/vc_column][/vc_row]","Events","","inherit","closed","open","","133-autosave-v1","","","2015-04-19 06:25:42","2015-04-19 06:25:42","","133","http://ioptima.co.il/133-autosave-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES("475","2","2015-05-13 14:52:03","2015-05-13 14:52:03","","WGC","","inherit","closed","open","","wgc","","","2015-05-13 14:52:03","2015-05-13 14:52:03","","0","http://ioptima.co.il/wp-content/uploads/2015/05/WGC.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("476","2","2015-05-29 13:15:45","0000-00-00 00:00:00","","Auto Draft","","auto-draft","closed","open","","","","","2015-05-29 13:15:45","0000-00-00 00:00:00","","0","http://ioptima.co.il/?p=476","0","post","","0");
INSERT INTO `wp_posts` VALUES("477","1","2015-05-29 16:25:45","0000-00-00 00:00:00","","Auto Draft","","auto-draft","closed","open","","","","","2015-05-29 16:25:45","0000-00-00 00:00:00","","0","http://ioptima.co.il/?p=477","0","post","","0");
INSERT INTO `wp_posts` VALUES("478","3","2015-05-30 05:36:56","0000-00-00 00:00:00","","Auto Draft","","auto-draft","closed","open","","","","","2015-05-30 05:36:56","0000-00-00 00:00:00","","0","http://ioptima.co.il/?p=478","0","post","","0");


DROP TABLE IF EXISTS `wp_revslider_css`;

CREATE TABLE `wp_revslider_css` (
  `id` int(9) NOT NULL AUTO_INCREMENT,
  `handle` text COLLATE utf8_unicode_ci NOT NULL,
  `settings` text COLLATE utf8_unicode_ci,
  `hover` text COLLATE utf8_unicode_ci,
  `params` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `wp_revslider_css` VALUES("1",".tp-caption.big_yellow","","","{\"position\":\"absolute\",\"color\":\"#ffd658\",\"text-shadow\":\"none\",\"font-weight\":\"400\",\"font-size\":\"100px\",\"line-height\":\"36px\",\"font-family\":\"\\\"Open Sans\\\"\",\"padding\":\"0px 4px\",\"padding-top\":\"1px\",\"margin\":\"0px\",\"border-width\":\"0px\",\"border-style\":\"none\",\"background-color\":\"transparent\"}");
INSERT INTO `wp_revslider_css` VALUES("2",".tp-caption.big_bluee","","","{\"position\":\"absolute\",\"color\":\"blue\",\"text-shadow\":\"none\",\"font-weight\":\"400\",\"font-size\":\"78px\",\"line-height\":\"36px\",\"font-family\":\"\\\"Open Sans\\\"\",\"padding\":\"0px 4px\",\"padding-top\":\"1px\",\"margin\":\"0px\",\"border-width\":\"0px\",\"border-style\":\"none\",\"background-color\":\"transparent\"}");
INSERT INTO `wp_revslider_css` VALUES("3",".tp-caption.big_white","","","{\"position\":\"absolute\",\"color\":\"#fff\",\"text-shadow\":\"none\",\"font-weight\":\"700\",\"font-size\":\"36px\",\"line-height\":\"36px\",\"font-family\":\"Arial\",\"padding\":\"0px 4px\",\"padding-top\":\"1px\",\"margin\":\"0px\",\"border-width\":\"0px\",\"border-style\":\"none\",\"background-color\":\"#000\",\"letter-spacing\":\"-1.5px\"}");
INSERT INTO `wp_revslider_css` VALUES("4",".tp-caption.big_orange","","","{\"position\":\"absolute\",\"color\":\"#ff7302\",\"text-shadow\":\"none\",\"font-weight\":\"700\",\"font-size\":\"36px\",\"line-height\":\"36px\",\"font-family\":\"Arial\",\"padding\":\"0px 4px\",\"margin\":\"0px\",\"border-width\":\"0px\",\"border-style\":\"none\",\"background-color\":\"#fff\",\"letter-spacing\":\"-1.5px\"}");
INSERT INTO `wp_revslider_css` VALUES("5",".tp-caption.big_black","","","{\"position\":\"absolute\",\"color\":\"#000\",\"text-shadow\":\"none\",\"font-weight\":\"700\",\"font-size\":\"36px\",\"line-height\":\"36px\",\"font-family\":\"Arial\",\"padding\":\"0px 4px\",\"margin\":\"0px\",\"border-width\":\"0px\",\"border-style\":\"none\",\"background-color\":\"#fff\",\"letter-spacing\":\"-1.5px\"}");
INSERT INTO `wp_revslider_css` VALUES("6",".tp-caption.medium_grey","","","{\"position\":\"absolute\",\"color\":\"#fff\",\"text-shadow\":\"0px 2px 5px rgba(0, 0, 0, 0.5)\",\"font-weight\":\"700\",\"font-size\":\"20px\",\"line-height\":\"20px\",\"font-family\":\"Arial\",\"padding\":\"2px 4px\",\"margin\":\"0px\",\"border-width\":\"0px\",\"border-style\":\"none\",\"background-color\":\"#888\",\"white-space\":\"nowrap\"}");
INSERT INTO `wp_revslider_css` VALUES("7",".tp-caption.small_text","","","{\"position\":\"absolute\",\"color\":\"#fff\",\"text-shadow\":\"0px 2px 5px rgba(0, 0, 0, 0.5)\",\"font-weight\":\"700\",\"font-size\":\"14px\",\"line-height\":\"20px\",\"font-family\":\"Arial\",\"margin\":\"0px\",\"border-width\":\"0px\",\"border-style\":\"none\",\"white-space\":\"nowrap\"}");
INSERT INTO `wp_revslider_css` VALUES("8",".tp-caption.medium_text","","","{\"position\":\"absolute\",\"color\":\"#fff\",\"text-shadow\":\"0px 2px 5px rgba(0, 0, 0, 0.5)\",\"font-weight\":\"700\",\"font-size\":\"20px\",\"line-height\":\"20px\",\"font-family\":\"Arial\",\"margin\":\"0px\",\"border-width\":\"0px\",\"border-style\":\"none\",\"white-space\":\"nowrap\"}");
INSERT INTO `wp_revslider_css` VALUES("9",".tp-caption.large_text","","","{\"position\":\"absolute\",\"color\":\"#fff\",\"text-shadow\":\"0px 2px 5px rgba(0, 0, 0, 0.5)\",\"font-weight\":\"700\",\"font-size\":\"40px\",\"line-height\":\"40px\",\"font-family\":\"Arial\",\"margin\":\"0px\",\"border-width\":\"0px\",\"border-style\":\"none\",\"white-space\":\"nowrap\"}");
INSERT INTO `wp_revslider_css` VALUES("10",".tp-caption.very_large_text","","","{\"position\":\"absolute\",\"color\":\"white\",\"text-shadow\":\"none\",\"font-size\":\"38px\",\"line-height\":\"44px\",\"font-family\":\"Arial\",\"letter-spacing\":\"1px\",\"margin\":\"0px\",\"border-width\":\"0px\",\"border-style\":\"none\",\"white-space\":\"nowrap\",\"font-weight\":\"300\"}");
INSERT INTO `wp_revslider_css` VALUES("11",".tp-caption.very_big_white","","","{\"position\":\"absolute\",\"color\":\"#fff\",\"text-shadow\":\"none\",\"font-weight\":\"800\",\"font-size\":\"60px\",\"line-height\":\"60px\",\"font-family\":\"Arial\",\"margin\":\"0px\",\"border-width\":\"0px\",\"border-style\":\"none\",\"white-space\":\"nowrap\",\"padding\":\"0px 4px\",\"padding-top\":\"1px\",\"background-color\":\"#000\"}");
INSERT INTO `wp_revslider_css` VALUES("12",".tp-caption.very_big_black","","","{\"position\":\"absolute\",\"color\":\"#000\",\"text-shadow\":\"none\",\"font-weight\":\"700\",\"font-size\":\"60px\",\"line-height\":\"60px\",\"font-family\":\"Arial\",\"margin\":\"0px\",\"border-width\":\"0px\",\"border-style\":\"none\",\"white-space\":\"nowrap\",\"padding\":\"0px 4px\",\"padding-top\":\"1px\",\"background-color\":\"#fff\"}");
INSERT INTO `wp_revslider_css` VALUES("13",".tp-caption.modern_medium_fat","","","{\"position\":\"absolute\",\"color\":\"#000\",\"text-shadow\":\"none\",\"font-weight\":\"800\",\"font-size\":\"24px\",\"line-height\":\"20px\",\"font-family\":\"\\\"Open Sans\\\", sans-serif\",\"margin\":\"0px\",\"border-width\":\"0px\",\"border-style\":\"none\",\"white-space\":\"nowrap\"}");
INSERT INTO `wp_revslider_css` VALUES("14",".tp-caption.modern_medium_light","","","{\"position\":\"absolute\",\"color\":\"#000\",\"text-shadow\":\"none\",\"font-weight\":\"300\",\"font-size\":\"24px\",\"line-height\":\"20px\",\"font-family\":\"\\\"Open Sans\\\", sans-serif\",\"margin\":\"0px\",\"border-width\":\"0px\",\"border-style\":\"none\",\"white-space\":\"nowrap\"}");
INSERT INTO `wp_revslider_css` VALUES("15",".tp-caption.modern_big_bluebg","","","{\"position\":\"absolute\",\"color\":\"#fff\",\"text-shadow\":\"none\",\"font-weight\":\"800\",\"font-size\":\"30px\",\"line-height\":\"36px\",\"font-family\":\"\\\"Open Sans\\\", sans-serif\",\"padding\":\"3px 10px\",\"margin\":\"0px\",\"border-width\":\"0px\",\"border-style\":\"none\",\"background-color\":\"#4e5b6c\",\"letter-spacing\":\"0\"}");
INSERT INTO `wp_revslider_css` VALUES("16",".tp-caption.modern_big_redbg","","","{\"position\":\"absolute\",\"color\":\"#fff\",\"text-shadow\":\"none\",\"font-weight\":\"300\",\"font-size\":\"30px\",\"line-height\":\"36px\",\"font-family\":\"\\\"Open Sans\\\", sans-serif\",\"padding\":\"3px 10px\",\"padding-top\":\"1px\",\"margin\":\"0px\",\"border-width\":\"0px\",\"border-style\":\"none\",\"background-color\":\"#de543e\",\"letter-spacing\":\"0\"}");
INSERT INTO `wp_revslider_css` VALUES("17",".tp-caption.modern_small_text_dark","","","{\"position\":\"absolute\",\"color\":\"#555\",\"text-shadow\":\"none\",\"font-size\":\"14px\",\"line-height\":\"22px\",\"font-family\":\"Arial\",\"margin\":\"0px\",\"border-width\":\"0px\",\"border-style\":\"none\",\"white-space\":\"nowrap\"}");
INSERT INTO `wp_revslider_css` VALUES("18",".tp-caption.boxshadow","","","{\"-moz-box-shadow\":\"0px 0px 20px rgba(0, 0, 0, 0.5)\",\"-webkit-box-shadow\":\"0px 0px 20px rgba(0, 0, 0, 0.5)\",\"box-shadow\":\"0px 0px 20px rgba(0, 0, 0, 0.5)\"}");
INSERT INTO `wp_revslider_css` VALUES("19",".tp-caption.black","","","{\"color\":\"#000\",\"text-shadow\":\"none\"}");
INSERT INTO `wp_revslider_css` VALUES("20",".tp-caption.noshadow","","","{\"text-shadow\":\"none\"}");
INSERT INTO `wp_revslider_css` VALUES("21",".tp-caption.modern_medium_fat_white","{\"hover\":\"false\"}","\"\"","{\"color\":\"#ffffff\",\"text-shadow\":\"none\",\"font-weight\":\"500\",\"font-size\":\"32px\",\"line-height\":\"42px\",\"font-family\":\"\\\"Open Sans\\\", sans-serif\",\"margin\":\"0px\",\"white-space\":\"nowrap\",\"text-align\":\"justify !important\",\"background-color\":\"transparent\",\"text-decoration\":\"none\",\"border-width\":\"0px\",\"border-color\":\"rgb(255, 255, 255)\",\"border-style\":\"none\"}");


DROP TABLE IF EXISTS `wp_revslider_layer_animations`;

CREATE TABLE `wp_revslider_layer_animations` (
  `id` int(9) NOT NULL AUTO_INCREMENT,
  `handle` text COLLATE utf8_unicode_ci NOT NULL,
  `params` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



DROP TABLE IF EXISTS `wp_revslider_settings`;

CREATE TABLE `wp_revslider_settings` (
  `id` int(9) NOT NULL AUTO_INCREMENT,
  `general` text COLLATE utf8_unicode_ci NOT NULL,
  `params` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



DROP TABLE IF EXISTS `wp_revslider_sliders`;

CREATE TABLE `wp_revslider_sliders` (
  `id` int(9) NOT NULL AUTO_INCREMENT,
  `title` tinytext COLLATE utf8_unicode_ci NOT NULL,
  `alias` tinytext COLLATE utf8_unicode_ci,
  `params` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `wp_revslider_sliders` VALUES("1","Home","Home","{\"title\":\"Home\",\"alias\":\"Home\",\"shortcode\":\"[rev_slider Home]\",\"source_type\":\"gallery\",\"post_types\":\"post\",\"post_category\":\"\",\"post_sortby\":\"ID\",\"posts_sort_direction\":\"DESC\",\"max_slider_posts\":\"30\",\"excerpt_limit\":\"55\",\"slider_template_id\":\"\",\"posts_list\":\"\",\"slider_type\":\"fullwidth\",\"fullscreen_offset_container\":\"\",\"fullscreen_offset_size\":\"\",\"fullscreen_min_height\":\"\",\"full_screen_align_force\":\"off\",\"auto_height\":\"off\",\"force_full_width\":\"off\",\"min_height\":\"0\",\"width\":\"1920\",\"height\":\"576\",\"responsitive_w1\":\"940\",\"responsitive_sw1\":\"770\",\"responsitive_w2\":\"780\",\"responsitive_sw2\":\"500\",\"responsitive_w3\":\"510\",\"responsitive_sw3\":\"310\",\"responsitive_w4\":\"0\",\"responsitive_sw4\":\"0\",\"responsitive_w5\":\"0\",\"responsitive_sw5\":\"0\",\"responsitive_w6\":\"0\",\"responsitive_sw6\":\"0\",\"delay\":\"9000\",\"shuffle\":\"off\",\"lazy_load\":\"off\",\"use_wpml\":\"off\",\"enable_static_layers\":\"off\",\"next_slide_on_window_focus\":\"off\",\"simplify_ie8_ios4\":\"off\",\"stop_slider\":\"off\",\"stop_after_loops\":0,\"stop_at_slide\":2,\"show_timerbar\":\"hide\",\"loop_slide\":\"loop\",\"position\":\"center\",\"margin_top\":0,\"margin_bottom\":0,\"margin_left\":0,\"margin_right\":0,\"shadow_type\":\"0\",\"padding\":0,\"background_color\":\"#E9E9E9\",\"background_dotted_overlay\":\"none\",\"show_background_image\":\"false\",\"background_image\":\"\",\"bg_fit\":\"cover\",\"bg_repeat\":\"no-repeat\",\"bg_position\":\"center top\",\"stop_on_hover\":\"on\",\"keyboard_navigation\":\"off\",\"navigation_style\":\"round\",\"navigaion_type\":\"bullet\",\"navigation_arrows\":\"solo\",\"navigaion_always_on\":\"false\",\"hide_thumbs\":200,\"navigaion_align_hor\":\"center\",\"navigaion_align_vert\":\"bottom\",\"navigaion_offset_hor\":\"0\",\"navigaion_offset_vert\":20,\"leftarrow_align_hor\":\"left\",\"leftarrow_align_vert\":\"center\",\"leftarrow_offset_hor\":20,\"leftarrow_offset_vert\":0,\"rightarrow_align_hor\":\"right\",\"rightarrow_align_vert\":\"center\",\"rightarrow_offset_hor\":20,\"rightarrow_offset_vert\":0,\"thumb_width\":100,\"thumb_height\":50,\"thumb_amount\":5,\"use_spinner\":\"0\",\"spinner_color\":\"#FFFFFF\",\"use_parallax\":\"off\",\"disable_parallax_mobile\":\"off\",\"parallax_type\":\"mouse\",\"parallax_bg_freeze\":\"off\",\"parallax_level_1\":\"5\",\"parallax_level_2\":\"10\",\"parallax_level_3\":\"15\",\"parallax_level_4\":\"20\",\"parallax_level_5\":\"25\",\"parallax_level_6\":\"30\",\"parallax_level_7\":\"35\",\"parallax_level_8\":\"40\",\"parallax_level_9\":\"45\",\"parallax_level_10\":\"50\",\"touchenabled\":\"on\",\"swipe_velocity\":75,\"swipe_min_touches\":1,\"drag_block_vertical\":\"false\",\"disable_on_mobile\":\"off\",\"disable_kenburns_on_mobile\":\"off\",\"hide_slider_under\":0,\"hide_defined_layers_under\":0,\"hide_all_layers_under\":0,\"hide_arrows_on_mobile\":\"off\",\"hide_bullets_on_mobile\":\"off\",\"hide_thumbs_on_mobile\":\"off\",\"hide_thumbs_under_resolution\":0,\"hide_thumbs_delay_mobile\":1500,\"start_with_slide\":\"1\",\"first_transition_active\":\"true\",\"first_transition_type\":\"fade\",\"first_transition_duration\":300,\"first_transition_slot_amount\":7,\"reset_transitions\":\"\",\"reset_transition_duration\":0,\"0\":\"Execute settings on all slides\",\"jquery_noconflict\":\"on\",\"js_to_body\":\"false\",\"output_type\":\"none\",\"custom_css\":\"\",\"custom_javascript\":\"\",\"template\":\"false\"}");


DROP TABLE IF EXISTS `wp_revslider_slides`;

CREATE TABLE `wp_revslider_slides` (
  `id` int(9) NOT NULL AUTO_INCREMENT,
  `slider_id` int(9) NOT NULL,
  `slide_order` int(11) NOT NULL,
  `params` text COLLATE utf8_unicode_ci NOT NULL,
  `layers` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `wp_revslider_slides` VALUES("3","1","2","{\"background_type\":\"image\",\"image\":\"http:\\/\\/ioptima.co.il\\/wp-content\\/uploads\\/2014\\/04\\/ioptima.jpg\",\"image_id\":\"137\",\"title\":\"Eye\",\"state\":\"published\",\"slide_transition\":\"slidehorizontal\",\"0\":\"Choose Image\",\"slot_amount\":\"7\",\"transition_rotation\":\"0\",\"transition_duration\":\"300\",\"delay\":\"\",\"enable_link\":\"false\",\"link_type\":\"regular\",\"link\":\"\",\"link_open_in\":\"same\",\"slide_link\":\"nothing\",\"link_pos\":\"front\",\"slide_thumb\":\"\",\"fullwidth_centering\":\"true\",\"date_from\":\"\",\"date_to\":\"\",\"slide_bg_color\":\"#E7E7E7\",\"0\":\"Choose Image\"}","[{\"text\":\"A new <b>CLASS<\\/b> of Glaucoma Surgery<\\/br>\\n\\n<span style=\\\"position: absolute; font-size: 84%;\\\"><b><span style=\\\"font-size: 122%;\\\">C<\\/span><\\/b>O<sub>2<\\/sub> <b><span style=\\\"font-size: 122%;\\\">L<\\/span><\\/b>aser <b><span style=\\\"font-size: 122%;\\\">A<\\/span><\\/b><\\/font>ssisted <b><span style=\\\"font-size: 122%;\\\">S<\\/span><\\/b>clerectomy <b><span style=\\\"font-size: 122%;\\\">S<\\/span><\\/b>urgery<\\/span>\",\"type\":\"text\",\"left\":167,\"top\":88,\"animation\":\"fade\",\"easing\":\"easeOutExpo\",\"speed\":300,\"align_hor\":\"left\",\"align_vert\":\"top\",\"hiddenunder\":false,\"resizeme\":false,\"link\":\"\",\"link_open_in\":\"same\",\"link_slide\":\"nothing\",\"scrollunder_offset\":\"\",\"style\":\"very_large_text\",\"time\":800,\"endtime\":\"\",\"endspeed\":300,\"endanimation\":\"auto\",\"endeasing\":\"nothing\",\"corner_left\":\"nothing\",\"corner_right\":\"nothing\",\"serial\":\"0\",\"endTimeFinal\":8700,\"endSpeedFinal\":300,\"realEndTime\":9000,\"timeLast\":8200}]");
INSERT INTO `wp_revslider_slides` VALUES("4","1","3","{\"background_type\":\"image\",\"image\":\"http:\\/\\/ioptima.co.il\\/wp-content\\/uploads\\/2014\\/05\\/CLASS-benefits-1.jpg\",\"image_id\":\"170\",\"title\":\"Surgeon\",\"state\":\"published\",\"slide_transition\":\"slidehorizontal\",\"0\":\"Remove\",\"slot_amount\":7,\"transition_rotation\":0,\"transition_duration\":300,\"delay\":\"\",\"enable_link\":\"false\",\"link_type\":\"regular\",\"link\":\"\",\"link_open_in\":\"same\",\"slide_link\":\"nothing\",\"link_pos\":\"front\",\"slide_thumb\":\"\",\"fullwidth_centering\":\"true\",\"date_from\":\"\",\"date_to\":\"\",\"slide_bg_color\":\"#E7E7E7\",\"save_performance\":\"off\",\"class_attr\":\"\",\"id_attr\":\"\",\"attr_attr\":\"\",\"data_attr\":\"\",\"slide_bg_external\":\"\",\"bg_fit\":\"cover\",\"bg_fit_x\":\"100\",\"bg_fit_y\":\"100\",\"bg_repeat\":\"no-repeat\",\"bg_position\":\"center top\",\"bg_position_x\":\"0\",\"bg_position_y\":\"0\",\"bg_end_position_x\":\"0\",\"bg_end_position_y\":\"0\",\"bg_end_position\":\"center top\",\"kenburn_effect\":\"off\",\"kb_start_fit\":\"100\",\"kb_end_fit\":\"100\",\"kb_duration\":\"9000\",\"kb_easing\":\"Linear.easeNone\",\"0\":\"Remove\"}","[{\"style\":\"\",\"text\":\"Image 8\",\"type\":\"image\",\"image_url\":\"http:\\/\\/ioptima.co.il\\/wp-content\\/uploads\\/2014\\/05\\/Black-Background-big.png\",\"left\":126,\"top\":-14,\"animation\":\"fade\",\"easing\":\"easeOutExpo\",\"speed\":700,\"align_hor\":\"left\",\"align_vert\":\"top\",\"hiddenunder\":false,\"resizeme\":false,\"link\":\"\",\"link_open_in\":\"same\",\"link_slide\":\"nothing\",\"scrollunder_offset\":\"\",\"time\":1000,\"endtime\":8400,\"endspeed\":600,\"endanimation\":\"fadeout\",\"endeasing\":\"nothing\",\"corner_left\":\"nothing\",\"corner_right\":\"nothing\",\"serial\":\"0\",\"endTimeFinal\":8400,\"endSpeedFinal\":600,\"realEndTime\":9000,\"timeLast\":8400,\"loop_animation\":\"none\",\"loop_easing\":\"Power3.easeInOut\",\"loop_speed\":\"2\",\"loop_startdeg\":\"-20\",\"loop_enddeg\":\"20\",\"loop_xorigin\":\"50\",\"loop_yorigin\":\"50\",\"loop_xstart\":\"0\",\"loop_xend\":\"0\",\"loop_ystart\":\"0\",\"loop_yend\":\"0\",\"loop_zoomstart\":\"1\",\"loop_zoomend\":\"1\",\"loop_angle\":\"0\",\"loop_radius\":\"10\",\"split\":\"none\",\"endsplit\":\"none\",\"splitdelay\":\"10\",\"endsplitdelay\":\"10\",\"max_height\":\"auto\",\"max_width\":\"auto\",\"2d_rotation\":\"0\",\"2d_origin_x\":\"50\",\"2d_origin_y\":\"50\",\"parallax_level\":\"-\",\"whitespace\":\"nowrap\",\"static_start\":\"1\",\"static_end\":\"1\",\"width\":700,\"height\":746,\"endWithSlide\":true},{\"text\":\"<span style=\\\"font-size: 115%;\\\">CLASS<\\/span> transforms complex, invasive<\\/br> and risky glaucoma surgery into a safe,<\\/br> elegant, and precise procedure\",\"type\":\"text\",\"left\":170,\"top\":63,\"animation\":\"tp-fade\",\"easing\":\"easeOutExpo\",\"speed\":300,\"align_hor\":\"left\",\"align_vert\":\"top\",\"hiddenunder\":false,\"resizeme\":false,\"link\":\"\",\"link_open_in\":\"same\",\"link_slide\":\"nothing\",\"scrollunder_offset\":\"\",\"style\":\"modern_medium_fat_white\",\"time\":1300,\"endtime\":\"8700\",\"endspeed\":300,\"endanimation\":\"auto\",\"endeasing\":\"nothing\",\"corner_left\":\"nothing\",\"corner_right\":\"nothing\",\"serial\":\"1\",\"endTimeFinal\":8700,\"endSpeedFinal\":300,\"realEndTime\":9000,\"timeLast\":7700,\"loop_animation\":\"none\",\"loop_easing\":\"Power3.easeInOut\",\"loop_speed\":\"2\",\"loop_startdeg\":\"-20\",\"loop_enddeg\":\"20\",\"loop_xorigin\":\"50\",\"loop_yorigin\":\"50\",\"loop_xstart\":\"0\",\"loop_xend\":\"0\",\"loop_ystart\":\"0\",\"loop_yend\":\"0\",\"loop_zoomstart\":\"1\",\"loop_zoomend\":\"1\",\"loop_angle\":\"0\",\"loop_radius\":\"10\",\"split\":\"none\",\"endsplit\":\"none\",\"splitdelay\":\"10\",\"endsplitdelay\":\"10\",\"max_height\":\"auto\",\"max_width\":\"auto\",\"2d_rotation\":\"0\",\"2d_origin_x\":\"50\",\"2d_origin_y\":\"50\",\"parallax_level\":\"-\",\"whitespace\":\"nowrap\",\"static_start\":\"1\",\"static_end\":\"2\",\"width\":-1,\"height\":-1,\"endWithSlide\":true,\"alt\":\"\",\"scaleX\":\"\",\"scaleY\":\"\",\"scaleProportional\":false,\"attrID\":\"\",\"attrClasses\":\"\",\"attrTitle\":\"\",\"attrRel\":\"\",\"link_id\":\"\",\"link_class\":\"\",\"link_title\":\"\",\"link_rel\":\"\"},{\"style\":\"\",\"text\":\"Surgeon\",\"type\":\"image\",\"image_url\":\"http:\\/\\/ioptima.co.il\\/wp-content\\/uploads\\/2014\\/05\\/surgeon1.png\",\"left\":1034,\"top\":-21,\"animation\":\"fade\",\"easing\":\"easeOutExpo\",\"speed\":1000,\"align_hor\":\"left\",\"align_vert\":\"top\",\"hiddenunder\":false,\"resizeme\":false,\"link\":\"\",\"link_open_in\":\"same\",\"link_slide\":\"nothing\",\"scrollunder_offset\":\"\",\"time\":1000,\"endtime\":\"\",\"endspeed\":800,\"endanimation\":\"fadeout\",\"endeasing\":\"nothing\",\"corner_left\":\"nothing\",\"corner_right\":\"nothing\",\"serial\":\"2\",\"endTimeFinal\":8000,\"endSpeedFinal\":800,\"realEndTime\":9000,\"timeLast\":8000,\"loop_animation\":\"none\",\"loop_easing\":\"Power3.easeInOut\",\"loop_speed\":\"2\",\"loop_startdeg\":\"-20\",\"loop_enddeg\":\"20\",\"loop_xorigin\":\"50\",\"loop_yorigin\":\"50\",\"loop_xstart\":\"0\",\"loop_xend\":\"0\",\"loop_ystart\":\"0\",\"loop_yend\":\"0\",\"loop_zoomstart\":\"1\",\"loop_zoomend\":\"1\",\"loop_angle\":\"0\",\"loop_radius\":\"10\",\"split\":\"none\",\"endsplit\":\"none\",\"splitdelay\":\"10\",\"endsplitdelay\":\"10\",\"max_height\":\"auto\",\"max_width\":\"auto\",\"2d_rotation\":\"0\",\"2d_origin_x\":\"50\",\"2d_origin_y\":\"50\",\"parallax_level\":\"-\",\"whitespace\":\"nowrap\",\"static_start\":\"1\",\"static_end\":\"1\",\"width\":485,\"height\":600,\"endWithSlide\":true},{\"text\":\"<a class=\\\"btn btn-shortcode btn-large  btn-no-icon\\\" style=\\\"background: #1a80b6;\\\" href=\\\"\\/for-physicians\\/class-benefits\\/\\\"><span class=\\\"btn-text\\\" style=\\\"color:white;font-size: 18px;font-family: Raleway, sans-serif;\\\">Learn More<\\/span><\\/a>\",\"type\":\"text\",\"left\":167,\"top\":299,\"animation\":\"fade\",\"easing\":\"easeOutExpo\",\"speed\":300,\"align_hor\":\"left\",\"align_vert\":\"top\",\"hiddenunder\":false,\"resizeme\":false,\"link\":\"\",\"link_open_in\":\"same\",\"link_slide\":\"nothing\",\"scrollunder_offset\":\"\",\"style\":\"\",\"time\":1600,\"endtime\":\"\",\"endspeed\":300,\"endanimation\":\"auto\",\"endeasing\":\"nothing\",\"corner_left\":\"nothing\",\"corner_right\":\"nothing\",\"serial\":\"3\",\"endTimeFinal\":8700,\"endSpeedFinal\":300,\"realEndTime\":9000,\"timeLast\":7400,\"loop_animation\":\"none\",\"loop_easing\":\"Power3.easeInOut\",\"loop_speed\":\"2\",\"loop_startdeg\":\"-20\",\"loop_enddeg\":\"20\",\"loop_xorigin\":\"50\",\"loop_yorigin\":\"50\",\"loop_xstart\":\"0\",\"loop_xend\":\"0\",\"loop_ystart\":\"0\",\"loop_yend\":\"0\",\"loop_zoomstart\":\"1\",\"loop_zoomend\":\"1\",\"loop_angle\":\"0\",\"loop_radius\":\"10\",\"split\":\"none\",\"endsplit\":\"none\",\"splitdelay\":\"10\",\"endsplitdelay\":\"10\",\"max_height\":\"auto\",\"max_width\":\"auto\",\"2d_rotation\":\"0\",\"2d_origin_x\":\"50\",\"2d_origin_y\":\"50\",\"parallax_level\":\"-\",\"whitespace\":\"nowrap\",\"static_start\":\"1\",\"static_end\":\"1\",\"width\":-1,\"height\":-1,\"endWithSlide\":true}]");
INSERT INTO `wp_revslider_slides` VALUES("6","1","4","{\"background_type\":\"image\",\"image\":\"http:\\/\\/ioptima.co.il\\/wp-content\\/uploads\\/2014\\/05\\/IOPtimas-solution.jpg\",\"image_id\":\"168\",\"title\":\"Family\",\"state\":\"published\",\"slide_transition\":\"slidehorizontal\",\"0\":\"Choose Image\",\"slot_amount\":\"7\",\"transition_rotation\":\"0\",\"transition_duration\":\"300\",\"delay\":\"\",\"enable_link\":\"false\",\"link_type\":\"regular\",\"link\":\"\",\"link_open_in\":\"same\",\"slide_link\":\"nothing\",\"link_pos\":\"front\",\"slide_thumb\":\"\",\"fullwidth_centering\":\"true\",\"date_from\":\"\",\"date_to\":\"\",\"slide_bg_color\":\"#E7E7E7\",\"0\":\"Choose Image\"}","[{\"style\":\"\",\"text\":\"Image 3\",\"type\":\"image\",\"image_url\":\"http:\\/\\/ioptima.co.il\\/wp-content\\/uploads\\/2014\\/05\\/Blue-Background.png\",\"left\":67,\"top\":-8,\"animation\":\"fade\",\"easing\":\"easeOutExpo\",\"speed\":300,\"align_hor\":\"left\",\"align_vert\":\"top\",\"hiddenunder\":false,\"resizeme\":false,\"link\":\"\",\"link_open_in\":\"same\",\"link_slide\":\"nothing\",\"scrollunder_offset\":\"\",\"time\":1000,\"endtime\":\"\",\"endspeed\":300,\"endanimation\":\"auto\",\"endeasing\":\"nothing\",\"corner_left\":\"nothing\",\"corner_right\":\"nothing\",\"serial\":\"0\",\"endTimeFinal\":8700,\"endSpeedFinal\":300,\"realEndTime\":9000,\"timeLast\":8000},{\"text\":\"<span style=\\\"font-size: 115%;\\\">CLASS<\\/span> is a successful and safe<\\/br> surgical procedure for the treatment<\\/br> of Glaucoma with growing popularity <\\/br>within surgeons and patients alike\",\"type\":\"text\",\"left\":126,\"top\":60,\"animation\":\"fade\",\"easing\":\"easeOutExpo\",\"speed\":300,\"align_hor\":\"left\",\"align_vert\":\"top\",\"hiddenunder\":false,\"resizeme\":false,\"link\":\"\",\"link_open_in\":\"same\",\"link_slide\":\"nothing\",\"scrollunder_offset\":\"\",\"style\":\"modern_medium_fat_white\",\"time\":1300,\"endtime\":\"\",\"endspeed\":300,\"endanimation\":\"auto\",\"endeasing\":\"nothing\",\"corner_left\":\"nothing\",\"corner_right\":\"nothing\",\"serial\":\"1\",\"endTimeFinal\":8700,\"endSpeedFinal\":300,\"realEndTime\":9000,\"timeLast\":7700},{\"text\":\"<a class=\\\"btn btn-shortcode btn-large  btn-no-icon\\\" style=\\\"background: #5E5E5E;\\\" href=\\\"\\/for-petients\\/ioptimas-solution\\/\\\"><span class=\\\"btn-text\\\" style=\\\"color:white;font-size: 18px;font-family: Raleway, sans-serif;\\\">Learn More<\\/span><\\/a>\\n\\n\",\"type\":\"text\",\"left\":132,\"top\":365,\"animation\":\"fade\",\"easing\":\"easeOutExpo\",\"speed\":300,\"align_hor\":\"left\",\"align_vert\":\"top\",\"hiddenunder\":false,\"resizeme\":false,\"link\":\"\",\"link_open_in\":\"same\",\"link_slide\":\"nothing\",\"scrollunder_offset\":\"\",\"style\":\"ioptima_button\",\"time\":1600,\"endtime\":\"\",\"endspeed\":300,\"endanimation\":\"auto\",\"endeasing\":\"nothing\",\"corner_left\":\"nothing\",\"corner_right\":\"nothing\",\"serial\":\"2\",\"endTimeFinal\":8700,\"endSpeedFinal\":300,\"realEndTime\":9000,\"timeLast\":7400}]");


DROP TABLE IF EXISTS `wp_revslider_static_slides`;

CREATE TABLE `wp_revslider_static_slides` (
  `id` int(9) NOT NULL AUTO_INCREMENT,
  `slider_id` int(9) NOT NULL,
  `params` text COLLATE utf8_unicode_ci NOT NULL,
  `layers` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



DROP TABLE IF EXISTS `wp_term_relationships`;

CREATE TABLE `wp_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `wp_term_relationships` VALUES("20","2","0");
INSERT INTO `wp_term_relationships` VALUES("26","2","0");
INSERT INTO `wp_term_relationships` VALUES("27","2","0");
INSERT INTO `wp_term_relationships` VALUES("28","2","0");
INSERT INTO `wp_term_relationships` VALUES("30","2","0");
INSERT INTO `wp_term_relationships` VALUES("33","3","0");
INSERT INTO `wp_term_relationships` VALUES("48","2","0");
INSERT INTO `wp_term_relationships` VALUES("49","2","0");
INSERT INTO `wp_term_relationships` VALUES("50","2","0");
INSERT INTO `wp_term_relationships` VALUES("51","2","0");
INSERT INTO `wp_term_relationships` VALUES("52","2","0");
INSERT INTO `wp_term_relationships` VALUES("53","2","0");
INSERT INTO `wp_term_relationships` VALUES("54","2","0");
INSERT INTO `wp_term_relationships` VALUES("55","2","0");
INSERT INTO `wp_term_relationships` VALUES("57","2","0");
INSERT INTO `wp_term_relationships` VALUES("58","2","0");
INSERT INTO `wp_term_relationships` VALUES("59","2","0");
INSERT INTO `wp_term_relationships` VALUES("61","2","0");
INSERT INTO `wp_term_relationships` VALUES("64","2","0");
INSERT INTO `wp_term_relationships` VALUES("65","2","0");
INSERT INTO `wp_term_relationships` VALUES("66","2","0");
INSERT INTO `wp_term_relationships` VALUES("100","2","0");
INSERT INTO `wp_term_relationships` VALUES("132","2","0");
INSERT INTO `wp_term_relationships` VALUES("135","2","0");
INSERT INTO `wp_term_relationships` VALUES("140","2","0");
INSERT INTO `wp_term_relationships` VALUES("247","2","0");
INSERT INTO `wp_term_relationships` VALUES("368","2","0");
INSERT INTO `wp_term_relationships` VALUES("381","2","0");


DROP TABLE IF EXISTS `wp_term_taxonomy`;

CREATE TABLE `wp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8_unicode_ci NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `wp_term_taxonomy` VALUES("1","1","category","","0","0");
INSERT INTO `wp_term_taxonomy` VALUES("2","2","nav_menu","","0","27");
INSERT INTO `wp_term_taxonomy` VALUES("3","3","nav_menu","","0","1");


DROP TABLE IF EXISTS `wp_terms`;

CREATE TABLE `wp_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  KEY `slug` (`slug`(191)),
  KEY `name` (`name`(191))
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `wp_terms` VALUES("1","Uncategorized","uncategorized","0");
INSERT INTO `wp_terms` VALUES("2","Main","main","0");
INSERT INTO `wp_terms` VALUES("3","Inner Footer","inner-footer","0");


DROP TABLE IF EXISTS `wp_usermeta`;

CREATE TABLE `wp_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=65 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `wp_usermeta` VALUES("1","1","first_name","");
INSERT INTO `wp_usermeta` VALUES("2","1","last_name","");
INSERT INTO `wp_usermeta` VALUES("3","1","nickname","wpengine");
INSERT INTO `wp_usermeta` VALUES("4","1","description","This is the \"wpengine\" admin user that our staff uses to gain access to your admin area to provide support and troubleshooting. It can only be accessed by a button in our secure log that auto generates a password and dumps that password after the staff member has logged in. We have taken extreme measures to ensure that our own user is not going to be misused to harm any of our clients sites.");
INSERT INTO `wp_usermeta` VALUES("5","1","rich_editing","true");
INSERT INTO `wp_usermeta` VALUES("6","1","comment_shortcuts","false");
INSERT INTO `wp_usermeta` VALUES("7","1","admin_color","fresh");
INSERT INTO `wp_usermeta` VALUES("8","1","use_ssl","0");
INSERT INTO `wp_usermeta` VALUES("9","1","show_admin_bar_front","true");
INSERT INTO `wp_usermeta` VALUES("10","1","wp_capabilities","a:1:{s:13:\"administrator\";b:1;}");
INSERT INTO `wp_usermeta` VALUES("11","1","wp_user_level","10");
INSERT INTO `wp_usermeta` VALUES("12","1","dismissed_wp_pointers","wp330_toolbar,wp330_saving_widgets,wp340_choose_image_from_library,wp340_customize_current_theme_link,wp350_media,wp360_revisions,wp360_locks");
INSERT INTO `wp_usermeta` VALUES("13","1","show_welcome_panel","1");
INSERT INTO `wp_usermeta` VALUES("14","2","first_name","");
INSERT INTO `wp_usermeta` VALUES("15","2","last_name","");
INSERT INTO `wp_usermeta` VALUES("16","2","nickname","ioptima");
INSERT INTO `wp_usermeta` VALUES("17","2","description","");
INSERT INTO `wp_usermeta` VALUES("18","2","rich_editing","true");
INSERT INTO `wp_usermeta` VALUES("19","2","comment_shortcuts","false");
INSERT INTO `wp_usermeta` VALUES("20","2","admin_color","fresh");
INSERT INTO `wp_usermeta` VALUES("21","2","use_ssl","0");
INSERT INTO `wp_usermeta` VALUES("22","2","show_admin_bar_front","true");
INSERT INTO `wp_usermeta` VALUES("23","2","wp_capabilities","a:1:{s:13:\"administrator\";b:1;}");
INSERT INTO `wp_usermeta` VALUES("24","2","wp_user_level","10");
INSERT INTO `wp_usermeta` VALUES("25","2","wp_dashboard_quick_press_last_post_id","476");
INSERT INTO `wp_usermeta` VALUES("26","2","managenav-menuscolumnshidden","a:4:{i:0;s:11:\"link-target\";i:1;s:11:\"css-classes\";i:2;s:3:\"xfn\";i:3;s:11:\"description\";}");
INSERT INTO `wp_usermeta` VALUES("27","2","metaboxhidden_nav-menus","a:3:{i:0;s:8:\"add-post\";i:1;s:12:\"add-post_tag\";i:2;s:15:\"add-post_format\";}");
INSERT INTO `wp_usermeta` VALUES("28","2","dismissed_wp_pointers","wp330_toolbar,wp350_media,wp390_widgets,wp410_dfw");
INSERT INTO `wp_usermeta` VALUES("29","2","wp_user-settings","editor=tinymce&libraryContent=browse&imgsize=full&urlbutton=post&align=left&hidetb=1&wplink=1&mfold=o");
INSERT INTO `wp_usermeta` VALUES("30","2","wp_user-settings-time","1429423143");
INSERT INTO `wp_usermeta` VALUES("31","2","closedpostboxes_page","a:1:{i:0;s:11:\"commentsdiv\";}");
INSERT INTO `wp_usermeta` VALUES("32","2","metaboxhidden_page","a:4:{i:0;s:11:\"postexcerpt\";i:1;s:11:\"commentsdiv\";i:2;s:7:\"slugdiv\";i:3;s:9:\"authordiv\";}");
INSERT INTO `wp_usermeta` VALUES("33","2","nav_menu_recently_edited","2");
INSERT INTO `wp_usermeta` VALUES("34","2","tgmpa_dismissed_notice","1");
INSERT INTO `wp_usermeta` VALUES("35","2","meta-box-order_page","a:3:{s:4:\"side\";s:36:\"submitdiv,pageparentdiv,postimagediv\";s:6:\"normal\";s:196:\"wpb_visual_composer,wpseo_meta,postexcerpt,postcustom,commentstatusdiv,commentsdiv,slugdiv,authordiv,peach_options_metabox,page_background_metabox,page_header_background_metabox,breadcrumb_metabox\";s:8:\"advanced\";s:0:\"\";}");
INSERT INTO `wp_usermeta` VALUES("36","2","screen_layout_page","2");
INSERT INTO `wp_usermeta` VALUES("37","2","wpseo_title","");
INSERT INTO `wp_usermeta` VALUES("38","2","wpseo_metadesc","");
INSERT INTO `wp_usermeta` VALUES("39","2","wpseo_metakey","");
INSERT INTO `wp_usermeta` VALUES("40","2","_yoast_wpseo_profile_updated","1405516622");
INSERT INTO `wp_usermeta` VALUES("41","2","googleplus","");
INSERT INTO `wp_usermeta` VALUES("42","2","twitter","");
INSERT INTO `wp_usermeta` VALUES("43","2","facebook","");
INSERT INTO `wp_usermeta` VALUES("44","3","first_name","");
INSERT INTO `wp_usermeta` VALUES("45","3","last_name","");
INSERT INTO `wp_usermeta` VALUES("46","3","nickname","ioptima2");
INSERT INTO `wp_usermeta` VALUES("47","3","description","");
INSERT INTO `wp_usermeta` VALUES("48","3","rich_editing","true");
INSERT INTO `wp_usermeta` VALUES("49","3","comment_shortcuts","false");
INSERT INTO `wp_usermeta` VALUES("50","3","admin_color","fresh");
INSERT INTO `wp_usermeta` VALUES("51","3","use_ssl","0");
INSERT INTO `wp_usermeta` VALUES("52","3","show_admin_bar_front","true");
INSERT INTO `wp_usermeta` VALUES("53","3","wp_capabilities","a:1:{s:6:\"editor\";b:1;}");
INSERT INTO `wp_usermeta` VALUES("54","3","wp_user_level","7");
INSERT INTO `wp_usermeta` VALUES("55","3","dismissed_wp_pointers","wp350_media,wp360_revisions,wp360_locks,wp390_widgets");
INSERT INTO `wp_usermeta` VALUES("56","3","wp_dashboard_quick_press_last_post_id","478");
INSERT INTO `wp_usermeta` VALUES("57","3","wp_user-settings","editor=tinymce&libraryContent=browse");
INSERT INTO `wp_usermeta` VALUES("58","3","wp_user-settings-time","1402902634");
INSERT INTO `wp_usermeta` VALUES("59","1","wp_dashboard_quick_press_last_post_id","477");
INSERT INTO `wp_usermeta` VALUES("60","3","_yoast_wpseo_profile_updated","1405516622");
INSERT INTO `wp_usermeta` VALUES("61","1","_yoast_wpseo_profile_updated","1405516622");
INSERT INTO `wp_usermeta` VALUES("62","2","session_tokens","a:2:{s:64:\"299abe1646d275c39b96bea2ead22950466ea5576c5e505f4dc81e6cdda8b716\";a:4:{s:10:\"expiration\";i:1433233214;s:2:\"ip\";s:14:\"199.203.151.77\";s:2:\"ua\";s:109:\"Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/42.0.2311.152 Safari/537.36\";s:5:\"login\";i:1432023614;}s:64:\"eea4468a3027e052492faad395758e9fe5f2a62db2694bb9b715737ed7cb63c8\";a:4:{s:10:\"expiration\";i:1434211585;s:2:\"ip\";s:13:\"87.68.145.182\";s:2:\"ua\";s:108:\"Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/43.0.2357.81 Safari/537.36\";s:5:\"login\";i:1433001985;}}");
INSERT INTO `wp_usermeta` VALUES("63","1","session_tokens","a:7:{s:64:\"3a48ae5f235a54eeaff553f5bc437de344a613f1b7b310f6de211eba4a62340a\";a:4:{s:10:\"expiration\";i:1433089542;s:2:\"ip\";s:13:\"66.162.212.19\";s:2:\"ua\";s:120:\"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/43.0.2357.81 Safari/537.36\";s:5:\"login\";i:1432916742;}s:64:\"fedca881a0c0d427c6fdacb4a131f4b50d086c99090936b39c6343e278c3a344\";a:4:{s:10:\"expiration\";i:1433089542;s:2:\"ip\";s:13:\"66.162.212.19\";s:2:\"ua\";s:120:\"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/43.0.2357.81 Safari/537.36\";s:5:\"login\";i:1432916742;}s:64:\"8c5c88481b151431adb8cdadc9e74298ff186cd0d97eb94fd6006b204c5bee30\";a:4:{s:10:\"expiration\";i:1433093523;s:2:\"ip\";s:13:\"198.58.111.80\";s:2:\"ua\";s:82:\"Mozilla/5.0 (Macintosh; Intel Mac OS X 10.10; rv:38.0) Gecko/20100101 Firefox/38.0\";s:5:\"login\";i:1432920723;}s:64:\"aaaaedb346a339f7afce47d67f0c188250cb0658e9648110c2a0f59b38d82652\";a:4:{s:10:\"expiration\";i:1433223421;s:2:\"ip\";s:13:\"66.162.212.19\";s:2:\"ua\";s:120:\"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/43.0.2357.81 Safari/537.36\";s:5:\"login\";i:1433050621;}s:64:\"4aeabd0b71380bf17a67fccd3c0c87056e756548d012675058ee93a4e348c676\";a:4:{s:10:\"expiration\";i:1433223422;s:2:\"ip\";s:13:\"66.162.212.19\";s:2:\"ua\";s:120:\"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/43.0.2357.81 Safari/537.36\";s:5:\"login\";i:1433050622;}s:64:\"b512e36683b2ff3e0554eddd5e9ffed00d7b8d5f3b8b09493aa0e973f5ac915b\";a:4:{s:10:\"expiration\";i:1433256236;s:2:\"ip\";s:13:\"66.162.212.19\";s:2:\"ua\";s:82:\"Mozilla/5.0 (Macintosh; Intel Mac OS X 10.10; rv:38.0) Gecko/20100101 Firefox/38.0\";s:5:\"login\";i:1433083436;}s:64:\"d516f39583a1a724d7921de67feed0cb3e23a76901a662512dc209535ee6411f\";a:4:{s:10:\"expiration\";i:1433256237;s:2:\"ip\";s:13:\"66.162.212.19\";s:2:\"ua\";s:82:\"Mozilla/5.0 (Macintosh; Intel Mac OS X 10.10; rv:38.0) Gecko/20100101 Firefox/38.0\";s:5:\"login\";i:1433083437;}}");


DROP TABLE IF EXISTS `wp_users`;

CREATE TABLE `wp_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `user_pass` varchar(64) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `wp_users` VALUES("1","wpengine","$P$BdqRF1gSaWNrNpC.YAMq8Ltq7.2xOM.","wpengine","bitbucket@wpengine.com","http://wpengine.com","2014-01-23 21:54:49","","0","wpengine");
INSERT INTO `wp_users` VALUES("2","ioptima","$P$BX2MiI8BWDLl/stV9yu7jybO1LaKGm/","ioptima","info@ioptima.co.il","http://ioptima.wpengine.com","2014-02-23 09:15:43","","0","ioptima");
INSERT INTO `wp_users` VALUES("3","ioptima2","$P$BLH7s/50ahvU2bntuv/Ke2MqQxH/8L1","ioptima2","peled99@gmail.com","","2014-05-23 06:30:00","","0","ioptima2");




